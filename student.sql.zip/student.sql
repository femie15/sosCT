-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2021 at 06:29 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oes_corrected`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stdid` bigint(20) NOT NULL,
  `stdname` varchar(40) DEFAULT NULL,
  `stdpassword` varchar(40) DEFAULT NULL,
  `emailid` varchar(40) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(1, '731', 'úÏ…W§', '731@oyoedu.ng', '8033550081', 'IGBOORA HIGH SCHOOL', 'OYO', '731'),
(2, '732', 'úÏ…W§', '732@oyoedu.ng', '8146891463', 'KASTAD SCONDARY SCHOOL,  IGBOORA', 'OYO', '732'),
(3, '733', 'úÏ…W§', '733@oyoedu.ng', '7059450513', 'GOLDEN LIGHT COLLEGE TAPA', 'OYO', '733'),
(4, '734', 'úÏ…W§', '734@oyoedu.ng', '8060225724', 'PINNACLE ROYAL COLLEGE ABEOKUTA', 'OGUN', '734'),
(5, '735', 'úÏ…W§', '735@oyoedu.ng', '8032307517', 'ANTI KEMI MODEL COLLEGE', 'OGUN', '735'),
(6, '736', 'úÏ…W§', '736@oyoedu.ng', '8088200078', 'HIS GRACE HIGH SCHL, IDERE', 'OYO', '736'),
(7, '737', 'úÏ…W§', '737@oyoedu.ng', '8061630688', 'AL-HIKMA SEC. SCHL, IDERE', 'OYO', '737'),
(8, '738', 'úÏ…W§', '738@oyoedu.ng', '8144011771', 'HIS GRACE HIGH SCHL, IDERE', 'OYO', '738'),
(9, '739', 'úÏ…W§', '739@oyoedu.ng', '7032697959', 'AL-HIKMA SEC. SCHL, IDERE', 'OYO', '739'),
(10, '7310', 'úÏ…W§', '7310@oyoedu.ng', '8157928253', 'ANGEL\'S HEIGHT COL. AYETE', 'OYO', '7310'),
(11, '7311', 'úÏ…W§', '7311@oyoedu.ng', '8028114055', 'BAPT. MODEL HIGH SCH. ERUWA', 'OYO', '7311'),
(12, '7312', 'úÏ…W§', '7312@oyoedu.ng', '8050909713', 'IGBOORA HIGH SCHOOL', 'OYO', '7312'),
(13, '7313', 'úÏ…W§', '7313@oyoedu.ng', '8050909713', 'IGBOORA HIGH SCHOOL', 'OYO', '7313'),
(14, '7314', 'úÏ…W§', '7314@oyoedu.ng', '8163611705', 'CTY ACADEMY SAGAMU ', 'OYO', '7314'),
(15, '7315', 'úÏ…W§', '7315@oyoedu.ng', '8166100583', 'GOODNEWS COLLEGE, AYETE', 'OYO', '7315'),
(16, '7316', 'úÏ…W§', '7316@oyoedu.ng', '8160057547', 'HIS GRACE HIGH SCHL, IDERE', 'OYO', '7316'),
(17, '7317', 'úÏ…W§', '7317@oyoedu.ng', '8108639268', 'HIS GRACE HIGH SCHL, IDERE', 'OYO', '7317'),
(18, '7318', 'úÏ…W§', '7318@oyoedu.ng', '7062702412', 'OBASEEKU GRAM. SCHL ERUWA', 'OYO', '7318'),
(19, '7319', 'úÏ…W§', '7319@oyoedu.ng', '7054731528', 'OBASEEKU GRAM. SCHL ERUWA', 'OYO', '7319'),
(20, '7320', 'úÏ…W§', '7320@oyoedu.ng', '8054728107', 'IFELODUN COMP H/S ERUWA', 'OYO', '7320'),
(21, '7321', 'úÏ…W§', '7321@oyoedu.ng', '8085160912', 'FLOURISHLAND COLLEGE AYETE', 'OYO', '7321'),
(22, '7322', 'úÏ…W§', '7322@oyoedu.ng', '8036634584', 'AYELOGUN GRM SCL IDERE', 'OYO', '7322'),
(23, '7323', 'úÏ…W§', '7323@oyoedu.ng', '8073393817', 'ABLE ROYAL COL. TAPA', 'OYO', '7323'),
(24, '7324', 'úÏ…W§', '7324@oyoedu.ng', '8130447248', 'ABLE ROYAL COL. TAPA', 'OYO', '7324'),
(25, '7325', 'úÏ…W§', '7325@oyoedu.ng', '7036966962', 'MUSLM ACADEMY AYETE', 'OYO', '7325'),
(26, '7326', 'úÏ…W§', '7326@oyoedu.ng', '8107728114', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7326'),
(27, '7327', 'úÏ…W§', '7327@oyoedu.ng', '7032449709', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7327'),
(28, '7328', 'úÏ…W§', '7328@oyoedu.ng', '9084492884', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7328'),
(29, '7329', 'úÏ…W§', '7329@oyoedu.ng', '8156481255', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '7329'),
(30, '7330', 'úÏ…W§', '7330@oyoedu.ng', '7055498183', 'AYELOGUN GRAM SCH. IDERE', 'OYO', '7330'),
(31, '7331', 'úÏ…W§', '7331@oyoedu.ng', '8165451998', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7331'),
(32, '7332', 'úÏ…W§', '7332@oyoedu.ng', '8051221395', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7332'),
(33, '7333', 'úÏ…W§', '7333@oyoedu.ng', '7054808132', 'MAKU GRAM SCH. TAPA', 'OYO', '7333'),
(34, '7334', 'úÏ…W§', '7334@oyoedu.ng', '8136457119', 'MAKU GRAM SCH. TAPA', 'OYO', '7334'),
(35, '7335', 'úÏ…W§', '7335@oyoedu.ng', '8059400833', 'IGBOORA HIGH SCH. IGBOORA', 'OGUN', '7335'),
(36, '7336', 'úÏ…W§', '7336@oyoedu.ng', '7057516148', 'AL-HIKMA MODEL COLL, IDERE', 'OYO', '7336'),
(37, '7337', 'úÏ…W§', '7337@oyoedu.ng', '8104783856', 'AL-HIKMA MODEL COLL, IDERE', 'OYO', '7337'),
(38, '7338', 'úÏ…W§', '7338@oyoedu.ng', '8143017393', 'MTHODIST GRAM SCH. IGBOORA', 'OYO', '7338'),
(39, '7339', 'úÏ…W§', '7339@oyoedu.ng', '8143807269', 'MUSLM ACADEMY AYETE', 'OYO', '7339'),
(40, '7340', 'úÏ…W§', '7340@oyoedu.ng', '7081199931', 'MUSLM ACADEMY AYETE', 'OYO', '7340'),
(41, '7341', 'úÏ…W§', '7341@oyoedu.ng', '7057069884', 'AMZING GRACE MODEL COLL. IDERE', 'OYO', '7341'),
(42, '7342', 'úÏ…W§', '7342@oyoedu.ng', '7048477667', 'IEREKODO HIGH SCHL IGBOORA', 'OYO', '7342'),
(43, '7343', 'úÏ…W§', '7343@oyoedu.ng', '7039297856', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7343'),
(44, '7344', 'úÏ…W§', '7344@oyoedu.ng', '8030941678', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '7344'),
(45, '7345', 'úÏ…W§', '7345@oyoedu.ng', '8167181934', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '7345'),
(46, '7346', 'úÏ…W§', '7346@oyoedu.ng', '8071194870', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '7346'),
(47, '7347', 'úÏ…W§', '7347@oyoedu.ng', '8142100629', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '7347'),
(48, '7348', 'úÏ…W§', '7348@oyoedu.ng', '7067482352', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '7348'),
(49, '7349', 'úÏ…W§', '7349@oyoedu.ng', '8168695842', 'KING SEED ACADEMY', 'OYO', '7349'),
(50, '7350', 'úÏ…W§', '7350@oyoedu.ng', '', 'METHODIST GRAM SCH', 'OYO', '7350'),
(51, '7351', 'úÏ…W§', '7351@oyoedu.ng', '', 'METHODIST GRAM SCH', 'OYO', '7351'),
(52, '7352', 'úÏ…W§', '7352@oyoedu.ng', '', 'METHODIST GRAM SCH', 'OYO', '7352'),
(53, '7353', 'úÏ…W§', '7353@oyoedu.ng', '8103376239', 'ADEGOKE COLLEGE, IGBOORA', 'OYO', '7353'),
(54, '7354', 'úÏ…W§', '7354@oyoedu.ng', '8059370266', 'ADEGOKE COLLEGE, IGBOORA', 'OYO', '7354'),
(55, '7355', 'úÏ…W§', '7355@oyoedu.ng', '8162404243', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7355'),
(56, '7356', 'úÏ…W§', '7356@oyoedu.ng', '8149491905', 'FLOUHRISHLAND COLL. AYETE', 'OYO', '7356'),
(57, '7357', 'úÏ…W§', '7357@oyoedu.ng', '8061183662', 'AL-HIKMA MODEL COLL, IDERE', 'OYO', '7357'),
(58, '7358', 'úÏ…W§', '7358@oyoedu.ng', '8024150630', 'GLORIOUS MODEL COLLEGE ABK.', 'OGUN', '7358'),
(59, '7359', 'úÏ…W§', '7359@oyoedu.ng', '7019442297', 'ROYAL DIADEM COLL IGANGAN', 'OYO', '7359'),
(60, '7360', 'úÏ…W§', '7360@oyoedu.ng', '9056233947', 'PROVINCE COLLEGE ITELE OGUN', 'OYO', '7360'),
(61, '7361', 'úÏ…W§', '7361@oyoedu.ng', '9054988038', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7361'),
(62, '7362', 'úÏ…W§', '7362@oyoedu.ng', '9054988038', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7362'),
(63, '7363', 'úÏ…W§', '7363@oyoedu.ng', '7050790391', 'DIVINE BAP. MODEL COLL. IGANGAN', 'OYO', '7363'),
(64, '7364', 'úÏ…W§', '7364@oyoedu.ng', '9034798143', 'NAWARUDEEN GRAM. SCH. IGBOORA', 'OYO', '7364'),
(65, '7365', 'úÏ…W§', '7365@oyoedu.ng', '9034438284', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7365'),
(66, '7366', 'úÏ…W§', '7366@oyoedu.ng', '7032146869', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7366'),
(67, '7367', 'úÏ…W§', '7367@oyoedu.ng', '7083217071', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7367'),
(68, '7368', 'úÏ…W§', '7368@oyoedu.ng', '8146352944', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7368'),
(69, '7369', 'úÏ…W§', '7369@oyoedu.ng', '8071325458', 'NOBEL HIGH SCHOOL, OMI, IBADAN', 'OYO', '7369'),
(70, '7370', 'úÏ…W§', '7370@oyoedu.ng', '8037486783', 'ADEGOKE COLLEGE, IGBOORA', 'OYO', '7370'),
(71, '7371', 'úÏ…W§', '7371@oyoedu.ng', '9013406664', 'ANGEL HIGH COLLEGE, AYETE', 'OYO', '7371'),
(72, '7372', 'úÏ…W§', '7372@oyoedu.ng', '8167584843', 'MAKU GRAM SCH. TAPA', 'OYO', '7372'),
(73, '7373', 'úÏ…W§', '7373@oyoedu.ng', '8146173032', 'MAKU GRAM SCH. TAPA', 'OYO', '7373'),
(74, '7374', 'úÏ…W§', '7374@oyoedu.ng', '8058453518', 'JUBILANT COLLEGE, TAPA', 'OYO', '7374'),
(75, '7375', 'úÏ…W§', '7375@oyoedu.ng', '8165207095', 'OGBOJA GRAM SCH, IGBOORA', 'OYO', '7375'),
(76, '7376', 'úÏ…W§', '7376@oyoedu.ng', '8142254221', 'OGBOJA GRAM SCH, IGBOORA', 'OYO', '7376'),
(77, '7377', 'úÏ…W§', '7377@oyoedu.ng', '7067547291', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7377'),
(78, '7378', 'úÏ…W§', '7378@oyoedu.ng', '9132821874', 'OGBOJA GRAM SCH, IGBOORA', 'OYO', '7378'),
(79, '7379', 'úÏ…W§', '7379@oyoedu.ng', '9063662725', 'OBASEEKU HIGH SCHOOL, ERUWA', 'OYO', '7379'),
(80, '7380', 'úÏ…W§', '7380@oyoedu.ng', '9039548441', 'ROYAL STAR, IGBOORA', 'OYO', '7380'),
(81, '7381', 'úÏ…W§', '7381@oyoedu.ng', '9064038336', 'OLUYOLE HIGH SCHL, IBADAN', 'OYO', '7381'),
(82, '7382', 'úÏ…W§', '7382@oyoedu.ng', '7033511418', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7382'),
(83, '7383', 'úÏ…W§', '7383@oyoedu.ng', '8162404243', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7383'),
(84, '7384', 'úÏ…W§', '7384@oyoedu.ng', '7065468005', 'JOINT HEIRS SEC SCHL, IBADAN', 'OYO', '7384'),
(85, '7385', 'úÏ…W§', '7385@oyoedu.ng', '8042474502', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7385'),
(86, '7386', 'úÏ…W§', '7386@oyoedu.ng', '9030708668', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7386'),
(87, '7387', 'úÏ…W§', '7387@oyoedu.ng', '7025170619', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7387'),
(88, '7388', 'úÏ…W§', '7388@oyoedu.ng', '7040440986', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7388'),
(89, '7389', 'úÏ…W§', '7389@oyoedu.ng', '8105767747', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7389'),
(90, '7390', 'úÏ…W§', '7390@oyoedu.ng', '8105767747', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7390'),
(91, '7391', 'úÏ…W§', '7391@oyoedu.ng', '9015188184', 'GLORIOUS COLLEGE, IDERE', 'OYO', '7391'),
(92, '7392', 'úÏ…W§', '7392@oyoedu.ng', '7058794805', 'ROYAL STAR, IGBOORA', 'OYO', '7392'),
(93, '7393', 'úÏ…W§', '7393@oyoedu.ng', '7065318172', 'AYELOGUN GRAM SCH. IDERE', 'OYO', '7393'),
(94, '7394', 'úÏ…W§', '7394@oyoedu.ng', '9131574281', 'AL-HIKMA MODEL COLL, IDERE', 'OYO', '7394'),
(95, '7395', 'úÏ…W§', '7395@oyoedu.ng', '8079898399', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '7395'),
(96, '7396', 'úÏ…W§', '7396@oyoedu.ng', '7062754638', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7396'),
(97, '7397', 'úÏ…W§', '7397@oyoedu.ng', '7057044680', 'AMAZING GRACE MODEL COLL. IDERE', 'OYO', '7397'),
(98, '7398', 'úÏ…W§', '7398@oyoedu.ng', '8141506439', 'GOLDEN LIGHT COLLEGE', 'OYO', '7398'),
(99, '7399', 'úÏ…W§', '7399@oyoedu.ng', '7056915147', 'SUCCESS MUSLIM COLLEGE IGANGAN', 'OYO', '7399'),
(100, '73100', 'úÏ…W§', '73100@oyoedu.ng', '8025637866', 'DIVINE BAP. MODEL COLL. IGANGAN', 'OYO', '73100'),
(101, '73101', 'úÏ…W§', '73101@oyoedu.ng', '8025637866', 'DIVINE BAP. MODEL COLL. IGANGAN', 'OYO', '73101'),
(102, '73102', 'úÏ…W§', '73102@oyoedu.ng', '8025637866', 'DIVINE BAP. MODEL COLL. IGANGAN', 'OYO', '73102'),
(103, '73103', 'úÏ…W§', '73103@oyoedu.ng', '7059877568', 'ROYAL DIADEM COLL IGANGAN', 'OYO', '73103'),
(104, '73104', 'úÏ…W§', '73104@oyoedu.ng', '8058453518', 'JUBILANT COLLEGE, TAPA', 'OYO', '73104'),
(105, '73105', 'úÏ…W§', '73105@oyoedu.ng', '8136663687', 'OKEDERE HIGH SCHOOL IDERE', 'OYO', '73105'),
(106, '73106', 'úÏ…W§', '73106@oyoedu.ng', '8138141548', 'OKEDERE HIGH SCHOOL IDERE', 'OYO', '73106'),
(107, '73107', 'úÏ…W§', '73107@oyoedu.ng', '8112019536', 'OKEDERE HIGH SCHOOL IDERE', 'OYO', '73107'),
(108, '73108', 'úÏ…W§', '73108@oyoedu.ng', '9064631911', 'OKEDERE HIGH SCHOOL IDERE', 'OYO', '73108'),
(109, '73109', 'úÏ…W§', '73109@oyoedu.ng', '7082562767', 'ANGEL HIGH COLLEGE, AYETE', 'OYO', '73109'),
(110, '73110', 'úÏ…W§', '73110@oyoedu.ng', '7045375963', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '73110'),
(111, '73111', 'úÏ…W§', '73111@oyoedu.ng', '7058842384', 'NAWARUDEEN GRAM. SCH. IGBOORA', 'OYO', '73111'),
(112, '73112', 'úÏ…W§', '73112@oyoedu.ng', '7662895054', 'ANGEL HIGH COLLEGE, AYETE', 'OYO', '73112'),
(113, '73113', 'úÏ…W§', '73113@oyoedu.ng', '7040766800', 'METHODIST GRAM SCH IGBOORA', 'OYO', '73113'),
(114, '73114', 'úÏ…W§', '73114@oyoedu.ng', '8051251315', 'IGBOORA HIGH SCH. IGBOORA', 'OYO', '73114'),
(115, '11115', 'úÏ…W§', '11115@oyoedu.ng', '8100959229', 'ALUBARIKA COLLEGE IB', 'OYO', '11115'),
(116, '11116', 'úÏ…W§', '11116@oyoedu.ng', '8063031019', 'DE-PIONEER COLLEGE', 'OSUN', '11116'),
(117, '11117', 'úÏ…W§', '11117@oyoedu.ng', '8075236602', 'AL-MUNIR MODEL', 'OYO', '11117'),
(118, '11118', 'úÏ…W§', '11118@oyoedu.ng', '8061514371', 'BRIGHT COLLEGE', 'CROSS RIVER', '11118'),
(119, '11119', 'úÏ…W§', '11119@oyoedu.ng', '8066604667', 'ST.THERESA SCHOOL', 'OGUN', '11119'),
(120, '11120', 'úÏ…W§', '11120@oyoedu.ng', '8028260874', 'CTY SCHOOL', 'OYO', '11120'),
(121, '11121', 'úÏ…W§', '11121@oyoedu.ng', '8077617432', 'ST.ANNES SCHOOL', 'OYO', '11121'),
(122, '11122', 'úÏ…W§', '11122@oyoedu.ng', '8077617432', 'ST.ANNES SCHOOL', 'OYO', '11122'),
(123, '11123', 'úÏ…W§', '11123@oyoedu.ng', '8059094379', 'SHINNING PRI COLLEGE', 'OYO', '11123'),
(124, '11124', 'úÏ…W§', '11124@oyoedu.ng', '8072588854', 'IBADAN GRAMMAR SCH', 'OYO', '11124'),
(125, '11125', 'úÏ…W§', '11125@oyoedu.ng', '8077187449', 'ADESOLA SCHOOL.OMI', 'OYO', '11125'),
(126, '11126', 'úÏ…W§', '11126@oyoedu.ng', '8037513174', 'MUSLIM GRAMMER SCHOOL', 'OYO', '11126'),
(127, '11127', 'úÏ…W§', '11127@oyoedu.ng', '7065257644', 'DE-FIRDAUS COLLEGE', 'OGUN', '11127'),
(128, '11128', 'úÏ…W§', '11128@oyoedu.ng', '8143068474', 'RIGHT VISION GLOBAL ACADEMY', 'OYO', '11128'),
(129, '11129', 'úÏ…W§', '11129@oyoedu.ng', '8070464420', 'BEULAH MODEL COLLEGE', 'OYO', '11129'),
(130, '11130', 'úÏ…W§', '11130@oyoedu.ng', '9064626161', 'FEDERAL GOVERNMENT GIRL IPETUMODU', 'OYO', '11130'),
(131, '11131', 'úÏ…W§', '11131@oyoedu.ng', '8169446152', 'HERITAGE FOUNDATION SCHOOL', 'OYO', '11131'),
(132, '11132', 'úÏ…W§', '11132@oyoedu.ng', '8054461747', 'MOSLEM GRAMMAR SCHOOL', 'KWARA', '11132'),
(133, '11133', 'úÏ…W§', '11133@oyoedu.ng', '8073460036', 'GRACE FIELD INT\'L ', 'OYO', '11133'),
(134, '11134', 'úÏ…W§', '11134@oyoedu.ng', '7060477202', 'ADIB PRIVATE SCH', 'OYO', '11134'),
(135, '11135', 'úÏ…W§', '11135@oyoedu.ng', '8054114317', 'ASSALAM MODEL', 'OYO', '11135'),
(136, '11136', 'úÏ…W§', '11136@oyoedu.ng', '8062117373', 'LANFAMS SCH', 'OYO', '11136'),
(137, '11137', 'úÏ…W§', '11137@oyoedu.ng', '8038244081', 'FOWEB COLLEGE', 'OYO', '11137'),
(138, '11138', 'úÏ…W§', '11138@oyoedu.ng', '9019232844', 'THE LORDS FIELD HIGH SCH', 'OYO', '11138'),
(139, '11139', 'úÏ…W§', '11139@oyoedu.ng', '8024323299', 'AL-MIZAN HIGH SCH', 'OYO', '11139'),
(140, '11140', 'úÏ…W§', '11140@oyoedu.ng', '7059131819', 'ZUMURAT HUJAJ COMM GRAM', 'OYO', '11140'),
(141, '11141', 'úÏ…W§', '11141@oyoedu.ng', '9050588450', 'FCG COLLEGE', 'OYO', '11141'),
(142, '11142', 'úÏ…W§', '11142@oyoedu.ng', '7015306627', 'A MAKERS COLLEGE', 'OYO', '11142'),
(143, '11143', 'úÏ…W§', '11143@oyoedu.ng', '7015306627', 'AMAKER\'S COLLEGE', 'OYO', '11143'),
(144, '11144', 'úÏ…W§', '11144@oyoedu.ng', '8073724124', 'ALFURQAN MODEL', 'OYO', '11144'),
(145, '11145', 'úÏ…W§', '11145@oyoedu.ng', '8023518010', 'GOVERNMENT COLLEGE', 'OYO', '11145'),
(146, '11146', 'úÏ…W§', '11146@oyoedu.ng', '818538564', 'THE NOBLE STANDARD', 'OYO', '11146'),
(147, '11147', 'úÏ…W§', '11147@oyoedu.ng', '8056639927', 'ANSARUDEEN HIGH SCH', 'OYO', '11147'),
(148, '11148', 'úÏ…W§', '11148@oyoedu.ng', '8163612335', 'ANSARUDEEN HIGH SCH', 'OYO', '11148'),
(149, '11149', 'úÏ…W§', '11149@oyoedu.ng', '8177187449', 'ADESOLA  SCH', 'OYO', '11149'),
(150, '11150', 'úÏ…W§', '11150@oyoedu.ng', '8033966161', 'ANAJAT COLLEGE', 'OYO', '11150'),
(151, '11151', 'úÏ…W§', '11151@oyoedu.ng', '8032307294', 'QUIVER OF GRACE', 'OYO', '11151'),
(152, '11152', 'úÏ…W§', '11152@oyoedu.ng', '8157143127', 'OBA AKINBIYI HIGH', 'OYO', '11152'),
(153, '11153', 'úÏ…W§', '11153@oyoedu.ng', '8032202705', 'COMMAND SEC. SCH.', 'OYO', '11153'),
(154, '11154', 'úÏ…W§', '11154@oyoedu.ng', '9050588450', 'FIRST CLASS GROUP OF SCH', 'OYO', '11154'),
(155, '11155', 'úÏ…W§', '11155@oyoedu.ng', '8073454123', 'MUSLIM COMMUNITY ACADEMY', 'OYO', '11155'),
(156, '11156', 'úÏ…W§', '11156@oyoedu.ng', '8052583852', 'ALQALAM AR-TICULATE', 'OYO', '11156'),
(157, '11157', 'úÏ…W§', '11157@oyoedu.ng', '8074512078', 'GOVERNMENT COLLEGE', 'OYO', '11157'),
(158, '11158', 'úÏ…W§', '11158@oyoedu.ng', '8074512078', 'GOVERNMENT COLLEGE', 'OYO', '11158'),
(159, '11159', 'úÏ…W§', '11159@oyoedu.ng', '7036037083', 'ARABIC NUMERALS', 'OYO', '11159'),
(160, '11160', 'úÏ…W§', '11160@oyoedu.ng', '8055619568', 'ARABIC NUMERAL COLLEGE', 'OYO', '11160'),
(161, '11161', 'úÏ…W§', '11161@oyoedu.ng', '8023340627', 'ANSARUDEEN HIGH SCH', 'OYO', '11161'),
(162, '11162', 'úÏ…W§', '11162@oyoedu.ng', '8169446152', 'HERITAGE FOUNDATION SCHOOL', 'OYO', '11162'),
(163, '11163', 'úÏ…W§', '11163@oyoedu.ng', '8038279267', 'MUFLIHUN HIGH SCH', 'KOGI', '11163'),
(164, '11164', 'úÏ…W§', '11164@oyoedu.ng', '8058386938', 'ABADINA COLLEGE', 'OYO', '11164'),
(165, '11165', 'úÏ…W§', '11165@oyoedu.ng', '8161881632', 'ST.THERESA COLLEGE', 'OSUN', '11165'),
(166, '11166', 'úÏ…W§', '11166@oyoedu.ng', '8065940322', 'EDUCATIONAL LEGACY', 'OYO', '11166'),
(167, '11167', 'úÏ…W§', '11167@oyoedu.ng', '8023514695', 'CITY INT SCH', 'KOGI', '11167'),
(168, '11168', 'úÏ…W§', '11168@oyoedu.ng', '8069813755', 'MUSLIM GRAMMAR SCH', 'OYO', '11168'),
(169, '11169', 'úÏ…W§', '11169@oyoedu.ng', '8061681645', 'MUSLIM GRAMMAR SCH', 'OYO', '11169'),
(170, '11170', 'úÏ…W§', '11170@oyoedu.ng', '9032683848', 'OVERFLOWING MERCY', 'OYO', '11170'),
(171, '11171', 'úÏ…W§', '11171@oyoedu.ng', '8037246005', 'GLOBAL LIGHT MUSLIM COL.', 'OYO', '11171'),
(172, '31172', 'úÏ…W§', '31172@oyoedu.ng', '8163306377', 'GOVERNMENT SECONDARY SCH.', 'OYO', '31172'),
(173, '11173', 'úÏ…W§', '11173@oyoedu.ng', '8056374937', 'ALLAHULIAYU COMP.', 'OYO', '11173'),
(174, '11174', 'úÏ…W§', '11174@oyoedu.ng', '8064675006', 'DE-FERDAUS SCHOOL', 'OYO', '11174'),
(175, '11175', 'úÏ…W§', '11175@oyoedu.ng', '8059958035', 'ALQURAN NIP SCH.OLOGMEN', 'OYO', '11175'),
(176, '11176', 'úÏ…W§', '11176@oyoedu.ng', '8054461747', 'MUSLIM GRAMMAR SCH', 'KWARA', '11176'),
(177, '11177', 'úÏ…W§', '11177@oyoedu.ng', '8029284526', 'MERCY COLLEGE', 'OYO', '11177'),
(178, '11178', 'úÏ…W§', '11178@oyoedu.ng', '8074510121', 'INTELLIGENT QUOTIENT ACADEMY', 'OYO', '11178'),
(179, '11179', 'úÏ…W§', '11179@oyoedu.ng', '8054114317', 'ASSALAM MODEL', 'OYO', '11179'),
(180, '11180', 'úÏ…W§', '11180@oyoedu.ng', '8055753361', 'IMG GRAMMAR SCH', 'OYO', '11180'),
(181, '11181', 'úÏ…W§', '11181@oyoedu.ng', '8079596090', 'CITY SEC SCH', 'OYO', '11181'),
(182, '11182', 'úÏ…W§', '11182@oyoedu.ng', '8060697302', 'TAAWUNU ', 'OYO', '11182'),
(183, '11183', 'úÏ…W§', '11183@oyoedu.ng', '8079596090', 'CITY SEC SCH', 'OYO', '11183'),
(184, '11184', 'úÏ…W§', '11184@oyoedu.ng', '8067172876', 'ST. ANNES SCH', 'OYO', '11184'),
(185, '11185', 'úÏ…W§', '11185@oyoedu.ng', '8067172876', 'ST. ANNES SCH', 'OYO', '11185'),
(186, '11186', 'úÏ…W§', '11186@oyoedu.ng', '8166409404', 'IBADAN BOYS HIGH SCHOOL', 'OYO', '11186'),
(187, '11187', 'úÏ…W§', '11187@oyoedu.ng', '8066496464', 'LEO COMMUNITY HIGH SCH', 'ONDO', '11187'),
(188, '11188', 'úÏ…W§', '11188@oyoedu.ng', '8033840905', 'LAFAMS SCH', 'OYO', '11188'),
(189, '11189', 'úÏ…W§', '11189@oyoedu.ng', '8062117373', 'LANFAMS', 'OYO', '11189'),
(190, '11190', 'úÏ…W§', '11190@oyoedu.ng', '8028799499', 'FOREONE COLLEGE', 'OYO ', '11190'),
(191, '11191', 'úÏ…W§', '11191@oyoedu.ng', '8066496464', '', 'ONDO', '11191'),
(192, '11192', 'úÏ…W§', '11192@oyoedu.ng', '8100183918', 'COMMUNITY SEC ABA ALFA', 'OYO', '11192'),
(193, '11193', 'úÏ…W§', '11193@oyoedu.ng', '8023489456', 'COMPLETE SUCCESS', 'OYO', '11193'),
(194, '11194', 'úÏ…W§', '11194@oyoedu.ng', '8033662209', 'MATRIX COLLEGE', 'OGUN', '11194'),
(195, '11195', 'úÏ…W§', '11195@oyoedu.ng', '8067885097', 'MUFULLHUN HIGH SCH', 'OYO', '11195'),
(196, '11196', 'úÏ…W§', '11196@oyoedu.ng', '8059863131', 'COMMUNITY HIGH SCHOOL', 'OGUN ', '11196'),
(197, '11197', 'úÏ…W§', '11197@oyoedu.ng', '8171622292', 'BASHORUN OGUNMOLA HIGH SCH', 'OYO', '11197'),
(198, '11198', 'úÏ…W§', '11198@oyoedu.ng', '8060308525', 'FAROUK COMM GRAMM', 'OYO ', '11198'),
(199, '11199', 'úÏ…W§', '11199@oyoedu.ng', '9077134980', 'IBADAN BOYS HIGH SCH.', 'OYO', '11199'),
(200, '11200', 'úÏ…W§', '11200@oyoedu.ng', '8033717340', 'COMPREHENSIVE MODEL SCH.', 'OSUN', '11200'),
(201, '11201', 'úÏ…W§', '11201@oyoedu.ng', '8056496067', 'EBENEZER A/C GRAMMER SCH.', 'OYO', '11201'),
(202, '11202', 'úÏ…W§', '11202@oyoedu.ng', '9044017354', 'COMMUNITY GRAMMAR SCH', 'OGUN', '11202'),
(203, '11203', 'úÏ…W§', '11203@oyoedu.ng', '7033875459', 'TRIMPHANT COLLEGE', 'OYO', '11203'),
(204, '11204', 'úÏ…W§', '11204@oyoedu.ng', '8055370650', 'GIFTED HOME SEC', 'OSUN', '11204'),
(205, '11205', 'úÏ…W§', '11205@oyoedu.ng', '7058924102', 'HIGHER HIGH COLLEGE', 'OYO', '11205'),
(206, '11206', 'úÏ…W§', '11206@oyoedu.ng', '8060303802', 'QUEEN\'S SCHOOL', 'OSUN', '11206'),
(207, '11207', 'úÏ…W§', '11207@oyoedu.ng', '9057054359', 'ST. LOUIS GRAMMER', 'OYO', '11207'),
(208, '11208', 'úÏ…W§', '11208@oyoedu.ng', '8056145506', 'THE SMART SCH', 'OYO', '11208'),
(209, '11209', 'úÏ…W§', '11209@oyoedu.ng', '8058347368', 'ROCK OF SALVATION SEC. SCH', 'OYO', '11209'),
(210, '11210', 'úÏ…W§', '11210@oyoedu.ng', '8058023340', 'ST.ANNES', 'OYO', '11210'),
(211, '11211', 'úÏ…W§', '11211@oyoedu.ng', '8038454405', 'UPPER STANDARD COLLEGE', 'OYO', '11211'),
(212, '11212', 'úÏ…W§', '11212@oyoedu.ng', '8076736537', 'EYIINNI COMMUNITY HIGH SCH', 'OYO', '11212'),
(213, '11213', 'úÏ…W§', '11213@oyoedu.ng', '8038121127', 'NAOMI MODEL INT\' SCHOOL', 'OYO', '11213'),
(214, '11214', 'úÏ…W§', '11214@oyoedu.ng', '8038121127', 'NAOMI MODEL SECSCH', 'OYO', '11214'),
(215, '11215', 'úÏ…W§', '11215@oyoedu.ng', '8026065179', 'ST.ANNES SCHOOL', 'OGUN ', '11215'),
(216, '11216', 'úÏ…W§', '11216@oyoedu.ng', '802402546', 'IBADAN BOYS HIGH SCHOOL', 'OYO', '11216'),
(217, '11217', 'úÏ…W§', '11217@oyoedu.ng', '8057322984', 'CRESENT SCH OF ART', 'OYO', '11217'),
(218, '11218', 'úÏ…W§', '11218@oyoedu.ng', '8100040768', 'ELEYELE BAPTIST COLLEGE', 'GOMBE', '11218'),
(219, '11219', 'úÏ…W§', '11219@oyoedu.ng', '7051232146', 'CITY SCHOOL INT\'L', 'OYO', '11219'),
(220, '11220', 'úÏ…W§', '11220@oyoedu.ng', '8063175727', 'IBAADU RAHMON COLLEGE', 'OYO', '11220'),
(221, '11221', 'úÏ…W§', '11221@oyoedu.ng', '8030692733', 'ST TERESSA COLL', 'ENUGU', '11221'),
(222, '11222', 'úÏ…W§', '11222@oyoedu.ng', '7033716627', 'LIVING MIRACLE HIGH SCHOOL', 'OSUN', '11222'),
(223, '11223', 'úÏ…W§', '11223@oyoedu.ng', '8097324551', 'PROF.INTERNATION', 'OYO', '11223'),
(224, '11224', 'úÏ…W§', '11224@oyoedu.ng', '8097324551', 'PROF INT\'L SCH', 'OYO', '11224'),
(225, '11225', 'úÏ…W§', '11225@oyoedu.ng', '8039650114', 'ROCHAS FOUNDATION', 'KOGI', '11225'),
(226, '11226', 'úÏ…W§', '11226@oyoedu.ng', '9031051417', 'PATHFINDER COLLEGE', 'KOGI', '11226'),
(227, '11227', 'úÏ…W§', '11227@oyoedu.ng', '7068314087', 'ANSAR-UN-DEEN', 'OYO', '11227'),
(228, '11228', 'úÏ…W§', '11228@oyoedu.ng', '7065868619', 'LOYOLA JUNIOR SCH', 'ONDO', '11228'),
(229, '11229', 'úÏ…W§', '11229@oyoedu.ng', '8052144466', 'MERCYLAND INT\'L', 'OGUN', '11229'),
(230, '11230', 'úÏ…W§', '11230@oyoedu.ng', '8052073973', 'CRESENT SCHOOL', 'OGUN', '11230'),
(231, '11231', 'úÏ…W§', '11231@oyoedu.ng', '8072774247', 'OKE-ADO HIGH SCHOOL', 'OGUN', '11231'),
(232, '11232', 'úÏ…W§', '11232@oyoedu.ng', '8103374425', 'OLUYOLE HIGH SCH', 'OYO', '11232'),
(233, '11233', 'úÏ…W§', '11233@oyoedu.ng', '8036629911', 'OKE ADO BAPTIST', 'OYO', '11233'),
(234, '11234', 'úÏ…W§', '11234@oyoedu.ng', '8168905145', 'ODO-ONA COMM GRAMM SCH', 'OSUN', '11234'),
(235, '11235', 'úÏ…W§', '11235@oyoedu.ng', '9059446723', 'IBADAN GRAMMER SCH', 'KWARA', '11235'),
(236, '11236', 'úÏ…W§', '11236@oyoedu.ng', '8051389608', 'ST.ANNES SCHOOL', 'OYO', '11236'),
(237, '11237', 'úÏ…W§', '11237@oyoedu.ng', '8023579005', 'IB PROMINENT HEIGHT COLLEGE', 'OYO', '11237'),
(238, '11238', 'úÏ…W§', '11238@oyoedu.ng', '8051389608', 'ST.ANNES', 'OYO', '11238'),
(239, '11239', 'úÏ…W§', '11239@oyoedu.ng', '8035241148', 'GOD\'S CHILDREN', 'EKITI', '11239'),
(240, '11240', 'úÏ…W§', '11240@oyoedu.ng', '8034539728', 'THE WAY INT', 'OYO', '11240'),
(241, '11241', 'úÏ…W§', '11241@oyoedu.ng', '803777454', 'RIDWANULLAH COLLEGE BOLUWAJI IB', 'OYO', '11241'),
(242, '11242', 'úÏ…W§', '11242@oyoedu.ng', '7087034901', 'OLUYOLE PRIVATE INT\'L COMP.', 'OGUN', '11242'),
(243, '11243', 'úÏ…W§', '11243@oyoedu.ng', '8039650114', 'OKE ADO HIGH SCH', 'OGUN', '11243'),
(244, '11244', 'úÏ…W§', '11244@oyoedu.ng', '8067441290', 'IDIKAN COMPREHENSIVE COLLEGE', 'OSUN', '11244'),
(245, '11245', 'úÏ…W§', '11245@oyoedu.ng', '8144194283', 'EHINNI COMMUNITY ORITA CHALLENGE', 'OSUN', '11245'),
(246, '11246', 'úÏ…W§', '11246@oyoedu.ng', '8072981714', 'GODS PLAN MODEL COLLEGE', 'OYO', '11246'),
(247, '11247', 'úÏ…W§', '11247@oyoedu.ng', '9056387495', 'DAWAH CITADEL ', 'OYO', '11247'),
(248, '11248', 'úÏ…W§', '11248@oyoedu.ng', '8056680044', 'AL BARKA COPREHENSIVE COLLEGE', 'OYO', '11248'),
(249, '11249', 'úÏ…W§', '11249@oyoedu.ng', '8060660481', 'SEAT OF WISDOM', 'OYO', '11249'),
(250, '11250', 'úÏ…W§', '11250@oyoedu.ng', '8060660481', 'SEAT OF WISDOM COMPREHENSIVE COLEGE', 'OYO', '11250'),
(251, '11251', 'úÏ…W§', '11251@oyoedu.ng', '8055168724', 'BAPTIST SEC SCH', 'OSUN', '11251'),
(252, '11252', 'úÏ…W§', '11252@oyoedu.ng', '8033683643', 'MODESTY EXCEL SCH', 'OYO', '11252'),
(253, '11253', 'úÏ…W§', '11253@oyoedu.ng', '8028633236', 'BROAD MIND SCH', 'OSUN', '11253'),
(254, '11254', 'úÏ…W§', '11254@oyoedu.ng', '7055522309', 'LIVING MIRACLE', 'OYO', '11254'),
(255, '11255', 'úÏ…W§', '11255@oyoedu.ng', '8035530796', 'BOYS HIGH SCHOOL', 'OGUN', '11255'),
(256, '11256', 'úÏ…W§', '11256@oyoedu.ng', '8060118765', 'THE CROWN COLLEGE', 'OSUN', '11256'),
(257, '11257', 'úÏ…W§', '11257@oyoedu.ng', '8034726079', 'ORITAMEFA BAPTIST MODEL SCHOOL', 'OGUN', '11257'),
(258, '11258', 'úÏ…W§', '11258@oyoedu.ng', '8166489588', 'CITY INT SCH', 'OSUN', '11258'),
(259, '11259', 'úÏ…W§', '11259@oyoedu.ng', '8034241073', 'GOD\'S WILL COLLEGE', 'OGUN', '11259'),
(260, '11260', 'úÏ…W§', '11260@oyoedu.ng', '8071864353', 'ST TERESSA COLL', 'OGUN', '11260'),
(261, '11261', 'úÏ…W§', '11261@oyoedu.ng', '8057642143', 'ALLAHU-LI-AYU', 'OYO', '11261'),
(262, '11262', 'úÏ…W§', '11262@oyoedu.ng', '8053417853', 'BOSTON DE SUPREME ACA.& COLLEGE', 'OSUN', '11262'),
(263, '11263', 'úÏ…W§', '11263@oyoedu.ng', '8102349159', 'GODS PRECIOUS HERITAGE ', 'EKITI', '11263'),
(264, '11264', 'úÏ…W§', '11264@oyoedu.ng', '8102349159', 'GOD\'S PRECIOUS HEART', 'EKITI', '11264'),
(265, '11265', 'úÏ…W§', '11265@oyoedu.ng', '8090577530', 'IBADAN BOYS HIGH SCHOOL', 'OSUN', '11265'),
(266, '11266', 'úÏ…W§', '11266@oyoedu.ng', '8144897625', 'HIGH FLYER COLEGE', 'OYO', '11266'),
(267, '11267', 'úÏ…W§', '11267@oyoedu.ng', '8034879976', 'ST TERESSA COLL', 'OYO', '11267'),
(268, '11268', 'úÏ…W§', '11268@oyoedu.ng', '805948884', 'ECWA MODEL', 'KWARA', '11268'),
(269, '11269', 'úÏ…W§', '11269@oyoedu.ng', '8028831978', 'ECWA MODEL COLLEGE', 'OSUN', '11269'),
(270, '31270', 'úÏ…W§', '31270@oyoedu.ng', '8056667068', 'MIGHTY MIRACLE', 'OYO', '31270'),
(271, '11271', 'úÏ…W§', '11271@oyoedu.ng', '8056667068', 'MIGHTY MIRACLE', 'OYO', '11271'),
(272, '11272', 'úÏ…W§', '11272@oyoedu.ng', '8158500834', 'KINGDOM COLLEGE', 'OYO', '11272'),
(273, '11273', 'úÏ…W§', '11273@oyoedu.ng', '8033916319', 'KINGDOM INT\'L SCH', 'OYO', '11273'),
(274, '11274', 'úÏ…W§', '11274@oyoedu.ng', '8051924975', 'EVERBEST INT\'L COLLEGE', 'OYO', '11274'),
(275, '11275', 'úÏ…W§', '11275@oyoedu.ng', '8035427774', 'BEULAH MODEL SCH', 'OYO', '11275'),
(276, '11276', 'úÏ…W§', '11276@oyoedu.ng', '8107136786', 'FRONT LINERS COLLEGE', 'OSUN', '11276'),
(277, '11277', 'úÏ…W§', '11277@oyoedu.ng', '8033923294', 'YOUNG TALENT', 'OSUN', '11277'),
(278, '11278', 'úÏ…W§', '11278@oyoedu.ng', '8149496422', 'HALL MARK COLLEGE', 'OYO', '11278'),
(279, '11279', 'úÏ…W§', '11279@oyoedu.ng', '7081550880', 'WINNERS ARISE AND SHINE ', 'OYO', '11279'),
(280, '11280', 'úÏ…W§', '11280@oyoedu.ng', '8055232500', 'COMMUNITY SEC', 'OYO', '11280'),
(281, '11281', 'úÏ…W§', '11281@oyoedu.ng', '7056783521', 'ANSARUDEEN', 'OYO', '11281'),
(282, '11282', 'úÏ…W§', '11282@oyoedu.ng', '8056873020', 'DE-EVERGREEN', 'OYO', '11282'),
(283, '11283', 'úÏ…W§', '11283@oyoedu.ng', '8028017836', 'IMG APATA', 'OYO', '11283'),
(284, '11284', 'úÏ…W§', '11284@oyoedu.ng', '7065659632', 'COMMUNITY GRAMMAR SCH', 'OYO', '11284'),
(285, '11285', 'úÏ…W§', '11285@oyoedu.ng', '8032803259', 'ST FRANCIS COLLEGE', 'OSUN', '11285'),
(286, '11286', 'úÏ…W§', '11286@oyoedu.ng', '8099392029', 'ARMY DAY SCHOOL', 'OYO', '11286'),
(287, '11287', 'úÏ…W§', '11287@oyoedu.ng', '8139366162', 'OJO HIGH SCHOOL IB', 'OYO', '11287'),
(288, '11288', 'úÏ…W§', '11288@oyoedu.ng', '8079318795', 'GLORIFIED THY NAME', 'OGUN', '11288'),
(289, '11289', 'úÏ…W§', '11289@oyoedu.ng', '907334392', 'ST. ANNES SCHOOL', 'OYO', '11289'),
(290, '11290', 'úÏ…W§', '11290@oyoedu.ng', '8038754923', 'THE LORD SCHOOL', 'EKITI', '11290'),
(291, '11291', 'úÏ…W§', '11291@oyoedu.ng', '8038754923', 'THE LOAID CITADEL SEC SCHOOL', 'EKITI', '11291'),
(292, '11292', 'úÏ…W§', '11292@oyoedu.ng', '8050228171', 'SABATUDEEN GIRLS GRAMMAR SCH', 'OYO', '11292'),
(293, '11293', 'úÏ…W§', '11293@oyoedu.ng', '8053591856', 'GBEDE OGUM SCH', 'OYO', '11293'),
(294, '11294', 'úÏ…W§', '11294@oyoedu.ng', '9072192323', 'ERADUN SCHOOL', 'OYO', '11294'),
(295, '11295', 'úÏ…W§', '11295@oyoedu.ng', '8052060963', 'ADEM SEC. SCHOOL', 'OYO', '11295'),
(296, '11296', 'úÏ…W§', '11296@oyoedu.ng', '8057433390', 'BEST WAY FOUNDATION COLLEG', 'OYO', '11296'),
(297, '11297', 'úÏ…W§', '11297@oyoedu.ng', '8055453114', 'COMPREHENSIVE ', 'OYO', '11297'),
(298, '11298', 'úÏ…W§', '11298@oyoedu.ng', '8119759553', 'ST  ANNES', 'OYO', '11298'),
(299, '11299', 'úÏ…W§', '11299@oyoedu.ng', '8034993953', 'SPEVER PRIVATE COLL', 'OYO', '11299'),
(300, '11300', 'úÏ…W§', '11300@oyoedu.ng', '8033196510', 'INIOLUWA HIGH SCHOOL', 'OYO', '11300'),
(301, '11301', 'úÏ…W§', '11301@oyoedu.ng', '8143600939', 'NEW LIFE PRIVATE SCH', 'OYO', '11301'),
(302, '31302', 'úÏ…W§', '31302@oyoedu.ng', '8053023099', 'ISLAMIC HIGH SCHOOL', 'OYO', '31302'),
(303, '11303', 'úÏ…W§', '11303@oyoedu.ng', '8063790491', 'BRIGHT HORIZON COLLEGE', 'ONDO', '11303'),
(304, '11304', 'úÏ…W§', '11304@oyoedu.ng', '8035529084', 'CLEVERLAND COLLEGE', 'OYO', '11304'),
(305, '11305', 'úÏ…W§', '11305@oyoedu.ng', '8154534823', 'UDGS', 'OYO', '11305'),
(306, '11306', 'úÏ…W§', '11306@oyoedu.ng', '8036672666', 'GLORIOUS COLLEGE', 'OSUN', '11306'),
(307, '11307', 'úÏ…W§', '11307@oyoedu.ng', '8062293807', 'FAMZAD MODEL', 'OYO', '11307'),
(308, '11308', 'úÏ…W§', '11308@oyoedu.ng', '8056566189', 'BASHORUN OGUNMOLA HIGH SCH', 'OGUN', '11308'),
(309, '11309', 'úÏ…W§', '11309@oyoedu.ng', '8057670291', 'MICFIS INTERNATIONAL SCH', 'OSUN', '11309'),
(310, '11310', 'úÏ…W§', '11310@oyoedu.ng', '9029652202', 'ALUBARIKA SECONDARY SCH', 'OGUN', '11310'),
(311, '11311', 'úÏ…W§', '11311@oyoedu.ng', '8064996305', 'AL BARKA KIDDIES', 'OGUN', '11311'),
(312, '11312', 'úÏ…W§', '11312@oyoedu.ng', '8033663160', 'GRACIOUS OFFSPRING SOKA.IB', 'OYO', '11312'),
(313, '11313', 'úÏ…W§', '11313@oyoedu.ng', '7015216444', 'IMM MODELS SCHOOL', 'OYO', '11313'),
(314, '11314', 'úÏ…W§', '11314@oyoedu.ng', '7015216444', 'IMM MODEL SCH', 'OYO', '11314'),
(315, '11315', 'úÏ…W§', '11315@oyoedu.ng', '8148847933', 'OBAAKINBIYI MODEL SCH', 'LAGOS', '11315'),
(316, '11316', 'úÏ…W§', '11316@oyoedu.ng', '7053280870', 'TRIOLAS COLLEGE', 'OYO', '11316'),
(317, '31317', 'úÏ…W§', '31317@oyoedu.ng', '7061607020', 'COMMUNITY HIGH SCHOOL', 'OYO', '31317'),
(318, '11318', 'úÏ…W§', '11318@oyoedu.ng', '7080338490', 'OKE ADO COMP. SCH', 'OYO', '11318'),
(319, '11319', 'úÏ…W§', '11319@oyoedu.ng', '', 'YEKINI ADEOJO SCH', 'OYO', '11319'),
(320, '11320', 'úÏ…W§', '11320@oyoedu.ng', '8056164906', 'MOSLEN GRAMMAR', 'KWARA', '11320'),
(321, '11321', 'úÏ…W§', '11321@oyoedu.ng', '8056164906', 'MUSLIM GRAMMAR SCH', 'OYO', '11321'),
(322, '11322', 'úÏ…W§', '11322@oyoedu.ng', '8033971007', 'UPPER STANDARD', 'OYO', '11322'),
(323, '11323', 'úÏ…W§', '11323@oyoedu.ng', '8139068854', 'GRACE LAND VOLICE SCHOOL', 'OYO', '11323'),
(324, '11324', 'úÏ…W§', '11324@oyoedu.ng', '9091972460', 'DE, PIONEER COLEGE ', 'OYO', '11324'),
(325, '11325', 'úÏ…W§', '11325@oyoedu.ng', '7067054572', 'FLORENCE HIGH SCH', 'OSUN', '11325'),
(326, '11326', 'úÏ…W§', '11326@oyoedu.ng', '8067434466', 'GREENVILE COLLEGE', 'OSUN', '11326'),
(327, '11327', 'úÏ…W§', '11327@oyoedu.ng', '8162907033', 'EYINI HIGH SCHOOL', 'OYO', '11327'),
(328, '11328', 'úÏ…W§', '11328@oyoedu.ng', '7037384637', 'PRAISE ACADEMY', 'OGUN', '11328'),
(329, '11329', 'úÏ…W§', '11329@oyoedu.ng', '7065810857', 'UPJ SEC SCH', 'OYO', '11329'),
(330, '11330', 'úÏ…W§', '11330@oyoedu.ng', '8165571250', 'PRINCELY COLLEGE IBADAN', 'EKITI', '11330'),
(331, '31331', 'úÏ…W§', '31331@oyoedu.ng', '8055482581', 'GOVERNMENT COLEGE', 'ONDO', '31331'),
(332, '11332', 'úÏ…W§', '11332@oyoedu.ng', '7031821386', 'BAPTIST SECONDARY SCHOOL', 'OGUN', '11332'),
(333, '11333', 'úÏ…W§', '11333@oyoedu.ng', '8064910076', 'OGBERE COMM. SCHOOL', 'OYO', '11333'),
(334, '11334', 'úÏ…W§', '11334@oyoedu.ng', '8039553717', 'SCEPTRE COMP COLLEGE', 'OYO', '11334'),
(335, '11335', 'úÏ…W§', '11335@oyoedu.ng', '8060446678', 'GOD\'S WILL PRIVATE SCH', 'OYO', '11335'),
(336, '11336', 'úÏ…W§', '11336@oyoedu.ng', '8051588517', 'RIDWANULLAHI', 'OGUN', '11336'),
(337, '11337', 'úÏ…W§', '11337@oyoedu.ng', '8065644581', 'BAPTIST SEC SCH', 'EKITI', '11337'),
(338, '11338', 'úÏ…W§', '11338@oyoedu.ng', '8066632367', 'SPED INT SEC SCH', 'OYO', '11338'),
(339, '11339', 'úÏ…W§', '11339@oyoedu.ng', '8066632367', 'SPED INT\'L', 'OYO', '11339'),
(340, '11340', 'úÏ…W§', '11340@oyoedu.ng', '8028865304', 'UNITED COMP COLLEGE', 'OYO', '11340'),
(341, '11341', 'úÏ…W§', '11341@oyoedu.ng', '8066584848', 'OLUMIDE SCH', 'OYO', '11341'),
(342, '11342', 'úÏ…W§', '11342@oyoedu.ng', '7069601006', 'MUFLIHUN HIGH SCH', 'OYO', '11342'),
(343, '11343', 'úÏ…W§', '11343@oyoedu.ng', '8030669420', 'SOW ACADEMY', 'OSUN', '11343'),
(344, '11344', 'úÏ…W§', '11344@oyoedu.ng', '8057334124', 'ST.THERESA SCHOOL', 'OYO', '11344'),
(345, '11345', 'úÏ…W§', '11345@oyoedu.ng', '8037282509', 'CRESENT MONTESSORI', 'LAGOS', '11345'),
(346, '11346', 'úÏ…W§', '11346@oyoedu.ng', '8067815485', 'DIVINE COLLEGE', 'OYO', '11346'),
(347, '11347', 'úÏ…W§', '11347@oyoedu.ng', '8053157375', 'IBHS', 'ONDO', '11347'),
(348, '11348', 'úÏ…W§', '11348@oyoedu.ng', '7068553383', 'BASHORUN OGUNMOLA HIGH SCH', 'OSUN', '11348'),
(349, '11349', 'úÏ…W§', '11349@oyoedu.ng', '8158023734', 'LIBERTY ACADEMY', 'OSUN', '11349'),
(350, '11350', 'úÏ…W§', '11350@oyoedu.ng', '812225044', 'FUNDAMENTAL STUDENT ', 'OYO', '11350'),
(351, '11351', 'úÏ…W§', '11351@oyoedu.ng', '8138216918', 'OUR LADY OF APOSTLE', 'OSUN', '11351'),
(352, '11352', 'úÏ…W§', '11352@oyoedu.ng', '8054068191', 'DISTINGUISH TUTORS MODEL SEC SCH', 'ONDO', '11352'),
(353, '11353', 'úÏ…W§', '11353@oyoedu.ng', '8033543893', 'DIVINE WISDOM BAPTIST ACADEMY', 'EKITI', '11353'),
(354, '11354', 'úÏ…W§', '11354@oyoedu.ng', '7067448203', 'JUBILEE ROSE SCHOOL', 'OSUN', '11354'),
(355, '11355', 'úÏ…W§', '11355@oyoedu.ng', '9016823053', 'GLORIOUS INT', 'OYO', '11355'),
(356, '11356', 'úÏ…W§', '11356@oyoedu.ng', '8153842742', 'A-Z ADEMDUM', 'OYO', '11356'),
(357, '11357', 'úÏ…W§', '11357@oyoedu.ng', '9059826960', 'LOYOLA COLLEGE', 'OSUN', '11357'),
(358, '11358', 'úÏ…W§', '11358@oyoedu.ng', '8143412933', 'OGUNMOLA SCHOOL', 'OYO', '11358'),
(359, '11359', 'úÏ…W§', '11359@oyoedu.ng', '8030714469', 'BAPTIST COLLEGE', 'EKITI', '11359'),
(360, '11360', 'úÏ…W§', '11360@oyoedu.ng', '8053355560', 'MERCY COLL', 'OYO', '11360'),
(361, '11361', 'úÏ…W§', '11361@oyoedu.ng', '8101244440', 'ODUONA KEKERE ', 'OYO', '11361'),
(362, '11362', 'úÏ…W§', '11362@oyoedu.ng', '8066259892', 'ST TERRESSA ', 'OYO', '11362'),
(363, '11363', 'úÏ…W§', '11363@oyoedu.ng', '8026060029', 'COMMUNITY SEC SCH', 'OYO', '11363'),
(364, '11364', 'úÏ…W§', '11364@oyoedu.ng', '9076274973', 'ST.THERESA COLLEGE', 'OYO', '11364'),
(365, '11365', 'úÏ…W§', '11365@oyoedu.ng', '8154119890', 'HIGH CLASS SCH OF SCI', 'OYO', '11365'),
(366, '11366', 'úÏ…W§', '11366@oyoedu.ng', '', '', 'OYO', '11366'),
(367, '11367', 'úÏ…W§', '11367@oyoedu.ng', '', '', 'OYO', '11367'),
(368, '11368', 'úÏ…W§', '11368@oyoedu.ng', '8055948235', 'GREAT GRACE COLLEGE', 'OYO', '11368'),
(369, '11369', 'úÏ…W§', '11369@oyoedu.ng', '7062064485', 'GREAT GRACE COLLEGE', 'OYO', '11369'),
(370, '11370', 'úÏ…W§', '11370@oyoedu.ng', '8160262646', 'BLEEZAT ACADEMY', 'OSUN', '11370'),
(371, '11371', 'úÏ…W§', '11371@oyoedu.ng', '8067215321', 'ABBEY TECH SEC SCH.', 'OYO', '11371'),
(372, '11372', 'úÏ…W§', '11372@oyoedu.ng', '8053400613', 'ABE TECHNICAL SEC.', 'OYO', '11372'),
(373, '11373', 'úÏ…W§', '11373@oyoedu.ng', '7035383333', 'AYESUN GRAMMAR SCH.APETE', 'OYO', '11373'),
(374, '11374', 'úÏ…W§', '11374@oyoedu.ng', '8071897849', 'OKE ERI COMPREHENSIVE', 'OYO', '11374'),
(375, '11375', 'úÏ…W§', '11375@oyoedu.ng', '8071154162', 'ATIKATE BRIGHTER ', 'EKITI', '11375'),
(376, '11376', 'úÏ…W§', '11376@oyoedu.ng', '8053576013', 'QUEENS SCH', 'OSUN', '11376'),
(377, '11377', 'úÏ…W§', '11377@oyoedu.ng', '9071814034', 'EBENEZER A/C GRAMMER SCH.', 'OYO', '11377'),
(378, '11378', 'úÏ…W§', '11378@oyoedu.ng', '8057119172', 'ST TERESSA COLL', 'OYO', '11378'),
(379, '31379', 'úÏ…W§', '31379@oyoedu.ng', '8060231405', 'BAPTIST HIGH SCH', 'OSUN', '31379'),
(380, '11380', 'úÏ…W§', '11380@oyoedu.ng', '8071897849', 'OKE ERI COMPREHENSIVE HIGH SCH', 'OYO', '11380'),
(381, '11381', 'úÏ…W§', '11381@oyoedu.ng', '7054763871', 'ROCK OF AGES MODEL ACADEMY', 'EKITI', '11381'),
(382, '11382', 'úÏ…W§', '11382@oyoedu.ng', '8143160909', 'ASALAM COLLEGE', 'OYO', '11382'),
(383, '11383', 'úÏ…W§', '11383@oyoedu.ng', '8055112316', 'ADEX COLLEGE', 'OGUN', '11383'),
(384, '11384', 'úÏ…W§', '11384@oyoedu.ng', '8012519511', 'OUR LADY OF APOSTLE', 'OGUN', '11384'),
(385, '11385', 'úÏ…W§', '11385@oyoedu.ng', '8067381024', 'ADEX INT SCH', 'OGUN', '11385'),
(386, '11386', 'úÏ…W§', '11386@oyoedu.ng', '8128484354', 'THE SKY LIMIT SEC SCH', 'OGUN', '11386'),
(387, '11387', 'úÏ…W§', '11387@oyoedu.ng', '8035818004', 'ST.JAMES CATHEDRAL COLLEGE', 'ONDO', '11387'),
(388, '11388', 'úÏ…W§', '11388@oyoedu.ng', '8079781944', 'BAPTIST SEC SCH', 'OGUN', '11388'),
(389, '11389', 'úÏ…W§', '11389@oyoedu.ng', '9029264443', 'COMPREHENSIVE HIGH SCHOOL', 'OYO', '11389'),
(390, '11390', 'úÏ…W§', '11390@oyoedu.ng', '8054527628', 'FOLATAYO UNIQUE', 'OSUN', '11390'),
(391, '11391', 'úÏ…W§', '11391@oyoedu.ng', '8073264847', 'MUSLIM MODEL', 'OYO', '11391'),
(392, '11392', 'úÏ…W§', '11392@oyoedu.ng', '8060255049', 'COMMUNITY GRAMMAR SCH', 'OYO', '11392'),
(393, '11393', 'úÏ…W§', '11393@oyoedu.ng', '8032418736', 'QUEENS SCH', 'OYO', '11393'),
(394, '11394', 'úÏ…W§', '11394@oyoedu.ng', '8117608189', 'MULTI GREEN SCH', 'OGUN', '11394'),
(395, '11395', 'úÏ…W§', '11395@oyoedu.ng', '8077468739', 'FOCUS GROUP OF SCH', 'OSUN', '11395'),
(396, '11396', 'úÏ…W§', '11396@oyoedu.ng', '', 'FOLATEYO UNIQUE', 'OGUN', '11396'),
(397, '11397', 'úÏ…W§', '11397@oyoedu.ng', '9058532559', 'FOLATAYO UNIQUE PRIV.SCH', 'OGUN', '11397'),
(398, '11398', 'úÏ…W§', '11398@oyoedu.ng', '8034456159', 'IB.SOUTH DIOCEESE COMP', 'OYO', '11398'),
(399, '11399', 'úÏ…W§', '11399@oyoedu.ng', '8062276043', 'ST.LUKES SCHOOL', 'OYO', '11399'),
(400, '11400', 'úÏ…W§', '11400@oyoedu.ng', '8164752371', 'QUEENS SCHOOL', 'OYO', '11400'),
(401, '11401', 'úÏ…W§', '11401@oyoedu.ng', '8034675100', 'GRACE LAND VINE COLLEGE', 'OSUN', '11401'),
(402, '11402', 'úÏ…W§', '11402@oyoedu.ng', '8163086331', 'MONILOLA GROUP OF SCH.', 'ONDO', '11402'),
(403, '11403', 'úÏ…W§', '11403@oyoedu.ng', '8035234248', 'UNION BAPTIST COLLEGE', 'OYO', '11403'),
(404, '11404', 'úÏ…W§', '11404@oyoedu.ng', '9025136867', 'EXCELLENT KIDDIES PALACE', 'EKITI', '11404'),
(405, '11405', 'úÏ…W§', '11405@oyoedu.ng', '8055400615', 'MUFLIHUN HIGH SCH', 'OYO', '11405'),
(406, '11406', 'úÏ…W§', '11406@oyoedu.ng', '8118340675', 'FOUNTAIN INT\'L SEC SCH', 'OGUN', '11406'),
(407, '11407', 'úÏ…W§', '11407@oyoedu.ng', '9013129898', 'ROYAL DIADEM', 'ONDO', '11407'),
(408, '11408', 'úÏ…W§', '11408@oyoedu.ng', '8033972785', 'ST.ANNS\'S GIRLS', 'OGUN', '11408'),
(409, '11409', 'úÏ…W§', '11409@oyoedu.ng', '8038728433', 'REFORMAL LIFE COLEGE', 'OGUN', '11409'),
(410, '11410', 'úÏ…W§', '11410@oyoedu.ng', '8035488644', 'GLORIFIED UNIQUE', 'OGUN', '11410'),
(411, '11411', 'úÏ…W§', '11411@oyoedu.ng', '8027533323', 'SUNSHINE INT\'L', 'OGUN', '11411'),
(412, '11412', 'úÏ…W§', '11412@oyoedu.ng', '8053954486', 'IMM ACADEMY SCHOOL', 'OGUN', '11412'),
(413, '11413', 'úÏ…W§', '11413@oyoedu.ng', '8034652302', 'ST.ANNES SCHOOL', 'OGUN', '11413'),
(414, '11414', 'úÏ…W§', '11414@oyoedu.ng', '7039634483', 'FUMWAY SEC SCH', 'OYO', '11414'),
(415, '11415', 'úÏ…W§', '11415@oyoedu.ng', '8055323273', 'ST. THERASA COLLEGE', 'OYO', '11415'),
(416, '11416', 'úÏ…W§', '11416@oyoedu.ng', '8050797429', 'ST.ANNES MOLETE', 'OYO', '11416'),
(417, '11417', 'úÏ…W§', '11417@oyoedu.ng', '7032041506', 'BASHORUN OGUNMOLA', 'OYO', '11417'),
(418, '11418', 'úÏ…W§', '11418@oyoedu.ng', '8033545614', 'OLUYOLE EST. GRAMMAR', 'BENIN REPUBLIC', '11418'),
(419, '11419', 'úÏ…W§', '11419@oyoedu.ng', '8075138962', 'METHODIST GRAMMER', 'OSUN', '11419'),
(420, '11420', 'úÏ…W§', '11420@oyoedu.ng', '8169446152', 'HERITAGE FOUNDATION SCHOOL', 'OYO', '11420'),
(421, '11421', 'úÏ…W§', '11421@oyoedu.ng', '7032041506', 'BASHORUN OGUNMOLA I.B', 'OYO', '11421'),
(422, '11422', 'úÏ…W§', '11422@oyoedu.ng', '7012318724', 'NEW LIFE', 'OYO', '11422'),
(423, '11423', 'úÏ…W§', '11423@oyoedu.ng', '7062262280', 'SUMMIT COMPREHENSIVE COLLEGE', 'OSUN', '11423'),
(424, '11424', 'úÏ…W§', '11424@oyoedu.ng', '7031131029', 'VANTAGE COMP', 'OGUN', '11424'),
(425, '11425', 'úÏ…W§', '11425@oyoedu.ng', '8055834161', 'YEJIDE GIRLS GRAMMER', 'OYO', '11425'),
(426, '11426', 'úÏ…W§', '11426@oyoedu.ng', '8060742968', 'ADONAI PRIVATE SCHOOL', 'OYO', '11426'),
(427, '11427', 'úÏ…W§', '11427@oyoedu.ng', '8082130696', 'MELTING POINT PRIVATE COLLEGE', 'OYO', '11427'),
(428, '11428', 'úÏ…W§', '11428@oyoedu.ng', '8056332733', 'COMMAND SCH', 'OYO', '11428'),
(429, '11429', 'úÏ…W§', '11429@oyoedu.ng', '8059224541', 'LIBERTY ACADAMY', 'OGUN', '11429'),
(430, '11430', 'úÏ…W§', '11430@oyoedu.ng', '8034969211', 'ST.ANNES SCHOOL', 'OYO', '11430'),
(431, '11431', 'úÏ…W§', '11431@oyoedu.ng', '8030787719', 'ST.ANNES SCHOOL', 'OGUN', '11431'),
(432, '11432', 'úÏ…W§', '11432@oyoedu.ng', '8075022439', 'MUFUNIHUN HIGH SCH', '', '11432'),
(433, '11433', 'úÏ…W§', '11433@oyoedu.ng', '7032983506', 'HIS KINGDOM HIGH SCHOOL', 'OYO', '11433'),
(434, '11434', 'úÏ…W§', '11434@oyoedu.ng', '8053887994', 'TF COLLEGE', 'OSUN', '11434'),
(435, '11435', 'úÏ…W§', '11435@oyoedu.ng', '9041867785', 'FUTURE TREASURE', 'OYO', '11435'),
(436, '11436', 'úÏ…W§', '11436@oyoedu.ng', '8023841981', 'IBD GRAMMAR SCH', 'OYO', '11436'),
(437, '11437', 'úÏ…W§', '11437@oyoedu.ng', '8023841981', 'IBADAN GRAMMAR', 'OYO', '11437'),
(438, '11438', 'úÏ…W§', '11438@oyoedu.ng', '8023841981', 'IBADAN GRAMMAR', 'OYO', '11438'),
(439, '11439', 'úÏ…W§', '11439@oyoedu.ng', '8054126963', 'IMG TOTAL GARDEN', 'OYO', '11439'),
(440, '11440', 'úÏ…W§', '11440@oyoedu.ng', '8023841981', 'IBD GRAMMAR SCH', 'OYO', '11440'),
(441, '11441', 'úÏ…W§', '11441@oyoedu.ng', '7038033362', 'EXCELLENT COLLEGE', 'OYO', '11441'),
(442, '11442', 'úÏ…W§', '11442@oyoedu.ng', '8073106985', 'GOVT COLLEGE IBADAN', 'OYO', '11442'),
(443, '11443', 'úÏ…W§', '11443@oyoedu.ng', '8038236042', 'UPPER STANDARD COLLEGE', 'OYO', '11443'),
(444, '11444', 'úÏ…W§', '11444@oyoedu.ng', '7032275947', 'CITY INT\'L SCH.', 'OYO', '11444'),
(445, '11445', 'úÏ…W§', '11445@oyoedu.ng', '8061614647', 'BINTO CLASSIC', 'OYO', '11445'),
(446, '11446', 'úÏ…W§', '11446@oyoedu.ng', '7068463353', 'DOLAB PRIVATE SCH', 'LAGOS', '11446'),
(447, '11447', 'úÏ…W§', '11447@oyoedu.ng', '80761423114', 'MERCY COLLEGE', 'OGUN', '11447'),
(448, '11448', 'úÏ…W§', '11448@oyoedu.ng', '8076423114', 'MERCYLAND COLLEGE', 'OGUN', '11448'),
(449, '11449', 'úÏ…W§', '11449@oyoedu.ng', '7057752401', 'IBADAN GRAMMAR SCH', 'OYO', '11449'),
(450, '11450', 'úÏ…W§', '11450@oyoedu.ng', '8055402918', 'ROYAL PATHFINDER COLLEGE', 'OYO', '11450'),
(451, '11451', 'úÏ…W§', '11451@oyoedu.ng', '8033481850', 'NEW HORIZON ACADEMY', 'OGUN', '11451'),
(452, '11452', 'úÏ…W§', '11452@oyoedu.ng', '8033481850', 'NEW HORIZON ACADEMY', 'OGUN', '11452'),
(453, '11453', 'úÏ…W§', '11453@oyoedu.ng', '8032753208', 'IBADAN GRAMMAR SCH', 'OYO', '11453'),
(454, '11454', 'úÏ…W§', '11454@oyoedu.ng', '8034284745', 'MULTI GREEN', 'OYO', '11454'),
(455, '11455', 'úÏ…W§', '11455@oyoedu.ng', '7031963682', 'MERCY INT\'L SCH', 'ONDO', '11455'),
(456, '11456', 'úÏ…W§', '11456@oyoedu.ng', '8052297929', 'NEW CROSS COLLEGE', 'OYO', '11456'),
(457, '11457', 'úÏ…W§', '11457@oyoedu.ng', '8034100399', 'AL-MIZAN HIGH SCHOOL', 'OYO', '11457'),
(458, '11458', 'úÏ…W§', '11458@oyoedu.ng', '8034783002', 'AS-SALAM MODEL', 'OYO', '11458'),
(459, '11459', 'úÏ…W§', '11459@oyoedu.ng', '8095316138', 'ABIMBOLA EXCEL AMOLAJA IB', 'OYO', '11459'),
(460, '11460', 'úÏ…W§', '11460@oyoedu.ng', '8144256647', 'ST. ANNES', 'OYO', '11460'),
(461, '11461', 'úÏ…W§', '11461@oyoedu.ng', '8051668096', 'ANSWAR ISLAM GRAMMAR', 'OSUN', '11461'),
(462, '11462', 'úÏ…W§', '11462@oyoedu.ng', '8051668096', 'ANSWAR ISLAM GRAMMER', 'OSUN', '11462'),
(463, '11463', 'úÏ…W§', '11463@oyoedu.ng', '8064396679', 'CENFEX INT\'L', 'ONDO', '11463'),
(464, '11464', 'úÏ…W§', '11464@oyoedu.ng', '8056991576', 'ST ISABEL COMPREHENSIVE', 'OSUN', '11464'),
(465, '11465', 'úÏ…W§', '11465@oyoedu.ng', '8036527541', 'QUEENS SCH', 'EKITI', '11465'),
(466, '11466', 'úÏ…W§', '11466@oyoedu.ng', '8141525440', 'OGUNMOLA GRAMMAR SCH', 'OGUN', '11466'),
(467, '11467', 'úÏ…W§', '11467@oyoedu.ng', '8064396679', 'CENFEX HIGH SCH', 'ONDO', '11467'),
(468, '11468', 'úÏ…W§', '11468@oyoedu.ng', '8038084488', 'OMG APATA', 'OGUN', '11468'),
(469, '11469', 'úÏ…W§', '11469@oyoedu.ng', '8072468819', 'BAPTIST SEC SCH OKE-ADO', 'OSUN', '11469'),
(470, '11470', 'úÏ…W§', '11470@oyoedu.ng', '8162371577', 'ECWA MODEL', 'OYO', '11470'),
(471, '11471', 'úÏ…W§', '11471@oyoedu.ng', '8033719685', 'GOD REIGNETH', 'EKITI', '11471'),
(472, '11472', 'úÏ…W§', '11472@oyoedu.ng', '8051169255', 'GLORIFIED THY NAME', 'OSUN', '11472'),
(473, '11473', 'úÏ…W§', '11473@oyoedu.ng', '8060811933', 'COMMUNITY HIGH SCH', 'OYO', '11473'),
(474, '11474', 'úÏ…W§', '11474@oyoedu.ng', '8053182573', 'FUMWAY SEC SCH', 'OYO', '11474'),
(475, '11475', 'úÏ…W§', '11475@oyoedu.ng', '8034633880', 'THE AMAZING GRACE ', 'OSUN', '11475'),
(476, '11476', 'úÏ…W§', '11476@oyoedu.ng', '8056955180', 'AL-KITAB MODEL ', 'OYO', '11476'),
(477, '11477', 'úÏ…W§', '11477@oyoedu.ng', '8033682807', 'ROYAL DIADEM SCHOOL', 'OSUN', '11477'),
(478, '11478', 'úÏ…W§', '11478@oyoedu.ng', '8034235650', 'BEULAH MODEL COLEGE', 'OYO', '11478'),
(479, '11479', 'úÏ…W§', '11479@oyoedu.ng', '8079329951', 'AYOBAMI COMPREHENSIVE HIGHT SCH', 'OYO', '11479'),
(480, '11480', 'úÏ…W§', '11480@oyoedu.ng', '8162849850', 'THE APOSTOLIC CHURCH', 'OYO', '11480'),
(481, '11481', 'úÏ…W§', '11481@oyoedu.ng', '8056637350', 'KIDDIES EXCEL COLLEGE', 'OSUN', '11481'),
(482, '11482', 'úÏ…W§', '11482@oyoedu.ng', '9034573251', 'HOLY TRINITY SCH', 'OYO', '11482'),
(483, '11483', 'úÏ…W§', '11483@oyoedu.ng', '7086955457', '', 'OYO', '11483'),
(484, '11484', 'úÏ…W§', '11484@oyoedu.ng', '8103945495', 'EHINI GRAMMER SCHOOL', 'OYO', '11484'),
(485, '11485', 'úÏ…W§', '11485@oyoedu.ng', '8053821661', 'GOOD SHEPERD ', 'OYO', '11485'),
(486, '11486', 'úÏ…W§', '11486@oyoedu.ng', '8056262036', 'GOOD SHEPERD ', 'OYO', '11486'),
(487, '11487', 'úÏ…W§', '11487@oyoedu.ng', '9052709466', 'THE MULTI-LINGUAL SCHOOL', 'OSUN', '11487'),
(488, '11488', 'úÏ…W§', '11488@oyoedu.ng', '8069472255', 'YEJIDE GIRLS GRAMMER', 'OYO', '11488'),
(489, '11489', 'úÏ…W§', '11489@oyoedu.ng', '8069472255', 'YEJIDE GIRLS GRAMMER', 'OYO', '11489'),
(490, '11490', 'úÏ…W§', '11490@oyoedu.ng', '8029074970', 'IBHS', 'OYO', '11490'),
(491, '11491', 'úÏ…W§', '11491@oyoedu.ng', '8050771363', 'BAPTIST GRAMMAR SCH', 'OYO', '11491'),
(492, '11492', 'úÏ…W§', '11492@oyoedu.ng', '8056710530', 'KOBOURE SEC SCHOOL', 'OYO', '11492'),
(493, '11493', 'úÏ…W§', '11493@oyoedu.ng', '7061998594', 'COMMAND SCHOOL', 'OYO', '11493'),
(494, '11494', 'úÏ…W§', '11494@oyoedu.ng', '8060355384', 'IWO ROAD BAPTIST', 'OYO', '11494'),
(495, '11495', 'úÏ…W§', '11495@oyoedu.ng', '8055516199', 'THE LIGHT SCH', 'OSUN', '11495'),
(496, '11496', 'úÏ…W§', '11496@oyoedu.ng', '8125437647', 'OGBA GRAMMAR SCH', 'ONDO', '11496'),
(497, '11497', 'úÏ…W§', '11497@oyoedu.ng', '8135889139', 'IDEAL COLLEGE IJOKODO', 'OYO', '11497'),
(498, '11498', 'úÏ…W§', '11498@oyoedu.ng', '9038198792', 'IDEAL COLLEGE IJOKODO', 'OYO', '11498'),
(499, '11499', 'úÏ…W§', '11499@oyoedu.ng', '8038075484', 'CREATETIVE COMPREHENSIVE SCHOOL', 'OYO', '11499'),
(500, '11500', 'úÏ…W§', '11500@oyoedu.ng', '8052237188', 'COMMUNITY GRAMMAR SCH', 'OYO', '11500'),
(501, '11501', 'úÏ…W§', '11501@oyoedu.ng', '9035294571', 'PHORHEBS ATANDA', 'OYO', '11501'),
(502, '11502', 'úÏ…W§', '11502@oyoedu.ng', '8051377551', 'OUR LADY OF APOSTLES', 'OYO', '11502'),
(503, '11503', 'úÏ…W§', '11503@oyoedu.ng', '8131835256', 'RENASCENT GRAMMAR SCH', 'OYO', '11503'),
(504, '11504', 'úÏ…W§', '11504@oyoedu.ng', '8053048481', 'IZIOMZ ADIKIBE', 'IMO', '11504'),
(505, '11505', 'úÏ…W§', '11505@oyoedu.ng', '9062185297', 'ELEYELE HIGH SCHOOL', 'OYO', '11505'),
(506, '11506', 'úÏ…W§', '11506@oyoedu.ng', '9031822534', 'ST.THERESA\'S', 'OYO', '11506'),
(507, '11507', 'úÏ…W§', '11507@oyoedu.ng', '7030703066', 'COMMUNITY GRAMMER', 'EDO', '11507'),
(508, '11508', 'úÏ…W§', '11508@oyoedu.ng', '8036935516', 'PROSPECT HIGH SCHOOL', 'OYO', '11508'),
(509, '11509', 'úÏ…W§', '11509@oyoedu.ng', '9015759759', 'OBA ABAS ALESINLOYE GRAMM', 'OYO', '11509'),
(510, '11510', 'úÏ…W§', '11510@oyoedu.ng', '7050917536', 'GLORIOUS COLLEGE', 'OYO  ', '11510'),
(511, '11511', 'úÏ…W§', '11511@oyoedu.ng', '8066442142', 'EMERAILD SCHOOL', 'OYO', '11511'),
(512, '11512', 'úÏ…W§', '11512@oyoedu.ng', '8066442142', 'BOLD EMERALD SCHOOL', 'OYO', '11512'),
(513, '11513', 'úÏ…W§', '11513@oyoedu.ng', '8055913501', 'UPPER STANDARD', 'OYO', '11513'),
(514, '11514', 'úÏ…W§', '11514@oyoedu.ng', '8055913501', 'UPPER STANDARD', 'OYO', '11514'),
(515, '11515', 'úÏ…W§', '11515@oyoedu.ng', '9021972159', 'ST.ANNES SCHOOL', 'OGUN', '11515'),
(516, '11516', 'úÏ…W§', '11516@oyoedu.ng', '8056511492', 'STARS COMPREHENSIVE COLLEGE', 'OYO', '11516');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(517, '11517', 'úÏ…W§', '11517@oyoedu.ng', '8056165824', 'GLORIOUS MODEL COLLEGE', 'OYO', '11517'),
(518, '11518', 'úÏ…W§', '11518@oyoedu.ng', '8067235735', 'RIGHT VISION GLOBAL ACADEMY', 'OYO', '11518'),
(519, '11519', 'úÏ…W§', '11519@oyoedu.ng', '8034990669', 'AMAZING GRACE COLLEGE', 'OYO', '11519'),
(520, '11520', 'úÏ…W§', '11520@oyoedu.ng', '8023347486', 'MUSLIM MODEL COLLEGE', 'OGUN', '11520'),
(521, '11521', 'úÏ…W§', '11521@oyoedu.ng', '8156971247', 'GLORIOUS COLLEGE', 'OYO', '11521'),
(522, '11522', 'úÏ…W§', '11522@oyoedu.ng', '8167004909', 'THE BRILLS HIGH SCH', 'OYO', '11522'),
(523, '11523', 'úÏ…W§', '11523@oyoedu.ng', '8074441818', 'IKOLABA GRAMAR SCH ', 'OYO', '11523'),
(524, '11524', 'úÏ…W§', '11524@oyoedu.ng', '7068364895', 'BETHEL CITY', 'OSUN', '11524'),
(525, '11525', 'úÏ…W§', '11525@oyoedu.ng', '8060761787', 'BRIGHTEST STAR COLLEGE', 'EKITI', '11525'),
(526, '11526', 'úÏ…W§', '11526@oyoedu.ng', '7062172885', 'ZENITH COLLEGE', 'OYO', '11526'),
(527, '11527', 'úÏ…W§', '11527@oyoedu.ng', '9031149638', 'BEYOUND THE SKY COLLEGE', 'OSUN', '11527'),
(528, '11528', 'úÏ…W§', '11528@oyoedu.ng', '8053512891', 'ADEX GROUP OF SCH', 'OSUN', '11528'),
(529, '11529', 'úÏ…W§', '11529@oyoedu.ng', '8023469925', 'ADEX SECRET SCH', 'OYO', '11529'),
(530, '11530', 'úÏ…W§', '11530@oyoedu.ng', '8023469925', 'ADEX-SECRET SCHOOL', 'OYO', '11530'),
(531, '11531', 'úÏ…W§', '11531@oyoedu.ng', '8059338398', 'ABAYOMI SCHOOL', 'OYO', '11531'),
(532, '11532', 'úÏ…W§', '11532@oyoedu.ng', '8050884549', 'A-MAKER COLLEGE', 'OYO', '11532'),
(533, '11533', 'úÏ…W§', '11533@oyoedu.ng', '8058568765', 'THE LORD CITADEL', 'OYO', '11533'),
(534, '11534', 'úÏ…W§', '11534@oyoedu.ng', '7086954161', 'THE VIRTUE COLLEGE', 'OYO', '11534'),
(535, '11535', 'úÏ…W§', '11535@oyoedu.ng', '9055179002', 'OGUNMOLA HIGH', 'OYO', '11535'),
(536, '11536', 'úÏ…W§', '11536@oyoedu.ng', '9055179002', 'OGUNMOLA HIGH SCH', 'OYO', '11536'),
(537, '11537', 'úÏ…W§', '11537@oyoedu.ng', '8131051962', 'THE JEWELS OLODO', 'OYO', '11537'),
(538, '11538', 'úÏ…W§', '11538@oyoedu.ng', '7052037063', 'AL-IMAM COMP', 'OYO', '11538'),
(539, '11539', 'úÏ…W§', '11539@oyoedu.ng', '8124608018', 'ST.THERESA COLLEGE', 'ONDO', '11539'),
(540, '11540', 'úÏ…W§', '11540@oyoedu.ng', '8063061667', 'OKE ADO BAPTIST COMP', 'OYO', '11540'),
(541, '11541', 'úÏ…W§', '11541@oyoedu.ng', '8067001158', 'IMG GRAMMAR SCH', 'OSUN', '11541'),
(542, '11542', 'úÏ…W§', '11542@oyoedu.ng', '8054223960', 'STANNES SCH', 'OSUN', '11542'),
(543, '11543', 'úÏ…W§', '11543@oyoedu.ng', '8054223960', 'ST. ANNES SCH', 'OSUN', '11543'),
(544, '11544', 'úÏ…W§', '11544@oyoedu.ng', '8189809590', 'MUSLIM MODEL COLL', 'OYO', '11544'),
(545, '11545', 'úÏ…W§', '11545@oyoedu.ng', '8054565553', 'ADEM SEC.SCH', 'OYO', '11545'),
(546, '11546', 'úÏ…W§', '11546@oyoedu.ng', '8069815747', 'ST.ANNES', 'OYO', '11546'),
(547, '11547', 'úÏ…W§', '11547@oyoedu.ng', '8034068198', 'RADIANCE HIGH SCH.APATA', 'OYO', '11547'),
(548, '11548', 'úÏ…W§', '11548@oyoedu.ng', '8034125983', 'ST.THERESEA', 'KWARA', '11548'),
(549, '11549', 'úÏ…W§', '11549@oyoedu.ng', '7067866040', 'MOUNT ZION COMP', 'OYO', '11549'),
(550, '11550', 'úÏ…W§', '11550@oyoedu.ng', '7067866040', '', 'OYO', '11550'),
(551, '11551', 'úÏ…W§', '11551@oyoedu.ng', '8160712670', 'FOREX COLLEGE ', 'OSUN', '11551'),
(552, '11552', 'úÏ…W§', '11552@oyoedu.ng', '8062186494', 'MUSLIM GRAMMAR SCH', 'OGUN', '11552'),
(553, '11553', 'úÏ…W§', '11553@oyoedu.ng', '9021521363', 'MOSLEN GRAMMAR', 'OGUN', '11553'),
(554, '11554', 'úÏ…W§', '11554@oyoedu.ng', '7039625267', 'QUEENS SCHOOL', 'OSUN', '11554'),
(555, '11555', 'úÏ…W§', '11555@oyoedu.ng', '8035300554', 'SUNSHINE COLLEGE', 'OSUN', '11555'),
(556, '11556', 'úÏ…W§', '11556@oyoedu.ng', '7063832379', 'PDLS INT', 'OYO', '11556'),
(557, '11557', 'úÏ…W§', '11557@oyoedu.ng', '8038464968', 'MOUNT ZION INT', 'OGUN', '11557'),
(558, '11558', 'úÏ…W§', '11558@oyoedu.ng', '8030836302', 'MOUNT ZION INT', 'OYO', '11558'),
(559, '11559', 'úÏ…W§', '11559@oyoedu.ng', '8052179606', 'BENEVOILENCE COLLEGE', 'EKITI', '11559'),
(560, '11560', 'úÏ…W§', '11560@oyoedu.ng', '8060755073', 'ST.PAUL ANGLICAN COLLEGE', 'EKITI', '11560'),
(561, '11561', 'úÏ…W§', '11561@oyoedu.ng', '8039358348', 'BINTO CLASSIC ACADEMY', 'OYO', '11561'),
(562, '11562', 'úÏ…W§', '11562@oyoedu.ng', '8023414139', 'EMBETHE GROUP OF SCH', '', '11562'),
(563, '11563', 'úÏ…W§', '11563@oyoedu.ng', '8023414139', 'EMBETHE SCHOOL', '', '11563'),
(564, '11564', 'úÏ…W§', '11564@oyoedu.ng', '8085469965', 'BASHORUN OGUNMOLA', 'EKITI', '11564'),
(565, '11565', 'úÏ…W§', '11565@oyoedu.ng', '8039650114', 'ROCHAS FOUNDATION', 'OYO', '11565'),
(566, '11566', 'úÏ…W§', '11566@oyoedu.ng', '8039650114', 'ROCHAS FOUNDATION', 'OYO', '11566'),
(567, '11567', 'úÏ…W§', '11567@oyoedu.ng', '8059097030', 'UPPER  STANDARD ', 'OGUN', '11567'),
(568, '11568', 'úÏ…W§', '11568@oyoedu.ng', '8059097030', 'UPPER STANDARD', 'OGUN', '11568'),
(569, '11569', 'úÏ…W§', '11569@oyoedu.ng', '8059097030', 'UPPER STANDARD COLLEGE', 'OGUN', '11569'),
(570, '11570', 'úÏ…W§', '11570@oyoedu.ng', '8034606664', 'ALQIBLA SCH', 'OYO', '11570'),
(571, '11571', 'úÏ…W§', '11571@oyoedu.ng', '8101697809', 'AR. ANNES', 'OYO', '11571'),
(572, '11572', 'úÏ…W§', '11572@oyoedu.ng', '8135710504', 'YEJIDE GIRLS GRAMMAR SCH', 'OYO', '11572'),
(573, '11573', 'úÏ…W§', '11573@oyoedu.ng', '8037648244', 'SACRED HEART', 'ONDO', '11573'),
(574, '11574', 'úÏ…W§', '11574@oyoedu.ng', '7059708260', 'HIGH CLASS SCH OF SCIENCE', 'OYO', '11574'),
(575, '11575', 'úÏ…W§', '11575@oyoedu.ng', '7059706260', 'HIGH CLASS SCHOOL OF SCIENCE ', 'OYO', '11575'),
(576, '11576', 'úÏ…W§', '11576@oyoedu.ng', '8069200933', 'GRACE ROYAL ACADEMY', 'OSUN', '11576'),
(577, '11577', 'úÏ…W§', '11577@oyoedu.ng', '8059159138', 'ST.ANNES COLLEGE', 'ONDO', '11577'),
(578, '11578', 'úÏ…W§', '11578@oyoedu.ng', '7058488969', 'FRONT RUNNER SCH', 'OYO', '11578'),
(579, '11579', 'úÏ…W§', '11579@oyoedu.ng', '8033515199', 'UPPER STANDARD COLLEGE', 'OYO', '11579'),
(580, '11580', 'úÏ…W§', '11580@oyoedu.ng', '8055323273', 'TOP ONT\'L SCHOOL', 'OSUN', '11580'),
(581, '11581', 'úÏ…W§', '11581@oyoedu.ng', '8028508879', 'BRIGHT BRAIN ACADEMY', 'EKITI', '11581'),
(582, '11582', 'úÏ…W§', '11582@oyoedu.ng', '8051144121', 'COMMUNITY SEC SCH', 'OYO', '11582'),
(583, '11583', 'úÏ…W§', '11583@oyoedu.ng', '8051029901', 'NOON WALQALAM GROUP OF SCH', 'OYO', '11583'),
(584, '11584', 'úÏ…W§', '11584@oyoedu.ng', '8051029901', 'NOON WALQALAM GROUP OF SCH ', 'OYO', '11584'),
(585, '11585', 'úÏ…W§', '11585@oyoedu.ng', '8026256348', 'GOODWILL COMPREHENSIVE SCH', 'OYO', '11585'),
(586, '11586', 'úÏ…W§', '11586@oyoedu.ng', '8069694716', 'A MAKERS COLLEGE', 'OYO', '11586'),
(587, '11587', 'úÏ…W§', '11587@oyoedu.ng', '8086303631', 'GOVERNMENT COLLEGE', 'OYO', '11587'),
(588, '11588', 'úÏ…W§', '11588@oyoedu.ng', '8060583563', 'ICRETA SCHOOL', 'OSUN', '11588'),
(589, '11589', 'úÏ…W§', '11589@oyoedu.ng', '7055451902', 'MONARCH MODEL COLLEGE', 'OYO', '11589'),
(590, '11590', 'úÏ…W§', '11590@oyoedu.ng', '7084291286', 'HALLMARK SCHOOL', 'OYO', '11590'),
(591, '11591', 'úÏ…W§', '11591@oyoedu.ng', '8033643745', 'ATANDA INT\'L ', 'KOGI', '11591'),
(592, '11592', 'úÏ…W§', '11592@oyoedu.ng', '8071076640', 'SUCCESS SCH', 'OYO', '11592'),
(593, '11593', 'úÏ…W§', '11593@oyoedu.ng', '7033286353', 'BASHORUN OGUNMOLA HIGH SCH', 'OSUN', '11593'),
(594, '11594', 'úÏ…W§', '11594@oyoedu.ng', '7081729125', 'YEJIDE GIRLS GRAMMAR SCH', 'OGUN', '11594'),
(595, '11595', 'úÏ…W§', '11595@oyoedu.ng', '7059770977', 'GREATER LIGHT', 'LAGOS', '11595'),
(596, '11596', 'úÏ…W§', '11596@oyoedu.ng', '9064909078', 'LIJET MONTESSORI', 'OYO', '11596'),
(597, '11597', 'úÏ…W§', '11597@oyoedu.ng', '8072316464', 'ADEM SEC SCHOOL', 'OYO', '11597'),
(598, '11598', 'úÏ…W§', '11598@oyoedu.ng', '8038569120', 'DIVINE COLLEGE', 'OSUN', '11598'),
(599, '11599', 'úÏ…W§', '11599@oyoedu.ng', '8038569120', 'DIVINE COLLEGE.ODO ONA', 'OSUN', '11599'),
(600, '11600', 'úÏ…W§', '11600@oyoedu.ng', '9064909078', 'LWET MONTESSORI SCHOOL', 'OYO', '11600'),
(601, '11601', 'úÏ…W§', '11601@oyoedu.ng', '8033640824', 'ALLAHU-KAMAL', 'OSUN', '11601'),
(602, '11602', 'úÏ…W§', '11602@oyoedu.ng', '7068396366', 'FIRST CLASS COLLEGE', 'OYO', '11602'),
(603, '11603', 'úÏ…W§', '11603@oyoedu.ng', '8026496672', 'QUEEN SCHOOL', 'OYO', '11603'),
(604, '11604', 'úÏ…W§', '11604@oyoedu.ng', '8103489940', 'GRACE INT\'L N/P', 'OSUN', '11604'),
(605, '11605', 'úÏ…W§', '11605@oyoedu.ng', '8073513139', 'OLUMIDE HIGH SCHOOL', 'OYO', '11605'),
(606, '11606', 'úÏ…W§', '11606@oyoedu.ng', '7086849626', 'GO-AHEAD PRE-VASITY COLLEGE', 'OSUN', '11606'),
(607, '11607', 'úÏ…W§', '11607@oyoedu.ng', '8135244575', 'FRUIT OF LOVE COLLEGE', 'OYO', '11607'),
(608, '11608', 'úÏ…W§', '11608@oyoedu.ng', '8053445382', 'IBADAN GRAMMER SCH', 'OYO', '11608'),
(609, '11609', 'úÏ…W§', '11609@oyoedu.ng', '8115141881', 'ST.LOUIS SCHOOL', 'OYO', '11609'),
(610, '11610', 'úÏ…W§', '11610@oyoedu.ng', '8039485642', 'ALIAZEEZ SEC SCH', 'OYO', '11610'),
(611, '11611', 'úÏ…W§', '11611@oyoedu.ng', '8064181989', 'CTY INT\'L SCHOOL', 'OYO', '11611'),
(612, '11612', 'úÏ…W§', '11612@oyoedu.ng', '8055305218', 'RHEMA CHAPEL INT\'L', 'OYO', '11612'),
(613, '11613', 'úÏ…W§', '11613@oyoedu.ng', '7057812546', 'CALVARY SCHOOL', 'OSUN', '11613'),
(614, '11614', 'úÏ…W§', '11614@oyoedu.ng', '8056204598', 'OXFORD BROOKES', 'EDO', '11614'),
(615, '11615', 'úÏ…W§', '11615@oyoedu.ng', '7033453664', 'COMMUNITY SEC SCHOOL', 'OYO', '11615'),
(616, '11616', 'úÏ…W§', '11616@oyoedu.ng', '7033453664', 'COMMUNITY SEC SCHOOL', 'OYO', '11616'),
(617, '11617', 'úÏ…W§', '11617@oyoedu.ng', '814295564', 'BAPTIST SEC SCH OKE-ADO', 'OYO', '11617'),
(618, '11618', 'úÏ…W§', '11618@oyoedu.ng', '9152769307', 'QUEENS SCH', 'OYO', '11618'),
(619, '11619', 'úÏ…W§', '11619@oyoedu.ng', '8074151084', 'ROSE OF SHARON SEC SCH', 'OGUN', '11619'),
(620, '11620', 'úÏ…W§', '11620@oyoedu.ng', '8069636633', 'ECWA MODEL', 'OSUN', '11620'),
(621, '11621', 'úÏ…W§', '11621@oyoedu.ng', '8076304207', 'KINGS AND DAY GOD', 'EKITI', '11621'),
(622, '11622', 'úÏ…W§', '11622@oyoedu.ng', '8034992121', 'OUR LADY OF APOSTLE', 'EKITI', '11622'),
(623, '11623', 'úÏ…W§', '11623@oyoedu.ng', '8038301944', 'SAMLAK GROUP', 'OGUN', '11623'),
(624, '11624', 'úÏ…W§', '11624@oyoedu.ng', '807489617', 'ST.THERESA\'S COLLEGE', 'OGUN', '11624'),
(625, '11625', 'úÏ…W§', '11625@oyoedu.ng', '8138713064', 'ISPC ', 'OYO', '11625'),
(626, '11626', 'úÏ…W§', '11626@oyoedu.ng', '9072481461', 'GREAT ARCHIEVER', 'OGUN', '11626'),
(627, '11627', 'úÏ…W§', '11627@oyoedu.ng', '8051144121', 'COMMUNITY SEC SCH', 'OYO', '11627'),
(628, '11628', 'úÏ…W§', '11628@oyoedu.ng', '8034039051', 'GO-AHEAD PREVARSITY COLLEGE', 'ONDO', '11628'),
(629, '11629', 'úÏ…W§', '11629@oyoedu.ng', '8178500714', 'GOD\'S FOUNDATION', 'OYO', '11629'),
(630, '11630', 'úÏ…W§', '11630@oyoedu.ng', '8066720884', 'GLAD TIDIES ', 'ONDO', '11630'),
(631, '11631', 'úÏ…W§', '11631@oyoedu.ng', '7033453664', 'COMM SEC SCH SANGO', 'OYO', '11631'),
(632, '11632', 'úÏ…W§', '11632@oyoedu.ng', '8074890939', 'HILL CREST HIGH SCHOOL', 'OYO', '11632'),
(633, '11633', 'úÏ…W§', '11633@oyoedu.ng', '8034382546', 'ROYAL SEED COLLEGE', 'OSUN', '11633'),
(634, '11634', 'úÏ…W§', '11634@oyoedu.ng', '8036787710', 'MFM SCH', 'ONDO ', '11634'),
(635, '11635', 'úÏ…W§', '11635@oyoedu.ng', '7034236358', 'BOYS HIGH SCHOOL', 'EKITI', '11635'),
(636, '11636', 'úÏ…W§', '11636@oyoedu.ng', '8073618555', 'COMPRENSIVE', 'OYO', '11636'),
(637, '11637', 'úÏ…W§', '11637@oyoedu.ng', '9068298122', 'EMINENT SCH', 'EKITI', '11637'),
(638, '11638', 'úÏ…W§', '11638@oyoedu.ng', '8052253011', 'COMMUNITY GRAMMAR SCH', 'OYO', '11638'),
(639, '11639', 'úÏ…W§', '11639@oyoedu.ng', '8180381594', 'HIS HOME COLLEGE', 'OYO', '11639'),
(640, '11640', 'úÏ…W§', '11640@oyoedu.ng', '8055196686', 'ROSE OF SHARON', 'ONDO', '11640'),
(641, '11641', 'úÏ…W§', '11641@oyoedu.ng', '8079798571', 'ST TERESSA COLL', 'ONDO', '11641'),
(642, '11642', 'úÏ…W§', '11642@oyoedu.ng', '8033540618', 'MULTI GREEN SCH', 'OGUN ', '11642'),
(643, '11643', 'úÏ…W§', '11643@oyoedu.ng', '8033540618', 'MULTI GREEN', 'OGUN', '11643'),
(644, '11644', 'úÏ…W§', '11644@oyoedu.ng', '8060970790', 'LEADERS COLLEGE', 'OYO', '11644'),
(645, '11645', 'úÏ…W§', '11645@oyoedu.ng', '8169827675', 'CENFEX HIGH SCH', 'OSUN', '11645'),
(646, '11646', 'úÏ…W§', '11646@oyoedu.ng', '9020629568', 'ROYAL SEED ACADEMY', 'OGUN', '11646'),
(647, '11647', 'úÏ…W§', '11647@oyoedu.ng', '8035834291', 'ST. ANNE\'S SECONDARY', 'OYO', '11647'),
(648, '11648', 'úÏ…W§', '11648@oyoedu.ng', '8035834291', 'ST. ANNE\'S SCH', 'OYO', '11648'),
(649, '11649', 'úÏ…W§', '11649@oyoedu.ng', '8064235731', 'ALL SAINT COLLEGE', 'ONDO', '11649'),
(650, '11650', 'úÏ…W§', '11650@oyoedu.ng', '7052037063', 'AL-IMAM COMP', 'OYO', '11650'),
(651, '11651', 'úÏ…W§', '11651@oyoedu.ng', '8055231629', 'APEL MODEL COLLEGE', 'OYO', '11651'),
(652, '11652', 'úÏ…W§', '11652@oyoedu.ng', '8128824747', 'IMG HIGH SCHOOL', 'ONDO', '11652'),
(653, '11653', 'úÏ…W§', '11653@oyoedu.ng', '7065399095', 'AJIDEX PRIVATE SCH. IDANRE ONDO', 'ONDO', '11653'),
(654, '11654', 'úÏ…W§', '11654@oyoedu.ng', '807735606', 'PRAISE AKINYEMI', 'OYO', '11654'),
(655, '11655', 'úÏ…W§', '11655@oyoedu.ng', '8077350606', 'PRAISE AKINYEMI', 'OYO', '11655'),
(656, '11656', 'úÏ…W§', '11656@oyoedu.ng', '8036238527', 'FRONT LINERS COLLEGE', 'OGUN', '11656'),
(657, '11657', 'úÏ…W§', '11657@oyoedu.ng', '8059981541', 'ADEDUNKE SEC SCH', 'KWARA', '11657'),
(658, '11658', 'úÏ…W§', '11658@oyoedu.ng', '8033848989', 'ARMY BARRACKS SCH', 'OSUN', '11658'),
(659, '11659', 'úÏ…W§', '11659@oyoedu.ng', '8162949735', 'UPPER STANDARD COLLEGE', 'OSUN', '11659'),
(660, '11660', 'úÏ…W§', '11660@oyoedu.ng', '8033820090', 'ST.LOUIS GRAMMAR SCHOOL', 'OYO', '11660'),
(661, '11661', 'úÏ…W§', '11661@oyoedu.ng', '8033986530', 'ST.LOUIS GRAMMAR SCHOOL', 'OYO', '11661'),
(662, '11662', 'úÏ…W§', '11662@oyoedu.ng', '08`151193718', 'DENIS MODEL COLLEGE', 'EKITI', '11662'),
(663, '11663', 'úÏ…W§', '11663@oyoedu.ng', '8051193718', 'D NISS SCHOOL', 'OYO', '11663'),
(664, '11664', 'úÏ…W§', '11664@oyoedu.ng', '8034660062', 'NEWHORIZON SEC. SCHOOL', 'OYO', '11664'),
(665, '11665', 'úÏ…W§', '11665@oyoedu.ng', '8023874372', '', 'OYO', '11665'),
(666, '11666', 'úÏ…W§', '11666@oyoedu.ng', '8134512505', 'ABBEY SEC SCH', 'KOGI', '11666'),
(667, '11667', 'úÏ…W§', '11667@oyoedu.ng', '8035022055', 'ROYAL DIADEM COLLEGE', 'OSUN', '11667'),
(668, '11668', 'úÏ…W§', '11668@oyoedu.ng', '', 'ECWA MODEL COLL', 'OYO', '11668'),
(669, '11669', 'úÏ…W§', '11669@oyoedu.ng', '8067384901', 'SUNSHINE DIAMOND', 'OYO', '11669'),
(670, '11670', 'úÏ…W§', '11670@oyoedu.ng', '9033437797', 'GHOD\'S CANOPY', 'ONDO', '11670'),
(671, '11671', 'úÏ…W§', '11671@oyoedu.ng', '8033598656', 'ANAJAT SEC. SCHOOL', 'OYO', '11671'),
(672, '11672', 'úÏ…W§', '11672@oyoedu.ng', '7082420440', 'ISLAMIL HERITAGE MOD', 'OGUN', '11672'),
(673, '11673', 'úÏ…W§', '11673@oyoedu.ng', '8152739368', 'ATAYESE COLL', 'OYO', '11673'),
(674, '11674', 'úÏ…W§', '11674@oyoedu.ng', '7038209167', 'ATANDA INT SCH ', 'OGUN', '11674'),
(675, '11675', 'úÏ…W§', '11675@oyoedu.ng', '8035773006', 'BINTO CLASSIC', 'OYO', '11675'),
(676, '11676', 'úÏ…W§', '11676@oyoedu.ng', '8032882106', 'IMG YEMETU', 'OSUN', '11676'),
(677, '11677', 'úÏ…W§', '11677@oyoedu.ng', '7039281780', 'GOODNESS AND MERCY ACADEMY', 'EKITI', '11677'),
(678, '11678', 'úÏ…W§', '11678@oyoedu.ng', '8131933602', 'GOODNESS AND MERCY SCH', 'EKITI', '11678'),
(679, '11679', 'úÏ…W§', '11679@oyoedu.ng', '8055169322', 'THE VIRTOUS COLLEGE', 'OYO', '11679'),
(680, '11680', 'úÏ…W§', '11680@oyoedu.ng', '8079052688', 'FRONTINE MUSLIM SCH.', 'OGUN', '11680'),
(681, '11681', 'úÏ…W§', '11681@oyoedu.ng', '8068486474', 'NEW HORIZON ACADEMY', 'OSUN', '11681'),
(682, '11682', 'úÏ…W§', '11682@oyoedu.ng', '8077162665', 'ST ANNES JUNIOR SCH', 'EKITI', '11682'),
(683, '11683', 'úÏ…W§', '11683@oyoedu.ng', '8039104547', 'ADEM SEC SCHOOL', 'OSUN', '11683'),
(684, '11684', 'úÏ…W§', '11684@oyoedu.ng', '8039104547', 'ADEM SEC. SCHOOL', 'OSUN', '11684'),
(685, '11685', 'úÏ…W§', '11685@oyoedu.ng', '9066238223', 'GOOD FORTUNE SEC SCH', 'ONDO', '11685'),
(686, '11686', 'úÏ…W§', '11686@oyoedu.ng', '8058511642', 'COMMUNITY GRAMMAR SCH', 'OYO', '11686'),
(687, '11687', 'úÏ…W§', '11687@oyoedu.ng', '7010105828', 'T.L OYESINA MEMORIAL', 'OYO', '11687'),
(688, '11688', 'úÏ…W§', '11688@oyoedu.ng', '7059587026', 'MOLETE HIGH SCH', 'OYO', '11688'),
(689, '11689', 'úÏ…W§', '11689@oyoedu.ng', '8075457101', 'COMMUNITY GRAMMAR SCH', 'ONDO', '11689'),
(690, '11690', 'úÏ…W§', '11690@oyoedu.ng', '8054582691', 'ENIOLA TESTIMONY', 'EKITI', '11690'),
(691, '11691', 'úÏ…W§', '11691@oyoedu.ng', '8033662153', 'NURULISLAMUIYAH SEC SCH', 'OYO', '11691'),
(692, '11692', 'úÏ…W§', '11692@oyoedu.ng', '8051083641', 'BRIGHTEST STAR COLLEGE', 'KOGI', '11692'),
(693, '11693', 'úÏ…W§', '11693@oyoedu.ng', '9032915335', 'ST.ANNES', 'OSUN', '11693'),
(694, '11694', 'úÏ…W§', '11694@oyoedu.ng', '9050517300', 'MERCY PRIVATE SEC', 'OYO', '11694'),
(695, '11695', 'úÏ…W§', '11695@oyoedu.ng', '8050531873', 'MOUNT ROSE HIGH SCH', 'OYO', '11695'),
(696, '11696', 'úÏ…W§', '11696@oyoedu.ng', '8130936078', 'BLOSSOM INT\'L SCH', 'OYO', '11696'),
(697, '11697', 'úÏ…W§', '11697@oyoedu.ng', '7037551578', 'DIVINE COLLEGE', 'EKITI', '11697'),
(698, '11698', 'úÏ…W§', '11698@oyoedu.ng', '8032073553', 'MACMAN INT\'L SCHOOL', 'OYO', '11698'),
(699, '11699', 'úÏ…W§', '11699@oyoedu.ng', '8066496464', 'IMG GRAMMAR SCH', 'OYO', '11699'),
(700, '11700', 'úÏ…W§', '11700@oyoedu.ng', '7035710343', 'ARABIC AND ISLAMIC SCH', 'OSUN', '11700'),
(701, '11701', 'úÏ…W§', '11701@oyoedu.ng', '8071703399', 'FORTUNATE COLLEGE', 'OYO', '11701'),
(702, '11702', 'úÏ…W§', '11702@oyoedu.ng', '8037264954', 'PENVILE SCHOOL', 'ONDO', '11702'),
(703, '11703', 'úÏ…W§', '11703@oyoedu.ng', '8037264954', 'PENUILLE SCHOOL', 'ONDO', '11703'),
(704, '11704', 'úÏ…W§', '11704@oyoedu.ng', '8020581819', 'GRACE PRIVATE SCHOOL', 'OSUN', '11704'),
(705, '11705', 'úÏ…W§', '11705@oyoedu.ng', '9064080854', 'ST.THERESA COLLEGE', 'OSUN', '11705'),
(706, '11706', 'úÏ…W§', '11706@oyoedu.ng', '8036930575', 'ST.DAVID CATHEDRAL COLLEGE', 'OYO', '11706'),
(707, '11707', 'úÏ…W§', '11707@oyoedu.ng', '8105430547', 'ANSARUDEEN HIGH SCH', 'OYO', '11707'),
(708, '11708', 'úÏ…W§', '11708@oyoedu.ng', '8031121311', ' BRIGHT BRAIN ACADEMY', 'OYO', '11708'),
(709, '11709', 'úÏ…W§', '11709@oyoedu.ng', '8052324830', 'NEW HORIZON PRIVATE SCHOOL', 'OYO', '11709'),
(710, '11710', 'úÏ…W§', '11710@oyoedu.ng', '8134017907', 'ALL AGES COLLEGE', 'OYO', '11710'),
(711, '11711', 'úÏ…W§', '11711@oyoedu.ng', '8133443231', 'GREAT FOLAD COLEGE', 'OYO', '11711'),
(712, '11712', 'úÏ…W§', '11712@oyoedu.ng', '8039243926', 'ADE-ROYAL GROUP OF SCHOOL ', 'OYO', '11712'),
(713, '11713', 'úÏ…W§', '11713@oyoedu.ng', '8024318202', 'ANWARUDEEN ISLAM', 'OYO', '11713'),
(714, '11714', 'úÏ…W§', '11714@oyoedu.ng', '8147781723', 'BAPTIST SEC SCH', 'OGUN', '11714'),
(715, '11715', 'úÏ…W§', '11715@oyoedu.ng', '8147781723', 'BAPTIST SEC SCH', 'OGUN', '11715'),
(716, '11716', 'úÏ…W§', '11716@oyoedu.ng', '9056131444', 'IBADAN MINICIPAL GOVT.SCH', 'OYO', '11716'),
(717, '11717', 'úÏ…W§', '11717@oyoedu.ng', '8034239331', 'ALEGONGON COMM SEC SCH', 'OYO', '11717'),
(718, '11718', 'úÏ…W§', '11718@oyoedu.ng', '8020376359', 'ORITAMEFA BAPTIST MODEL SCHOOL', 'OYO', '11718'),
(719, '11719', 'úÏ…W§', '11719@oyoedu.ng', '9032257578', 'ABADINA GRAMMER SCHOOL', 'OYO', '11719'),
(720, '11720', 'úÏ…W§', '11720@oyoedu.ng', '8066609774', 'BEST SOLID SCHOOL', 'KWARA', '11720'),
(721, '11721', 'úÏ…W§', '11721@oyoedu.ng', '8032074321', 'NOBEL HIGH SCH', 'OYO', '11721'),
(722, '11722', 'úÏ…W§', '11722@oyoedu.ng', '7041766833', 'EMEKA\'S COLLEGE', 'OYO', '11722'),
(723, '11723', 'úÏ…W§', '11723@oyoedu.ng', '8032133445', 'CTY SCHOOL', 'OYO', '11723'),
(724, '11724', 'úÏ…W§', '11724@oyoedu.ng', '8143398113', 'ABAYOMI INT\'L SCHOOL', 'OSUN', '11724'),
(725, '11725', 'úÏ…W§', '11725@oyoedu.ng', '7035183380', 'AFRO IBADAN SCHOOL', 'EDO', '11725'),
(726, '11726', 'úÏ…W§', '11726@oyoedu.ng', '8032392373', 'COMPRENSIVE HIGH SCHOOL', 'OSUN', '11726'),
(727, '11727', 'úÏ…W§', '11727@oyoedu.ng', '7089642204', 'COMMUNITY GRAMMAR SCH', 'KOGI', '11727'),
(728, '11728', 'úÏ…W§', '11728@oyoedu.ng', '8058570341', 'COMMUNITY GRAMMAR SCH', 'OYO', '11728'),
(729, '11729', 'úÏ…W§', '11729@oyoedu.ng', '8156113642', 'DISTINCT COLLEGE', 'OYO', '11729'),
(730, '11730', 'úÏ…W§', '11730@oyoedu.ng', '8058570341', 'COMMUNITY GRAMMAR SCH', 'OYO', '11730'),
(731, '11731', 'úÏ…W§', '11731@oyoedu.ng', '7053167282', 'EXCELSOR COLLEGE', 'OYO', '11731'),
(732, '11732', 'úÏ…W§', '11732@oyoedu.ng', '8035644871', 'AL-EEMAN GROUP OF SCH', 'OGUN', '11732'),
(733, '11733', 'úÏ…W§', '11733@oyoedu.ng', '8035644871', 'AL-EEMAN', 'OGUN', '11733'),
(734, '11734', 'úÏ…W§', '11734@oyoedu.ng', '8105823633', 'CALIFA SEC SCH', 'OYO', '11734'),
(735, '11735', 'úÏ…W§', '11735@oyoedu.ng', '8107048050', 'ISI', 'OYO', '11735'),
(736, '11736', 'úÏ…W§', '11736@oyoedu.ng', '8106255200', 'PUPILS GIRL GRAMMAR SCH', 'OSUN', '11736'),
(737, '11737', 'úÏ…W§', '11737@oyoedu.ng', '8106255200', 'PUPILS GIRLS SCH.', 'OSUN', '11737'),
(738, '11738', 'úÏ…W§', '11738@oyoedu.ng', '8035670389', 'HIGH SCH OF SCIENCE', 'IMO', '11738'),
(739, '11739', 'úÏ…W§', '11739@oyoedu.ng', '8036666768', 'IGSS', 'IMO', '11739'),
(740, '11740', 'úÏ…W§', '11740@oyoedu.ng', '8037469408', 'THE VIRTUE COLLEGE', 'OSUN', '11740'),
(741, '11741', 'úÏ…W§', '11741@oyoedu.ng', '8065790729', 'EMESH CHRIST SCH', 'ANAMBRA', '11741'),
(742, '11742', 'úÏ…W§', '11742@oyoedu.ng', '8060432238', 'FOUNTAIN INT\'L SCH', 'OYO', '11742'),
(743, '11743', 'úÏ…W§', '11743@oyoedu.ng', '8054584833', 'FOLA MODEL SCHOOL', 'OYO', '11743'),
(744, '11744', 'úÏ…W§', '11744@oyoedu.ng', '8035530779', 'QUEENS SCH', 'OSUN', '11744'),
(745, '11745', 'úÏ…W§', '11745@oyoedu.ng', '8056494005', 'TUNI BELLS SCH', 'OYO', '11745'),
(746, '11746', 'úÏ…W§', '11746@oyoedu.ng', '8112021567', 'OWODE KETU HIGH SCH', 'OGUN', '11746'),
(747, '11747', 'úÏ…W§', '11747@oyoedu.ng', '', 'PRECIOUS GIFT COMPREHENSIVE ', 'EDO', '11747'),
(748, '11748', 'úÏ…W§', '11748@oyoedu.ng', '8037265033', 'GOD PROPOSE INT', 'OYO', '11748'),
(749, '11749', 'úÏ…W§', '11749@oyoedu.ng', '8079916687', 'IBHS', 'OSUN', '11749'),
(750, '11750', 'úÏ…W§', '11750@oyoedu.ng', '', 'GREAT DIPLOMAT SCH IDI ISE', 'OYO', '11750'),
(751, '11751', 'úÏ…W§', '11751@oyoedu.ng', '8164822702', 'AWAWU ISLAM GRAMMAR', 'OYO', '11751'),
(752, '11752', 'úÏ…W§', '11752@oyoedu.ng', '9060424556', 'FEDERAL GOVT SCH OGBOMOSHO', 'ANAMBRA', '11752'),
(753, '11753', 'úÏ…W§', '11753@oyoedu.ng', '8034067036', 'FEDERAL COLLEGE OGBOMOSO', 'ANAMBRA', '11753'),
(754, '11754', 'úÏ…W§', '11754@oyoedu.ng', '7053222355', 'ST.ANNES SCHOOL', 'OYO', '11754'),
(755, '11755', 'úÏ…W§', '11755@oyoedu.ng', '7053222355', 'ST ANNES JUNIOR SCH', 'OYO', '11755'),
(756, '11756', 'úÏ…W§', '11756@oyoedu.ng', '8094065676', 'GOVERNMENT COLLEGE', 'OGUN', '11756'),
(757, '11757', 'úÏ…W§', '11757@oyoedu.ng', '7034662574', 'BAPTIST SCHOOL', 'EKITI', '11757'),
(758, '11758', 'úÏ…W§', '11758@oyoedu.ng', '8087850819', 'TOP BRAIN COLLEGE', 'OYO', '11758'),
(759, '11759', 'úÏ…W§', '11759@oyoedu.ng', '7056620755', 'LIVING MIRACLE HIGH SCHOOL', 'OYO', '11759'),
(760, '11760', 'úÏ…W§', '11760@oyoedu.ng', '8052539367', 'YEJIDE GIRLS GRAMMER', 'EKITI', '11760'),
(761, '11761', 'úÏ…W§', '11761@oyoedu.ng', '8052547596', 'FRONTRUNNERS SCHOOL', 'KWARA', '11761'),
(762, '11762', 'úÏ…W§', '11762@oyoedu.ng', '7061366774', 'IB BOYS HIGH SCH', 'ANAMBRA', '11762'),
(763, '11763', 'úÏ…W§', '11763@oyoedu.ng', '7061366774', 'IB BOYS HIGH SCH', 'ANAMBRA', '11763'),
(764, '11764', 'úÏ…W§', '11764@oyoedu.ng', '8062725293', 'EYINNI HIGH SCHOOL', 'EBONYI', '11764'),
(765, '11765', 'úÏ…W§', '11765@oyoedu.ng', '8170186013', 'BRIGHT LAND MODEL SCH', 'EDO', '11765'),
(766, '11766', 'úÏ…W§', '11766@oyoedu.ng', '8076807691', 'OKEBOLA COMP.', 'IMO', '11766'),
(767, '11767', 'úÏ…W§', '11767@oyoedu.ng', '8157423332', 'OKEBOLA COMP.', 'IMO', '11767'),
(768, '11768', 'úÏ…W§', '11768@oyoedu.ng', '8051111596', 'SHPS', 'ANAMBRA', '11768'),
(769, '11769', 'úÏ…W§', '11769@oyoedu.ng', '8059585019', 'OBA ABBAS ALESINLOYE GRA.', 'BENUE', '11769'),
(770, '11770', 'úÏ…W§', '11770@oyoedu.ng', '8033927178', 'BAPTIST COMP.', 'OSUN', '11770'),
(771, '11771', 'úÏ…W§', '11771@oyoedu.ng', '8033927178', 'BAPTIST SEC SCH', 'OSUN', '11771'),
(772, '11772', 'úÏ…W§', '11772@oyoedu.ng', '8066067783', 'COMP. HIGH SCHOOL', 'OSUN', '11772'),
(773, '11773', 'úÏ…W§', '11773@oyoedu.ng', '8034917421', 'DIVINE HERITAGE SCH', 'OYO', '11773'),
(774, '11774', 'úÏ…W§', '11774@oyoedu.ng', '8055075265', 'ADEM SEC SCH', 'OYO', '11774'),
(775, '31775', 'úÏ…W§', '31775@oyoedu.ng', '8055075265', 'ADEM SECONDARY SCH', 'OYO', '31775'),
(776, '11776', 'úÏ…W§', '11776@oyoedu.ng', '8054251169', 'GOLDEN FUTURE GROUP OF SCH', 'EKITI', '11776'),
(777, '11777', 'úÏ…W§', '11777@oyoedu.ng', '7063934063', 'OLUYOLE ESTATE GRAMM.SCH', 'KOGI', '11777'),
(778, '11778', 'úÏ…W§', '11778@oyoedu.ng', '8166492404', 'ST MICHEAL ANGLICAN SCH', 'OSUN', '11778'),
(779, '11779', 'úÏ…W§', '11779@oyoedu.ng', '8035265981', 'BASHORUN OGUNMOLA', 'OGUN', '11779'),
(780, '11780', 'úÏ…W§', '11780@oyoedu.ng', '9045796011', 'ANSARUDEEN ', 'OYO', '11780'),
(781, '11781', 'úÏ…W§', '11781@oyoedu.ng', '8071425765', 'ST. ANNES SCHOOL', 'OYO', '11781'),
(782, '11782', 'úÏ…W§', '11782@oyoedu.ng', '8057966341', 'ABADINA COLLEGE', 'OYO', '11782'),
(783, '11783', 'úÏ…W§', '11783@oyoedu.ng', '8165507623', 'AKINTOLA HIGH SCH', 'ANAMBRA', '11783'),
(784, '11784', 'úÏ…W§', '11784@oyoedu.ng', '9138588489', 'COMMUNITY SEC SCH', 'EDO', '11784'),
(785, '11785', 'úÏ…W§', '11785@oyoedu.ng', '8056704593', 'OYALAMI COMMUNITY', 'EKITI', '11785'),
(786, '11786', 'úÏ…W§', '11786@oyoedu.ng', '8073949250', 'FOMWAN GRAMM SCH', 'OYO', '11786'),
(787, '11787', 'úÏ…W§', '11787@oyoedu.ng', '8052923095', 'AYOOLA SEC SCHOOL', 'OYO', '11787'),
(788, '11788', 'úÏ…W§', '11788@oyoedu.ng', '7061887329', 'BRIGHT BRAIN COLLEGE', 'OSUN', '11788'),
(789, '11789', 'úÏ…W§', '11789@oyoedu.ng', '8061574944', 'ECWA MODEL COLL', 'OSUN', '11789'),
(790, '11790', 'úÏ…W§', '11790@oyoedu.ng', '8138885918', 'MIND BUILDER COLLEGE', 'KOGI', '11790'),
(791, '11791', 'úÏ…W§', '11791@oyoedu.ng', '8062141942', 'ADVENTISTN HERITAGE', 'BENUE', '11791'),
(792, '11792', 'úÏ…W§', '11792@oyoedu.ng', '8030655150', 'CHRIST LOVE GRP OF SCH.', 'OYO', '11792'),
(793, '11793', 'úÏ…W§', '11793@oyoedu.ng', '8079952126', 'IVORY DOMINION', 'OYO', '11793'),
(794, '11794', 'úÏ…W§', '11794@oyoedu.ng', '8050755781', 'OUR LADY OF APOSTLE', 'OSUN', '11794'),
(795, '11795', 'úÏ…W§', '11795@oyoedu.ng', '8038084244', 'ELEYELE HIGH SCHOOL', 'OYO', '11795'),
(796, '11796', 'úÏ…W§', '11796@oyoedu.ng', '8035777224', 'LUKE\'S SCHOOL', 'OGUN', '11796'),
(797, '11797', 'úÏ…W§', '11797@oyoedu.ng', '8057417983', 'ST.DAVID KUDETI', 'OSUN', '11797'),
(798, '11798', 'úÏ…W§', '11798@oyoedu.ng', '8067159439', 'HONEYGOLD HIGH SCHOOL', 'ONDO', '11798'),
(799, '11799', 'úÏ…W§', '11799@oyoedu.ng', '8062582372', 'MOLETE BAPTIST', 'OYO', '11799'),
(800, '11800', 'úÏ…W§', '11800@oyoedu.ng', '8038267202', 'CHRIST LOVE SEC SCH', 'OYO', '11800'),
(801, '11801', 'úÏ…W§', '11801@oyoedu.ng', '8069182843', 'QUEEN\'S SCHOOL', 'OSUN', '11801'),
(802, '11802', 'úÏ…W§', '11802@oyoedu.ng', '8070815111', 'BENEVOLENCE COLLEGE', 'ONDO', '11802'),
(803, '11803', 'úÏ…W§', '11803@oyoedu.ng', '8055940904', 'ST TERESSA COLL', 'OSUN', '11803'),
(804, '11804', 'úÏ…W§', '11804@oyoedu.ng', '8028941010', 'MARK OF GRACE COLLEGE', 'ONDO', '11804'),
(805, '11805', 'úÏ…W§', '11805@oyoedu.ng', '8028941010', 'MARK OF GRACE COLLEGE', 'ONDO', '11805'),
(806, '11806', 'úÏ…W§', '11806@oyoedu.ng', '8030829512', 'YEJIDE GIRLS GRAMMAR SCH', 'OYO', '11806'),
(807, '11807', 'úÏ…W§', '11807@oyoedu.ng', '8131815838', 'ST ALBERT', 'OGUN', '11807'),
(808, '11808', 'úÏ…W§', '11808@oyoedu.ng', '8033652677', 'COMMAND DAY SEC', 'OYO', '11808'),
(809, '11809', 'úÏ…W§', '11809@oyoedu.ng', '8068439830', 'OKE-BOLA COMPREHENSIVE', 'OYO', '11809'),
(810, '11810', 'úÏ…W§', '11810@oyoedu.ng', '8068439830', 'OKE BOLA COMP HIGH SCH', 'OYO', '11810'),
(811, '11811', 'úÏ…W§', '11811@oyoedu.ng', '8059218339', 'ST ANNES JUNIOR SCH', 'OYO', '11811'),
(812, '11812', 'úÏ…W§', '11812@oyoedu.ng', '7065591887', 'ST.DAVID ', 'OYO', '11812'),
(813, '11813', 'úÏ…W§', '11813@oyoedu.ng', '8069573090', 'MARIANE PRIVATE', 'OYO', '11813'),
(814, '11814', 'úÏ…W§', '11814@oyoedu.ng', '8055112261', 'YEJIDE GIRLS GRAMMER', 'OYO', '11814'),
(815, '11815', 'úÏ…W§', '11815@oyoedu.ng', '8024242513', 'BASHORUN OGUNMOLA', 'ONDO', '11815'),
(816, '11816', 'úÏ…W§', '11816@oyoedu.ng', '8161873732', 'AMAZING INT\'L COLLEGE', 'OYO', '11816'),
(817, '11817', 'úÏ…W§', '11817@oyoedu.ng', '8071480505', 'TIAS COLLEGE .APATA', 'OYO', '11817'),
(818, '11818', 'úÏ…W§', '11818@oyoedu.ng', '8034155486', 'SUNDORA INTER\'L SCHOOL', 'OSUN', '11818'),
(819, '11819', 'úÏ…W§', '11819@oyoedu.ng', '7051556362', 'UPPER STANDARD', 'OGUN', '11819'),
(820, '11820', 'úÏ…W§', '11820@oyoedu.ng', '8067817464', 'EMPEROR GOLD COLLEGE', 'KWARA', '11820'),
(821, '11821', 'úÏ…W§', '11821@oyoedu.ng', '8130841315', 'ST.ANNES COLLEGE', 'OGUN', '11821'),
(822, '11822', 'úÏ…W§', '11822@oyoedu.ng', '8039170569', 'DAYSPRING ACAD.', 'OYO', '11822'),
(823, '11823', 'úÏ…W§', '11823@oyoedu.ng', '8039137898', 'FEM FOUNDATION', 'EKITI', '11823'),
(824, '11824', 'úÏ…W§', '11824@oyoedu.ng', '8039137898', 'FEM FOUNDATION', 'EKITI', '11824'),
(825, '11825', 'úÏ…W§', '11825@oyoedu.ng', '', 'COMMUNITY GRAMMAR SCH', 'OYO', '11825'),
(826, '11826', 'úÏ…W§', '11826@oyoedu.ng', '8101130790', 'CCC HIGH SCH', 'OYO  ', '11826'),
(827, '11827', 'úÏ…W§', '11827@oyoedu.ng', '8076183464', 'NAOMI MODEL SECSCH', 'OYO', '11827'),
(828, '11828', 'úÏ…W§', '11828@oyoedu.ng', '9030021228', 'A\' MARKERS', 'OYO', '11828'),
(829, '11829', 'úÏ…W§', '11829@oyoedu.ng', '8060406440', 'AMAZON GRACE', 'OYO', '11829'),
(830, '11830', 'úÏ…W§', '11830@oyoedu.ng', '8060406440', 'THE AMAZING GRACE', 'OYO', '11830'),
(831, '11831', 'úÏ…W§', '11831@oyoedu.ng', '8034360459', 'QUEENS SCH', 'OYO', '11831'),
(832, '11832', 'úÏ…W§', '11832@oyoedu.ng', '', 'QUEENS SCH', 'OYO', '11832'),
(833, '11833', 'úÏ…W§', '11833@oyoedu.ng', '9072306559', 'ASSALAM MODEL', 'OYO', '11833'),
(834, '11834', 'úÏ…W§', '11834@oyoedu.ng', '9075039759', 'ANSARUDEEN SEC', 'OYO', '11834'),
(835, '11835', 'úÏ…W§', '11835@oyoedu.ng', '8185774157', 'TVC COLLEGE', 'OYO', '11835'),
(836, '11836', 'úÏ…W§', '11836@oyoedu.ng', '8185774157', 'T.V.C', 'OYO', '11836'),
(837, '11837', 'úÏ…W§', '11837@oyoedu.ng', '8168947304', 'SOUD FOUNDATION', 'OYO', '11837'),
(838, '11838', 'úÏ…W§', '11838@oyoedu.ng', '8030658057', 'PRAISE ACADEMY', 'OYO', '11838'),
(839, '11839', 'úÏ…W§', '11839@oyoedu.ng', '9068134550', 'ADONAI ADVANCE PRIVATE SCH', 'OSUN', '11839'),
(840, '11840', 'úÏ…W§', '11840@oyoedu.ng', '8036329609', 'ADONAI ADVANCE PRIVATE SCH', 'OSUN', '11840'),
(841, '11841', 'úÏ…W§', '11841@oyoedu.ng', '8067488331', 'ABBEY STANDARD COLLEGE', 'OSUN', '11841'),
(842, '11842', 'úÏ…W§', '11842@oyoedu.ng', '8056216047', 'IBADAN GRAMMER SCH', 'OYO', '11842'),
(843, '11843', 'úÏ…W§', '11843@oyoedu.ng', '8035295658', 'GOVERNMENT COLLEGE', 'OYO', '11843'),
(844, '11844', 'úÏ…W§', '11844@oyoedu.ng', '8153843077', 'VANTAGE COMPREHENSIVE COLL', 'OYO', '11844'),
(845, '11845', 'úÏ…W§', '11845@oyoedu.ng', '7040530308', 'UNIQUE HIGH GRADE', 'ONDO', '11845'),
(846, '11846', 'úÏ…W§', '11846@oyoedu.ng', '8131147151', 'AGELU GRAMMAR SCHOOL', 'OYO', '11846'),
(847, '11847', 'úÏ…W§', '11847@oyoedu.ng', '7063845385', 'INIOLUWA SCH', 'OYO', '11847'),
(848, '11848', 'úÏ…W§', '11848@oyoedu.ng', '8160179571', 'BUSY BRAIN COLL', 'OSUN', '11848'),
(849, '11849', 'úÏ…W§', '11849@oyoedu.ng', '8036329609', 'ADONAI ADVANCE PRIVATE SCH', 'OSUN', '11849'),
(850, '11850', 'úÏ…W§', '11850@oyoedu.ng', '8035295685', 'GOVT.COLLEGE IBADAN', 'OYO', '11850'),
(851, '11851', 'úÏ…W§', '11851@oyoedu.ng', '7068494936', 'SUNSHINE CRYSTAL SCH', 'OGUN', '11851'),
(852, '11852', 'úÏ…W§', '11852@oyoedu.ng', '8055340990', 'YOUNG TALENT SEC SCH', 'OGUN', '11852'),
(853, '11853', 'úÏ…W§', '11853@oyoedu.ng', '8130429355', 'ABBEY SEC SCH', 'OGUN', '11853'),
(854, '11854', 'úÏ…W§', '11854@oyoedu.ng', '8026143770', 'DE PIONEER HIGH SCH', 'OYO', '11854'),
(855, '11855', 'úÏ…W§', '11855@oyoedu.ng', '8033989931', 'COMMUNITY GRAMMAR SCH', 'OSUN', '11855'),
(856, '11856', 'úÏ…W§', '11856@oyoedu.ng', '9071230860', 'GOD STAR STANDARD', 'OYO', '11856'),
(857, '11857', 'úÏ…W§', '11857@oyoedu.ng', '8059157992', 'GOD\'S STAR STANDARD SCHOOL', 'OYO', '11857'),
(858, '11858', 'úÏ…W§', '11858@oyoedu.ng', '', '', 'OYO', '11858'),
(859, '11859', 'úÏ…W§', '11859@oyoedu.ng', '8055485080', 'ZUMRATUL HUJAJ', '', '11859'),
(860, '11860', 'úÏ…W§', '11860@oyoedu.ng', '8053515338', 'THE GOOD SHEPARD INT;L SCH', 'OYO', '11860'),
(861, '11861', 'úÏ…W§', '11861@oyoedu.ng', '8056797746', 'ANSAR-URDEEN HIGH SCH', 'OYO', '11861'),
(862, '11862', 'úÏ…W§', '11862@oyoedu.ng', '8034753270', 'FORTUNES LAND INTERNATIONAL SCH', 'OGUN', '11862'),
(863, '11863', 'úÏ…W§', '11863@oyoedu.ng', '8052000985', 'COMMUNITY HIGH SCHOOL', 'OGUN', '11863'),
(864, '11864', 'úÏ…W§', '11864@oyoedu.ng', '8181964691', 'PROGRESS ZION COLLEGE', 'OGUN', '11864'),
(865, '11865', 'úÏ…W§', '11865@oyoedu.ng', '7038860647', 'E-CLASS MODEL', 'OYO', '11865'),
(866, '11866', 'úÏ…W§', '11866@oyoedu.ng', '7039005836', 'GOLDEN FUTURE SEC SCHOOL', 'OYO', '11866'),
(867, '11867', 'úÏ…W§', '11867@oyoedu.ng', '7034285600', 'THE VIRTUE COLLEGE', 'KWARA', '11867'),
(868, '11868', 'úÏ…W§', '11868@oyoedu.ng', '9054809481', 'OKE BOLA COMP HIGH SCH', 'OYO', '11868'),
(869, '11869', 'úÏ…W§', '11869@oyoedu.ng', '9066680660', 'ATANDE NEIGHBOURHOOD PRIVATE SEC.', 'LAGOS', '11869'),
(870, '11870', 'úÏ…W§', '11870@oyoedu.ng', '8034651717', 'MERC SEAT COLLEGE', 'ONDO', '11870'),
(871, '11871', 'úÏ…W§', '11871@oyoedu.ng', '8079520055', 'EYINI HIGH SCHOOL', 'OGUN', '11871'),
(872, '11872', 'úÏ…W§', '11872@oyoedu.ng', '8033887760', 'E-TUTOULS  COLLEGE OMI IBD', 'OYO', '11872'),
(873, '11873', 'úÏ…W§', '11873@oyoedu.ng', '8109540398', 'ABIMBOLA EXCEL AMUKOKO', 'OYO', '11873'),
(874, '31874', 'úÏ…W§', '31874@oyoedu.ng', '8034494773', 'GOVERNMENT COLLEGE', 'KWARA', '31874'),
(875, '11875', 'úÏ…W§', '11875@oyoedu.ng', '7047074282', 'OYETERU COMMUNITY APATA', 'OYO', '11875'),
(876, '11876', 'úÏ…W§', '11876@oyoedu.ng', '7050357165', 'BAPTIST SEC SCH', 'OSUN', '11876'),
(877, '11877', 'úÏ…W§', '11877@oyoedu.ng', '8079668640', 'ST. ANNE\'S SECONDARY', 'OYO', '11877'),
(878, '11878', 'úÏ…W§', '11878@oyoedu.ng', '8065167017', 'COMMAND SCH', 'OYO', '11878'),
(879, '11879', 'úÏ…W§', '11879@oyoedu.ng', '8036351745', ' THE FAVOUR COLLEGE', 'EKITI', '11879'),
(880, '11880', 'úÏ…W§', '11880@oyoedu.ng', '8034193267', 'LIFESPRING COLLEGE', 'OYO', '11880'),
(881, '11881', 'úÏ…W§', '11881@oyoedu.ng', '8146570061', 'ST.THERESA\'S COLLEGE', 'OGUN', '11881'),
(882, '11882', 'úÏ…W§', '11882@oyoedu.ng', '7065563252', 'IMG', 'OYO', '11882'),
(883, '31883', 'úÏ…W§', '31883@oyoedu.ng', '8035142308', 'ASSALAM MODEL', 'OYO', '31883'),
(884, '11884', 'úÏ…W§', '11884@oyoedu.ng', '8076353966', 'OKEBOLA COMP.', 'OYO', '11884'),
(885, '11885', 'úÏ…W§', '11885@oyoedu.ng', '9067333453', 'OYO STATE COMPREHENSIVE MODEL COLLEGE', 'OYO', '11885'),
(886, '11886', 'úÏ…W§', '11886@oyoedu.ng', '8059821065', 'UPPER STANDARD COLLEGE', 'OGUN', '11886'),
(887, '11887', 'úÏ…W§', '11887@oyoedu.ng', '8066077721', 'SCORES COLLEGE', 'DELTA', '11887'),
(888, '11888', 'úÏ…W§', '11888@oyoedu.ng', '8066077721', 'SCORES COLLEGE', 'DELTA', '11888'),
(889, '11889', 'úÏ…W§', '11889@oyoedu.ng', '80644243977', 'ANSAUDEEN LIBERTY', 'OYO', '11889'),
(890, '11890', 'úÏ…W§', '11890@oyoedu.ng', '8064423977', 'ANSAUDEEN LIBERTY', 'OYO', '11890'),
(891, '11891', 'úÏ…W§', '11891@oyoedu.ng', '8055059609', 'EMERALD LAUREL', 'OSUN', '11891'),
(892, '11892', 'úÏ…W§', '11892@oyoedu.ng', '8034102969', 'HEADCORNER STONE COLLEGE', 'OYO', '11892'),
(893, '11893', 'úÏ…W§', '11893@oyoedu.ng', '7061076872', 'ALIKLAS COMP', 'OYO', '11893'),
(894, '11894', 'úÏ…W§', '11894@oyoedu.ng', '9049709146', 'PROSPECT HIGH SCH', 'OYO', '11894'),
(895, '11895', 'úÏ…W§', '11895@oyoedu.ng', '8023755587', 'THE LIGHT ACADEMY', 'OYO', '11895'),
(896, '11896', 'úÏ…W§', '11896@oyoedu.ng', '8035635844', 'FORTUINE COLLEGE', 'OYO', '11896'),
(897, '11897', 'úÏ…W§', '11897@oyoedu.ng', '8075360453', 'BAPTIST SEC SCH', 'KOGI', '11897'),
(898, '11898', 'úÏ…W§', '11898@oyoedu.ng', '8034988641', 'PIONEERS COLLEGE', 'OYO', '11898'),
(899, '11899', 'úÏ…W§', '11899@oyoedu.ng', '7017483759', 'ABADINA COLLEGE', 'ONDO', '11899'),
(900, '11900', 'úÏ…W§', '11900@oyoedu.ng', '8034412594', 'HONEY GROW INT\'L SCH', 'OSUN', '11900'),
(901, '11901', 'úÏ…W§', '11901@oyoedu.ng', '8105837354', 'OLUYOLE EST. GRAMMAR', 'KOGI', '11901'),
(902, '11902', 'úÏ…W§', '11902@oyoedu.ng', '7031606767', 'CORNER STONE SCH', 'OYO', '11902'),
(903, '11903', 'úÏ…W§', '11903@oyoedu.ng', '8056179216', 'J ROCK OF AGES ', 'OGUN', '11903'),
(904, '11904', 'úÏ…W§', '11904@oyoedu.ng', '8069011605', 'BUSY BRAIN COLLEGE', 'IMO', '11904'),
(905, '11905', 'úÏ…W§', '11905@oyoedu.ng', '8060479653', 'OLUMIDE HEIGHT', 'OYO', '11905'),
(906, '11906', 'úÏ…W§', '11906@oyoedu.ng', '9064984484', 'EYINNI HIGH SCHOOL', 'ONDO', '11906'),
(907, '11907', 'úÏ…W§', '11907@oyoedu.ng', '8037221445', 'INIOLUWA HIGH SCH', 'OYO', '11907'),
(908, '11908', 'úÏ…W§', '11908@oyoedu.ng', '8038024717', 'INIOLUWA HIGH SCH', 'OYO', '11908'),
(909, '11909', 'úÏ…W§', '11909@oyoedu.ng', '7015129754', 'BRILLIANT STAR', 'OYO', '11909'),
(910, '11910', 'úÏ…W§', '11910@oyoedu.ng', '8075157396', 'ST.ANNES SCHOOL', 'OYO', '11910'),
(911, '11911', 'úÏ…W§', '11911@oyoedu.ng', '7064337434', 'BEULAH MODEL COLLEGE', 'ONDO', '11911'),
(912, '11912', 'úÏ…W§', '11912@oyoedu.ng', '8068576340', 'OMOLOLA WISDOM COLLEGE', 'ONDO', '11912'),
(913, '11913', 'úÏ…W§', '11913@oyoedu.ng', '8033930545', 'KOGBODINTER SCH', 'OYO', '11913'),
(914, '11914', 'úÏ…W§', '11914@oyoedu.ng', '8033930545', 'KOGBODI INT SCH', 'OYO', '11914'),
(915, '11915', 'úÏ…W§', '11915@oyoedu.ng', '9134831647', 'GOVERNMENT COLLEGE', 'OYO', '11915'),
(916, '11916', 'úÏ…W§', '11916@oyoedu.ng', '8052107379', 'UPPER STANDARD', 'OYO', '11916'),
(917, '11917', 'úÏ…W§', '11917@oyoedu.ng', '8076028751', 'EXCEPTIONER STAR', 'OYO', '11917'),
(918, '11918', 'úÏ…W§', '11918@oyoedu.ng', '8039520001', 'LOVE OF GOD IMPERIAL COLLEGE', 'OYO', '11918'),
(919, '11919', 'úÏ…W§', '11919@oyoedu.ng', '8033803364', 'IMAN COLLEGE', 'OYO', '11919'),
(920, '11920', 'úÏ…W§', '11920@oyoedu.ng', '7062922260', 'THE LORD GIFT COLLEGE', 'OYO', '11920'),
(921, '11921', 'úÏ…W§', '11921@oyoedu.ng', '9026532882', 'ST.ANNES SCHOOL', 'OYO', '11921'),
(922, '11922', 'úÏ…W§', '11922@oyoedu.ng', '7038396583', 'DIVINE MODEL', 'ONDO', '11922'),
(923, '11923', 'úÏ…W§', '11923@oyoedu.ng', '9033665280', 'MAYFLOWER SCH IKENE OGUN STATE', 'PLATEAU', '11923'),
(924, '11924', 'úÏ…W§', '11924@oyoedu.ng', '8055373495', 'SEAT OF WISDOM GROUP OF SCH', 'ANAMBRA', '11924'),
(925, '11925', 'úÏ…W§', '11925@oyoedu.ng', '8034665085', 'QUEENS COLLEGE', 'ANAMBRA', '11925'),
(926, '11926', 'úÏ…W§', '11926@oyoedu.ng', '8170777197', 'FRUIT OF LOVE', 'IMO', '11926'),
(927, '11927', 'úÏ…W§', '11927@oyoedu.ng', '8057472266', 'ONIREKE HIGH SCH', 'ABIA', '11927'),
(928, '11928', 'úÏ…W§', '11928@oyoedu.ng', '8057472266', 'ONIREKE HIGH SCH', 'ABIA', '11928'),
(929, '11929', 'úÏ…W§', '11929@oyoedu.ng', '7064284044', 'ST TERESSA COLL', 'ENUGU', '11929'),
(930, '11930', 'úÏ…W§', '11930@oyoedu.ng', '8078220070', 'IB BOYS HIGH SCH', 'ENUGU', '11930'),
(931, '11931', 'úÏ…W§', '11931@oyoedu.ng', '8038095732', 'NIKADEX HIGH SCHOOL', 'KWARA', '11931'),
(932, '11932', 'úÏ…W§', '11932@oyoedu.ng', '8059848363', 'BAPTIST SEC SCH', 'OGUN', '11932'),
(933, '11933', 'úÏ…W§', '11933@oyoedu.ng', '8038033092', 'RADIANCE SEC.SCH,INNPC ', 'OYO', '11933'),
(934, '11934', 'úÏ…W§', '11934@oyoedu.ng', '8102615657', 'HONEYGOLD HIGH SCHOOL', 'ONDO', '11934'),
(935, '11935', 'úÏ…W§', '11935@oyoedu.ng', '8066471403', 'LIBERTY ACADAMY', 'KOGI', '11935'),
(936, '11936', 'úÏ…W§', '11936@oyoedu.ng', '', 'QUEEN\'S JUNIOR SCH', 'OSUN', '11936'),
(937, '11937', 'úÏ…W§', '11937@oyoedu.ng', '8134572185', 'GOD WITH US COMP. COLL.', 'OSUN', '11937'),
(938, '11938', 'úÏ…W§', '11938@oyoedu.ng', '8065071290', 'GOD WITH US COMP. COLL.', 'OSUN', '11938'),
(939, '11939', 'úÏ…W§', '11939@oyoedu.ng', '8032182615', 'POLICE SECONDARY', 'ENUGU', '11939'),
(940, '11940', 'úÏ…W§', '11940@oyoedu.ng', '8107217346', 'MIZENAT COLLEGE', 'ONDO', '11940'),
(941, '11941', 'úÏ…W§', '11941@oyoedu.ng', '8166795093', 'ECWA MODEL COLL', 'OYO', '11941'),
(942, '11942', 'úÏ…W§', '11942@oyoedu.ng', '8055912187', 'OLLY-LAW', 'OGUN', '11942'),
(943, '11943', 'úÏ…W§', '11943@oyoedu.ng', '8034659913', 'ALQURRA COLLEGE', 'OYO', '11943'),
(944, '11944', 'úÏ…W§', '11944@oyoedu.ng', '80057064307', 'PEOPLES GIRL GRAMMAR SCH', 'OSUN', '11944'),
(945, '11945', 'úÏ…W§', '11945@oyoedu.ng', '8034982081', 'TENDER MERCY', 'OGUN', '11945'),
(946, '11946', 'úÏ…W§', '11946@oyoedu.ng', '7068835010', 'YEJIDE GIRLS GRAMMAR SCH', 'EBONYI', '11946'),
(947, '11947', 'úÏ…W§', '11947@oyoedu.ng', '8033775200', 'CHAMPMAN COLLEGE', 'IMO', '11947'),
(948, '11948', 'úÏ…W§', '11948@oyoedu.ng', '8132508818', 'OUR LADY OF APOSTLES', 'IMO', '11948'),
(949, '11949', 'úÏ…W§', '11949@oyoedu.ng', '7055037404', 'ST.JOSEPH CATHOLIC SEC SCH', 'ONDO', '11949'),
(950, '11950', 'úÏ…W§', '11950@oyoedu.ng', '7035700237', 'CRESENT SCHOOL', 'OSUN', '11950'),
(951, '11951', 'úÏ…W§', '11951@oyoedu.ng', '8060163891', 'SAM JONNAH COLLEGE', 'OSUN', '11951'),
(952, '11952', 'úÏ…W§', '11952@oyoedu.ng', '8100529400', 'VANTAGE COMPREHENSIVE', 'OYO', '11952'),
(953, '11953', 'úÏ…W§', '11953@oyoedu.ng', '8060222128', 'QUEEN SCHOOL', 'OYO', '11953'),
(954, '11954', 'úÏ…W§', '11954@oyoedu.ng', '8060222128', 'QUEENS SCH', 'OYO', '11954'),
(955, '11955', 'úÏ…W§', '11955@oyoedu.ng', '8188037899', 'IVOPRY DOMINION', 'ENUGU', '11955'),
(956, '11956', 'úÏ…W§', '11956@oyoedu.ng', '8132633310', 'DIVINE COLLEGE', 'EDO', '11956'),
(957, '11957', 'úÏ…W§', '11957@oyoedu.ng', '8162613649', 'COMPRENSIVE', 'IMO', '11957'),
(958, '11958', 'úÏ…W§', '11958@oyoedu.ng', '8055201332', 'CHRIST LOVE SCHOOL', 'OYO', '11958'),
(959, '11959', 'úÏ…W§', '11959@oyoedu.ng', '8054298528', 'THE VIRTUE MODEL SCHOOL', 'OYO', '11959'),
(960, '11960', 'úÏ…W§', '11960@oyoedu.ng', '8075045004', 'ST TERESSA COLL', 'EDO', '11960'),
(961, '11961', 'úÏ…W§', '11961@oyoedu.ng', '8033859186', 'GLORYDAY HIGH SCH.', 'ANAMBRA', '11961'),
(962, '11962', 'úÏ…W§', '11962@oyoedu.ng', '8053128517', 'ST TERESSA COLL', 'IMO', '11962'),
(963, '11963', 'úÏ…W§', '11963@oyoedu.ng', '8064463608', 'MERHODIST JUNIOR GRAM SCH', 'IMO', '11963'),
(964, '11964', 'úÏ…W§', '11964@oyoedu.ng', '8033500141', 'LAURELLA INT\'L', 'DELTA', '11964'),
(965, '11965', 'úÏ…W§', '11965@oyoedu.ng', '8069821965', 'ST.PAUL SCHOOL', 'ENUGU', '11965'),
(966, '11966', 'úÏ…W§', '11966@oyoedu.ng', '8035796614', 'COMMAND DAY SEC SCH', 'OYO', '11966'),
(967, '11967', 'úÏ…W§', '11967@oyoedu.ng', '8037287589', 'TOBI INT. SCH', 'KOGI', '11967'),
(968, '11968', 'úÏ…W§', '11968@oyoedu.ng', '7070507229', 'ROYAL TREST SCH', 'KWARA', '11968'),
(969, '11969', 'úÏ…W§', '11969@oyoedu.ng', '8070507229', 'ROYAL CREST SCHOOL', 'OYO', '11969'),
(970, '11970', 'úÏ…W§', '11970@oyoedu.ng', '8051136622', 'TESTIMONY GROUP', 'OYO', '11970'),
(971, '11971', 'úÏ…W§', '11971@oyoedu.ng', '8069545596', 'ELEYELE BAPTIST COLLEGE', 'DELTA', '11971'),
(972, '11972', 'úÏ…W§', '11972@oyoedu.ng', '9037423643', 'AMAZING GRACE ', 'OSUN', '11972'),
(973, '11973', 'úÏ…W§', '11973@oyoedu.ng', '9152432035', 'BOYS HIGH SCH', 'ABIA ', '11973'),
(974, '11974', 'úÏ…W§', '11974@oyoedu.ng', '8130821549', 'BAPTIST SEC. SCH.', 'IMO', '11974'),
(975, '11975', 'úÏ…W§', '11975@oyoedu.ng', '8136939365', 'QUEENS SCH.', 'OYO', '11975'),
(976, '11976', 'úÏ…W§', '11976@oyoedu.ng', '8060264179', 'GOD\'S BILLIONAIRE SEC. SCH.', 'OYO', '11976'),
(977, '11977', 'úÏ…W§', '11977@oyoedu.ng', '9015178549', 'OGBERE COMM.SCH', 'OYO', '11977'),
(978, '11978', 'úÏ…W§', '11978@oyoedu.ng', '8022658836', 'IBADAN BOYS HIGH SCHOOL', 'OYO', '11978'),
(979, '11979', 'úÏ…W§', '11979@oyoedu.ng', '8035663608', 'TOYBIS COLLEGE', 'KOGI', '11979'),
(980, '11980', 'úÏ…W§', '11980@oyoedu.ng', '8060076785', 'GRACIOUS OFFSPRING SCH', 'OYO', '11980'),
(981, '11981', 'úÏ…W§', '11981@oyoedu.ng', '8064379054', 'UPPER STANDARD COLLEGE', 'ABIA', '11981'),
(982, '11982', 'úÏ…W§', '11982@oyoedu.ng', '8151962230', 'A.B.E TECHNICAL', 'OYO', '11982'),
(983, '11983', 'úÏ…W§', '11983@oyoedu.ng', '8136871117', 'INIKIPI MAYFLOWER', 'OYO', '11983'),
(984, '11984', 'úÏ…W§', '11984@oyoedu.ng', '8136871117', 'INIKIPI MAY FLOWER', 'OYO', '11984'),
(985, '11985', 'úÏ…W§', '11985@oyoedu.ng', '8136871117', 'INIKIPI MAYFLOWER', 'OYO', '11985'),
(986, '11986', 'úÏ…W§', '11986@oyoedu.ng', '8136871117', 'INIKIPI MAY FLOWER', 'OYO', '11986'),
(987, '11987', 'úÏ…W§', '11987@oyoedu.ng', '8034308520', 'RUBBIES INT SCH', 'KWARA', '11987'),
(988, '11988', 'úÏ…W§', '11988@oyoedu.ng', '8060400681', 'GODS PLAN MODEL', 'OYO', '11988'),
(989, '11989', 'úÏ…W§', '11989@oyoedu.ng', '7060489071', 'GOVERNMENT COLLEGE', 'ONDO', '11989'),
(990, '11990', 'úÏ…W§', '11990@oyoedu.ng', '7060489071', 'QUEENS SCH', 'ONDO', '11990'),
(991, '11991', 'úÏ…W§', '11991@oyoedu.ng', '7067056585', 'GLORIOUS KINGS AND QUEENS COLLEGE', 'OYO', '11991'),
(992, '11992', 'úÏ…W§', '11992@oyoedu.ng', '7065056585', 'KINGS AND QUEEN COLLEGE', 'OYO', '11992'),
(993, '11993', 'úÏ…W§', '11993@oyoedu.ng', '7060755001', 'OBMS TIGARDEN', 'EKITI', '11993'),
(994, '11994', 'úÏ…W§', '11994@oyoedu.ng', '8038464968', 'MOUNT ZION INT', 'OSUN', '11994'),
(995, '11995', 'úÏ…W§', '11995@oyoedu.ng', '8059164110', 'FOLASADE PRIVATE SCH', 'OYO', '11995'),
(996, '11996', 'úÏ…W§', '11996@oyoedu.ng', '8034305465', 'GOVT.COLLEGE IBADAN', 'OYO', '11996'),
(997, '11997', 'úÏ…W§', '11997@oyoedu.ng', '8165278141', 'NOBLE KIDDIES SCHOOL', 'ANAMBRA', '11997'),
(998, '11998', 'úÏ…W§', '11998@oyoedu.ng', '7032294466', 'ST.THERESA', 'KWARA ', '11998'),
(999, '11999', 'úÏ…W§', '11999@oyoedu.ng', '8067202445', 'RHEMA COLLEGE', 'OYO', '11999'),
(1000, '111000', 'úÏ…W§', '111000@oyoedu.ng', '9063602726', 'ST.LOUIS COLLEGE', 'OSUN', '111000'),
(1001, '111001', 'úÏ…W§', '111001@oyoedu.ng', '708397695', 'POTTERS-HOUSE', 'EKITI', '111001'),
(1002, '111002', 'úÏ…W§', '111002@oyoedu.ng', '8069175132', 'ULTIMATE PRIVATE SEC SCH', 'OGUN', '111002'),
(1003, '111003', 'úÏ…W§', '111003@oyoedu.ng', '9023061540', 'CHARIS MODEL COLLEGE', 'OGUN', '111003'),
(1004, '111004', 'úÏ…W§', '111004@oyoedu.ng', '8034853545', 'MODEL EXEL PRI SCH', 'ONDO', '111004'),
(1005, '111005', 'úÏ…W§', '111005@oyoedu.ng', '8034853545', 'MODESTY EXCEL PRI', 'ONDO', '111005'),
(1006, '111006', 'úÏ…W§', '111006@oyoedu.ng', '8066353350', 'GLORIFY THY NAME SEC SCH', 'OSUN', '111006'),
(1007, '111007', 'úÏ…W§', '111007@oyoedu.ng', '8056168380', 'GOD PROPOSES COLLEGE', 'OYO', '111007'),
(1008, '111008', 'úÏ…W§', '111008@oyoedu.ng', '8088949927', 'LIFE SPRING PRIVATE SCH', 'OSUN', '111008'),
(1009, '111009', 'úÏ…W§', '111009@oyoedu.ng', '8056168380', 'GOD PPURPOSE SECONDARY', 'OYO', '111009'),
(1010, '111010', 'úÏ…W§', '111010@oyoedu.ng', '8039123737', 'BEST WAY COLLEGE', 'OYO', '111010'),
(1011, '111011', 'úÏ…W§', '111011@oyoedu.ng', '8060137687', 'OUR LADY OF APOSTLES', 'OSUN', '111011'),
(1012, '111012', 'úÏ…W§', '111012@oyoedu.ng', '9137623640', 'DIVINE LIFTER', 'OSUN', '111012'),
(1013, '111013', 'úÏ…W§', '111013@oyoedu.ng', '8133345497', 'SUPREME INT', 'OSUN', '111013'),
(1014, '111014', 'úÏ…W§', '111014@oyoedu.ng', '8133345497', 'SUPREME INT\'L', 'OSUN', '111014'),
(1015, '111015', 'úÏ…W§', '111015@oyoedu.ng', '8028831978', 'UNIQUE HIGH GRADE', 'OSUN', '111015'),
(1016, '111016', 'úÏ…W§', '111016@oyoedu.ng', '802883178', 'UNIQUE HIGH GRADE', 'OSUN', '111016'),
(1017, '111017', 'úÏ…W§', '111017@oyoedu.ng', '8034923744', 'MERCLEVE SEC. SCH', 'EKITI', '111017'),
(1018, '111018', 'úÏ…W§', '111018@oyoedu.ng', '7031096060', 'OYO STATE COMPREHENSIVE MODEL COLLEGE', 'OYO', '111018'),
(1019, '111019', 'úÏ…W§', '111019@oyoedu.ng', '9028686844', 'GLADYS HIGH SCH,KETU LAGOS', 'LAGOS', '111019'),
(1020, '111020', 'úÏ…W§', '111020@oyoedu.ng', '7060641661', 'HIGH CLASS SCH OF SCI', 'OSUN', '111020'),
(1021, '111021', 'úÏ…W§', '111021@oyoedu.ng', '8034653129', 'BAPTIST SEC SCH', 'OYO', '111021'),
(1022, '111022', 'úÏ…W§', '111022@oyoedu.ng', '7032979690', 'QUEEN\'S SCHOOL', 'ONDO', '111022'),
(1023, '111023', 'úÏ…W§', '111023@oyoedu.ng', '7066622930', 'SPLENDID MODEL COLLEGE', 'ONDO', '111023'),
(1024, '111024', 'úÏ…W§', '111024@oyoedu.ng', '8132757633', 'GOVERNMENT COLLEGE', 'OYO', '111024'),
(1025, '111025', 'úÏ…W§', '111025@oyoedu.ng', '8059186832', 'RIDWANULLAHI SEC SCH', 'OYO', '111025'),
(1026, '111026', 'úÏ…W§', '111026@oyoedu.ng', '8033932114', 'QUEEN SCH OOL.COLLEGE', 'OYO', '111026'),
(1027, '111027', 'úÏ…W§', '111027@oyoedu.ng', '8033932114', 'QUEENS SCH', 'OYO', '111027'),
(1028, '111028', 'úÏ…W§', '111028@oyoedu.ng', '80066747280', 'METHODIST GRAMMAR SCH', 'EKITI', '111028'),
(1029, '111029', 'úÏ…W§', '111029@oyoedu.ng', '8038759896', 'MERCY INTE\'L SCHOOL', 'OSUN', '111029'),
(1030, '111030', 'úÏ…W§', '111030@oyoedu.ng', '8104014954', 'STAR RISE', 'OSUN', '111030'),
(1031, '111031', 'úÏ…W§', '111031@oyoedu.ng', '7033810101', 'GRACELAND SCH', 'EKITI', '111031'),
(1032, '111032', 'úÏ…W§', '111032@oyoedu.ng', '8058515775', 'ECWA MODEL', 'OGUN', '111032'),
(1033, '111033', 'úÏ…W§', '111033@oyoedu.ng', '7065177283', 'TIM CAROL  COLLEGE', 'OYO', '111033'),
(1034, '111034', 'úÏ…W§', '111034@oyoedu.ng', '', 'COMMUNITY GRAMMAR SCH', 'OYO', '111034');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(1035, '111035', 'úÏ…W§', '111035@oyoedu.ng', '8066356348', 'RAPHY PRIVATE SCH', 'LAGOS', '111035'),
(1036, '111036', 'úÏ…W§', '111036@oyoedu.ng', '8066450275', 'YEJIDE GIRLS GRAMMAR SCH', 'OSUN', '111036'),
(1037, '111037', 'úÏ…W§', '111037@oyoedu.ng', '8067764418', 'OLUBI MEMORIAL GRAMMAR SCH', 'EKITI', '111037'),
(1038, '111038', 'úÏ…W§', '111038@oyoedu.ng', '8068281361', 'ELEYELE SECONDARY SCH', 'OYO', '111038'),
(1039, '111039', 'úÏ…W§', '111039@oyoedu.ng', '8036498605', 'EPHRAIM COMPREHENSIVE COLLEGE', 'OYO', '111039'),
(1040, '111040', 'úÏ…W§', '111040@oyoedu.ng', '8060614936', 'WITH GOD PRIVATE SCH', 'OSUN', '111040'),
(1041, '111041', 'úÏ…W§', '111041@oyoedu.ng', '8060614936', 'WITH GOD PRIVATE SCH', 'OSUN', '111041'),
(1042, '111042', 'úÏ…W§', '111042@oyoedu.ng', '8132986103', 'ST ANNES JUNIOR SCH', 'OSUN', '111042'),
(1043, '111043', 'úÏ…W§', '111043@oyoedu.ng', '7088509772', 'OKEBOLA COMP.', 'AKWA IBOM', '111043'),
(1044, '111044', 'úÏ…W§', '111044@oyoedu.ng', '8189989650', 'GLADTIDE COMP', 'OYO', '111044'),
(1045, '111045', 'úÏ…W§', '111045@oyoedu.ng', '8032420889', 'EMPEROR GOLD COLLEGE', 'DELTA', '111045'),
(1046, '111046', 'úÏ…W§', '111046@oyoedu.ng', '8032420889', 'EMPROR GOLD', 'DELTA', '111046'),
(1047, '111047', 'úÏ…W§', '111047@oyoedu.ng', '9152759682', 'BOLAJI GROUP OF SCH', 'ENUGU', '111047'),
(1048, '111048', 'úÏ…W§', '111048@oyoedu.ng', '7057247821', 'ISABATEEN GIRLS GRAM SCH', 'OYO', '111048'),
(1049, '111049', 'úÏ…W§', '111049@oyoedu.ng', '9152778626', 'ST.LOUIS COLLEGE', 'OYO', '111049'),
(1050, '111050', 'úÏ…W§', '111050@oyoedu.ng', '8076524809', 'UNIQUE HIGH GRADE', 'OYO', '111050'),
(1051, '111051', 'úÏ…W§', '111051@oyoedu.ng', '9057116039', 'GOVERNMENT COLLEGE', 'OYO', '111051'),
(1052, '111052', 'úÏ…W§', '111052@oyoedu.ng', '8034360459', 'QUEENS SCH ', 'OYO', '111052'),
(1053, '111053', 'úÏ…W§', '111053@oyoedu.ng', '8034360459', 'QUEENS SCH', 'OYO', '111053'),
(1054, '111054', 'úÏ…W§', '111054@oyoedu.ng', '8073812170', 'MMCR', 'OYO', '111054'),
(1055, '111055', 'úÏ…W§', '111055@oyoedu.ng', '8076496610', 'FOUNTAIN INT\'L SEC SCH', 'OYO', '111055'),
(1056, '111056', 'úÏ…W§', '111056@oyoedu.ng', '7060570401', 'MUFLIHUN HIGH SCH', 'OYO', '111056'),
(1057, '111057', 'úÏ…W§', '111057@oyoedu.ng', '7060570401', 'MUFLIHUN HIGH SCH', 'OYO', '111057'),
(1058, '111058', 'úÏ…W§', '111058@oyoedu.ng', '8061366056', 'ST TERESSA COLL', 'OYO', '111058'),
(1059, '111059', 'úÏ…W§', '111059@oyoedu.ng', '', 'OUR LADY OF APOSTLES', 'ONDO', '111059'),
(1060, '111060', 'úÏ…W§', '111060@oyoedu.ng', '7036809757', 'MERIT GRAMMER SCH. AYEGUN', 'OYO', '111060'),
(1061, '111061', 'úÏ…W§', '111061@oyoedu.ng', '7060892054', 'OUR LADY OF APOSTLE', 'EDO', '111061'),
(1062, '111062', 'úÏ…W§', '111062@oyoedu.ng', '8134834354', 'GLORIFIED SCHOOL', 'AKWA IBOM', '111062'),
(1063, '111063', 'úÏ…W§', '111063@oyoedu.ng', '8034834354', 'GLORIFIED UNIQUE', 'AKWA IBOM', '111063'),
(1064, '111064', 'úÏ…W§', '111064@oyoedu.ng', '8132890829', 'BAPTIST SEC SCH', 'EBONYI', '111064'),
(1065, '111065', 'úÏ…W§', '111065@oyoedu.ng', '8168265708', 'FOREMOST INTERNATIONAL', 'BENUE', '111065'),
(1066, '111066', 'úÏ…W§', '111066@oyoedu.ng', '', '', 'BENUE', '111066'),
(1067, '111067', 'úÏ…W§', '111067@oyoedu.ng', '8067729949', 'OUR LADY OF APOSTLE', 'ANAMBRA', '111067'),
(1068, '111068', 'úÏ…W§', '111068@oyoedu.ng', '8071906609', 'ROCK OF AGE ACADE ', 'OYO', '111068'),
(1069, '111069', 'úÏ…W§', '111069@oyoedu.ng', '8055200610', 'ENIOLA INT\'L COLLEGE', 'OYO', '111069'),
(1070, '111070', 'úÏ…W§', '111070@oyoedu.ng', '8106866963', 'APANPA ROYAL SEC SCH', 'OYO', '111070'),
(1071, '111071', 'úÏ…W§', '111071@oyoedu.ng', '8032182492', 'MARINY SCHOOL ', 'OYO', '111071'),
(1072, '111072', 'úÏ…W§', '111072@oyoedu.ng', '8039288564', 'ALALIAU ATOODA', 'OYO', '111072'),
(1073, '111073', 'úÏ…W§', '111073@oyoedu.ng', '8039288564', 'ALALIAH ATODU', 'OSUN', '111073'),
(1074, '111074', 'úÏ…W§', '111074@oyoedu.ng', '9037040749', 'ASSALAM UNIQUE', 'OYO', '111074'),
(1075, '111075', 'úÏ…W§', '111075@oyoedu.ng', '8056409365', 'ALBARKA SCH', 'OYO', '111075'),
(1076, '111076', 'úÏ…W§', '111076@oyoedu.ng', '9037040749', 'ASSALAM UNIQUE', 'OYO', '111076'),
(1077, '111077', 'úÏ…W§', '111077@oyoedu.ng', '8028277579', 'GREAT FOLAD COLEGE', 'OYO', '111077'),
(1078, '111078', 'úÏ…W§', '111078@oyoedu.ng', '8032182492', 'MARINY SCH', 'OYO', '111078'),
(1079, '111079', 'úÏ…W§', '111079@oyoedu.ng', '8073322957', 'THE RIGHT ACHIEVER', 'OYO', '111079'),
(1080, '111080', 'úÏ…W§', '111080@oyoedu.ng', '8073322957', 'THE RIGHT ARCIEVERS SCH', 'OYO', '111080'),
(1081, '111081', 'úÏ…W§', '111081@oyoedu.ng', '8054078929', 'RIDWALAHI COMP.', 'OYO', '111081'),
(1082, '111082', 'úÏ…W§', '111082@oyoedu.ng', '8034233906', 'IMAM ZUBAIR', 'OYO', '111082'),
(1083, '111083', 'úÏ…W§', '111083@oyoedu.ng', '9031277982', 'EMMAMIC MODEL', 'OYO', '111083'),
(1084, '111084', 'úÏ…W§', '111084@oyoedu.ng', '8078137244', 'CAPSTONE MISSION', 'OGUN', '111084'),
(1085, '111085', 'úÏ…W§', '111085@oyoedu.ng', '9031585216', '', 'OYO', '111085'),
(1086, '111086', 'úÏ…W§', '111086@oyoedu.ng', '8186031845', 'RELIEF HIGH SCH', 'OYO', '111086'),
(1087, '111087', 'úÏ…W§', '111087@oyoedu.ng', '7014993291', 'ECWA MODEL COLLEGE', 'OYO', '111087'),
(1088, '111088', 'úÏ…W§', '111088@oyoedu.ng', '8052248094', 'AS.SALLAM MODEL', 'OYO', '111088'),
(1089, '111089', 'úÏ…W§', '111089@oyoedu.ng', '8052248094', 'ASSALAM MODEL', 'OYO', '111089'),
(1090, '111090', 'úÏ…W§', '111090@oyoedu.ng', '8054393037', 'PEOPLE\'S GIRL GRAMMAR SCHOOL', 'OYO', '111090'),
(1091, '111091', 'úÏ…W§', '111091@oyoedu.ng', '8023677554', 'OLUYOLE EST. GRAMMAR', 'OYO', '111091'),
(1092, '111092', 'úÏ…W§', '111092@oyoedu.ng', '8135125157', 'OGUNMULA HIGH', 'EDO', '111092'),
(1093, '111093', 'úÏ…W§', '111093@oyoedu.ng', '8103755359', 'COMMAND DAY SEC SCH', 'OYO', '111093'),
(1094, '111094', 'úÏ…W§', '111094@oyoedu.ng', '8060446390', 'COMMUNITY GRAMMER', 'OYO', '111094'),
(1095, '111095', 'úÏ…W§', '111095@oyoedu.ng', '8051534608', 'OYO STATE COMP MODEL COLLEGE', 'OYO', '111095'),
(1096, '111096', 'úÏ…W§', '111096@oyoedu.ng', '8038566531', 'OYO STATE COMP MODEL COLLEGE', 'OYO', '111096'),
(1097, '111097', 'úÏ…W§', '111097@oyoedu.ng', '7032025587', 'ST TERESSA COLL', 'EDO', '111097'),
(1098, '111098', 'úÏ…W§', '111098@oyoedu.ng', '7032025587', 'ST.THERESA\'S COLLEGE', 'EDO', '111098'),
(1099, '111099', 'úÏ…W§', '111099@oyoedu.ng', '8085576112', 'ADEM MODEL SCH', 'OYO', '111099'),
(1100, '111100', 'úÏ…W§', '111100@oyoedu.ng', '8129961940', 'SACRED HEART PRIV.SCH', 'OGUN', '111100'),
(1101, '111101', 'úÏ…W§', '111101@oyoedu.ng', '803094844', 'ROYAL SEED GROUP OF SCH', 'EKITI', '111101'),
(1102, '111102', 'úÏ…W§', '111102@oyoedu.ng', '8167358325', 'ST ANNES SCH', 'OSUN', '111102'),
(1103, '111103', 'úÏ…W§', '111103@oyoedu.ng', '8101691082', 'BRIGHT BRAINY SCH', 'OSUN', '111103'),
(1104, '111104', 'úÏ…W§', '111104@oyoedu.ng', '8039271255', 'ST.ANNES', 'KWARA', '111104'),
(1105, '111105', 'úÏ…W§', '111105@oyoedu.ng', '8039271255', 'ST. ANNES SCHOOL', 'KWARA', '111105'),
(1106, '111106', 'úÏ…W§', '111106@oyoedu.ng', '8151144121', 'COMMUNITY SEC SCH', 'OYO', '111106'),
(1107, '111107', 'úÏ…W§', '111107@oyoedu.ng', '8113110103', 'BOYS HIGH SCHOOL', 'OYO', '111107'),
(1108, '111108', 'úÏ…W§', '111108@oyoedu.ng', '8056371208', 'PETER MORENNICS', 'OYO', '111108'),
(1109, '111109', 'úÏ…W§', '111109@oyoedu.ng', '8055301184', 'GCI APATA', 'OYO', '111109'),
(1110, '111110', 'úÏ…W§', '111110@oyoedu.ng', '8056549727', 'AL-IKLAS INT PRI', 'OYO', '111110'),
(1111, '111111', 'úÏ…W§', '111111@oyoedu.ng', '9072099798', 'HEART FORD PRIVATE SCH', 'OYO', '111111'),
(1112, '111112', 'úÏ…W§', '111112@oyoedu.ng', '8071178256', 'FOREMOST SECONDARY SCH', 'OYO', '111112'),
(1113, '111113', 'úÏ…W§', '111113@oyoedu.ng', '8052440969', 'ARCIEVERS SCHOOL', 'OSUN', '111113'),
(1114, '111114', 'úÏ…W§', '111114@oyoedu.ng', '8159545594', 'PEACE INT\'L COLLEGE', 'OYO', '111114'),
(1115, '111115', 'úÏ…W§', '111115@oyoedu.ng', '8056466385', 'CALCULUS COLLEGE', 'BENUE', '111115'),
(1116, '111116', 'úÏ…W§', '111116@oyoedu.ng', '7028947438', 'GLORIOUS COLLEGE ', 'KOGI', '111116'),
(1117, '111117', 'úÏ…W§', '111117@oyoedu.ng', '8149508912', 'FAZL-I-OMAR AHMADIYYA', 'OYO', '111117'),
(1118, '111118', 'úÏ…W§', '111118@oyoedu.ng', '7058383935', 'RHEMA CHAPEL', 'OYO', '111118'),
(1119, '111119', 'úÏ…W§', '111119@oyoedu.ng', '8038464968', 'MOUNT ZION.COM', 'OYO', '111119'),
(1120, '111120', 'úÏ…W§', '111120@oyoedu.ng', '805865505', 'PUPILS\'S GRAMMAR SCH', 'OYO', '111120'),
(1121, '111121', 'úÏ…W§', '111121@oyoedu.ng', '8058653550', 'PUPILS GIRLS GRAMMAR SCH', 'OYO', '111121'),
(1122, '111122', 'úÏ…W§', '111122@oyoedu.ng', '8058653505', 'PUPILS GIRL GRAMMAR SCH', 'OYO', '111122'),
(1123, '111123', 'úÏ…W§', '111123@oyoedu.ng', '8164068387', 'LAIRKEN INT SCH', 'OYO', '111123'),
(1124, '111124', 'úÏ…W§', '111124@oyoedu.ng', '8034105813', 'QUEENS SCH', 'OSUN', '111124'),
(1125, '111125', 'úÏ…W§', '111125@oyoedu.ng', '8035805994', 'ANGLICAN GRAMMAR', 'OYO', '111125'),
(1126, '111126', 'úÏ…W§', '111126@oyoedu.ng', '8038464968', 'MOUNT ZION COMP', 'OYO', '111126'),
(1127, '111127', 'úÏ…W§', '111127@oyoedu.ng', '8038464968', '', 'OYO', '111127'),
(1128, '111128', 'úÏ…W§', '111128@oyoedu.ng', '8062469034', 'NEW CLAUSE COLLEGE', 'ANAMBRA', '111128'),
(1129, '111129', 'úÏ…W§', '111129@oyoedu.ng', '7039178221', 'NEW CROSS COLLEGE', 'ANAMBRA', '111129'),
(1130, '111130', 'úÏ…W§', '111130@oyoedu.ng', '8038794218', 'ABBEY STANDARD COLLEGE', 'ANAMBRA', '111130'),
(1131, '111131', 'úÏ…W§', '111131@oyoedu.ng', '8077033077', 'ST. THERASA COLLEGE', 'OYO', '111131'),
(1132, '111132', 'úÏ…W§', '111132@oyoedu.ng', '7067967178', 'EMPROR GOLD COLLEGE', 'ONDO', '111132'),
(1133, '111133', 'úÏ…W§', '111133@oyoedu.ng', '7067967178', 'EMPROR GOLD COLLEGE', 'ONDO', '111133'),
(1134, '111134', 'úÏ…W§', '111134@oyoedu.ng', '9023119913', 'SEAT OF WISDOM COMPREHENSIVE COLEGE', 'ANAMBRA', '111134'),
(1135, '111135', 'úÏ…W§', '111135@oyoedu.ng', '8060794449', 'SURE MERCY PRIVATE SCH', 'OYO', '111135'),
(1136, '111136', 'úÏ…W§', '111136@oyoedu.ng', '8153459915', 'LIVING MIRACLE HIGH SCHOOL', 'ABIA', '111136'),
(1137, '111137', 'úÏ…W§', '111137@oyoedu.ng', '8062796721', 'EPHRAIM COMP. COLLEGE', 'RIVER', '111137'),
(1138, '111138', 'úÏ…W§', '111138@oyoedu.ng', '8034783109', 'BAPTIST SECONDARY', 'ABIA', '111138'),
(1139, '111139', 'úÏ…W§', '111139@oyoedu.ng', '8038584903', ' HIGHER GROUND INT\'L', 'EKITI', '111139'),
(1140, '111140', 'úÏ…W§', '111140@oyoedu.ng', '8060359994', 'BAPTIST SEC SCH', 'DELTA', '111140'),
(1141, '111141', 'úÏ…W§', '111141@oyoedu.ng', '8078886561', 'BRIGHT BRAIN ', 'OYO', '111141'),
(1142, '111142', 'úÏ…W§', '111142@oyoedu.ng', '8055955578', 'SHARPMAN COLLEGE', 'IMO', '111142'),
(1143, '111143', 'úÏ…W§', '111143@oyoedu.ng', '8034274495', 'FRONT MODEL COLLEGE', 'OYO', '111143'),
(1144, '111144', 'úÏ…W§', '111144@oyoedu.ng', '8055859973', 'AL-KITAB MODEL ', 'OYO', '111144'),
(1145, '111145', 'úÏ…W§', '111145@oyoedu.ng', '8033660982', 'AL-ISLAMIYAH MODEL SCHOOL', 'OYO', '111145'),
(1146, '111146', 'úÏ…W§', '111146@oyoedu.ng', '8130774646', 'OUR LADY OF APOSTLE', 'ONDO', '111146'),
(1147, '111147', 'úÏ…W§', '111147@oyoedu.ng', '8050311463', 'OUR LADY OF APOSTLE', 'EKITI', '111147'),
(1148, '111148', 'úÏ…W§', '111148@oyoedu.ng', '7012710254', 'FOLA MODEL SCHOOL', 'OGUN', '111148'),
(1149, '111149', 'úÏ…W§', '111149@oyoedu.ng', '8114655551', 'SEKINO GLORY SCH', 'OYO', '111149'),
(1150, '111150', 'úÏ…W§', '111150@oyoedu.ng', '8025253853', 'IMG MORE PLANTA', 'OSUN', '111150'),
(1151, '111151', 'úÏ…W§', '111151@oyoedu.ng', '8056017432', 'LIVING MIRACLE HIGH SCHOOL', 'OSUN', '111151'),
(1152, '111152', 'úÏ…W§', '111152@oyoedu.ng', '8065344403', 'ROCHAS FOUNDATION', 'OGUN', '111152'),
(1153, '111153', 'úÏ…W§', '111153@oyoedu.ng', '8100266888', 'GREAT GRACE COLLEGE', 'ANAMBRA', '111153'),
(1154, '111154', 'úÏ…W§', '111154@oyoedu.ng', '7032328078', 'DE-PIONEER COLLEGE', 'EKITI', '111154'),
(1155, '111155', 'úÏ…W§', '111155@oyoedu.ng', '9051029398', 'AL-WASIU MODEL', 'OYO', '111155'),
(1156, '111156', 'úÏ…W§', '111156@oyoedu.ng', '8037924067', 'TRIUMPH SECONDARY SCH', 'OYO', '111156'),
(1157, '111157', 'úÏ…W§', '111157@oyoedu.ng', '8033820090', 'UPPER STANDARD SEC.SCH', 'EDO', '111157'),
(1158, '111158', 'úÏ…W§', '111158@oyoedu.ng', '8079796090', 'EYINNI GRAMMAR SCH', 'OYO', '111158'),
(1159, '111159', 'úÏ…W§', '111159@oyoedu.ng', '7034692552', 'ST.ANNES', 'ABIA', '111159'),
(1160, '111160', 'úÏ…W§', '111160@oyoedu.ng', '9027368578', 'ST THERESA\'S COLLEGE', 'OYO', '111160'),
(1161, '111161', 'úÏ…W§', '111161@oyoedu.ng', '7069565483', 'FRONT RUNNERSCH', 'OSUN', '111161'),
(1162, '111162', 'úÏ…W§', '111162@oyoedu.ng', '7069565483', 'FRONTRUNERS', 'OSUN', '111162'),
(1163, '111163', 'úÏ…W§', '111163@oyoedu.ng', '8075475500', 'STARGATE INT\'L', 'OYO', '111163'),
(1164, '111164', 'úÏ…W§', '111164@oyoedu.ng', '8038044940', 'ST BRIDGS SECONDARY SCH', 'OYO', '111164'),
(1165, '111165', 'úÏ…W§', '111165@oyoedu.ng', '7067011715', 'SUNDORA INTL', 'OGUN', '111165'),
(1166, '111166', 'úÏ…W§', '111166@oyoedu.ng', '9029361850', 'OUR LADY OF APOSTLE', 'OGUN', '111166'),
(1167, '111167', 'úÏ…W§', '111167@oyoedu.ng', '8031100705', 'JOY SEC SCH', 'KWARA', '111167'),
(1168, '311168', 'úÏ…W§', '311168@oyoedu.ng', '7052249960', 'ST. ANNES SCH', 'OYO', '311168'),
(1169, '111169', 'úÏ…W§', '111169@oyoedu.ng', '9076114929', 'METHODIST SECONDARY SCH', 'OYO', '111169'),
(1170, '111170', 'úÏ…W§', '111170@oyoedu.ng', '8035671439', 'EMPEROR GOLD COILLEGE', 'EDO', '111170'),
(1171, '111171', 'úÏ…W§', '111171@oyoedu.ng', '8060739654', 'GOVERNMENT COLLEGE IBADAN', 'EDO', '111171'),
(1172, '111172', 'úÏ…W§', '111172@oyoedu.ng', '8035629666', 'GREAT GRACE COLLEGE', 'IMO', '111172'),
(1173, '111173', 'úÏ…W§', '111173@oyoedu.ng', '8129073801', 'UPPER STANDARD', 'OYO', '111173'),
(1174, '111174', 'úÏ…W§', '111174@oyoedu.ng', '8032446867', 'KINGDOM SCH', 'OYO', '111174'),
(1175, '111175', 'úÏ…W§', '111175@oyoedu.ng', '8032446867', 'KINGDOM SCHOOL', 'OYO', '111175'),
(1176, '111176', 'úÏ…W§', '111176@oyoedu.ng', '8036875051', 'ARMY DAY HIGH SCH', 'OYO', '111176'),
(1177, '111177', 'úÏ…W§', '111177@oyoedu.ng', '8119587573', 'ANGLICAN SEC. SCH.', 'OGUN', '111177'),
(1178, '111178', 'úÏ…W§', '111178@oyoedu.ng', '8034118161', 'BAPTIST SEC. SCH.', 'OYO', '111178'),
(1179, '111179', 'úÏ…W§', '111179@oyoedu.ng', '8035873466', 'SUNDORA PRIVATE SCH', 'NIGER ', '111179'),
(1180, '111180', 'úÏ…W§', '111180@oyoedu.ng', '8067845858', 'YETAB GROUP OF SCH', 'EKITI', '111180'),
(1181, '111181', 'úÏ…W§', '111181@oyoedu.ng', '9058532559', 'FOLATEYO UNIQUE', 'EDO', '111181'),
(1182, '111182', 'úÏ…W§', '111182@oyoedu.ng', '9058532559', 'FOLATAYO UNIQUE PRIV.SCH', 'EDO', '111182'),
(1183, '111183', 'úÏ…W§', '111183@oyoedu.ng', '8038551572', 'ADEM SEC SCHOOL', 'OSUN', '111183'),
(1184, '111184', 'úÏ…W§', '111184@oyoedu.ng', '8033739192', 'NEWLIFE COLLEGE', 'OYO', '111184'),
(1185, '111185', 'úÏ…W§', '111185@oyoedu.ng', '8107988899', 'IFE OLUWA COLLEGE', 'OYO', '111185'),
(1186, '111186', 'úÏ…W§', '111186@oyoedu.ng', '9135682434', 'ADEM GROUP', 'OYO', '111186'),
(1187, '111187', 'úÏ…W§', '111187@oyoedu.ng', '8060001320', 'ADEM GROUP OF SCH', 'OYO', '111187'),
(1188, '111188', 'úÏ…W§', '111188@oyoedu.ng', '8060483309', 'GREAT GRACE CAMPUS', 'EKITI', '111188'),
(1189, '111189', 'úÏ…W§', '111189@oyoedu.ng', '8056490369', 'ABBAR AILFA COMM SCH', 'OYO', '111189'),
(1190, '111190', 'úÏ…W§', '111190@oyoedu.ng', '8113507091', 'IJEBU ODE GRAMMER SCH', 'OGUN', '111190'),
(1191, '111191', 'úÏ…W§', '111191@oyoedu.ng', '8033698444', 'ADEM GROUP OF SCH', 'OSUN', '111191'),
(1192, '111192', 'úÏ…W§', '111192@oyoedu.ng', '9038094224', 'QUEEN\'S SCHOOL', 'OYO', '111192'),
(1193, '111193', 'úÏ…W§', '111193@oyoedu.ng', '8062373488', 'FED. COLL OF EDU', 'KOGI', '111193'),
(1194, '111194', 'úÏ…W§', '111194@oyoedu.ng', '8058277988', 'OKE BOLA COMPREHENSIVE HIGH SCH', 'BENUE', '111194'),
(1195, '111195', 'úÏ…W§', '111195@oyoedu.ng', '8058277988', 'OKE BOLA COMPREHENSIVE', 'BENUE', '111195'),
(1196, '111196', 'úÏ…W§', '111196@oyoedu.ng', '7033955612', 'OKE BOLA COMP HIGH SCH', 'BENUE', '111196'),
(1197, '111197', 'úÏ…W§', '111197@oyoedu.ng', '8163319607', 'GREAT STAR INT\'L SCH', 'OYO', '111197'),
(1198, '111198', 'úÏ…W§', '111198@oyoedu.ng', '8163319607', 'BHIS', 'KWARA', '111198'),
(1199, '111199', 'úÏ…W§', '111199@oyoedu.ng', '8035214404', 'BOYS HIGH SCHOOL', 'KWARA', '111199'),
(1200, '111200', 'úÏ…W§', '111200@oyoedu.ng', '8058334609', 'SEAT OF WISDOM', 'OSUN', '111200'),
(1201, '111201', 'úÏ…W§', '111201@oyoedu.ng', '8038410593', 'REFORMER COLLEGE', 'KWARA', '111201'),
(1202, '111202', 'úÏ…W§', '111202@oyoedu.ng', '8038410593', 'REFORMER COLL', 'KWARA', '111202'),
(1203, '111203', 'úÏ…W§', '111203@oyoedu.ng', '8036617657', 'COMMUNITY GRAMMER', 'OYO', '111203'),
(1204, '111204', 'úÏ…W§', '111204@oyoedu.ng', '9014505068', 'IBADAN GRAMMAR SCH', 'KOGI', '111204'),
(1205, '111205', 'úÏ…W§', '111205@oyoedu.ng', '7063262575', 'SAM JOHN TALENT', 'KWARA', '111205'),
(1206, '111206', 'úÏ…W§', '111206@oyoedu.ng', '8058334609', 'ARCIEVERS MODEL SCH', 'OYO', '111206'),
(1207, '111207', 'úÏ…W§', '111207@oyoedu.ng', '8036012768', 'COMMUNITY GRAMMAR SCH', 'OYO', '111207'),
(1208, '111208', 'úÏ…W§', '111208@oyoedu.ng', '8036012768', '', 'OYO', '111208'),
(1209, '111209', 'úÏ…W§', '111209@oyoedu.ng', '9032320928', '', 'OYO', '111209'),
(1210, '111210', 'úÏ…W§', '111210@oyoedu.ng', '8163315024', 'DIVINE MODEL', 'KOGI', '111210'),
(1211, '111211', 'úÏ…W§', '111211@oyoedu.ng', '7082288510', 'APENI ONIYERI SECSCH', 'OYO', '111211'),
(1212, '111212', 'úÏ…W§', '111212@oyoedu.ng', '7082288510', 'ROSE OF SHARON SCHOOL', 'OGUN', '111212'),
(1213, '111213', 'úÏ…W§', '111213@oyoedu.ng', '8163071767', 'ROSE OF SHARON SCHOOL', 'OGUN', '111213'),
(1214, '111214', 'úÏ…W§', '111214@oyoedu.ng', '7035239810', 'EHINNI COMMUNITY ORITA CHALLENGE', 'ABIA', '111214'),
(1215, '111215', 'úÏ…W§', '111215@oyoedu.ng', '8067203748', 'FEDERAL SCIENCE AND TECHNOLOGY', 'ABIA', '111215'),
(1216, '111216', 'úÏ…W§', '111216@oyoedu.ng', '8048286363', 'SEBOL SCHOOL', 'OGUN', '111216'),
(1217, '111217', 'úÏ…W§', '111217@oyoedu.ng', '8038784540', 'COMMAND SCHOOL', 'OYO', '111217'),
(1218, '111218', 'úÏ…W§', '111218@oyoedu.ng', '8054115433', 'COMMAND SCHOOL', 'OYO', '111218'),
(1219, '111219', 'úÏ…W§', '111219@oyoedu.ng', '8085077077', 'ALLAHU NOOR COMP', 'OYO', '111219'),
(1220, '111220', 'úÏ…W§', '111220@oyoedu.ng', '8102747721', 'SCHOLARS ACADEMY', 'OYO', '111220'),
(1221, '111221', 'úÏ…W§', '111221@oyoedu.ng', '802899092', 'ANSARUDEEN', 'OYO', '111221'),
(1222, '111222', 'úÏ…W§', '111222@oyoedu.ng', '8053348989', 'HILL CREST HIGH SCHOOL', 'OYO', '111222'),
(1223, '111223', 'úÏ…W§', '111223@oyoedu.ng', '8052210190', 'AL-SALAM SCHOL', 'OYO', '111223'),
(1224, '111224', 'úÏ…W§', '111224@oyoedu.ng', '8052210190', 'OYO GOVERNMENT', 'OYO', '111224'),
(1225, '111225', 'úÏ…W§', '111225@oyoedu.ng', '9064181289', 'OYO GOVERNMENT', 'OYO', '111225'),
(1226, '111226', 'úÏ…W§', '111226@oyoedu.ng', '8063384253', 'ST.THERESA\'S COLLEGE', 'OYO', '111226'),
(1227, '111227', 'úÏ…W§', '111227@oyoedu.ng', '', 'EPHRAM KIDS ', 'OYO', '111227'),
(1228, '111228', 'úÏ…W§', '111228@oyoedu.ng', '8138700790', 'OLUMIDE HEIGHT', 'OYO', '111228'),
(1229, '111229', 'úÏ…W§', '111229@oyoedu.ng', '8078984694', 'GOVERNMENT COLLEGE', 'OYO', '111229'),
(1230, '111230', 'úÏ…W§', '111230@oyoedu.ng', '8163317960', 'BEULAH MODEL COLLEGE', 'OGUN', '111230'),
(1231, '111231', 'úÏ…W§', '111231@oyoedu.ng', '8034382718', 'BRIGHT BRAIN', 'OYO', '111231'),
(1232, '111232', 'úÏ…W§', '111232@oyoedu.ng', '8066571290', 'OYSCO COMP.', 'OYO', '111232'),
(1233, '111233', 'úÏ…W§', '111233@oyoedu.ng', '7035576740', 'IBHS', 'ABIA', '111233'),
(1234, '111234', 'úÏ…W§', '111234@oyoedu.ng', '8033930545', 'ST.BOYS HIGH SCH', 'EBONYI', '111234'),
(1235, '111235', 'úÏ…W§', '111235@oyoedu.ng', '8077162673', 'ST ANNES JUNIOR SCH', 'OYO', '111235'),
(1236, '111236', 'úÏ…W§', '111236@oyoedu.ng', '8077546836', 'AMAZING GRACE INT\'L', 'OYO', '111236'),
(1237, '111237', 'úÏ…W§', '111237@oyoedu.ng', '9133101973', 'IBHS', 'ANAMBRA', '111237'),
(1238, '111238', 'úÏ…W§', '111238@oyoedu.ng', '8077546836', 'FUTURE LEADERS', 'OYO', '111238'),
(1239, '111239', 'úÏ…W§', '111239@oyoedu.ng', '8067190584', 'ST.ANNES', 'OYO', '111239'),
(1240, '111240', 'úÏ…W§', '111240@oyoedu.ng', '7052183059', 'ST.ANNES SCHOOL', 'OYO', '111240'),
(1241, '111241', 'úÏ…W§', '111241@oyoedu.ng', '8033598148', 'SUCCESS ARCHIEVER', 'EKITI', '111241'),
(1242, '111242', 'úÏ…W§', '111242@oyoedu.ng', '7065076199', 'VIRTUOUS COLLEGE ELEBU', 'KOGI', '111242'),
(1243, '111243', 'úÏ…W§', '111243@oyoedu.ng', '8103835617', 'ROCK OF AGES', 'EKITI', '111243'),
(1244, '111244', 'úÏ…W§', '111244@oyoedu.ng', '7055980777', 'ST.LUKES COLLEGE MOLETE', 'ONDO', '111244'),
(1245, '111245', 'úÏ…W§', '111245@oyoedu.ng', '8035629854', 'CROWN COLLEGE', 'OYO', '111245'),
(1246, '111246', 'úÏ…W§', '111246@oyoedu.ng', '8161651980', 'CHRIST NATIONAL', 'LAGOS', '111246'),
(1247, '111247', 'úÏ…W§', '111247@oyoedu.ng', '8064853770', 'VIRTUOS HIGH SCHOOL', 'OYO', '111247'),
(1248, '111248', 'úÏ…W§', '111248@oyoedu.ng', '7033192691', 'VICTIOUS HIGH SCHOOL', 'OYO', '111248'),
(1249, '111249', 'úÏ…W§', '111249@oyoedu.ng', '9011357072', 'SUCCESS ARCEIVERS INT\'L ', 'OYO', '111249'),
(1250, '111250', 'úÏ…W§', '111250@oyoedu.ng', '8066421871', 'ATANDA HIGH SCH OLUYOLE', 'KOGI', '111250'),
(1251, '111251', 'úÏ…W§', '111251@oyoedu.ng', '7010287332', 'ST.ANNES SCHOOL', 'KWARA', '111251'),
(1252, '111252', 'úÏ…W§', '111252@oyoedu.ng', '8059536595', 'BRIGHTEST STAR COLLEGE', 'OGUN', '111252'),
(1253, '111253', 'úÏ…W§', '111253@oyoedu.ng', '7037167700', 'CROWN COLLEGE', 'OYO', '111253'),
(1254, '111254', 'úÏ…W§', '111254@oyoedu.ng', '', 'DIVINE HERITAGE', 'OYO', '111254'),
(1255, '111255', 'úÏ…W§', '111255@oyoedu.ng', '7037167700', 'ST.GABRIEL GRAMMAR SCH', 'EKITI', '111255'),
(1256, '111256', 'úÏ…W§', '111256@oyoedu.ng', '8024500963', 'ST.GABRIEL GRAMMAR SCH', 'EKITI', '111256'),
(1257, '111257', 'úÏ…W§', '111257@oyoedu.ng', '8035776556', 'PASSION HOME SCHOOLS', 'OGUN', '111257'),
(1258, '111258', 'úÏ…W§', '111258@oyoedu.ng', '7069417869', 'GCI', '', '111258'),
(1259, '111259', 'úÏ…W§', '111259@oyoedu.ng', '8038061185', 'COMMAND SCH', 'KWARA', '111259'),
(1260, '111260', 'úÏ…W§', '111260@oyoedu.ng', '8131939303', 'THE LIGHT ACADEMY', 'OYO', '111260'),
(1261, '111261', 'úÏ…W§', '111261@oyoedu.ng', '8034941620', 'GOVERNMENT COLLEGE', 'OYO', '111261'),
(1262, '111262', 'úÏ…W§', '111262@oyoedu.ng', '7069352295', 'COMMAND SEC. SCH.', 'OYO', '111262'),
(1263, '111263', 'úÏ…W§', '111263@oyoedu.ng', '9073698420', 'ST.THERESA\'S SCHOOL', 'OSUN', '111263'),
(1264, '111264', 'úÏ…W§', '111264@oyoedu.ng', '8131939308', 'BAPTIST SEC SCH', 'OYO', '111264'),
(1265, '111265', 'úÏ…W§', '111265@oyoedu.ng', '8033258159', 'COMMAND SEC. SCH.', 'OYO', '111265'),
(1266, '111266', 'úÏ…W§', '111266@oyoedu.ng', '8033258159', 'THE LIGHT ACADEMY', 'OSUN', '111266'),
(1267, '111267', 'úÏ…W§', '111267@oyoedu.ng', '8039486283', 'THE LIGHT ACADEMY', 'OSUN', '111267'),
(1268, '111268', 'úÏ…W§', '111268@oyoedu.ng', '8065580101', 'IGBO ORA HIGH SCH', 'OYO', '111268'),
(1269, '111269', 'úÏ…W§', '111269@oyoedu.ng', '8034303411', 'AL-AWAL SEC SCH AMULOKO', 'OYO', '111269'),
(1270, '111270', 'úÏ…W§', '111270@oyoedu.ng', '8061681645', 'UMMUL QUROH', 'OYO', '111270'),
(1271, '111271', 'úÏ…W§', '111271@oyoedu.ng', '8036969479', 'GOVERNMENT COLLEGE', 'OYO', '111271'),
(1272, '111272', 'úÏ…W§', '111272@oyoedu.ng', '7037408282', 'SUNSHINE COLLEGE', 'OYO', '111272'),
(1273, '111273', 'úÏ…W§', '111273@oyoedu.ng', '8066708891', 'METHODIST GRAMMER SCH', 'KWARA', '111273'),
(1274, '111274', 'úÏ…W§', '111274@oyoedu.ng', '8169852020', 'MOBADUK INT\'L', 'OSUN', '111274'),
(1275, '111275', 'úÏ…W§', '111275@oyoedu.ng', '7061280298', 'BEST BRAIN COLLEGE', 'OYO', '111275'),
(1276, '111276', 'úÏ…W§', '111276@oyoedu.ng', '8025214156', 'ST. ANNES SCH', 'OYO', '111276'),
(1277, '111277', 'úÏ…W§', '111277@oyoedu.ng', '9028026880', 'MADIBO INT\'L GROUP OF SCH', 'OYO', '111277'),
(1278, '111278', 'úÏ…W§', '111278@oyoedu.ng', '8060999759', 'AL-FATHA INT\'L', 'OYO', '111278'),
(1279, '111279', 'úÏ…W§', '111279@oyoedu.ng', '8032657125', 'ST DAVID SCH', 'OYO', '111279'),
(1280, '111280', 'úÏ…W§', '111280@oyoedu.ng', '8056139126', 'ST.MARY SCHOOL', 'OYO', '111280'),
(1281, '111281', 'úÏ…W§', '111281@oyoedu.ng', '8056139126', 'MIGRATION SCHOOL', 'OYO', '111281'),
(1282, '111282', 'úÏ…W§', '111282@oyoedu.ng', '8035218052', 'MIGRATION SCH', 'OYO', '111282'),
(1283, '111283', 'úÏ…W§', '111283@oyoedu.ng', '9020669743', 'UPPER STANDARD COLLEGE', 'OSUN', '111283'),
(1284, '111284', 'úÏ…W§', '111284@oyoedu.ng', '8055282275', 'STAR MODEL SCH', 'OYO', '111284'),
(1285, '111285', 'úÏ…W§', '111285@oyoedu.ng', '8076767864', 'IKOLABA GRAMAR SCH ', 'OYO', '111285'),
(1286, '111286', 'úÏ…W§', '111286@oyoedu.ng', '8022256778', 'ALLAHU-UL-AYU', 'OYO', '111286'),
(1287, '111287', 'úÏ…W§', '111287@oyoedu.ng', '7034877219', 'COMMUNITY SCH', 'OYO', '111287'),
(1288, '111288', 'úÏ…W§', '111288@oyoedu.ng', '8057885709', 'ST TERRESSA ', 'OGUN', '111288'),
(1289, '111289', 'úÏ…W§', '111289@oyoedu.ng', '8077361704', 'IMG GRAMM SCH', 'IMO', '111289'),
(1290, '111290', 'úÏ…W§', '111290@oyoedu.ng', '8031163907', 'IMG', 'IMO', '111290'),
(1291, '111291', 'úÏ…W§', '111291@oyoedu.ng', '8034274209', 'ST JAMES CATHEDRAL', 'ANAMBRA', '111291'),
(1292, '111292', 'úÏ…W§', '111292@oyoedu.ng', '8030744765', 'FRUIT OFLOVE COLLEGE.', 'OSUN', '111292'),
(1293, '111293', 'úÏ…W§', '111293@oyoedu.ng', '8037427887', 'SAMJOAN SEC SCH', 'OSUN', '111293'),
(1294, '111294', 'úÏ…W§', '111294@oyoedu.ng', '8039509718', 'ROSCHAS FOUNDATION', 'KWARA', '111294'),
(1295, '111295', 'úÏ…W§', '111295@oyoedu.ng', '8066484090', 'CALVARY INT\'L SCH', 'KWARA', '111295'),
(1296, '111296', 'úÏ…W§', '111296@oyoedu.ng', '7011999757', 'ELEYELE BAPTIST COLLEGE', 'JOS', '111296'),
(1297, '111297', 'úÏ…W§', '111297@oyoedu.ng', '9078232516', 'DOLAB INT SCH', 'OGUN', '111297'),
(1298, '111298', 'úÏ…W§', '111298@oyoedu.ng', '8036661757', 'MIE-REHOBOTH', 'KOGI', '111298'),
(1299, '111299', 'úÏ…W§', '111299@oyoedu.ng', '8038999112', 'ASSKIF INT\'L', 'OYO', '111299'),
(1300, '111300', 'úÏ…W§', '111300@oyoedu.ng', '7014350708', 'ASSKIF INT,L COLLEGE', 'OYO', '111300'),
(1301, '111301', 'úÏ…W§', '111301@oyoedu.ng', '8076294470', 'FORTRESS PRIVATE SCH.', 'OSUN', '111301'),
(1302, '111302', 'úÏ…W§', '111302@oyoedu.ng', '8160615869', 'EMPEROR GOLD', 'EDO', '111302'),
(1303, '111303', 'úÏ…W§', '111303@oyoedu.ng', '8029824980', 'EVENGEL COLLEGE', 'ABIA', '111303'),
(1304, '111304', 'úÏ…W§', '111304@oyoedu.ng', '7066759079', 'ST.THERESA\'S SEC', 'DELTA', '111304'),
(1305, '111305', 'úÏ…W§', '111305@oyoedu.ng', '8052312220', 'SAINT LOUIS', 'IMO', '111305'),
(1306, '111306', 'úÏ…W§', '111306@oyoedu.ng', '7037861938', 'INI OLUWA HIGH SCHOOL', 'ONDO', '111306'),
(1307, '111307', 'úÏ…W§', '111307@oyoedu.ng', '8063868051', 'POSSIBILITY MODEL SCH', 'AKWA IBOM', '111307'),
(1308, '111308', 'úÏ…W§', '111308@oyoedu.ng', '8022571560', 'CHRIST HERITAGE', 'AKWA-IBOM', '111308'),
(1309, '111309', 'úÏ…W§', '111309@oyoedu.ng', '8035324917', 'ROYAL GATE SCH', 'OGUN', '111309'),
(1310, '111310', 'úÏ…W§', '111310@oyoedu.ng', '8162645456', 'ANSARU-DEEN', 'OGUN', '111310'),
(1311, '111311', 'úÏ…W§', '111311@oyoedu.ng', '8114764876', 'NEW DAWN COMPREHENSIVE', 'OYO', '111311'),
(1312, '111312', 'úÏ…W§', '111312@oyoedu.ng', '8058687481', 'AL-QALAM COLLEGE', 'OYO', '111312'),
(1313, '111313', 'úÏ…W§', '111313@oyoedu.ng', '9081258901', 'D WAY GROUP OF SCHOOL', 'OYO', '111313'),
(1314, '111314', 'úÏ…W§', '111314@oyoedu.ng', '8056663331', 'UNION BAPTIST', 'OYO', '111314'),
(1315, '111315', 'úÏ…W§', '111315@oyoedu.ng', '8056663331', 'UNION BAPTIST', 'OYO', '111315'),
(1316, '111316', 'úÏ…W§', '111316@oyoedu.ng', '8077564287', 'ROCHAS FOUNDATION', 'OYO', '111316'),
(1317, '111317', 'úÏ…W§', '111317@oyoedu.ng', '7012367906', 'SEAT OF WISDOM COMP', 'IMO', '111317'),
(1318, '111318', 'úÏ…W§', '111318@oyoedu.ng', '8056435570', 'MARADE SCHOLARS', 'DELTA', '111318'),
(1319, '111319', 'úÏ…W§', '111319@oyoedu.ng', '7066922859', 'ST.THERESA OKE-ADO', 'OSUN', '111319'),
(1320, '111320', 'úÏ…W§', '111320@oyoedu.ng', '8157279666', 'ANWARUSLAM', 'OYO', '111320'),
(1321, '111321', 'úÏ…W§', '111321@oyoedu.ng', '8055377666', 'NOBLE STANDARD SCH', 'OYO', '111321'),
(1322, '111322', 'úÏ…W§', '111322@oyoedu.ng', '8032287224', 'OGBERE COMM. SCHOOL', 'OYO', '111322'),
(1323, '111323', 'úÏ…W§', '111323@oyoedu.ng', '8124253117', 'GOVERNMENT COLLEGE', 'OYO', '111323'),
(1324, '111324', 'úÏ…W§', '111324@oyoedu.ng', '8067970868', 'FRUIT OF LOVE', 'OSUN', '111324'),
(1325, '111325', 'úÏ…W§', '111325@oyoedu.ng', '8064664222', 'GLORIOUS COLLEGE', 'OYO', '111325'),
(1326, '111326', 'úÏ…W§', '111326@oyoedu.ng', '7055036188', 'ONYX ROYAL COLLEGE', 'OSUN', '111326'),
(1327, '111327', 'úÏ…W§', '111327@oyoedu.ng', '8123608884', 'GSGS', 'LAGOS', '111327'),
(1328, '111328', 'úÏ…W§', '111328@oyoedu.ng', '7086230751', 'PROVIDENCE HIGH SCHOOL', 'OYO', '111328'),
(1329, '111329', 'úÏ…W§', '111329@oyoedu.ng', '9090165743', 'HIGH FLYER COLLEGE', 'OYO', '111329'),
(1330, '111330', 'úÏ…W§', '111330@oyoedu.ng', '8055111208', 'OLUYOLE ESTATE', 'OYO', '111330'),
(1331, '111331', 'úÏ…W§', '111331@oyoedu.ng', '9022244308', 'RICHERLES ACADEMY', 'OYO', '111331'),
(1332, '111332', 'úÏ…W§', '111332@oyoedu.ng', '8056637350', 'ANGLICAN COMM GRA', 'OYO', '111332'),
(1333, '111333', 'úÏ…W§', '111333@oyoedu.ng', '8034122661', 'ORIADE COMPREHENSIVE SCH', 'OYO', '111333'),
(1334, '111334', 'úÏ…W§', '111334@oyoedu.ng', '8074041867', 'ANGLICAN GRAMMAR SCH', 'OYO', '111334'),
(1335, '111335', 'úÏ…W§', '111335@oyoedu.ng', '7055539499', 'KIDDIES EXCEL', 'KWARA', '111335'),
(1336, '111336', 'úÏ…W§', '111336@oyoedu.ng', '8053612751', 'ABADINA COLLEGE', 'OYO', '111336'),
(1337, '111337', 'úÏ…W§', '111337@oyoedu.ng', '8070807029', 'ST LUOIS SCH', 'YOBE', '111337'),
(1338, '111338', 'úÏ…W§', '111338@oyoedu.ng', '8060151764', 'TAOMI COLLEGE', 'IBADAN', '111338'),
(1339, '111339', 'úÏ…W§', '111339@oyoedu.ng', '8152128244', 'FAIZI-I-OMAR AHMDIYA', 'OYO', '111339'),
(1340, '111340', 'úÏ…W§', '111340@oyoedu.ng', '8030644485', 'ECWA MODEL', 'OYO', '111340'),
(1341, '111341', 'úÏ…W§', '111341@oyoedu.ng', '7036124208', 'IKOLABA GRAMMAR SCH', 'OYO', '111341'),
(1342, '111342', 'úÏ…W§', '111342@oyoedu.ng', '8038322304', 'ANSARUDEEN HIGH SCH', 'OYO', '111342'),
(1343, '111343', 'úÏ…W§', '111343@oyoedu.ng', '7045458247', 'RUBBIES INT COLLEGE', 'OYO', '111343'),
(1344, '111344', 'úÏ…W§', '111344@oyoedu.ng', '9031727678', 'ALIAMEED MODEL', 'OYO', '111344'),
(1345, '111345', 'úÏ…W§', '111345@oyoedu.ng', '8023726003', 'ADIB PRIVATE SCH', 'OYO', '111345'),
(1346, '111346', 'úÏ…W§', '111346@oyoedu.ng', '8028828947', 'BAPTIST GRAMMAR', 'OGUN', '111346'),
(1347, '111347', 'úÏ…W§', '111347@oyoedu.ng', '8058230049', 'ARABIC NUMERAL COLLEGE', 'OYO', '111347'),
(1348, '111348', 'úÏ…W§', '111348@oyoedu.ng', '7016138015', 'CITY ACADEMY', 'OYO', '111348'),
(1349, '111349', 'úÏ…W§', '111349@oyoedu.ng', '8054706632', 'DIVINE COLLEGE', 'OGUN', '111349'),
(1350, '111350', 'úÏ…W§', '111350@oyoedu.ng', '8073307052', 'EYINNI COMPREHENSIVE ', 'OYO', '111350'),
(1351, '111351', 'úÏ…W§', '111351@oyoedu.ng', '8060267684', 'BAPTIST SEC SCH', 'OYO', '111351'),
(1352, '111352', 'úÏ…W§', '111352@oyoedu.ng', '8050439444', 'ST GABRIAL MOKOLA', 'OYO', '111352'),
(1353, '111353', 'úÏ…W§', '111353@oyoedu.ng', '8032132487', 'MOSLEEN GRAMMAR', 'OYO', '111353'),
(1354, '111354', 'úÏ…W§', '111354@oyoedu.ng', '8056617148', 'ZUMRATUL HUJAJ', '', '111354'),
(1355, '111355', 'úÏ…W§', '111355@oyoedu.ng', ' ', 'ALBURUW SCH', 'OSUN', '111355'),
(1356, '111356', 'úÏ…W§', '111356@oyoedu.ng', '8071946151', 'SCHOLARS ACADEMY', 'OYO', '111356'),
(1357, '111357', 'úÏ…W§', '111357@oyoedu.ng', '8071946155', 'KINGSWAY COLLEGE ', 'OSUN', '111357'),
(1358, '111358', 'úÏ…W§', '111358@oyoedu.ng', '8062373488', 'KINGSWAY COLLEGE AYANRE', 'OSUN', '111358'),
(1359, '111359', 'úÏ…W§', '111359@oyoedu.ng', '8033820090', 'BAPTIS HIGH SCHOOL', 'PLATEAU', '111359'),
(1360, '111360', 'úÏ…W§', '111360@oyoedu.ng', '8062073054', 'UPPER STANDARD COLLEGE', 'EDO', '111360'),
(1361, '111361', 'úÏ…W§', '111361@oyoedu.ng', '8149141600', 'QUEENS SCH', 'DELTA', '111361'),
(1362, '111362', 'úÏ…W§', '111362@oyoedu.ng', '8107285762', 'ST. JAMES CATHEDRAL COLL.', 'ENUGU', '111362'),
(1363, '111363', 'úÏ…W§', '111363@oyoedu.ng', '7033161073', 'IMG APATA', 'OGUN', '111363'),
(1364, '111364', 'úÏ…W§', '111364@oyoedu.ng', '8053382323', 'ST.THERESA SCHOOL', 'ENUGU', '111364'),
(1365, '111365', 'úÏ…W§', '111365@oyoedu.ng', '8038074643', 'ARIYO INT\'L COLLEGE', 'DELTA', '111365'),
(1366, '111366', 'úÏ…W§', '111366@oyoedu.ng', '8038074643', 'ST.BRIGIS MOKOLA', 'IMO', '111366'),
(1367, '111367', 'úÏ…W§', '111367@oyoedu.ng', '8058343274', 'ST. BRIGIS SCH.', 'IMO', '111367'),
(1368, '111368', 'úÏ…W§', '111368@oyoedu.ng', '8034205494', 'EYINNI COMMUNITY GRAMMAR SCH', 'ANAMBRA', '111368'),
(1369, '111369', 'úÏ…W§', '111369@oyoedu.ng', '8062073053', 'ST JAMES CATHEDRAL', 'ENUGUN', '111369'),
(1370, '111370', 'úÏ…W§', '111370@oyoedu.ng', '7036434458', 'BRIGHTER SOLUTION', 'OYO', '111370'),
(1371, '111371', 'úÏ…W§', '111371@oyoedu.ng', '8075266943', 'INIOLUWA HIGH SCH', 'LAGOS', '111371'),
(1372, '111372', 'úÏ…W§', '111372@oyoedu.ng', '7038474065', 'IMAM ZUBAIR SCHOOL', 'OYO', '111372'),
(1373, '111373', 'úÏ…W§', '111373@oyoedu.ng', '7087558835', 'BRISHAT SKUR', 'IMO', '111373'),
(1374, '111374', 'úÏ…W§', '111374@oyoedu.ng', '7066759079', 'ST LOUIS MOKOLA', 'IMO', '111374'),
(1375, '111375', 'úÏ…W§', '111375@oyoedu.ng', '8136201391', 'ST. TERESA\'S COLLEGE', 'DELTA', '111375'),
(1376, '111376', 'úÏ…W§', '111376@oyoedu.ng', '8038302068', 'ST.THERESA\'S COLLEGE', 'DELTA', '111376'),
(1377, '111377', 'úÏ…W§', '111377@oyoedu.ng', '9023310094', 'FED.GOVT COLLEGE', 'ANAMBRA', '111377'),
(1378, '111378', 'úÏ…W§', '111378@oyoedu.ng', '8062449450', 'OKE-ADO BAPTIST COMP COLL', 'ABIA', '111378'),
(1379, '111379', 'úÏ…W§', '111379@oyoedu.ng', '8055306768', 'ST.CELEBS HIGH SCHOOL', 'ABIA', '111379'),
(1380, '111380', 'úÏ…W§', '111380@oyoedu.ng', '8072182087', 'SACRED HEART', 'EDO', '111380'),
(1381, '111381', 'úÏ…W§', '111381@oyoedu.ng', '7065974176', 'AL-ILAL LAGOS', 'OYO', '111381'),
(1382, '111382', 'úÏ…W§', '111382@oyoedu.ng', '8034240170', 'HIS MAJESTY SCH', 'OGUN', '111382'),
(1383, '111383', 'úÏ…W§', '111383@oyoedu.ng', '8080263952', 'ST ANNES JUNIOR SCH', 'EDO', '111383'),
(1384, '111384', 'úÏ…W§', '111384@oyoedu.ng', '8059404802', 'GREAT GRACE PRIVATE SCHOOL', 'ONDO', '111384'),
(1385, '111385', 'úÏ…W§', '111385@oyoedu.ng', '8038350278', 'RUBBIES INT COLLEGE', 'LAGOS', '111385'),
(1386, '111386', 'úÏ…W§', '111386@oyoedu.ng', '8059404802', 'OXFORD BROOKES', 'ONDO', '111386'),
(1387, '111387', 'úÏ…W§', '111387@oyoedu.ng', '8055162503', 'OXFORD BROOKES', 'ONDO', '111387'),
(1388, '111388', 'úÏ…W§', '111388@oyoedu.ng', '8025565657', 'DIVINE COLLEGE', 'KOGI', '111388'),
(1389, '111389', 'úÏ…W§', '111389@oyoedu.ng', '8057064307', 'GLORIOUS SEC SCH', 'OSUN', '111389'),
(1390, '111390', 'úÏ…W§', '111390@oyoedu.ng', '8033775200', 'SHARPMAN COLLEGE', 'ANAMBRA', '111390'),
(1391, '111391', 'úÏ…W§', '111391@oyoedu.ng', '8038152410', 'PUPILS GIRL GRAMMAR SCH', 'OYO', '111391'),
(1392, '111392', 'úÏ…W§', '111392@oyoedu.ng', '8057064307', 'PUPIL GRAMMAR SCH', 'OYO', '111392'),
(1393, '111393', 'úÏ…W§', '111393@oyoedu.ng', '8054149071', 'ALHIKMAH SCH.', 'OYO', '111393'),
(1394, '111394', 'úÏ…W§', '111394@oyoedu.ng', '8051461183', 'AL-ISLAMMIYAH', 'OYO', '111394'),
(1395, '111395', 'úÏ…W§', '111395@oyoedu.ng', '8033484185', 'BAPTIST PRIVATE OKE-APATA', 'OYO', '111395'),
(1396, '111396', 'úÏ…W§', '111396@oyoedu.ng', '8056705748', 'LARIKE COLLEGE', 'EDO', '111396'),
(1397, '111397', 'úÏ…W§', '111397@oyoedu.ng', '7063904322', 'ADEM SEC SCH', 'OGUN', '111397'),
(1398, '111398', 'úÏ…W§', '111398@oyoedu.ng', '7063904322', 'ADEM SEC SCH', 'OGUN', '111398'),
(1399, '111399', 'úÏ…W§', '111399@oyoedu.ng', '8032390949', 'THE PREMIER CORNER STONE ACADEMY', 'BENUE', '111399'),
(1400, '111400', 'úÏ…W§', '111400@oyoedu.ng', '8066462028', 'OKEBOLA COMP SCHOOL', 'OYO', '111400'),
(1401, '111401', 'úÏ…W§', '111401@oyoedu.ng', '8066462028', 'ABBEY STANDARD', 'OGUN', '111401'),
(1402, '111402', 'úÏ…W§', '111402@oyoedu.ng', '8066781602', '', 'OGUN', '111402'),
(1403, '111403', 'úÏ…W§', '111403@oyoedu.ng', '8023147671', 'YEJIDE GRAMMAR SCH', 'OYO', '111403'),
(1404, '111404', 'úÏ…W§', '111404@oyoedu.ng', '8036206116', 'ST. TERESA\'S COLLEGE', 'OYO', '111404'),
(1405, '111405', 'úÏ…W§', '111405@oyoedu.ng', '8032387901', 'LANTEM PRIVATE SCH', 'OYO', '111405'),
(1406, '111406', 'úÏ…W§', '111406@oyoedu.ng', '8033572902', 'DYNOLINKS GRP OF SCH', 'OYO', '111406'),
(1407, '111407', 'úÏ…W§', '111407@oyoedu.ng', '8033572902', 'HIGHER GROUND', 'DELTA', '111407'),
(1408, '111408', 'úÏ…W§', '111408@oyoedu.ng', '8037417313', 'HIGHER GROUND', 'DELTA', '111408'),
(1409, '111409', 'úÏ…W§', '111409@oyoedu.ng', '8034950288', 'LIVING MIRACLE', 'OYO', '111409'),
(1410, '111410', 'úÏ…W§', '111410@oyoedu.ng', '8034913730', '', 'OGUN', '111410'),
(1411, '111411', 'úÏ…W§', '111411@oyoedu.ng', '8037417313', 'IBADAN PROMINENT HEIGHT', 'OGUN', '111411'),
(1412, '111412', 'úÏ…W§', '111412@oyoedu.ng', '8037417313', 'PROMINENT HEIGHT', 'OGUN', '111412'),
(1413, '111413', 'úÏ…W§', '111413@oyoedu.ng', '8036851713', 'PROMINENT HEIGHT', 'OGUN', '111413'),
(1414, '111414', 'úÏ…W§', '111414@oyoedu.ng', '8060318100', 'BY HIS WOUND INT\'L COLLEGE', 'OSUN', '111414'),
(1415, '111415', 'úÏ…W§', '111415@oyoedu.ng', '8094170160', 'ECWA MODEL SCHOOL', 'OGUN', '111415'),
(1416, '111416', 'úÏ…W§', '111416@oyoedu.ng', '9078074602', 'ECWA MODEL COLLEGE', 'OYO', '111416'),
(1417, '111417', 'úÏ…W§', '111417@oyoedu.ng', '8084794181', 'COMP. HIGH SCHOOL', 'OGUN', '111417'),
(1418, '111418', 'úÏ…W§', '111418@oyoedu.ng', '8074377472', 'QUEENS SCH', 'OGUN', '111418'),
(1419, '111419', 'úÏ…W§', '111419@oyoedu.ng', '8126408851', 'OUR JOY COLLEGE', 'OYO', '111419'),
(1420, '111420', 'úÏ…W§', '111420@oyoedu.ng', '8055514549', 'REHOBOTH CITADELOF KNOWLEDGE', 'OGUN', '111420'),
(1421, '111421', 'úÏ…W§', '111421@oyoedu.ng', '8142397988', 'CHRIST HIGH SCH', 'OYO', '111421'),
(1422, '111422', 'úÏ…W§', '111422@oyoedu.ng', '8054226253', 'GLOBAL LIGHT MUSLIM COLLEGE', 'OYO', '111422'),
(1423, '111423', 'úÏ…W§', '111423@oyoedu.ng', '8030659296', 'SACRET HEART PRAUATIS SCH', 'OGUN', '111423'),
(1424, '111424', 'úÏ…W§', '111424@oyoedu.ng', '7057913724', 'ALKINGSDALE HIGH SCHOOL', 'OGUN', '111424'),
(1425, '111425', 'úÏ…W§', '111425@oyoedu.ng', '8109652460', 'ST TERESSA COLL', 'OYO', '111425'),
(1426, '111426', 'úÏ…W§', '111426@oyoedu.ng', '7057913724', 'GOVERNMENT COLEGE', 'DELTA', '111426'),
(1427, '111427', 'úÏ…W§', '111427@oyoedu.ng', '8033342294', 'GOVERNMENT COLLEGE', 'DELTA', '111427'),
(1428, '111428', 'úÏ…W§', '111428@oyoedu.ng', '8033342294', 'MIGHT TRUMPET INT\'L SCH', 'OYO', '111428'),
(1429, '111429', 'úÏ…W§', '111429@oyoedu.ng', '8117552347', 'MIGHTY TRUMPET INTE\'L SCHOOL', 'OYO', '111429'),
(1430, '111430', 'úÏ…W§', '111430@oyoedu.ng', '8033342294', 'MIGHT TRUMPET INT', 'OYO', '111430'),
(1431, '111431', 'úÏ…W§', '111431@oyoedu.ng', '8036191798', 'MIGHTY TRIUMPET', 'OYO', '111431'),
(1432, '111432', 'úÏ…W§', '111432@oyoedu.ng', '8033863641', 'IDIKAN BAPTIST SEC SCH', 'DELTA', '111432'),
(1433, '111433', 'úÏ…W§', '111433@oyoedu.ng', '8076675210', 'NOBLE HIGH SCH.', 'OYO', '111433'),
(1434, '111434', 'úÏ…W§', '111434@oyoedu.ng', '8038009102', 'EVER FORWARD SCH ', 'OGUN', '111434'),
(1435, '111435', 'úÏ…W§', '111435@oyoedu.ng', '8061241235', 'MASTER MODEL', 'OYO', '111435'),
(1436, '111436', 'úÏ…W§', '111436@oyoedu.ng', '8056070939', 'STARLITE COLLEGE', 'OYO', '111436'),
(1437, '111437', 'úÏ…W§', '111437@oyoedu.ng', '8056070939', 'JESUS GLORY GROUP', 'OSUN', '111437'),
(1438, '111438', 'úÏ…W§', '111438@oyoedu.ng', '8169501894', 'BODDITEL GROUP OF SCHOOL', 'OSUN', '111438'),
(1439, '111439', 'úÏ…W§', '111439@oyoedu.ng', '8066653374', 'ADEX INT\'L SCH.ORITA', 'ONDO', '111439'),
(1440, '111440', 'úÏ…W§', '111440@oyoedu.ng', '9022419254', 'BOFEL COLLEGE', 'OYO', '111440'),
(1441, '111441', 'úÏ…W§', '111441@oyoedu.ng', '', 'IKOLABA GRAMMAR SCH', 'OYO', '111441'),
(1442, '111442', 'úÏ…W§', '111442@oyoedu.ng', '8138079508', 'KOLABA GRAMM SCH', 'OYO', '111442'),
(1443, '111443', 'úÏ…W§', '111443@oyoedu.ng', '9058932559', 'IBADAN BOYS HIGH SCHOOL', 'OSUN', '111443'),
(1444, '111444', 'úÏ…W§', '111444@oyoedu.ng', '9058532559', 'FOLATEYO UNIQUE', 'OSUN', '111444'),
(1445, '111445', 'úÏ…W§', '111445@oyoedu.ng', '7049673270', 'FOLATAYO UNIQUE PRIV.SCH', 'OSUN', '111445'),
(1446, '311446', 'úÏ…W§', '311446@oyoedu.ng', '9069506517', 'ST.ANNES SCHOOL', 'OYO', '311446'),
(1447, '111447', 'úÏ…W§', '111447@oyoedu.ng', '8069313205', 'ST.THERESA\'S COLLEGE', 'OYO', '111447'),
(1448, '111448', 'úÏ…W§', '111448@oyoedu.ng', '8166468473', 'DIVINE TREASURE', 'EKITI', '111448'),
(1449, '111449', 'úÏ…W§', '111449@oyoedu.ng', '8077338795', 'MUFLINHUN SCH.', 'OYO', '111449'),
(1450, '111450', 'úÏ…W§', '111450@oyoedu.ng', '8028355494', 'ROCK OF SOLUTION', 'OYO', '111450'),
(1451, '111451', 'úÏ…W§', '111451@oyoedu.ng', '8035631555', 'EMPROR GOLD', 'OSUN', '111451'),
(1452, '111452', 'úÏ…W§', '111452@oyoedu.ng', '81066611868', 'COMMUNITY GRAMMAR SCH', 'OGUN', '111452'),
(1453, '111453', 'úÏ…W§', '111453@oyoedu.ng', '8140804695', 'ST. TERESA\'S COLLEGE', 'OYO', '111453'),
(1454, '111454', 'úÏ…W§', '111454@oyoedu.ng', '8075268608', 'ST TERRESSA ', 'OYO', '111454'),
(1455, '111455', 'úÏ…W§', '111455@oyoedu.ng', '8069326616', 'OWODE ESTATE COMM HIGH SCH', 'OYO', '111455'),
(1456, '111456', 'úÏ…W§', '111456@oyoedu.ng', '8036173770', 'THE LORD\'S FIELD COLLEGE', 'EKITI', '111456'),
(1457, '111457', 'úÏ…W§', '111457@oyoedu.ng', '8157692318', 'QUEENS SCH', 'OYO', '111457'),
(1458, '111458', 'úÏ…W§', '111458@oyoedu.ng', '8056167784', 'DOMINION COLLEGE', 'OYO', '111458'),
(1459, '111459', 'úÏ…W§', '111459@oyoedu.ng', '9034137297', 'THE CRYSTAL SCH', 'OYO', '111459'),
(1460, '111460', 'úÏ…W§', '111460@oyoedu.ng', '8160805619', 'OKEBOLA COMP SCHOOL', 'OGUN', '111460'),
(1461, '111461', 'úÏ…W§', '111461@oyoedu.ng', '8020726894', 'IMPACT COLLEGE', 'OYO', '111461'),
(1462, '111462', 'úÏ…W§', '111462@oyoedu.ng', '9022754172', 'ST.ANNE\'S JUNIOR', 'OYO', '111462'),
(1463, '111463', 'úÏ…W§', '111463@oyoedu.ng', '8103363463', 'LYDE SECONDARY SCH', 'OGUN', '111463'),
(1464, '111464', 'úÏ…W§', '111464@oyoedu.ng', '8038640148', 'MOLETE BAPTIST COLLEGE', 'OYO', '111464'),
(1465, '111465', 'úÏ…W§', '111465@oyoedu.ng', '8055456193', 'DIPLOMAT MODEL COLLEGE', 'EKITI', '111465'),
(1466, '111466', 'úÏ…W§', '111466@oyoedu.ng', '806494399', 'COMMUNITY HIGH SCHOOL', 'OYO', '111466'),
(1467, '111467', 'úÏ…W§', '111467@oyoedu.ng', '8038829301', 'ADIFASE HIGH SCH', 'OGUN', '111467'),
(1468, '111468', 'úÏ…W§', '111468@oyoedu.ng', '8164058789', 'LANTERN COMPREHENSIVE', 'EKITI', '111468'),
(1469, '111469', 'úÏ…W§', '111469@oyoedu.ng', '8053622578', 'CYMBERS INT', 'OSUN', '111469'),
(1470, '111470', 'úÏ…W§', '111470@oyoedu.ng', '8028944480', 'COMMUNITY GRAMMAR SCH', 'OGUN', '111470'),
(1471, '111471', 'úÏ…W§', '111471@oyoedu.ng', '8169383746', 'GOVERNMENT COLEGE', 'OYO', '111471'),
(1472, '111472', 'úÏ…W§', '111472@oyoedu.ng', '8169383746', 'GOVERNMENT COLLEGE', 'OYO', '111472'),
(1473, '111473', 'úÏ…W§', '111473@oyoedu.ng', '8129802129', 'ST LOUIS SCH', 'OYO', '111473'),
(1474, '111474', 'úÏ…W§', '111474@oyoedu.ng', '8034830484', 'PENVILE ACADEMY', 'OYO', '111474'),
(1475, '111475', 'úÏ…W§', '111475@oyoedu.ng', '7054523924', 'BIMBO CLASSIC ACADEMY', 'OYO', '111475'),
(1476, '111476', 'úÏ…W§', '111476@oyoedu.ng', '7038257204', 'GALAXY SEC SCHOOL', 'OGUN', '111476'),
(1477, '111477', 'úÏ…W§', '111477@oyoedu.ng', '8035451414', 'FRONT RUNNER', 'OSUN', '111477'),
(1478, '111478', 'úÏ…W§', '111478@oyoedu.ng', '8035451414', 'GLORIFIED UNIQUE COLL ', 'OGUN ', '111478'),
(1479, '111479', 'úÏ…W§', '111479@oyoedu.ng', '8072791920', 'GLORIFIED UNIQUE', 'OGUN', '111479'),
(1480, '111480', 'úÏ…W§', '111480@oyoedu.ng', '8051213263', 'IBADAN BOYS HIGH SCH', 'OYO ', '111480'),
(1481, '111481', 'úÏ…W§', '111481@oyoedu.ng', '8051213263', 'COMPREHENSIVE COLLEGE IB', 'ABIA', '111481'),
(1482, '111482', 'úÏ…W§', '111482@oyoedu.ng', '8062425589', 'COMP HIGH SCHOOL', 'ABIA', '111482'),
(1483, '111483', 'úÏ…W§', '111483@oyoedu.ng', '8062425589', 'NAOMI MODEL INT\' SCHOOL', 'OYO', '111483'),
(1484, '111484', 'úÏ…W§', '111484@oyoedu.ng', '8119006589', 'NAOMI MODEL SECSCH', 'OYO', '111484'),
(1485, '111485', 'úÏ…W§', '111485@oyoedu.ng', '8186134273', 'FIRST CLASS', 'OGUN', '111485'),
(1486, '111486', 'úÏ…W§', '111486@oyoedu.ng', '9022992311', 'DISTINCT JUBILEE INT\'L', 'OYO', '111486'),
(1487, '111487', 'úÏ…W§', '111487@oyoedu.ng', '8166795111', 'ABADINA GRAMMER SCHOOL', 'OYO', '111487'),
(1488, '111488', 'úÏ…W§', '111488@oyoedu.ng', '8065629415', 'LIVING MIRACLE', 'OGUN', '111488'),
(1489, '111489', 'úÏ…W§', '111489@oyoedu.ng', '8029490887', 'RICH ALLIES SE SCH', 'OSUN', '111489'),
(1490, '111490', 'úÏ…W§', '111490@oyoedu.ng', '8071074637', 'GRACE COLLEGE', 'OYO', '111490'),
(1491, '111491', 'úÏ…W§', '111491@oyoedu.ng', '8166795111', 'BAPTIST COMPRENSIVE COLLEGE', 'OSUN', '111491'),
(1492, '111492', 'úÏ…W§', '111492@oyoedu.ng', '7061079090', 'BAPTIST COMP. SCH', 'OSUN', '111492'),
(1493, '111493', 'úÏ…W§', '111493@oyoedu.ng', '8060617364', 'GEORGE& DUKE INT\'L', 'OSUN', '111493'),
(1494, '111494', 'úÏ…W§', '111494@oyoedu.ng', '8075331323', 'CANAN COMPREHENSIVE COLLEGE', 'OYO', '111494'),
(1495, '111495', 'úÏ…W§', '111495@oyoedu.ng', '8056979792', 'QUEENS SCH', '', '111495'),
(1496, '111496', 'úÏ…W§', '111496@oyoedu.ng', '8060232510', 'LEADERS ACADEMY', 'OYO', '111496'),
(1497, '111497', 'úÏ…W§', '111497@oyoedu.ng', '8050969145', 'GOD\'S GRACE SEC SCH', 'DELTA', '111497'),
(1498, '111498', 'úÏ…W§', '111498@oyoedu.ng', '8038360910', 'MIGHTY MIRACLE', 'OSUN', '111498'),
(1499, '111499', 'úÏ…W§', '111499@oyoedu.ng', '8062409444', 'BRILLIANT STAR', 'OYO', '111499'),
(1500, '111500', 'úÏ…W§', '111500@oyoedu.ng', '8035234527', 'MERCYSEAT PRIVATE SCH.', 'OYO', '111500'),
(1501, '111501', 'úÏ…W§', '111501@oyoedu.ng', '8128469665', 'GREAT GRACE COLLEGE', 'OYO', '111501'),
(1502, '111502', 'úÏ…W§', '111502@oyoedu.ng', '8034198427', 'FEDERAL TECHNICAL SCIENCE COLLEGE', 'OYO', '111502'),
(1503, '111503', 'úÏ…W§', '111503@oyoedu.ng', '8130700780', 'OLUYOLE HIGH SCHOOL', 'KOGI', '111503'),
(1504, '111504', 'úÏ…W§', '111504@oyoedu.ng', '7031166444', 'ST. TERESA\'S COLLEGE', 'EKITI', '111504'),
(1505, '111505', 'úÏ…W§', '111505@oyoedu.ng', '8067840941', 'ST.THERESA SCHOOL', 'OSUN', '111505'),
(1506, '111506', 'úÏ…W§', '111506@oyoedu.ng', '8033803024', 'FIRM FOUNDATION', 'KOGI', '111506'),
(1507, '111507', 'úÏ…W§', '111507@oyoedu.ng', '8035571788', 'ENTERNAL EXECELLENCY', 'EKITI', '111507'),
(1508, '111508', 'úÏ…W§', '111508@oyoedu.ng', '8070912529', 'ELITE COLLEGE', 'OSUN', '111508'),
(1509, '111509', 'úÏ…W§', '111509@oyoedu.ng', '8070912529', 'ST PAUL ANGLICAN', 'OSUN', '111509'),
(1510, '111510', 'úÏ…W§', '111510@oyoedu.ng', '8076355624', 'ST PAUL ANGLICAN SEC SCH', 'OSUN', '111510'),
(1511, '111511', 'úÏ…W§', '111511@oyoedu.ng', '8038122163', 'ST.PAUL ANGLICAN COLLEGE', 'OSUN', '111511'),
(1512, '111512', 'úÏ…W§', '111512@oyoedu.ng', '7066670259', 'DE-DEUION HIGH SCH', 'OSUN', '111512'),
(1513, '111513', 'úÏ…W§', '111513@oyoedu.ng', '8060388824', 'ST. ANNES SCH', 'OYO', '111513'),
(1514, '111514', 'úÏ…W§', '111514@oyoedu.ng', '8123313446', 'THE APOSTOLIC CHURCH MODEL COLL', 'OSUN', '111514'),
(1515, '111515', 'úÏ…W§', '111515@oyoedu.ng', '8038036591', 'IBADAN CITY ACADAMY', 'OYO', '111515'),
(1516, '111516', 'úÏ…W§', '111516@oyoedu.ng', '8034107449', 'RELIEF HIGH SCH', 'KWARA', '111516'),
(1517, '111517', 'úÏ…W§', '111517@oyoedu.ng', '8175397384', 'ST TERESSA COLL', 'ANAMBRA', '111517'),
(1518, '111518', 'úÏ…W§', '111518@oyoedu.ng', '8034752357', 'MIGHTY MIRACLE COLLEGE', 'ANAMBRA ', '111518'),
(1519, '111519', 'úÏ…W§', '111519@oyoedu.ng', '8075741829', 'ST LOUIS ', 'EDO', '111519'),
(1520, '111520', 'úÏ…W§', '111520@oyoedu.ng', '8033452517', 'ATANDA INT SCH', 'ONDO', '111520'),
(1521, '111521', 'úÏ…W§', '111521@oyoedu.ng', '8034659885', 'UPPER STANDARD', 'EKITI', '111521'),
(1522, '111522', 'úÏ…W§', '111522@oyoedu.ng', '8136783692', 'FOLA MODEL COLLEGE', 'ABIA', '111522'),
(1523, '111523', 'úÏ…W§', '111523@oyoedu.ng', '8067504901', 'ROYAL SEED COLLEGE', 'OYO', '111523'),
(1524, '111524', 'úÏ…W§', '111524@oyoedu.ng', '8165922976', 'ST. ANNS SCHOOL', 'OYO', '111524'),
(1525, '111525', 'úÏ…W§', '111525@oyoedu.ng', '7086207858', 'AGUGU HIGH SCH', 'OYO', '111525'),
(1526, '111526', 'úÏ…W§', '111526@oyoedu.ng', '8130445319', 'NESAN INT\'L ', 'DELTA', '111526'),
(1527, '111527', 'úÏ…W§', '111527@oyoedu.ng', '8072585006', 'NESAM INT\'L SCH', 'DELTA', '111527'),
(1528, '111528', 'úÏ…W§', '111528@oyoedu.ng', '8030445319', 'NESAM INT', 'DELTA', '111528'),
(1529, '111529', 'úÏ…W§', '111529@oyoedu.ng', '7032510935', 'BRIGHT BRAIN', 'OYO', '111529'),
(1530, '111530', 'úÏ…W§', '111530@oyoedu.ng', '8023970275', 'IBADAN PROMINENT JI', 'OGUN', '111530'),
(1531, '111531', 'úÏ…W§', '111531@oyoedu.ng', '8106275865', 'OGBERE COMM. SCHOOL', 'OYO', '111531'),
(1532, '111532', 'úÏ…W§', '111532@oyoedu.ng', '8073682305', 'HIGHFLYER COLLEGE', 'EDO', '111532'),
(1533, '111533', 'úÏ…W§', '111533@oyoedu.ng', '8075404944', 'ST. ANNES SCH', 'ANAMBRA', '111533'),
(1534, '111534', 'úÏ…W§', '111534@oyoedu.ng', '7083802219', 'BAPTIST SEC SCH', 'ENUGU', '111534');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(1535, '111535', 'úÏ…W§', '111535@oyoedu.ng', '7083802219', 'ST LOUIS MOKOLA', 'ENUGU', '111535'),
(1536, '111536', 'úÏ…W§', '111536@oyoedu.ng', '8168128838', 'SAINT LOUIS', 'ENUGU', '111536'),
(1537, '111537', 'úÏ…W§', '111537@oyoedu.ng', '8077034467', 'SACRED HEART PRIV.SCH', 'ANAMBRA', '111537'),
(1538, '111538', 'úÏ…W§', '111538@oyoedu.ng', '8097347431', 'FRONTRUNNER\'S COLLEGE', 'OYO', '111538'),
(1539, '111539', 'úÏ…W§', '111539@oyoedu.ng', '8066164551', 'LYDEB COMP COLLEGE', 'OGUN', '111539'),
(1540, '111540', 'úÏ…W§', '111540@oyoedu.ng', '8033907430', 'QUEEN SCHOOL', 'OYO', '111540'),
(1541, '111541', 'úÏ…W§', '111541@oyoedu.ng', '8033907430', 'GODS GLORY COLL', 'OYO', '111541'),
(1542, '111542', 'úÏ…W§', '111542@oyoedu.ng', '7087135549', 'GOD\'S GLORY COLLEGE', 'OYO', '111542'),
(1543, '111543', 'úÏ…W§', '111543@oyoedu.ng', '7087135549', 'ABSOLUTE SUCCESS', 'OSUN', '111543'),
(1544, '111544', 'úÏ…W§', '111544@oyoedu.ng', '8029595783', 'IBADAN ABSOLUTE', 'OSUN', '111544'),
(1545, '111545', 'úÏ…W§', '111545@oyoedu.ng', '8168984155', 'HIGH FLIER COLLEGE', 'OYO', '111545'),
(1546, '111546', 'úÏ…W§', '111546@oyoedu.ng', '8052315151', 'GOVT.JUNIOR SEC', 'OYO', '111546'),
(1547, '111547', 'úÏ…W§', '111547@oyoedu.ng', '9070305910', 'TITUOS MODEL', 'OSUN', '111547'),
(1548, '111548', 'úÏ…W§', '111548@oyoedu.ng', '8034917424', 'GLORIOUS INT\'L', 'OGUN', '111548'),
(1549, '111549', 'úÏ…W§', '111549@oyoedu.ng', '8166836871', 'RIDWANULLAHI SEC SCH', 'OYO', '111549'),
(1550, '111550', 'úÏ…W§', '111550@oyoedu.ng', '8109981573', 'HERITAGE SCHOOL', 'OYO', '111550'),
(1551, '111551', 'úÏ…W§', '111551@oyoedu.ng', '8064797076', 'THHRESHERS COMP', 'OYO', '111551'),
(1552, '111552', 'úÏ…W§', '111552@oyoedu.ng', '8051380118', 'DISTINCT JUBILEE', 'ONDO', '111552'),
(1553, '111553', 'úÏ…W§', '111553@oyoedu.ng', '8051380118', 'ECWA', 'OGUN ', '111553'),
(1554, '111554', 'úÏ…W§', '111554@oyoedu.ng', '8142355030', 'ECWA-SEC SCH', 'OGUN', '111554'),
(1555, '111555', 'úÏ…W§', '111555@oyoedu.ng', '7033882454', 'OBA ABAS ALESINLOYE GRAMM', 'ONDO', '111555'),
(1556, '111556', 'úÏ…W§', '111556@oyoedu.ng', '7038681943', 'ABUNDANT COLLEGE', 'OYO', '111556'),
(1557, '111557', 'úÏ…W§', '111557@oyoedu.ng', '7050902415', 'CELESTIAL SEC SCH', 'OYO', '111557'),
(1558, '111558', 'úÏ…W§', '111558@oyoedu.ng', '7050902415', 'ADEM GROUP OF SCH', 'OYO', '111558'),
(1559, '111559', 'úÏ…W§', '111559@oyoedu.ng', '8073389393', 'ADEM SEC SCHOOL', 'OYO', '111559'),
(1560, '111560', 'úÏ…W§', '111560@oyoedu.ng', '8122079685', 'GODS PLAN COLLEGE', 'OYO', '111560'),
(1561, '111561', 'úÏ…W§', '111561@oyoedu.ng', '8076915717', 'COMMUNITY EYINNI SCHOOL', 'OYO', '111561'),
(1562, '111562', 'úÏ…W§', '111562@oyoedu.ng', '8088474042', 'MODEL SCH.SOKA', 'OYO', '111562'),
(1563, '111563', 'úÏ…W§', '111563@oyoedu.ng', '8034498557', 'OYO STATE COMP MODEL COLL', 'OYO', '111563'),
(1564, '111564', 'úÏ…W§', '111564@oyoedu.ng', '8153502849', 'CHESHRIER HIGH', 'OYO', '111564'),
(1565, '111565', 'úÏ…W§', '111565@oyoedu.ng', '8153502849', 'BAPTIST SEC SCH', '', '111565'),
(1566, '111566', 'úÏ…W§', '111566@oyoedu.ng', '8065098833', 'BAPTIST SEC SCH', '', '111566'),
(1567, '111567', 'úÏ…W§', '111567@oyoedu.ng', '8039650114', 'ROCHAS FOUNDATION', 'KOGI', '111567'),
(1568, '111568', 'úÏ…W§', '111568@oyoedu.ng', '8066632805', 'ADE ROYAL COMP. COLLEGE', 'OYO', '111568'),
(1569, '111569', 'úÏ…W§', '111569@oyoedu.ng', '8079771100', 'ABBEY STANDARD COLLEGE', 'ONDO', '111569'),
(1570, '111570', 'úÏ…W§', '111570@oyoedu.ng', '8079771100', 'UNION BAPTIST .O', 'OYO', '111570'),
(1571, '111571', 'úÏ…W§', '111571@oyoedu.ng', '8030755697', 'UNION BAPTIST SCH', 'OYO', '111571'),
(1572, '111572', 'úÏ…W§', '111572@oyoedu.ng', '7014350708', 'HIGH CLASS SCHOOL', 'OYO', '111572'),
(1573, '111573', 'úÏ…W§', '111573@oyoedu.ng', '8034891421', 'FORTRESS PRIVATE SCH.', 'OSUN', '111573'),
(1574, '111574', 'úÏ…W§', '111574@oyoedu.ng', '8148519260', 'PEACE INT\'L COLLEGE', 'OYO', '111574'),
(1575, '111575', 'úÏ…W§', '111575@oyoedu.ng', '8070868472', 'ANGLICAN GRAMMAR', 'OYO', '111575'),
(1576, '111576', 'úÏ…W§', '111576@oyoedu.ng', '8034919330', 'MOSLEM GRAMMAR SCH', 'OYO', '111576'),
(1577, '111577', 'úÏ…W§', '111577@oyoedu.ng', '8034919330', 'MOSLEM GRAMMAR SCH', 'OYO', '111577'),
(1578, '111578', 'úÏ…W§', '111578@oyoedu.ng', '8034992196', 'COMMUNITY GRAMMAR SCH', 'EKITI', '111578'),
(1579, '111579', 'úÏ…W§', '111579@oyoedu.ng', '8164848556', 'OGBERE COMM.SCH', 'OYO', '111579'),
(1580, '111580', 'úÏ…W§', '111580@oyoedu.ng', '8056116083', 'COMMAND DAY SEC', 'OYO', '111580'),
(1581, '111581', 'úÏ…W§', '111581@oyoedu.ng', '7060443014', 'FORTRESS PRIVATE', 'OSUN', '111581'),
(1582, '111582', 'úÏ…W§', '111582@oyoedu.ng', '7060443014', 'BOHS IBADAN', 'OYO', '111582'),
(1583, '111583', 'úÏ…W§', '111583@oyoedu.ng', '816561514', 'BASORUN SCHOOL', 'OYO', '111583'),
(1584, '111584', 'úÏ…W§', '111584@oyoedu.ng', '8037736651', 'OUR LADY OF APOSTLES', 'OYO', '111584'),
(1585, '111585', 'úÏ…W§', '111585@oyoedu.ng', '8106096992', 'THE LIGHT ACADEMY', 'KWARA', '111585'),
(1586, '111586', 'úÏ…W§', '111586@oyoedu.ng', '9014433287', 'LAURELLA INT SCH', 'EKITI', '111586'),
(1587, '111587', 'úÏ…W§', '111587@oyoedu.ng', '', 'QUEEN\'S SCHOOL', 'OYO', '111587'),
(1588, '111588', 'úÏ…W§', '111588@oyoedu.ng', '8170985476', 'METHODIST GIRLS', 'OYO', '111588'),
(1589, '111589', 'úÏ…W§', '111589@oyoedu.ng', '8075542130', 'ESSCAS COLLEGE', 'OYO', '111589'),
(1590, '111590', 'úÏ…W§', '111590@oyoedu.ng', '8038075764', 'ST.THERESA', 'OYO', '111590'),
(1591, '111591', 'úÏ…W§', '111591@oyoedu.ng', '7053019293', 'OABCC', 'OYO', '111591'),
(1592, '111592', 'úÏ…W§', '111592@oyoedu.ng', '8078508579', 'NAOMI SCHOOL', 'OYO', '111592'),
(1593, '111593', 'úÏ…W§', '111593@oyoedu.ng', '8023659239', 'SANVIC MIRACLE SECONDARY SCH', 'OYO', '111593'),
(1594, '111594', 'úÏ…W§', '111594@oyoedu.ng', '8088918964', 'ST.THERESA', 'OYO', '111594'),
(1595, '111595', 'úÏ…W§', '111595@oyoedu.ng', '7057851039', 'HONOURABLE OLAJIRE', 'EKITI', '111595'),
(1596, '111596', 'úÏ…W§', '111596@oyoedu.ng', '8023383535', 'MOUNT ROSESCH', 'OGUN', '111596'),
(1597, '111597', 'úÏ…W§', '111597@oyoedu.ng', '7033736483', 'DIADEM SCH.', 'OGUN', '111597'),
(1598, '111598', 'úÏ…W§', '111598@oyoedu.ng', '8033853360', 'EBENZER BAPTIST', 'OYO', '111598'),
(1599, '111599', 'úÏ…W§', '111599@oyoedu.ng', '8129536005', 'ZIONEEL COLLEGE', 'OSUN', '111599'),
(1600, '111600', 'úÏ…W§', '111600@oyoedu.ng', '8068974109', 'GLORIOUS KING/QUEEN', 'OSUN', '111600'),
(1601, '111601', 'úÏ…W§', '111601@oyoedu.ng', '8164846974', 'ST TERRESSA ', 'OYO', '111601'),
(1602, '111602', 'úÏ…W§', '111602@oyoedu.ng', '8081769200', 'ATOBIJU GROUP SCH', 'OYO', '111602'),
(1603, '111603', 'úÏ…W§', '111603@oyoedu.ng', '8024821987', 'OGBERE COMM.SCH', 'OYO', '111603'),
(1604, '111604', 'úÏ…W§', '111604@oyoedu.ng', '8053048721', 'QUEEN SCHOOL', 'OYO', '111604'),
(1605, '111605', 'úÏ…W§', '111605@oyoedu.ng', '8059372146', 'FIRST CLASS COLLEGE', 'OYO', '111605'),
(1606, '111606', 'úÏ…W§', '111606@oyoedu.ng', '8059557792', 'ONIPE COMM. SEC SCH', 'OYO', '111606'),
(1607, '111607', 'úÏ…W§', '111607@oyoedu.ng', '8158727098', 'ADEM MODEL SCH', 'OGUN', '111607'),
(1608, '111608', 'úÏ…W§', '111608@oyoedu.ng', '8132219121', 'OLUNDE COMMUNITY SEC SCHOOL', 'OYO', '111608'),
(1609, '111609', 'úÏ…W§', '111609@oyoedu.ng', '8078888829', 'COMFORT SEC SCH', 'OYO', '111609'),
(1610, '111610', 'úÏ…W§', '111610@oyoedu.ng', '8028872642', 'ST LOUIS MOKOLA', 'OYO', '111610'),
(1611, '111611', 'úÏ…W§', '111611@oyoedu.ng', '8035777535', 'YOUNG TALENT COLLEGE', 'EKITI', '111611'),
(1612, '111612', 'úÏ…W§', '111612@oyoedu.ng', '8146283207', 'DISTINCT JUBILEE', 'KWARA', '111612'),
(1613, '111613', 'úÏ…W§', '111613@oyoedu.ng', '8165306426', 'ROYAL GRAT SCH', 'OYO', '111613'),
(1614, '111614', 'úÏ…W§', '111614@oyoedu.ng', '8136902526', 'LOYAL GATE SCH.', 'OYO', '111614'),
(1615, '111615', 'úÏ…W§', '111615@oyoedu.ng', '8151975012', 'OKE-ADO HIGH SCH', 'OYO', '111615'),
(1616, '111616', 'úÏ…W§', '111616@oyoedu.ng', '8149933515', 'EYINNI COMMUITY', 'OYO', '111616'),
(1617, '111617', 'úÏ…W§', '111617@oyoedu.ng', '8062198012', 'PUPILS GIRL GRAMMAR SCH', 'OYO', '111617'),
(1618, '111618', 'úÏ…W§', '111618@oyoedu.ng', '8028470852', 'GRACE COLLEGE', 'OGUN', '111618'),
(1619, '111619', 'úÏ…W§', '111619@oyoedu.ng', '7059111809', 'GRACE COLLEGE', 'OGUN', '111619'),
(1620, '111620', 'úÏ…W§', '111620@oyoedu.ng', '7059111809', '90 POINTS SEC SCH', 'OYO', '111620'),
(1621, '111621', 'úÏ…W§', '111621@oyoedu.ng', '8060129018', 'ANSARUDEEN', 'OYO', '111621'),
(1622, '111622', 'úÏ…W§', '111622@oyoedu.ng', '7031844000', 'OYO STATE COMPREHENSIVE MODEL COLLEGE', 'OYO', '111622'),
(1623, '111623', 'úÏ…W§', '111623@oyoedu.ng', '8034089821', 'ELBERT', 'OYO', '111623'),
(1624, '111624', 'úÏ…W§', '111624@oyoedu.ng', '8132241199', 'AMBETH MODEL SCH', 'OYO', '111624'),
(1625, '111625', 'úÏ…W§', '111625@oyoedu.ng', '8157545082', 'SUNDORA INT SCH', 'OYO', '111625'),
(1626, '111626', 'úÏ…W§', '111626@oyoedu.ng', '9069762079', 'YEJIDE GIRLS GRAMMAR SCH', 'OYO', '111626'),
(1627, '111627', 'úÏ…W§', '111627@oyoedu.ng', '8157545082', 'YOUNG PALENIS SCH', 'OYO', '111627'),
(1628, '111628', 'úÏ…W§', '111628@oyoedu.ng', '8051249743', 'YOUNG PALANIS', 'OYO', '111628'),
(1629, '111629', 'úÏ…W§', '111629@oyoedu.ng', '8038060699', 'THE SCEPTRE', 'EDO', '111629'),
(1630, '111630', 'úÏ…W§', '111630@oyoedu.ng', '8059379711', 'COMMAND DAY SCH', 'OYO', '111630'),
(1631, '111631', 'úÏ…W§', '111631@oyoedu.ng', '8038114616', 'QSI APATA', 'OYO', '111631'),
(1632, '111632', 'úÏ…W§', '111632@oyoedu.ng', '8147158843', 'ROYAL SEED COLLEGE', 'OSUN', '111632'),
(1633, '111633', 'úÏ…W§', '111633@oyoedu.ng', '8060761264', 'COMPREHENSIVE HIG SCH', 'ONDO', '111633'),
(1634, '111634', 'úÏ…W§', '111634@oyoedu.ng', '8155507641', 'NESAM INT\'L SCH', 'OGUN', '111634'),
(1635, '111635', 'úÏ…W§', '111635@oyoedu.ng', '8076393081', 'GIFTED HOME', 'OYO', '111635'),
(1636, '111636', 'úÏ…W§', '111636@oyoedu.ng', '8059158173', 'SEBOLA ACADEMY', 'OYO', '111636'),
(1637, '111637', 'úÏ…W§', '111637@oyoedu.ng', '8169504406', 'ENIOLA INT\'L COLLEGE', 'OYO', '111637'),
(1638, '111638', 'úÏ…W§', '111638@oyoedu.ng', '9021367755', 'TRUE LIGHT GROUP', 'OYO', '111638'),
(1639, '111639', 'úÏ…W§', '111639@oyoedu.ng', '8060566562', 'CONVENANT FAITH MODEL COLL', 'EKITII', '111639'),
(1640, '111640', 'úÏ…W§', '111640@oyoedu.ng', '8036944410', 'M.H.A SCHOOL', 'OYO', '111640'),
(1641, '111641', 'úÏ…W§', '111641@oyoedu.ng', '8060566562', 'ST.THERESA\'S COLEGE', 'OGUN', '111641'),
(1642, '111642', 'úÏ…W§', '111642@oyoedu.ng', '8052380761', 'M.H.A SCHOOL', 'OYO', '111642'),
(1643, '111643', 'úÏ…W§', '111643@oyoedu.ng', '8052380761', 'DALOL SCH', 'OYO', '111643'),
(1644, '111644', 'úÏ…W§', '111644@oyoedu.ng', '8090950227', 'DALOM SCHOOL', 'OYO', '111644'),
(1645, '111645', 'úÏ…W§', '111645@oyoedu.ng', '8066497609', 'GLORIOUS SCH', 'OGUN', '111645'),
(1646, '111646', 'úÏ…W§', '111646@oyoedu.ng', '8058687481', 'OYO STATE COMP MODEL COLLEGE', 'OYO', '111646'),
(1647, '111647', 'úÏ…W§', '111647@oyoedu.ng', '8076589240', 'AL-QALLAM SCH', 'OYO', '111647'),
(1648, '111648', 'úÏ…W§', '111648@oyoedu.ng', '9091954475', 'COMMUNITY GRAMMAR SCH', 'OYO', '111648'),
(1649, '111649', 'úÏ…W§', '111649@oyoedu.ng', '9066128505', 'ST LOUIS GRAMMAR SCH', 'ONDO', '111649'),
(1650, '111650', 'úÏ…W§', '111650@oyoedu.ng', '8055745874', 'ST LOUIS GRAMMER SCH', 'ONDO', '111650'),
(1651, '111651', 'úÏ…W§', '111651@oyoedu.ng', '8062481229', 'EMPEROR COLLEGE', 'OYO', '111651'),
(1652, '111652', 'úÏ…W§', '111652@oyoedu.ng', '7082808770', 'SUMMIT COMP', 'OYO', '111652'),
(1653, '111653', 'úÏ…W§', '111653@oyoedu.ng', '7051366296', 'RICH ALICE ACADEMY', 'EKITI', '111653'),
(1654, '111654', 'úÏ…W§', '111654@oyoedu.ng', '9058077893', 'CROWN STAR SEC. SCH', 'OYO', '111654'),
(1655, '111655', 'úÏ…W§', '111655@oyoedu.ng', '8073628394', 'GLORIOUS SEED COMPREHENSIVE S', 'OGUN', '111655'),
(1656, '111656', 'úÏ…W§', '111656@oyoedu.ng', '7083239515', 'BASHORUN OGUNMOLA', 'OGUN', '111656'),
(1657, '111657', 'úÏ…W§', '111657@oyoedu.ng', '8079918147', 'HIGH TOWER SCH', 'OSUN', '111657'),
(1658, '111658', 'úÏ…W§', '111658@oyoedu.ng', '8055144094', 'GO AHEAD PRE-VASITY COLLEGE', 'ONDO', '111658'),
(1659, '311659', 'úÏ…W§', '311659@oyoedu.ng', '8051449522', 'ANGLICAN GRAMMAR', 'OYO', '311659'),
(1660, '111660', 'úÏ…W§', '111660@oyoedu.ng', '8054154057', 'ST.ANNES SCHOOL', 'OYO', '111660'),
(1661, '111661', 'úÏ…W§', '111661@oyoedu.ng', '8038983802', 'CHRIST CHURCH COLLEGE', 'OYO', '111661'),
(1662, '111662', 'úÏ…W§', '111662@oyoedu.ng', '8038983802', 'ANURU SCHOOL', 'OYO', '111662'),
(1663, '111663', 'úÏ…W§', '111663@oyoedu.ng', '8039142858', 'ANURU NUR/P', 'OYO', '111663'),
(1664, '111664', 'úÏ…W§', '111664@oyoedu.ng', '8057219547', 'CARITAS SEC SCH', 'OYO', '111664'),
(1665, '111665', 'úÏ…W§', '111665@oyoedu.ng', '8168984155', 'ACCESS COLLEGE IBADAN', 'OYO', '111665'),
(1666, '111666', 'úÏ…W§', '111666@oyoedu.ng', '7018674135', 'GRACE ROYAL ACADEMY', 'OYO', '111666'),
(1667, '111667', 'úÏ…W§', '111667@oyoedu.ng', '8138548601', 'PRECIOUS GIFTS GROUP OF SCHOOLS', 'OGUN', '111667'),
(1668, '111668', 'úÏ…W§', '111668@oyoedu.ng', '8075083290', 'DE PIONEER SCH ', 'OYO', '111668'),
(1669, '111669', 'úÏ…W§', '111669@oyoedu.ng', '8040751113', 'BSSM MODEL SCHOOL', 'OYO', '111669'),
(1670, '111670', 'úÏ…W§', '111670@oyoedu.ng', '8035644871', 'DAB SEMM MODEL SCHOOL', 'OYO', '111670'),
(1671, '111671', 'úÏ…W§', '111671@oyoedu.ng', '8064882495', 'CHRIST HIGH SCH', 'OYO', '111671'),
(1672, '111672', 'úÏ…W§', '111672@oyoedu.ng', '8162780175', 'ATANDA INT\'L HIGH SCH', 'OSUN', '111672'),
(1673, '111673', 'úÏ…W§', '111673@oyoedu.ng', '8062780175', 'AS-SALAM MODEL', 'OYO', '111673'),
(1674, '111674', 'úÏ…W§', '111674@oyoedu.ng', '7031395706', 'AS-SALAM COLL.', 'OYO', '111674'),
(1675, '111675', 'úÏ…W§', '111675@oyoedu.ng', '8033809387', 'BEULAH MODEL COLLEGE', 'ONDO', '111675'),
(1676, '111676', 'úÏ…W§', '111676@oyoedu.ng', '8106559751', 'ABADINA COLLEGE', 'OSUN', '111676'),
(1677, '111677', 'úÏ…W§', '111677@oyoedu.ng', '8106559751', 'HEZDEB COLLEGE', 'OYO', '111677'),
(1678, '111678', 'úÏ…W§', '111678@oyoedu.ng', '8023998004', 'HEZLED COLL.KUSELA', 'OYO', '111678'),
(1679, '111679', 'úÏ…W§', '111679@oyoedu.ng', '8023998004', 'KINGDOM SCHOOL', 'OYO', '111679'),
(1680, '111680', 'úÏ…W§', '111680@oyoedu.ng', '8034647352', 'KINGDOM SCH', 'OYO', '111680'),
(1681, '111681', 'úÏ…W§', '111681@oyoedu.ng', '8181739496', 'OUR LADY OF APOSTLE', 'OSUN', '111681'),
(1682, '111682', 'úÏ…W§', '111682@oyoedu.ng', '7032637502', 'OBA-AKINBIYI HIGH SCH', 'OYO', '111682'),
(1683, '111683', 'úÏ…W§', '111683@oyoedu.ng', '7062385339', 'EBENEZER BAPTIST', 'OYO', '111683'),
(1684, '111684', 'úÏ…W§', '111684@oyoedu.ng', '8039288564', 'SCORES COLLEGE', 'OSUN', '111684'),
(1685, '111685', 'úÏ…W§', '111685@oyoedu.ng', '8145989663', 'ALQALAL SCH', 'OYO', '111685'),
(1686, '111686', 'úÏ…W§', '111686@oyoedu.ng', '8145989663', 'ALMIZAN GRAMMAR', 'OYO', '111686'),
(1687, '111687', 'úÏ…W§', '111687@oyoedu.ng', '8056462234', 'AL-QATAM COLLEGE', 'OYO', '111687'),
(1688, '111688', 'úÏ…W§', '111688@oyoedu.ng', '8047847869', 'URBAN DAY GRAMMAR', 'OYO', '111688'),
(1689, '111689', 'úÏ…W§', '111689@oyoedu.ng', '7047847868', 'UBAND DAYGRAMMAR SCH', 'OYO', '111689'),
(1690, '111690', 'úÏ…W§', '111690@oyoedu.ng', '8055301852', 'QUEEN SCHOOL', 'OYO', '111690'),
(1691, '111691', 'úÏ…W§', '111691@oyoedu.ng', '8128895426', 'QUEENS SCHOOL', 'OYO', '111691'),
(1692, '111692', 'úÏ…W§', '111692@oyoedu.ng', '8052535240', 'OUR LADY OF APOSTLES', 'OGUN', '111692'),
(1693, '111693', 'úÏ…W§', '111693@oyoedu.ng', '8077187779', 'TIMPET EBULLIENT', 'OSUN', '111693'),
(1694, '111694', 'úÏ…W§', '111694@oyoedu.ng', '7068182299', 'OMOTAYO PRIVATE SEC SCH', 'OSUN', '111694'),
(1695, '111695', 'úÏ…W§', '111695@oyoedu.ng', '8077187449', 'ADESOLA  SCH', 'OYO', '111695'),
(1696, '111696', 'úÏ…W§', '111696@oyoedu.ng', '8064728910', 'ADESOLA SCHOOL.OMI', 'OYO', '111696'),
(1697, '111697', 'úÏ…W§', '111697@oyoedu.ng', '8037231036', 'AS SALAM UNIQUE', 'OGUN', '111697'),
(1698, '111698', 'úÏ…W§', '111698@oyoedu.ng', '9065005815', 'ST ANNES', 'EKITI', '111698'),
(1699, '111699', 'úÏ…W§', '111699@oyoedu.ng', '7031246419', 'SCOLAND COLLEGE', 'OYO', '111699'),
(1700, '111700', 'úÏ…W§', '111700@oyoedu.ng', '7062077300', 'EYINNI HIGH SCH', 'OYO', '111700'),
(1701, '111701', 'úÏ…W§', '111701@oyoedu.ng', '8053615120', 'THE LIGHT ACADEMY', 'EKITI', '111701'),
(1702, '111702', 'úÏ…W§', '111702@oyoedu.ng', '8051986513', 'ARISE AND SHINE HOME', 'EDO', '111702'),
(1703, '111703', 'úÏ…W§', '111703@oyoedu.ng', '8053615120', 'ST.ANNES SCHOOL', 'OYO', '111703'),
(1704, '111704', 'úÏ…W§', '111704@oyoedu.ng', '8036830382', 'ST.ANNES.SCH', 'OYO', '111704'),
(1705, '111705', 'úÏ…W§', '111705@oyoedu.ng', '8032110860', 'OXFORD GROUPS', 'KOGI', '111705'),
(1706, '111706', 'úÏ…W§', '111706@oyoedu.ng', '8036830382', 'OXFORD BROOKS COLLEGE', 'KOGI', '111706'),
(1707, '111707', 'úÏ…W§', '111707@oyoedu.ng', '8062149172', 'INNER VISION HIGH SCH', 'KOGI', '111707'),
(1708, '111708', 'úÏ…W§', '111708@oyoedu.ng', '8045671443', 'FRONT MODEL COLLEGE', 'OYO', '111708'),
(1709, '111709', 'úÏ…W§', '111709@oyoedu.ng', '8032110860', 'BASHORUN OGUNMOLA HIGH SCH', 'OYO', '111709'),
(1710, '111710', 'úÏ…W§', '111710@oyoedu.ng', '8055524888', 'BASHORUN OGUNMOLA HIGH SCH', 'OYO', '111710'),
(1711, '111711', 'úÏ…W§', '111711@oyoedu.ng', '8053355560', 'MERCY COLLEGE', 'ONDO', '111711'),
(1712, '111712', 'úÏ…W§', '111712@oyoedu.ng', '8035659888', 'VICTORY CHRISTIAN SCH', 'EKITI', '111712'),
(1713, '111713', 'úÏ…W§', '111713@oyoedu.ng', '8035418787', 'J.RAPHAL SECONDARY SCHOOL', 'OSUN', '111713'),
(1714, '111714', 'úÏ…W§', '111714@oyoedu.ng', '8035737044', 'ELEKURO HIGH SCHOOL', 'ONDO', '111714'),
(1715, '111715', 'úÏ…W§', '111715@oyoedu.ng', '8055251227', 'ADEM GROUP OF SCH', 'EKITI', '111715'),
(1716, '111716', 'úÏ…W§', '111716@oyoedu.ng', '8060383391', 'ST TERRESSA ', 'ONDO', '111716'),
(1717, '111717', 'úÏ…W§', '111717@oyoedu.ng', '8059854623', 'ADEX GRAMMAR SCH', 'OYO', '111717'),
(1718, '111718', 'úÏ…W§', '111718@oyoedu.ng', '8036777485', 'DI-FRIDAUS', 'OYO', '111718'),
(1719, '111719', 'úÏ…W§', '111719@oyoedu.ng', '8060401579', 'WINNERS ARISE AND SHINE', 'OSUN', '111719'),
(1720, '111720', 'úÏ…W§', '111720@oyoedu.ng', '8169446152', 'HERITAGE FOUNDATION SCHOOL', 'OYO', '111720'),
(1721, '111721', 'úÏ…W§', '111721@oyoedu.ng', '8035629854', 'COMPRE. HIGH SCH.', 'OYO', '111721'),
(1722, '111722', 'úÏ…W§', '111722@oyoedu.ng', '7033462231', 'HIS OWN SCH', 'EKITI', '111722'),
(1723, '111723', 'úÏ…W§', '111723@oyoedu.ng', '8030759304', 'EBENEZER BAPTIST', 'OYO', '111723'),
(1724, '111724', 'úÏ…W§', '111724@oyoedu.ng', '8034271560', 'OYESINA HIGH SCH MONATAN', 'OYO', '111724'),
(1725, '111725', 'úÏ…W§', '111725@oyoedu.ng', '9033635893', 'SECOND HOME COLLEGE', 'OYO', '111725'),
(1726, '111726', 'úÏ…W§', '111726@oyoedu.ng', '8055267030', 'ST.ANNES SCHOOL', 'OSUN', '111726'),
(1727, '111727', 'úÏ…W§', '111727@oyoedu.ng', '7031237339', 'COMMAND DAY SEC SCH', 'OYO', '111727'),
(1728, '111728', 'úÏ…W§', '111728@oyoedu.ng', '8131682833', 'FAITH TRIUMPH', 'OYO', '111728'),
(1729, '111729', 'úÏ…W§', '111729@oyoedu.ng', '8062423916', 'ACHIEVERS PREVASITY COLLEGE', 'OGUN', '111729'),
(1730, '111730', 'úÏ…W§', '111730@oyoedu.ng', '7013624179', 'CLEMSY INT ACADEMY SCH  ', 'ONDO', '111730'),
(1731, '111731', 'úÏ…W§', '111731@oyoedu.ng', '8032293094', 'SCHOOL FAVOURS BODIJA', 'LAGOS', '111731'),
(1732, '111732', 'úÏ…W§', '111732@oyoedu.ng', '8026702984', 'FORTUNE HEIGHT SCH', 'OGUN', '111732'),
(1733, '111733', 'úÏ…W§', '111733@oyoedu.ng', '9024775518', 'ALL AGES COLLEGE', 'ONDO', '111733'),
(1734, '111734', 'úÏ…W§', '111734@oyoedu.ng', '8024130697', 'ST.ANNES', 'OSUN', '111734'),
(1735, '111735', 'úÏ…W§', '111735@oyoedu.ng', '7031763038', 'ST.THERESA', 'OGUN', '111735'),
(1736, '111736', 'úÏ…W§', '111736@oyoedu.ng', '7032185070', 'GOD THE FOUNDATION', 'OSUN', '111736'),
(1737, '111737', 'úÏ…W§', '111737@oyoedu.ng', '8037187862', 'GOVERNMENT COLEGE', 'OYO', '111737'),
(1738, '111738', 'úÏ…W§', '111738@oyoedu.ng', '8034253425', 'KIDS OF ZION', 'OYO', '111738'),
(1739, '111739', 'úÏ…W§', '111739@oyoedu.ng', '7030455586', 'BASHORUN OGUNMOLA HIGH SCH', 'EKITI', '111739'),
(1740, '111740', 'úÏ…W§', '111740@oyoedu.ng', '7032600679', 'NUT MODEL COLLEGE', 'OYO', '111740'),
(1741, '111741', 'úÏ…W§', '111741@oyoedu.ng', '8034784607', 'MARVELLOUS KIDDIES SEC SCH', 'OSUN', '111741'),
(1742, '111742', 'úÏ…W§', '111742@oyoedu.ng', '8034984607', 'MARVRLLOUS KIDDIES', 'OSUN', '111742'),
(1743, '111743', 'úÏ…W§', '111743@oyoedu.ng', '7059524510', 'MIGHTY MIRACLE', 'OSUN', '111743'),
(1744, '111744', 'úÏ…W§', '111744@oyoedu.ng', '8032178637', 'POLICE SECONDARY SCH', 'EKITI', '111744'),
(1745, '111745', 'úÏ…W§', '111745@oyoedu.ng', '8055300001', 'OMEGA COLLEGE', 'OYO', '111745'),
(1746, '111746', 'úÏ…W§', '111746@oyoedu.ng', '8168680000', 'ST.DAVID CATHEDRAL COLLEGE', 'KWARA', '111746'),
(1747, '111747', 'úÏ…W§', '111747@oyoedu.ng', '8032320077', 'ANGLICAN GRAMMAR', 'ONDO', '111747'),
(1748, '111748', 'úÏ…W§', '111748@oyoedu.ng', '8032320077', 'REMO METHODIST', 'ONDO', '111748'),
(1749, '111749', 'úÏ…W§', '111749@oyoedu.ng', '8075573887', 'REMO METHODIST', 'ONDO', '111749'),
(1750, '111750', 'úÏ…W§', '111750@oyoedu.ng', '8037954849', 'BUSY BRAIN COLL', 'ONDO', '111750'),
(1751, '111751', 'úÏ…W§', '111751@oyoedu.ng', '8075573887', 'EMPEROR', 'ONDO', '111751'),
(1752, '111752', 'úÏ…W§', '111752@oyoedu.ng', '8144217445', 'EMPEROR SCHOOL', 'ONDO', '111752'),
(1753, '111753', 'úÏ…W§', '111753@oyoedu.ng', '8035243031', 'GOD PURPOSE', 'OGUN', '111753'),
(1754, '111754', 'úÏ…W§', '111754@oyoedu.ng', '8033578764', 'FEDERAL GOVERNMENT GIRL IPETUMODU', 'ONDO', '111754'),
(1755, '111755', 'úÏ…W§', '111755@oyoedu.ng', '8030657218', 'ADT OF KINGS AND QUEENS', 'OYO', '111755'),
(1756, '111756', 'úÏ…W§', '111756@oyoedu.ng', '8076817945', 'IBADAN GRAMMER SCH', 'OYO', '111756'),
(1757, '111757', 'úÏ…W§', '111757@oyoedu.ng', '8033557931', 'UNITED SEC SCH', 'OYO', '111757'),
(1758, '111758', 'úÏ…W§', '111758@oyoedu.ng', '8168330109', 'OKE ADO COMP COLLEGE', 'OSUN', '111758'),
(1759, '111759', 'úÏ…W§', '111759@oyoedu.ng', '8171902425', 'CROWN COLLEGE', 'OSUN', '111759'),
(1760, '111760', 'úÏ…W§', '111760@oyoedu.ng', '8036377112', 'GLORIFY UNIQUE', 'EKITI', '111760'),
(1761, '311761', 'úÏ…W§', '311761@oyoedu.ng', '8053853483', 'OBMS TIGARDEN', 'OYO', '311761'),
(1762, '111762', 'úÏ…W§', '111762@oyoedu.ng', '8105941615', 'EMIFUNMI COLLEGE', 'OYO', '111762'),
(1763, '111763', 'úÏ…W§', '111763@oyoedu.ng', '8062268092', 'URBAN DAY GRAMMER SCHOOL', 'ONDO', '111763'),
(1764, '111764', 'úÏ…W§', '111764@oyoedu.ng', '8036377112', 'ECWA MODEL COLL', 'OYO', '111764'),
(1765, '111765', 'úÏ…W§', '111765@oyoedu.ng', '9152254858', 'ECWA MODEL COLLEGE', 'OYO', '111765'),
(1766, '111766', 'úÏ…W§', '111766@oyoedu.ng', '8074496802', 'THE LIGHT ACADEMY', 'ONDO', '111766'),
(1767, '111767', 'úÏ…W§', '111767@oyoedu.ng', '8052169906', 'LANTERN SEC.', 'OYO', '111767'),
(1768, '111768', 'úÏ…W§', '111768@oyoedu.ng', '8086865113', 'ADEM SEC SCHOOL', 'OSUN', '111768'),
(1769, '111769', 'úÏ…W§', '111769@oyoedu.ng', '8166532660', 'SUCCESS HIGH SCH', 'EKITI', '111769'),
(1770, '111770', 'úÏ…W§', '111770@oyoedu.ng', '8033819233', 'DOMINION CHRISTIAN COLLEGE', 'ONDO', '111770'),
(1771, '111771', 'úÏ…W§', '111771@oyoedu.ng', '7069407663', 'ST GABRIEL MOKOLA', 'EDO', '111771'),
(1772, '111772', 'úÏ…W§', '111772@oyoedu.ng', '7011219710', 'MULTI GREEN SCH', 'OGUN', '111772'),
(1773, '111773', 'úÏ…W§', '111773@oyoedu.ng', '8162396066', 'NEW LIFE COMPREHENSIVE', 'LAGOS', '111773'),
(1774, '111774', 'úÏ…W§', '111774@oyoedu.ng', '7018513881', 'ADEM SEC SCHOOL', 'OGUN', '111774'),
(1775, '111775', 'úÏ…W§', '111775@oyoedu.ng', '8079701930', 'CCCHS', 'OGUN', '111775'),
(1776, '111776', 'úÏ…W§', '111776@oyoedu.ng', '8038445309', 'ADEM SCHOOL', 'OGUN', '111776'),
(1777, '111777', 'úÏ…W§', '111777@oyoedu.ng', '8166838219', 'BIMTO CLASSIC ACADEMY', 'KWARA', '111777'),
(1778, '111778', 'úÏ…W§', '111778@oyoedu.ng', '9017534050', 'FOTRESS PRIVATE SCHOOL', 'OSUN', '111778'),
(1779, '111779', 'úÏ…W§', '111779@oyoedu.ng', '7062838138', 'ATOBIJU GROUP OF SCH', 'OYO', '111779'),
(1780, '111780', 'úÏ…W§', '111780@oyoedu.ng', '7062838138', 'IBNU TAEMIYAH SCH', 'OYO', '111780'),
(1781, '111781', 'úÏ…W§', '111781@oyoedu.ng', '8025465397', 'IBNUTAMIYAH MODEL COLLEGE', 'OYO', '111781'),
(1782, '111782', 'úÏ…W§', '111782@oyoedu.ng', '8054368031', 'GOODNEWS PRI SCH', 'OYO', '111782'),
(1783, '111783', 'úÏ…W§', '111783@oyoedu.ng', '8161163540', 'NUT SCH', 'OYO', '111783'),
(1784, '111784', 'úÏ…W§', '111784@oyoedu.ng', '8056581039', 'COMMUNITY HIGH SCH', 'OGUN', '111784'),
(1785, '111785', 'úÏ…W§', '111785@oyoedu.ng', '8162883357', 'GOVERNMENT COLLEGE', 'OGUN', '111785'),
(1786, '111786', 'úÏ…W§', '111786@oyoedu.ng', '8056581039', 'COMMAND DAY SECOND SCH.', 'OYO', '111786'),
(1787, '111787', 'úÏ…W§', '111787@oyoedu.ng', '7066377170', 'COMMAND DAY SEC SCH', 'OYO', '111787'),
(1788, '111788', 'úÏ…W§', '111788@oyoedu.ng', '8064408929', 'NAOMI SEC SCH', 'OYO', '111788'),
(1789, '111789', 'úÏ…W§', '111789@oyoedu.ng', '8162123162', 'NAOMI MODEL SECSCH', 'OYO', '111789'),
(1790, '111790', 'úÏ…W§', '111790@oyoedu.ng', '8062735971', 'QUEENS SCH', 'OYO', '111790'),
(1791, '111791', 'úÏ…W§', '111791@oyoedu.ng', '8162123162', 'QUEENS SCH', 'OYO', '111791'),
(1792, '111792', 'úÏ…W§', '111792@oyoedu.ng', '8026060029', 'COMMUNITY SEC SCH', 'EKITI', '111792'),
(1793, '111793', 'úÏ…W§', '111793@oyoedu.ng', '8038610181', 'HIGH FLYER COLLEGE', 'EKITI', '111793'),
(1794, '111794', 'úÏ…W§', '111794@oyoedu.ng', '8036810181', 'AGBAMU COMM GRAMM SCH', 'OYO', '111794'),
(1795, '111795', 'úÏ…W§', '111795@oyoedu.ng', '8036810181', 'COMMUNITY GRAMMAR SCH', 'OYO', '111795'),
(1796, '111796', 'úÏ…W§', '111796@oyoedu.ng', '9098069541', 'COMMNITY GRAMMER SCH.', 'OYO', '111796'),
(1797, '111797', 'úÏ…W§', '111797@oyoedu.ng', '803476995', 'ST.BRIDGES SCH', 'OSUN', '111797'),
(1798, '111798', 'úÏ…W§', '111798@oyoedu.ng', '8103979412', 'BAPTIST SEC SCH', 'IMO', '111798'),
(1799, '311799', 'úÏ…W§', '311799@oyoedu.ng', '8103979412', 'BAPTIST SEC SCH', 'IMO', '311799'),
(1800, '111800', 'úÏ…W§', '111800@oyoedu.ng', '8069786087', 'FRIUT OF LOVE', 'ANAMBRA', '111800'),
(1801, '111801', 'úÏ…W§', '111801@oyoedu.ng', '8110549886', 'ST.LOUIS SCHOOL', 'IMO', '111801'),
(1802, '111802', 'úÏ…W§', '111802@oyoedu.ng', '7053138700', 'OUR LADY OF APOSTLES', 'DELTA', '111802'),
(1803, '111803', 'úÏ…W§', '111803@oyoedu.ng', '7066408085', 'EYINNI COMPREHENSIVE ', 'EKITI', '111803'),
(1804, '111804', 'úÏ…W§', '111804@oyoedu.ng', '9151821709', 'ST. LOUIS GRAMMER', 'OGUN', '111804'),
(1805, '111805', 'úÏ…W§', '111805@oyoedu.ng', '9151821709', 'CHARITY COMPREHENSIVE COLLEGE', 'IMO', '111805'),
(1806, '111806', 'úÏ…W§', '111806@oyoedu.ng', '8035389216', 'CHARITY COMPREHENSIVE COLLEGE', 'IMO', '111806'),
(1807, '111807', 'úÏ…W§', '111807@oyoedu.ng', '8075536751', 'A MAKER SEC SCH', 'KOGI', '111807'),
(1808, '111808', 'úÏ…W§', '111808@oyoedu.ng', '8142366251', 'SUNDORA COLLEGE', 'OSUN', '111808'),
(1809, '111809', 'úÏ…W§', '111809@oyoedu.ng', '9027084555', 'BLOSSOM PRIVATE SCH', 'OGUN', '111809'),
(1810, '111810', 'úÏ…W§', '111810@oyoedu.ng', '7035382591', 'BAPTIST SCHOOL', 'ONDO', '111810'),
(1811, '111811', 'úÏ…W§', '111811@oyoedu.ng', '8074205252', 'AL-RAMON MODEL', 'OYO', '111811'),
(1812, '111812', 'úÏ…W§', '111812@oyoedu.ng', '8050346781', 'IMG', 'OYO', '111812'),
(1813, '111813', 'úÏ…W§', '111813@oyoedu.ng', '8074205252', 'QUEENS SCH', 'OGUN', '111813'),
(1814, '111814', 'úÏ…W§', '111814@oyoedu.ng', '8055219312', 'QUEENS COLLEGE', 'OGUN', '111814'),
(1815, '111815', 'úÏ…W§', '111815@oyoedu.ng', '81354767248', 'COMMAND SCH', 'ENUGU', '111815'),
(1816, '111816', 'úÏ…W§', '111816@oyoedu.ng', '902449411', 'MERCY INT COLLEGE', 'ANAMBRA', '111816'),
(1817, '111817', 'úÏ…W§', '111817@oyoedu.ng', '8143433093', 'IBADAN BOYS HIGH SCHOOL', 'OYO', '111817'),
(1818, '111818', 'úÏ…W§', '111818@oyoedu.ng', '8052272024', 'ST.THERESA\'S SCHOOL', 'OYO', '111818'),
(1819, '111819', 'úÏ…W§', '111819@oyoedu.ng', '8084794181', 'PEOPLE\'S GIRL GRAMMAR SCHOOL', 'OGUN', '111819'),
(1820, '111820', 'úÏ…W§', '111820@oyoedu.ng', '8051332951', 'ADEM GROUP OF SCH', 'OYO', '111820'),
(1821, '111821', 'úÏ…W§', '111821@oyoedu.ng', '8051332951', 'ADEM GROUP OF SCHOOLS', 'OYO', '111821'),
(1822, '111822', 'úÏ…W§', '111822@oyoedu.ng', '8077364758', 'GOD PROPOSES COLL', 'OGUN', '111822'),
(1823, '111823', 'úÏ…W§', '111823@oyoedu.ng', '8032428895', 'FUNDAMENTAL COLLEGE', 'OYO', '111823'),
(1824, '111824', 'úÏ…W§', '111824@oyoedu.ng', '8035785862', 'HEPHZIBAL COLLEGE ', 'OYO', '111824'),
(1825, '111825', 'úÏ…W§', '111825@oyoedu.ng', '8051210520', 'GLORIOUS HIEGHT SCH', 'OSUN', '111825'),
(1826, '111826', 'úÏ…W§', '111826@oyoedu.ng', '8035266752', 'LALAYE LADEJO MEMORIAL SCH', 'OGUN', '111826'),
(1827, '111827', 'úÏ…W§', '111827@oyoedu.ng', '8062141942', 'LIVING MIRACLE HIGH SCHOOL', 'ABIA', '111827'),
(1828, '111828', 'úÏ…W§', '111828@oyoedu.ng', '8163680688', 'SHARPMAN COLLEGE', 'OGUN', '111828'),
(1829, '111829', 'úÏ…W§', '111829@oyoedu.ng', '8060790883', 'CHESIRE HIGH SCH', 'OYO', '111829'),
(1830, '111830', 'úÏ…W§', '111830@oyoedu.ng', '8062141942', 'ADVENTISTN HERITAGE', 'EDO', '111830'),
(1831, '111831', 'úÏ…W§', '111831@oyoedu.ng', '9070312599', 'ADVENTISTN HERITAGE', 'EDO', '111831'),
(1832, '111832', 'úÏ…W§', '111832@oyoedu.ng', '8138525413', 'QUEEN SCHOOL', 'OGUN', '111832'),
(1833, '111833', 'úÏ…W§', '111833@oyoedu.ng', '8135376482', 'GOD\'S THE FOUNDATION', 'EDO', '111833'),
(1834, '111834', 'úÏ…W§', '111834@oyoedu.ng', '8154701128', 'HIS MAJESTY SCH', 'LAGOS', '111834'),
(1835, '111835', 'úÏ…W§', '111835@oyoedu.ng', '8026951868', 'OUR LADY OF APOSTLES', 'OGUN', '111835'),
(1836, '111836', 'úÏ…W§', '111836@oyoedu.ng', '8126918568', 'EVERGREEN HIGHSCH', 'EKITI', '111836'),
(1837, '111837', 'úÏ…W§', '111837@oyoedu.ng', '8106520325', 'KINGS PLACE SECONDARY SCH', 'EKITI', '111837'),
(1838, '111838', 'úÏ…W§', '111838@oyoedu.ng', '8057406313', 'YETAB COMPREHENSIVE SCH', 'OYO', '111838'),
(1839, '111839', 'úÏ…W§', '111839@oyoedu.ng', '9034621487', 'YEJIDE GIRLS GRAMMAR SCH', 'OGUN', '111839'),
(1840, '111840', 'úÏ…W§', '111840@oyoedu.ng', '8026951868', 'GOVERNMENT COLLEGE', 'OYO', '111840'),
(1841, '111841', 'úÏ…W§', '111841@oyoedu.ng', '8057978309', 'GOVERNMENT COLLEGE', 'OYO', '111841'),
(1842, '111842', 'úÏ…W§', '111842@oyoedu.ng', '7036330908', 'IMG HIGH SCHOOL', 'OYO', '111842'),
(1843, '111843', 'úÏ…W§', '111843@oyoedu.ng', '8100051503', 'ST JAMES CATHEDRAL PRI SCH', 'KWARA', '111843'),
(1844, '111844', 'úÏ…W§', '111844@oyoedu.ng', '9050019814', 'EXCEL SIOR COLLEGE', 'OSUN', '111844'),
(1845, '111845', 'úÏ…W§', '111845@oyoedu.ng', '7017552478', 'LIVING MIRACLE', 'OYO', '111845'),
(1846, '111846', 'úÏ…W§', '111846@oyoedu.ng', '8028741255', 'QUEEN\'S SCHOOL', 'OYO', '111846'),
(1847, '111847', 'úÏ…W§', '111847@oyoedu.ng', '8062320792', 'ST.STEVEN COLLEGE', 'OYO', '111847'),
(1848, '111848', 'úÏ…W§', '111848@oyoedu.ng', '9059292919', 'YONBO INT SCH', 'OYO', '111848'),
(1849, '111849', 'úÏ…W§', '111849@oyoedu.ng', '8033710864', 'NEW DAY GROUP OF SCH', 'OYO', '111849'),
(1850, '111850', 'úÏ…W§', '111850@oyoedu.ng', '8062320792', 'ANSAR-UN-DEEN', 'OSUN', '111850'),
(1851, '111851', 'úÏ…W§', '111851@oyoedu.ng', '8059013447', 'ANSRUDEEN HIGH SCH', 'OYO', '111851'),
(1852, '111852', 'úÏ…W§', '111852@oyoedu.ng', '8056029264', 'TARBIT MODEL COLLEGE', 'OSUN', '111852'),
(1853, '111853', 'úÏ…W§', '111853@oyoedu.ng', '8035230587', 'ST LOUIS MOKOLA', 'OSUN', '111853'),
(1854, '111854', 'úÏ…W§', '111854@oyoedu.ng', '9033079643', 'ANSARUDEEN ', 'OYO', '111854'),
(1855, '111855', 'úÏ…W§', '111855@oyoedu.ng', '8037735260', 'DIOSIS COMP COLL', 'OYO', '111855'),
(1856, '111856', 'úÏ…W§', '111856@oyoedu.ng', '8169446152', 'ISDCC', 'OGUN', '111856'),
(1857, '111857', 'úÏ…W§', '111857@oyoedu.ng', '8027303087', 'ST.DAVID HIGH SCHOOL', 'OYO', '111857'),
(1858, '111858', 'úÏ…W§', '111858@oyoedu.ng', '8034971321', 'MARVELLOUS GREATNESS', 'OYO', '111858'),
(1859, '111859', 'úÏ…W§', '111859@oyoedu.ng', '8027303087', 'UNION BAPTIST SCH.', 'KWARA', '111859'),
(1860, '111860', 'úÏ…W§', '111860@oyoedu.ng', '8027303087', 'UNION BAPTIST SCH', 'KWARA', '111860'),
(1861, '111861', 'úÏ…W§', '111861@oyoedu.ng', '8033458431', 'UNION BAPTIST SEC SCHOOL', 'KWARA', '111861'),
(1862, '111862', 'úÏ…W§', '111862@oyoedu.ng', '8050885341', 'COMMUNITY GRAMMAR SCH', 'OYO', '111862'),
(1863, '111863', 'úÏ…W§', '111863@oyoedu.ng', '8038236764', 'GREATER TOMORROW COLLEGE', 'OGUN', '111863'),
(1864, '111864', 'úÏ…W§', '111864@oyoedu.ng', '8035529084', 'CLEVERLAND COLLEGE', 'OYO', '111864'),
(1865, '111865', 'úÏ…W§', '111865@oyoedu.ng', '8079050688', 'TESTIMONY GLORIOUS', 'KWARA', '111865'),
(1866, '111866', 'úÏ…W§', '111866@oyoedu.ng', '8054582221', 'ST.ANNES', 'OYO', '111866'),
(1867, '111867', 'úÏ…W§', '111867@oyoedu.ng', '8030625358', 'GALAXY SCHOOL', 'OYO', '111867'),
(1868, '111868', 'úÏ…W§', '111868@oyoedu.ng', '8031331819', 'FEDERAL GOVERNMENT COLLEGE', 'OYO', '111868'),
(1869, '111869', 'úÏ…W§', '111869@oyoedu.ng', '80023929261', 'IBHS', 'OYO', '111869'),
(1870, '111870', 'úÏ…W§', '111870@oyoedu.ng', '8085451187', 'SHIELD MODEL', 'OYO', '111870'),
(1871, '111871', 'úÏ…W§', '111871@oyoedu.ng', '8056663579', 'CHRIST HIGH SCH', 'OYO', '111871'),
(1872, '111872', 'úÏ…W§', '111872@oyoedu.ng', '8109939367', 'RHODA\'S FOUNDATION', 'OGUN', '111872'),
(1873, '111873', 'úÏ…W§', '111873@oyoedu.ng', '8160907031', 'THE LEADERS COLLEGE', 'OYO', '111873'),
(1874, '111874', 'úÏ…W§', '111874@oyoedu.ng', '8058627524', 'ST ANNES JUNIOR SCH', 'OYO', '111874'),
(1875, '111875', 'úÏ…W§', '111875@oyoedu.ng', '7040446342', 'BAPTIST SEC. SCH.', 'OYO', '111875'),
(1876, '111876', 'úÏ…W§', '111876@oyoedu.ng', '8057977646', 'EMPROR GOLD COLLEGE', 'OSUN', '111876'),
(1877, '111877', 'úÏ…W§', '111877@oyoedu.ng', '8056551476', 'EMPEROR COLLEGE', 'OSUN', '111877'),
(1878, '111878', 'úÏ…W§', '111878@oyoedu.ng', '8057977646', 'EMPEROR COLLEGE', 'OYO', '111878'),
(1879, '111879', 'úÏ…W§', '111879@oyoedu.ng', '8065796596', 'EMPEROR COLLEGE', 'OYO', '111879'),
(1880, '111880', 'úÏ…W§', '111880@oyoedu.ng', '7040446342', 'MERCY COLLEGE', 'OYO', '111880'),
(1881, '111881', 'úÏ…W§', '111881@oyoedu.ng', '8056718011', 'EMPEROR COLLEGE', 'OSUN', '111881'),
(1882, '111882', 'úÏ…W§', '111882@oyoedu.ng', '8057977646', 'EMPROR GOLD COLLEGE', 'OSUN', '111882'),
(1883, '111883', 'úÏ…W§', '111883@oyoedu.ng', '8077981969', 'OYO STATE COMPREHENSIVE MODEL COLLEGE', 'OYO', '111883'),
(1884, '111884', 'úÏ…W§', '111884@oyoedu.ng', '8138079508', 'TOPBRAIN COMP COLLEGE', 'OYO', '111884'),
(1885, '111885', 'úÏ…W§', '111885@oyoedu.ng', '7033701112', 'ABADINA SECONDARY SCH', 'OYO', '111885'),
(1886, '111886', 'úÏ…W§', '111886@oyoedu.ng', '8034788824', 'NEW IFE OLU CIOLLEGE', 'OYO', '111886'),
(1887, '111887', 'úÏ…W§', '111887@oyoedu.ng', '8152573972', 'IBADAN BOYS HIGH SCH', 'OSUN', '111887'),
(1888, '111888', 'úÏ…W§', '111888@oyoedu.ng', '8038090356', 'GRACE OF GOD', 'OGUN', '111888'),
(1889, '111889', 'úÏ…W§', '111889@oyoedu.ng', '8100073156', 'OKE ADO BAPTIST ', 'OGUN', '111889'),
(1890, '111890', 'úÏ…W§', '111890@oyoedu.ng', '8170338567', 'RIDWANLLAHI', 'OYO', '111890'),
(1891, '111891', 'úÏ…W§', '111891@oyoedu.ng', '8103308215', 'COMMUNITY GRAMMAR SCH', 'OSUN', '111891'),
(1892, '111892', 'úÏ…W§', '111892@oyoedu.ng', '8040751113', 'SAGHS', 'OYO', '111892'),
(1893, '111893', 'úÏ…W§', '111893@oyoedu.ng', '8053006627', 'UNION BAPTIST COLLEGE', 'EKITI', '111893'),
(1894, '111894', 'úÏ…W§', '111894@oyoedu.ng', '8036029569', 'AMAD GROUP OF SCH', 'OSUN', '111894'),
(1895, '111895', 'úÏ…W§', '111895@oyoedu.ng', '', 'MOREX SCHOOL', 'OGUN', '111895'),
(1896, '111896', 'úÏ…W§', '111896@oyoedu.ng', '8034040469', 'MORET SECONDARY SCH', 'OGUN', '111896'),
(1897, '111897', 'úÏ…W§', '111897@oyoedu.ng', '8034040469', 'MORET SECONDARY SCH', 'OGUN ', '111897'),
(1898, '111898', 'úÏ…W§', '111898@oyoedu.ng', '8034895431', '', 'OYO', '111898'),
(1899, '111899', 'úÏ…W§', '111899@oyoedu.ng', '8132757633', 'LYDEB COLLEGE', 'OYO', '111899'),
(1900, '111900', 'úÏ…W§', '111900@oyoedu.ng', '8038293353', 'OUR LADY OF APOSTLES', 'OYO', '111900'),
(1901, '111901', 'úÏ…W§', '111901@oyoedu.ng', '8126241636', 'BODIJA INT\'L COLLEGE', 'OYO', '111901'),
(1902, '111902', 'úÏ…W§', '111902@oyoedu.ng', '8054039578', 'DALDM SCH', 'OYO', '111902'),
(1903, '111903', 'úÏ…W§', '111903@oyoedu.ng', '7057529295', 'GLORIOUS MODEL COLLEGE', 'OYO', '111903'),
(1904, '111904', 'úÏ…W§', '111904@oyoedu.ng', '7060537931', 'QUEENS SCHOOL', 'OSUN', '111904'),
(1905, '111905', 'úÏ…W§', '111905@oyoedu.ng', '8038094752', 'THE APOSTOLIC MODEL COLLEGE', 'OYO', '111905'),
(1906, '111906', 'úÏ…W§', '111906@oyoedu.ng', '9043474715', 'ST.ANNES', 'OYO', '111906'),
(1907, '111907', 'úÏ…W§', '111907@oyoedu.ng', '8052247442', 'COMMAND SCH', 'OYO', '111907'),
(1908, '111908', 'úÏ…W§', '111908@oyoedu.ng', '9026647483', 'QUEENS SCH', 'OYO', '111908'),
(1909, '111909', 'úÏ…W§', '111909@oyoedu.ng', '8076353966', 'BRAIN GOLO INT\'L SCH', 'OSUN', '111909'),
(1910, '111910', 'úÏ…W§', '111910@oyoedu.ng', '8035791977', 'ESTATE JUNIOR GRAMMAR SCH', 'LAGOS', '111910'),
(1911, '111911', 'úÏ…W§', '111911@oyoedu.ng', '9076274973', 'OKEBOLA COMP.', 'OYO', '111911'),
(1912, '111912', 'úÏ…W§', '111912@oyoedu.ng', '7033996700', 'ST.THERESA', 'OYO', '111912'),
(1913, '111913', 'úÏ…W§', '111913@oyoedu.ng', '8038633553', 'LEADERS COLLEGE', 'EKITI', '111913'),
(1914, '111914', 'úÏ…W§', '111914@oyoedu.ng', '8038228488', 'BHIS', 'OYO', '111914'),
(1915, '111915', 'úÏ…W§', '111915@oyoedu.ng', '9038228488', 'BOYS HIGH SCH', 'OYO', '111915'),
(1916, '111916', 'úÏ…W§', '111916@oyoedu.ng', '8061163575', 'ST.LOUIS SCHOOL', 'ONDO', '111916'),
(1917, '111917', 'úÏ…W§', '111917@oyoedu.ng', '7030062808', 'THE LIGHT ACADEMY', 'DELTA', '111917'),
(1918, '111918', 'úÏ…W§', '111918@oyoedu.ng', '8055302854', 'PRINCELY COLLEGE', 'OGUN', '111918'),
(1919, '111919', 'úÏ…W§', '111919@oyoedu.ng', '8033639071', 'QUEENS SCH INT\'L', 'OYO', '111919'),
(1920, '111920', 'úÏ…W§', '111920@oyoedu.ng', '8033675691', 'THE RIGHT ACHIEVER', 'OYO', '111920'),
(1921, '111921', 'úÏ…W§', '111921@oyoedu.ng', '8033675691', 'THE RIGHT ACHIEVER', 'OYO', '111921'),
(1922, '111922', 'úÏ…W§', '111922@oyoedu.ng', '8079970003', 'DAARUL HIKMAH', 'OYO', '111922'),
(1923, '111923', 'úÏ…W§', '111923@oyoedu.ng', '8056052352', 'DARUN HIKMU SCHOOL', 'OYO', '111923'),
(1924, '111924', 'úÏ…W§', '111924@oyoedu.ng', '8135903074', 'INNER VISION COLLEGE', 'OGUN', '111924'),
(1925, '111925', 'úÏ…W§', '111925@oyoedu.ng', '9055725238', 'IBUKUNOLU SCH', 'OYO', '111925'),
(1926, '111926', 'úÏ…W§', '111926@oyoedu.ng', '8072833916', 'ALROKEEB INT\'L', 'OYO', '111926'),
(1927, '111927', 'úÏ…W§', '111927@oyoedu.ng', '8077797397', 'THE NOBLE STANDARD', 'OYO', '111927'),
(1928, '111928', 'úÏ…W§', '111928@oyoedu.ng', '8028831392', 'WHITE CRESENT ACADEMY', 'OYO', '111928'),
(1929, '111929', 'úÏ…W§', '111929@oyoedu.ng', '7059696990', 'ST ANNES JUNIOR SCH', 'OYO', '111929'),
(1930, '111930', 'úÏ…W§', '111930@oyoedu.ng', '8028591272', 'QUEENS SCHOOL', 'OGUN', '111930'),
(1931, '111931', 'úÏ…W§', '111931@oyoedu.ng', '806650663', 'MOSLEEM SCHOOL', 'OYO', '111931'),
(1932, '111932', 'úÏ…W§', '111932@oyoedu.ng', '8171444046', 'CRESENT SCH OF ART AND SCIENCE', 'OYO', '111932'),
(1933, '111933', 'úÏ…W§', '111933@oyoedu.ng', '8108249365', 'YEJIDE GIRLS GRAMMAR SCH', 'OYO', '111933'),
(1934, '111934', 'úÏ…W§', '111934@oyoedu.ng', '9064327647', 'YEJIDE GIRLS GRAMMAR SCH', 'OYO', '111934'),
(1935, '111935', 'úÏ…W§', '111935@oyoedu.ng', '81674771614', 'HOPES AND FAITH ', 'ONDO', '111935'),
(1936, '111936', 'úÏ…W§', '111936@oyoedu.ng', '8056144791', 'ECWA MODEL', 'OYO', '111936'),
(1937, '111937', 'úÏ…W§', '111937@oyoedu.ng', '8055750254', 'CEDAR MATHETEIN COLLEGE', 'OYO', '111937'),
(1938, '111938', 'úÏ…W§', '111938@oyoedu.ng', '9054070734', 'ORITAMEFA BAPTIST MODEL SCHOOL', 'OYO', '111938'),
(1939, '111939', 'úÏ…W§', '111939@oyoedu.ng', '8060702954', 'BENEVOLENT SCHOOL', 'OSUN', '111939'),
(1940, '111940', 'úÏ…W§', '111940@oyoedu.ng', '8039154279', 'MARVELLOUS GRAMMAR SCH', 'OSUN', '111940'),
(1941, '111941', 'úÏ…W§', '111941@oyoedu.ng', '8056111037', 'CHRIST LOVE GROUP OF SSCHOOL', 'OYO', '111941'),
(1942, '111942', 'úÏ…W§', '111942@oyoedu.ng', '8079919275', 'DISTINGUISH TUTORS SEC SCH', 'OYO', '111942'),
(1943, '111943', 'úÏ…W§', '111943@oyoedu.ng', '9016588962', 'COMMAND SCHOOL', 'OSUN', '111943'),
(1944, '111944', 'úÏ…W§', '111944@oyoedu.ng', '8067331920', 'ST.LUKES SCHOOL', 'OYO', '111944'),
(1945, '111945', 'úÏ…W§', '111945@oyoedu.ng', '9078135183', 'JOSABIG SCH', 'SOKOTO', '111945'),
(1946, '111946', 'úÏ…W§', '111946@oyoedu.ng', '8026534320', 'ADEM GROUP OF SCHOOLS', 'OGUN', '111946'),
(1947, '111947', 'úÏ…W§', '111947@oyoedu.ng', '8133006298', 'GOD-GRACE SCHOOL', 'IBADAN', '111947'),
(1948, '111948', 'úÏ…W§', '111948@oyoedu.ng', '8078898482', 'SOLID FOUNDATION', 'EDO', '111948'),
(1949, '111949', 'úÏ…W§', '111949@oyoedu.ng', '7089091260', 'AM-FM GODS GRACE', 'OYO', '111949'),
(1950, '111950', 'úÏ…W§', '111950@oyoedu.ng', '8071634628', 'APERIN LEKURO', 'OYO', '111950'),
(1951, '111951', 'úÏ…W§', '111951@oyoedu.ng', '8132184276', 'IBADAN GRAMMAR', 'OSUN', '111951'),
(1952, '111952', 'úÏ…W§', '111952@oyoedu.ng', '8053324092', 'EHINNI COMMUNITY ORITA CHALLENGE', 'OYO', '111952'),
(1953, '111953', 'úÏ…W§', '111953@oyoedu.ng', '8060999666', 'IDI IKAN BAPTIST HIGH SCH', 'EKITI', '111953'),
(1954, '111954', 'úÏ…W§', '111954@oyoedu.ng', '8056605469', 'OBA ABAS ALESINLOYE GRAMM', 'KOGI', '111954'),
(1955, '111955', 'úÏ…W§', '111955@oyoedu.ng', '8078275311', 'COMMAND DAY SEC SCH', 'OYO', '111955'),
(1956, '111956', 'úÏ…W§', '111956@oyoedu.ng', '9060021063', 'GCI APATA', 'OGUN', '111956'),
(1957, '111957', 'úÏ…W§', '111957@oyoedu.ng', '8177531219', 'FIRST CLASS ACADEMY', 'OYO', '111957'),
(1958, '111958', 'úÏ…W§', '111958@oyoedu.ng', '9025966708', 'OUR LADY OF APOSTLE', 'OYO', '111958'),
(1959, '111959', 'úÏ…W§', '111959@oyoedu.ng', '9099186450', 'UNION BAPTIST', 'KWARA', '111959'),
(1960, '111960', 'úÏ…W§', '111960@oyoedu.ng', '7051394604', 'AYEGUN COMMUNITY GRAMMAR', 'OYO', '111960'),
(1961, '111961', 'úÏ…W§', '111961@oyoedu.ng', '8151361136', 'JOFIA INT\'L COLLEGE', 'OYO', '111961'),
(1962, '111962', 'úÏ…W§', '111962@oyoedu.ng', '8162087850', 'AL-INSAAN CITADEL OF SCHOOLS', 'OYO', '111962'),
(1963, '111963', 'úÏ…W§', '111963@oyoedu.ng', '8065729747', 'TA\'AWUNU SEC. SCH.', 'OYO', '111963'),
(1964, '111964', 'úÏ…W§', '111964@oyoedu.ng', '7059422674', 'THE TARGET GROUP OF SCH', 'OYO', '111964'),
(1965, '111965', 'úÏ…W§', '111965@oyoedu.ng', '8053192030', 'HIS MAJESTY COLLEGE', 'LAGOS ', '111965'),
(1966, '111966', 'úÏ…W§', '111966@oyoedu.ng', '8151037935', 'ABUNDANT LIFE SCH', 'OYO', '111966'),
(1967, '111967', 'úÏ…W§', '111967@oyoedu.ng', '8077971889', 'EYINNI JUNIOR  HIGH SCH', 'OYO', '111967'),
(1968, '111968', 'úÏ…W§', '111968@oyoedu.ng', '8034272367', 'OPTIMUM COMP. COLLEGE', 'OYO', '111968'),
(1969, '111969', 'úÏ…W§', '111969@oyoedu.ng', '7067448203', 'HILLCREST HIGH SCHOOL', 'OYO', '111969'),
(1970, '111970', 'úÏ…W§', '111970@oyoedu.ng', '9064930175', 'ADE FEDERAL GOVERNMENT SCH', 'OYO', '111970'),
(1971, '111971', 'úÏ…W§', '111971@oyoedu.ng', '8065642089', 'REHOBOT COLLEGE', 'OYO', '111971'),
(1972, '111972', 'úÏ…W§', '111972@oyoedu.ng', '7067448203', 'REOBATH GROUP OF SCH', 'OYO', '111972'),
(1973, '111973', 'úÏ…W§', '111973@oyoedu.ng', '8054676959', 'ST.ANNES JUNIOR SEC SCH', 'OSUN', '111973'),
(1974, '111974', 'úÏ…W§', '111974@oyoedu.ng', '8055456193', 'LEADERS COLLEGE', 'OYO', '111974'),
(1975, '111975', 'úÏ…W§', '111975@oyoedu.ng', '8039288564', 'TOP BRAIN KIDDIES', 'OYO', '111975'),
(1976, '111976', 'úÏ…W§', '111976@oyoedu.ng', '7067448203', 'INNER VISION HIGH', 'OYO', '111976'),
(1977, '111977', 'úÏ…W§', '111977@oyoedu.ng', '8127594192', 'GOVERNMENT COLEGE', 'KOGI', '111977'),
(1978, '111978', 'úÏ…W§', '111978@oyoedu.ng', '8127594192', 'GOVERNMENT COLEGE', 'KOGI', '111978'),
(1979, '111979', 'úÏ…W§', '111979@oyoedu.ng', '8053241751', 'REHOBOT COLLEGE', 'OYO', '111979'),
(1980, '111980', 'úÏ…W§', '111980@oyoedu.ng', '7067448003', 'REOBATH GROUP OF SCH', 'OYO', '111980'),
(1981, '311981', 'úÏ…W§', '311981@oyoedu.ng', '8064538726', 'COMMAND DAY', 'OYO', '311981'),
(1982, '111982', 'úÏ…W§', '111982@oyoedu.ng', '8070713024', 'ANGLICAN GRAMMER SCHOOL', 'OYO', '111982'),
(1983, '111983', 'úÏ…W§', '111983@oyoedu.ng', '8034927319', 'A MAKER SEC SCH', 'KOGI', '111983'),
(1984, '111984', 'úÏ…W§', '111984@oyoedu.ng', '8155644196', 'HOLY TRINITY GRAMMAR SCH', 'OYO', '111984'),
(1985, '111985', 'úÏ…W§', '111985@oyoedu.ng', '8103753230', 'SMABIIF COLLEGE AKOBO', 'OYO', '111985'),
(1986, '111986', 'úÏ…W§', '111986@oyoedu.ng', '8039554587', 'ADOF KINGS AND QUEENS COOLEGE', 'KOGI', '111986'),
(1987, '111987', 'úÏ…W§', '111987@oyoedu.ng', '8035144990', 'PENVIL ACADEMY', 'OYO', '111987'),
(1988, '111988', 'úÏ…W§', '111988@oyoedu.ng', '8063038481', 'METHODIST GRAMMER SCH', 'KANO', '111988'),
(1989, '111989', 'úÏ…W§', '111989@oyoedu.ng', '8131664022', 'SHIELD MODEL', 'OYO', '111989'),
(1990, '111990', 'úÏ…W§', '111990@oyoedu.ng', '8051636510', 'MORNING START COMPREHENSIVE', 'OYO', '111990'),
(1991, '111991', 'úÏ…W§', '111991@oyoedu.ng', '8131664022', 'PEOPLES GIRL GRAMMAR SCH', 'OYO', '111991'),
(1992, '111992', 'úÏ…W§', '111992@oyoedu.ng', '8131664022', 'PEOPLE\\S GIRLS\' GRAMM', 'OYO', '111992'),
(1993, '111993', 'úÏ…W§', '111993@oyoedu.ng', '8023268859', 'PEOPLE\'S GIRLS \'GRAMM', 'OYO', '111993'),
(1994, '111994', 'úÏ…W§', '111994@oyoedu.ng', '8054354239', 'FRONT MODEL COLLEGE', 'OYO', '111994'),
(1995, '111995', 'úÏ…W§', '111995@oyoedu.ng', '8023268859', 'QUEENS COLLEGE', 'OSUN', '111995'),
(1996, '111996', 'úÏ…W§', '111996@oyoedu.ng', '8028252481', 'QUEENS COLLEGE', 'OSUN', '111996'),
(1997, '111997', 'úÏ…W§', '111997@oyoedu.ng', '9052139568', 'MUSLIM GRAMMAR SCH', 'OYO', '111997'),
(1998, '111998', 'úÏ…W§', '111998@oyoedu.ng', '7061345202', 'ST.ANNES SCHOOL', 'OYO', '111998'),
(1999, '111999', 'úÏ…W§', '111999@oyoedu.ng', '8055052082', 'MARVELLOUS SCH', 'OYO', '111999'),
(2000, '112000', 'úÏ…W§', '112000@oyoedu.ng', '8132013996', 'OYO STATE COMP MODEL COLL', 'OYO', '112000'),
(2001, '112001', 'úÏ…W§', '112001@oyoedu.ng', '8110240390', 'MUSLIM MODEL COLL', 'OYO', '112001'),
(2002, '112002', 'úÏ…W§', '112002@oyoedu.ng', '7084491277', 'MUSLIM MODEL COLLEGE', 'OYO', '112002'),
(2003, '112003', 'úÏ…W§', '112003@oyoedu.ng', '8132013996', 'EHINNI COMMUNITY ORITA CHALLENGE', 'DELTA', '112003'),
(2004, '112004', 'úÏ…W§', '112004@oyoedu.ng', '8060446678', 'EYINNI COMMUITY', 'DELTA', '112004'),
(2005, '112005', 'úÏ…W§', '112005@oyoedu.ng', '8055203674', 'GOOD SHEPERED SCH', 'OGUN', '112005'),
(2006, '112006', 'úÏ…W§', '112006@oyoedu.ng', '8079765572', 'EXCEPTIONAL STAR', 'OSUN', '112006'),
(2007, '112007', 'úÏ…W§', '112007@oyoedu.ng', '7059284227', 'IB GRAMMAR SCH', 'OYO', '112007'),
(2008, '112008', 'úÏ…W§', '112008@oyoedu.ng', '8034029619', 'IBADAN GRAM SCH MOLETE', 'OYO', '112008'),
(2009, '112009', 'úÏ…W§', '112009@oyoedu.ng', '8063150955', 'RIDWANLLAHI', 'OYO', '112009'),
(2010, '112010', 'úÏ…W§', '112010@oyoedu.ng', '8028539697', 'STEADFAST COMP.', 'OYO', '112010'),
(2011, '112011', 'úÏ…W§', '112011@oyoedu.ng', '8135380208', 'COMMUNITYN HIGH BAKO', 'OYO', '112011'),
(2012, '112012', 'úÏ…W§', '112012@oyoedu.ng', '9055899516', 'ST. ANNES MOLETE', 'OGUN', '112012'),
(2013, '112013', 'úÏ…W§', '112013@oyoedu.ng', '8159499932', 'OKEBOLA COMP', 'OGUN', '112013'),
(2014, '112014', 'úÏ…W§', '112014@oyoedu.ng', '8174215291', 'IMG SCHOOL', 'OGUN', '112014'),
(2015, '112015', 'úÏ…W§', '112015@oyoedu.ng', '8076736887', 'SAINT BRIDGES SECOND', 'OGUN', '112015'),
(2016, '112016', 'úÏ…W§', '112016@oyoedu.ng', '8020825965', 'ADESANYA COMM. HIGH SC.', 'OGUN', '112016'),
(2017, '112017', 'úÏ…W§', '112017@oyoedu.ng', '8020805965', 'RIDWALAHI COMP.', 'OYO', '112017'),
(2018, '112018', 'úÏ…W§', '112018@oyoedu.ng', '8077889845', 'RIDWALAHI COMP.', 'OYO', '112018'),
(2019, '112019', 'úÏ…W§', '112019@oyoedu.ng', '8102079166', 'ATANDA INT\'L SCHOOL OLUYOLE', 'OGUN', '112019'),
(2020, '112020', 'úÏ…W§', '112020@oyoedu.ng', '8034382718', 'FORWELL COLLEGE', 'OYO', '112020'),
(2021, '112021', 'úÏ…W§', '112021@oyoedu.ng', '8124299250', 'ADONAI ADVANCE COLEGE', 'OYO', '112021'),
(2022, '112022', 'úÏ…W§', '112022@oyoedu.ng', '8080996649', 'IJEBU MUSLIM COLLEGE', 'OYO', '112022'),
(2023, '112023', 'úÏ…W§', '112023@oyoedu.ng', '8076155826', 'EMESTH CHRIST SCH', 'OGUN', '112023'),
(2024, '112024', 'úÏ…W§', '112024@oyoedu.ng', '8052132187', 'SOMIAT COLLEGE OYO STATE', 'OGUN', '112024'),
(2025, '112025', 'úÏ…W§', '112025@oyoedu.ng', '7037491073', 'AL ALEEM SCH', 'OYO', '112025'),
(2026, '112026', 'úÏ…W§', '112026@oyoedu.ng', '9026436437', 'ECWA', 'OGUN', '112026'),
(2027, '112027', 'úÏ…W§', '112027@oyoedu.ng', '8052212658', 'GEORGE AND DUKE INSTITUTION', 'OGUN', '112027'),
(2028, '112028', 'úÏ…W§', '112028@oyoedu.ng', '7060507738', 'ISPC COLLEGE', 'OYO', '112028'),
(2029, '112029', 'úÏ…W§', '112029@oyoedu.ng', '8034269201', 'EPHRAIM BAPTIST COLLEGE', 'OYO', '112029'),
(2030, '112030', 'úÏ…W§', '112030@oyoedu.ng', '8169446152', 'HERITAGE FOUNDATION SCHOOL', 'OYO', '112030'),
(2031, '112031', 'úÏ…W§', '112031@oyoedu.ng', '9028400966', 'JUBILEE ROSE SCHOOL', 'OYO', '112031'),
(2032, '112032', 'úÏ…W§', '112032@oyoedu.ng', '8062100453', 'BAPTIST SEC SCH', 'OYO', '112032'),
(2033, '112033', 'úÏ…W§', '112033@oyoedu.ng', '8034269201', 'EPHRAIM BAPTIST ', 'OYO', '112033');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(2034, '112034', 'úÏ…W§', '112034@oyoedu.ng', '8155389570', 'PACESSETTER COMPREHENSIVE COLLEGE', 'OYO', '112034'),
(2035, '112035', 'úÏ…W§', '112035@oyoedu.ng', '7030264046', 'AS-SALAM MODEL', 'OGUN', '112035'),
(2036, '112036', 'úÏ…W§', '112036@oyoedu.ng', '8053006627', 'MUFULLHUN HIGH SCH', 'OYO', '112036'),
(2037, '112037', 'úÏ…W§', '112037@oyoedu.ng', '8087231169', 'MOREX SCHOOL', 'OGUN', '112037'),
(2038, '112038', 'úÏ…W§', '112038@oyoedu.ng', '8060874038', 'SONDORA COLLEGE', 'EDO', '112038'),
(2039, '112039', 'úÏ…W§', '112039@oyoedu.ng', '8033240938', 'AT ALBERT CATHOLIC SCH', 'OGUN', '112039'),
(2040, '112040', 'úÏ…W§', '112040@oyoedu.ng', '8060874038', 'BOYS HIGH SCHOOL', 'BENUE', '112040'),
(2041, '112041', 'úÏ…W§', '112041@oyoedu.ng', '8038056669', 'BOYS HIGH SCHOOL', 'BENUE', '112041'),
(2042, '112042', 'úÏ…W§', '112042@oyoedu.ng', '7033686676', 'LAUNCH OUT COLLEGE SCH', 'OYO', '112042'),
(2043, '112043', 'úÏ…W§', '112043@oyoedu.ng', '8180306984', 'THE LIGHT ACADEMY', 'OGUN', '112043'),
(2044, '112044', 'úÏ…W§', '112044@oyoedu.ng', '7086557457', 'COMMUNITY GRAMMAR SCH', 'OGUN', '112044'),
(2045, '112045', 'úÏ…W§', '112045@oyoedu.ng', '9066901480', 'JANET COMPREHENSIVE COLLEGE', 'OYO', '112045'),
(2046, '112046', 'úÏ…W§', '112046@oyoedu.ng', '', 'SCEPTER PRIVATE', 'OYO', '112046'),
(2047, '112047', 'úÏ…W§', '112047@oyoedu.ng', '8068561852', 'APOSTOLIC FAITH', 'OYO', '112047'),
(2048, '112048', 'úÏ…W§', '112048@oyoedu.ng', '8077057901', 'ST.THERESA\'S COLLEGE', 'OGUN', '112048'),
(2049, '112049', 'úÏ…W§', '112049@oyoedu.ng', '', 'ST TERESSA COLL', 'OGUN', '112049'),
(2050, '112050', 'úÏ…W§', '112050@oyoedu.ng', '8054319544', 'OYO STATE COMP MODEL COLL', 'OYO', '112050'),
(2051, '112051', 'úÏ…W§', '112051@oyoedu.ng', '8077057901', 'OYO STATE COMPREHENSIVE MODEL COLLEGE', 'OYO', '112051'),
(2052, '112052', 'úÏ…W§', '112052@oyoedu.ng', '9055736643', 'IBADAN GRAMMAR SCH', 'EKITI', '112052'),
(2053, '112053', 'úÏ…W§', '112053@oyoedu.ng', '8075397527', 'ANGLICAN GRAMMAR', 'OYO', '112053'),
(2054, '112054', 'úÏ…W§', '112054@oyoedu.ng', '59362691', 'EBENEZER A/C GRAMMER SCH.', 'OYO', '112054'),
(2055, '112055', 'úÏ…W§', '112055@oyoedu.ng', '8053073618', 'EPHRAIM KIDDIS SEC', 'OYO', '112055'),
(2056, '112056', 'úÏ…W§', '112056@oyoedu.ng', '9132510676', 'MUFLIHUN HIGH SCHOOL', 'OYO', '112056'),
(2057, '112057', 'úÏ…W§', '112057@oyoedu.ng', '8130908743', 'ING GRAMM SCH', 'OYO', '112057'),
(2058, '112058', 'úÏ…W§', '112058@oyoedu.ng', '7064467408', 'THE VIRTUE COLLEGE', 'OYO', '112058'),
(2059, '112059', 'úÏ…W§', '112059@oyoedu.ng', '9084801748', 'OXFORD B COLLEGE', 'OYO', '112059'),
(2060, '112060', 'úÏ…W§', '112060@oyoedu.ng', '9036464732', 'ADEOLA ODUTOLA COLLEGE', 'ONDO', '112060'),
(2061, '112061', 'úÏ…W§', '112061@oyoedu.ng', '8083210075', 'ALMUNIR MODEL', 'OYO', '112061'),
(2062, '112062', 'úÏ…W§', '112062@oyoedu.ng', '8138582556', 'QUEENS SCH', 'ONDO', '112062'),
(2063, '112063', 'úÏ…W§', '112063@oyoedu.ng', '7062543542', 'MATRIX COLLEGE', 'CROSS RIVER', '112063'),
(2064, '112064', 'úÏ…W§', '112064@oyoedu.ng', '7062543512', 'MATRIX COLLEGE', 'CROSS RIVER', '112064'),
(2065, '112065', 'úÏ…W§', '112065@oyoedu.ng', '8034988931', 'THE LORD OF HOST', 'IMO', '112065'),
(2066, '112066', 'úÏ…W§', '112066@oyoedu.ng', '8033725936', 'BASHORUN OGUNMOLA I.B', 'OYO', '112066'),
(2067, '112067', 'úÏ…W§', '112067@oyoedu.ng', '8132331712', 'OKE-BOLA COMPREHENSIVE', '', '112067'),
(2068, '112068', 'úÏ…W§', '112068@oyoedu.ng', '8072981714', 'GODS PLAN MODEL COLLEGE', 'OYO', '112068'),
(2069, '112069', 'úÏ…W§', '112069@oyoedu.ng', '8063172184', 'IBADAN GRAMMAR SCH', 'OYO', '112069'),
(2070, '112070', 'úÏ…W§', '112070@oyoedu.ng', '8051321313', 'ST.LUKES COLLEGE', 'OYO', '112070'),
(2071, '112071', 'úÏ…W§', '112071@oyoedu.ng', '8079220015', 'ORIADE COMPREHENSIVE SCH', 'OYO', '112071'),
(2072, '112072', 'úÏ…W§', '112072@oyoedu.ng', '8036741680', 'RUBBIES INT\'L COLLEGE', 'OYO', '112072'),
(2073, '112073', 'úÏ…W§', '112073@oyoedu.ng', '8036741680', 'BAPTIST GRAMMAR SCH', 'OYO', '112073'),
(2074, '112074', 'úÏ…W§', '112074@oyoedu.ng', '8066778736', 'BAPTIST GRAMMAR SCH', 'OYO', '112074'),
(2075, '112075', 'úÏ…W§', '112075@oyoedu.ng', '8038403218', 'ST ANNES SCH', 'OYO', '112075'),
(2076, '112076', 'úÏ…W§', '112076@oyoedu.ng', '80231770835', 'GLAD TIDIES ', 'OYO', '112076'),
(2077, '112077', 'úÏ…W§', '112077@oyoedu.ng', '9029443203', 'BOYS HIGH SCHOOL', 'IMO', '112077'),
(2078, '112078', 'úÏ…W§', '112078@oyoedu.ng', '8165516270', 'ELEYELE HIGH SCHOOL', 'ANAMBRA', '112078'),
(2079, '112079', 'úÏ…W§', '112079@oyoedu.ng', '8058088268', 'IBD GRAMMER SCH', 'AKWA IBOM', '112079'),
(2080, '112080', 'úÏ…W§', '112080@oyoedu.ng', '7040933664', 'ST.THERESA\'S COLLEGE', 'DELTA', '112080'),
(2081, '112081', 'úÏ…W§', '112081@oyoedu.ng', '7033788687', 'QUEEN\'S SCHOOL', 'DELTA', '112081'),
(2082, '112082', 'úÏ…W§', '112082@oyoedu.ng', '8160798647', 'GREAT GRACE CAMPUS', 'ENUGU', '112082'),
(2083, '112083', 'úÏ…W§', '112083@oyoedu.ng', '8128809058', 'SEAT OF WISDOM', 'KOGI', '112083'),
(2084, '112084', 'úÏ…W§', '112084@oyoedu.ng', '8128809058', 'GLORIFIED UNIQUE COLL ', 'ANAMBRA', '112084'),
(2085, '112085', 'úÏ…W§', '112085@oyoedu.ng', '8062515401', 'GLORIFIED UNIQUE', 'ANAMBRA', '112085'),
(2086, '112086', 'úÏ…W§', '112086@oyoedu.ng', '8037274408', 'FIRM FOUNDATION', 'EDO', '112086'),
(2087, '112087', 'úÏ…W§', '112087@oyoedu.ng', '8131960385', 'DIVINE COLLEGE', 'EDO', '112087'),
(2088, '112088', 'úÏ…W§', '112088@oyoedu.ng', '8078513315', 'ST. TERESA\'S COLLEGE', 'OYO', '112088'),
(2089, '112089', 'úÏ…W§', '112089@oyoedu.ng', '8117179947', 'ST TERESSA COLL', 'OYO', '112089'),
(2090, '112090', 'úÏ…W§', '112090@oyoedu.ng', '8029688543', 'COMM.GRAM SCHOOL', 'OYO', '112090'),
(2091, '112091', 'úÏ…W§', '112091@oyoedu.ng', '8034387575', 'SUCCESS ARCEIVER', 'OYO', '112091'),
(2092, '112092', 'úÏ…W§', '112092@oyoedu.ng', '7064272252', 'ST.MICHEAL SCHOOL', 'AKWA', '112092'),
(2093, '112093', 'úÏ…W§', '112093@oyoedu.ng', '8073926492', 'ARMY COMMAND', 'IMO', '112093'),
(2094, '112094', 'úÏ…W§', '112094@oyoedu.ng', '8061163603', 'D-WAY GROUP', 'ENUGU', '112094'),
(2095, '112095', 'úÏ…W§', '112095@oyoedu.ng', '8030644088', 'ECWA MODEL', 'OYO', '112095'),
(2096, '112096', 'úÏ…W§', '112096@oyoedu.ng', '7052631147', 'ST.ANNES SCHOOL', 'RIVER', '112096'),
(2097, '112097', 'úÏ…W§', '112097@oyoedu.ng', '7052631147', 'ST ANNES JUNIOR SCH', 'OYO', '112097'),
(2098, '112098', 'úÏ…W§', '112098@oyoedu.ng', '7082845157', 'ST. ANNS SCHOOL', 'OYO', '112098'),
(2099, '112099', 'úÏ…W§', '112099@oyoedu.ng', '8037265034', 'ABAYOMI COLLEGE', 'EKITI', '112099'),
(2100, '112100', 'úÏ…W§', '112100@oyoedu.ng', '8038104522', 'MOLETE BAPTIST SCHOOL', 'LAGOS', '112100'),
(2101, '112101', 'úÏ…W§', '112101@oyoedu.ng', '7056839706', 'COMMAND SEC SCH.MOKOLA', 'ONDO', '112101'),
(2102, '112102', 'úÏ…W§', '112102@oyoedu.ng', '8033935848', 'ST.THERESA', 'OYO', '112102'),
(2103, '112103', 'úÏ…W§', '112103@oyoedu.ng', '8057070508', 'FOUNDATION COLLEGE AGUGU', 'OYO', '112103'),
(2104, '112104', 'úÏ…W§', '112104@oyoedu.ng', '8140072972', 'COMMUNITY GRAMM SCH', 'KOGI', '112104'),
(2105, '112105', 'úÏ…W§', '112105@oyoedu.ng', '7052743349', 'BAKO HIGH SCHOOL', 'OGUN', '112105'),
(2106, '112106', 'úÏ…W§', '112106@oyoedu.ng', '', 'ST TERESSA COLL', 'OYO', '112106'),
(2107, '112107', 'úÏ…W§', '112107@oyoedu.ng', '7052957542', 'ST.THERESA\'S COLLEGE', 'OYO', '112107'),
(2108, '112108', 'úÏ…W§', '112108@oyoedu.ng', '8151469313', 'OUR LADY OF APOSTLE', 'OGUN', '112108'),
(2109, '112109', 'úÏ…W§', '112109@oyoedu.ng', '8165100626', 'GRACE SEC SCH', 'OYO', '112109'),
(2110, '112110', 'úÏ…W§', '112110@oyoedu.ng', '8038302322', 'IMG GRAMMAR SCH', 'OYO', '112110'),
(2111, '112111', 'úÏ…W§', '112111@oyoedu.ng', '816389627', 'PRIME COLLEGE', 'OYO', '112111'),
(2112, '112112', 'úÏ…W§', '112112@oyoedu.ng', '8079229448', 'ACCESS GOLD COLLEGE', 'KOGI', '112112'),
(2113, '112113', 'úÏ…W§', '112113@oyoedu.ng', '8057233044', 'MOSLEN GRAMMAR', 'KWARA', '112113'),
(2114, '112114', 'úÏ…W§', '112114@oyoedu.ng', '87042856049', 'MUSLIM GRAMMAR SCH', 'OYO', '112114'),
(2115, '112115', 'úÏ…W§', '112115@oyoedu.ng', '8023566681', 'COMM GRAMM.SCH.EYINNI', 'OYO', '112115'),
(2116, '112116', 'úÏ…W§', '112116@oyoedu.ng', '7063650505', 'ST.THERESEA', 'LAGOS', '112116'),
(2117, '112117', 'úÏ…W§', '112117@oyoedu.ng', '8063694309', 'ABADINA COLLEGE', 'OYO', '112117'),
(2118, '112118', 'úÏ…W§', '112118@oyoedu.ng', '8132183583', 'ABBEY STANDARD SCH', 'OYO', '112118'),
(2119, '112119', 'úÏ…W§', '112119@oyoedu.ng', '8035270082', 'QUEENS SCHOOL', 'EDO', '112119'),
(2120, '112120', 'úÏ…W§', '112120@oyoedu.ng', '9068159966', 'AMAZING GRACE', 'OGUN', '112120'),
(2121, '112121', 'úÏ…W§', '112121@oyoedu.ng', '8063694309', 'ABBEY STANDARD', 'OYO', '112121'),
(2122, '112122', 'úÏ…W§', '112122@oyoedu.ng', '7033243976', 'FIRST CLASS COLLEGE', 'OSUN', '112122'),
(2123, '112123', 'úÏ…W§', '112123@oyoedu.ng', '8028269706', 'BETHEL CITY COLL', 'OSUN', '112123'),
(2124, '112124', 'úÏ…W§', '112124@oyoedu.ng', '8052176125', 'QUEEN\'S SCHOOL', 'OGUN', '112124'),
(2125, '112125', 'úÏ…W§', '112125@oyoedu.ng', '8186850488', 'QUEENS SCH', 'OGUN', '112125'),
(2126, '112126', 'úÏ…W§', '112126@oyoedu.ng', '8186850488', 'QUEENS SCH', 'OGUN', '112126'),
(2127, '312127', 'úÏ…W§', '312127@oyoedu.ng', '8051460965', 'ST ANNES SCH', 'OYO', '312127'),
(2128, '112128', 'úÏ…W§', '112128@oyoedu.ng', '8066253052', 'COMMAND DAY SEC', 'OYO', '112128'),
(2129, '112129', 'úÏ…W§', '112129@oyoedu.ng', '8051777867', 'COMMAND DAY SEC SCH', 'OGUN', '112129'),
(2130, '112130', 'úÏ…W§', '112130@oyoedu.ng', '8051020916', 'ARIYO SCHOOL', 'OYO', '112130'),
(2131, '452131', 'úÏ…W§', '452131@oyoedu.ng', '8067867742', 'ALIAK GROUP OF SCHOOL', 'OYO', '452131'),
(2132, '452132', 'úÏ…W§', '452132@oyoedu.ng', '9037930481', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452132'),
(2133, '452133', 'úÏ…W§', '452133@oyoedu.ng', '9071175484', 'MILLENIUM ', 'OYO', '452133'),
(2134, '452134', 'úÏ…W§', '452134@oyoedu.ng', '9071175484', 'MILLENIUM ', 'OYO', '452134'),
(2135, '452135', 'úÏ…W§', '452135@oyoedu.ng', '8137362682', 'ASHAKUR COMPREHENSIVE', 'OYO', '452135'),
(2136, '452136', 'úÏ…W§', '452136@oyoedu.ng', '7068572112', 'ASH-SHAKUL COMP SCHOOL', 'OYO', '452136'),
(2137, '452137', 'úÏ…W§', '452137@oyoedu.ng', '7035814349', 'NURUL-HAGQ GROUP OF SCHOOL', 'OYO', '452137'),
(2138, '452138', 'úÏ…W§', '452138@oyoedu.ng', '7030310809', 'RESURRECTION MODEL COLLEGE', 'OYO', '452138'),
(2139, '452139', 'úÏ…W§', '452139@oyoedu.ng', '8160686424', 'MILLENIUM ', 'OYO', '452139'),
(2140, '452140', 'úÏ…W§', '452140@oyoedu.ng', '9030739035', 'AK-BARUDDEEN', 'OYO', '452140'),
(2141, '452141', 'úÏ…W§', '452141@oyoedu.ng', '8036234963', 'AL-HYFAZ SCH.', 'OYO', '452141'),
(2142, '452142', 'úÏ…W§', '452142@oyoedu.ng', '9036379838', 'ISHAL MODEL COLLEGE', 'KWARA', '452142'),
(2143, '452143', 'úÏ…W§', '452143@oyoedu.ng', '8076222841', 'AL-HUFFAZH ACADEMY', 'OYO', '452143'),
(2144, '452144', 'úÏ…W§', '452144@oyoedu.ng', '9033929494', 'AKBARUDEEN COLLEGE', 'OYO', '452144'),
(2145, '452145', 'úÏ…W§', '452145@oyoedu.ng', '8063540968', 'SCHOLAR INTL SCHOOL', 'OYO', '452145'),
(2146, '452146', 'úÏ…W§', '452146@oyoedu.ng', '8063540968', 'SCHOLAR INT. SCHOOL', 'OYO', '452146'),
(2147, '452147', 'úÏ…W§', '452147@oyoedu.ng', '8036047662', 'MUSLIM COLLEGE', 'OYO', '452147'),
(2148, '452148', 'úÏ…W§', '452148@oyoedu.ng', '8132145372', 'ALMEDINA SEC SCHOOL', 'OYO', '452148'),
(2149, '452149', 'úÏ…W§', '452149@oyoedu.ng', '8035498127', 'AKBARUDEEN', 'OYO', '452149'),
(2150, '452150', 'úÏ…W§', '452150@oyoedu.ng', '8036915720', 'MERCY TEACH COLLEGE', 'OYO', '452150'),
(2151, '452151', 'úÏ…W§', '452151@oyoedu.ng', '7060998521', 'ZOE COLLEGE', 'OYO', '452151'),
(2152, '452152', 'úÏ…W§', '452152@oyoedu.ng', '7031854725', 'ZOE', 'OYO', '452152'),
(2153, '452153', 'úÏ…W§', '452153@oyoedu.ng', '7060998521', 'ZOE COLLEGE', 'OYO', '452153'),
(2154, '452154', 'úÏ…W§', '452154@oyoedu.ng', '7068466029', 'OKIN HIGH SCHOOL', 'OYO', '452154'),
(2155, '452155', 'úÏ…W§', '452155@oyoedu.ng', '8034836156', 'ORI OKE COMMUNITY', 'OYO', '452155'),
(2156, '452156', 'úÏ…W§', '452156@oyoedu.ng', '8061600093', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452156'),
(2157, '452157', 'úÏ…W§', '452157@oyoedu.ng', '7031048323', 'CHRIST MODEL COLLEGE', 'OYO', '452157'),
(2158, '452158', 'úÏ…W§', '452158@oyoedu.ng', '8162487362', 'METHODIST SECONDARY SCHOOL', 'OYO', '452158'),
(2159, '452159', 'úÏ…W§', '452159@oyoedu.ng', '8032340629', 'OGBOMOSO HIGH SCHOOL', 'OYO', '452159'),
(2160, '452160', 'úÏ…W§', '452160@oyoedu.ng', '8165336857', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452160'),
(2161, '452161', 'úÏ…W§', '452161@oyoedu.ng', '8060283812', 'ST FERDINAND GRAM SCHOOL', 'OYO', '452161'),
(2162, '452162', 'úÏ…W§', '452162@oyoedu.ng', '8060283812', 'ST FERDINAND GRAM SCHOOL', 'OYO', '452162'),
(2163, '452163', 'úÏ…W§', '452163@oyoedu.ng', '8036974774', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452163'),
(2164, '452164', 'úÏ…W§', '452164@oyoedu.ng', '8038636631', 'GEORGE GREEN COLLEGE', 'OYO', '452164'),
(2165, '452165', 'úÏ…W§', '452165@oyoedu.ng', '8031811242', 'MAYDAY COLLEGE', 'OYO', '452165'),
(2166, '452166', 'úÏ…W§', '452166@oyoedu.ng', '8138556634', 'AMCO', 'OSUN', '452166'),
(2167, '452167', 'úÏ…W§', '452167@oyoedu.ng', '7068502952', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452167'),
(2168, '452168', 'úÏ…W§', '452168@oyoedu.ng', '8060159381', 'REDEMPTION COLLEGE', 'OYO', '452168'),
(2169, '452169', 'úÏ…W§', '452169@oyoedu.ng', '8060159381', 'REDEMPTION', 'OYO', '452169'),
(2170, '452170', 'úÏ…W§', '452170@oyoedu.ng', '8138620399', 'AKBARUDEEN COLLEGE', 'OSUN', '452170'),
(2171, '452171', 'úÏ…W§', '452171@oyoedu.ng', '8034302135', 'ROBAB INT. COLLEGE', 'OYO', '452171'),
(2172, '452172', 'úÏ…W§', '452172@oyoedu.ng', '8160686356', 'DAVID CHAMPION ', 'OYO', '452172'),
(2173, '452173', 'úÏ…W§', '452173@oyoedu.ng', '7060494042', 'BAPTIST HGH SCHOOL', 'OYO', '452173'),
(2174, '452174', 'úÏ…W§', '452174@oyoedu.ng', '7084600034', 'GOD\'S TIME COLLEGE', 'OYO', '452174'),
(2175, '452175', 'úÏ…W§', '452175@oyoedu.ng', '8060160798', 'CHRIST  WAY', 'OYO', '452175'),
(2176, '452176', 'úÏ…W§', '452176@oyoedu.ng', '8066358960', 'PRAISE CHAPEL COLLEGE OGB', 'OYO', '452176'),
(2177, '452177', 'úÏ…W§', '452177@oyoedu.ng', '8066358960', 'PRAISE CHAPEL COLLEGE OGB', 'OYO', '452177'),
(2178, '452178', 'úÏ…W§', '452178@oyoedu.ng', '8161161702', 'ZOE COLLEGE', 'OYO', '452178'),
(2179, '452179', 'úÏ…W§', '452179@oyoedu.ng', '8033281342', 'OGBOMOSO GRAMMAR SCHOOL', 'OYO', '452179'),
(2180, '452180', 'úÏ…W§', '452180@oyoedu.ng', '8062153952', 'CHRIST MODEL COLLEGE', 'OYO', '452180'),
(2181, '452181', 'úÏ…W§', '452181@oyoedu.ng', '7067452429', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452181'),
(2182, '452182', 'úÏ…W§', '452182@oyoedu.ng', '7063087267', 'RHEMAL SCHOOL', 'OYO', '452182'),
(2183, '452183', 'úÏ…W§', '452183@oyoedu.ng', '8035038439', 'CAC GRAMM SCHOOL', 'OYO', '452183'),
(2184, '452184', 'úÏ…W§', '452184@oyoedu.ng', '7033835078', 'CHRIST THE KING', 'OYO', '452184'),
(2185, '452185', 'úÏ…W§', '452185@oyoedu.ng', '8107114041', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452185'),
(2186, '452186', 'úÏ…W§', '452186@oyoedu.ng', '8067140876', 'MAYDAY MONTESSORI', 'OYO', '452186'),
(2187, '452187', 'úÏ…W§', '452187@oyoedu.ng', '708072274', 'MILLENIUM ', 'OSUN', '452187'),
(2188, '452188', 'úÏ…W§', '452188@oyoedu.ng', '8161632288', 'GOSHEN HIGH SCHOOL', 'OYO', '452188'),
(2189, '452189', 'úÏ…W§', '452189@oyoedu.ng', '8060213839', 'MARYLAND CATH. GRAMM.', 'OYO', '452189'),
(2190, '452190', 'úÏ…W§', '452190@oyoedu.ng', '8069128951', 'ZOE', 'OYO', '452190'),
(2191, '452191', 'úÏ…W§', '452191@oyoedu.ng', '8139105698', 'TEMPLE BAPTIST SCHOOL', 'OYO', '452191'),
(2192, '452192', 'úÏ…W§', '452192@oyoedu.ng', '8038271300', 'DOTWORD ACADEMY', 'OYO', '452192'),
(2193, '452193', 'úÏ…W§', '452193@oyoedu.ng', '8065665833', 'HOLU COMP. COLLEGE', 'OYO', '452193'),
(2194, '452194', 'úÏ…W§', '452194@oyoedu.ng', '8064942121', 'OGB GRAM. SCHOOL', 'OYO', '452194'),
(2195, '452195', 'úÏ…W§', '452195@oyoedu.ng', '8039094961', 'SOUN HGH SCHOOL ', 'OYO', '452195'),
(2196, '452196', 'úÏ…W§', '452196@oyoedu.ng', '9039614519', 'SKYE HIGH SCHOOL', 'OYO', '452196'),
(2197, '452197', 'úÏ…W§', '452197@oyoedu.ng', '8065195120', 'WESLEY COLLEGE', 'OYO', '452197'),
(2198, '452198', 'úÏ…W§', '452198@oyoedu.ng', '8163627828', 'MILLENIUM ', 'OYO', '452198'),
(2199, '452199', 'úÏ…W§', '452199@oyoedu.ng', '8036915720', 'ZOE', 'OYO', '452199'),
(2200, '452200', 'úÏ…W§', '452200@oyoedu.ng', '8066540583', 'GOMAL', 'OYO', '452200'),
(2201, '452201', 'úÏ…W§', '452201@oyoedu.ng', '8030419407', 'SOUN HGH SCHOOL ', 'OYO', '452201'),
(2202, '452202', 'úÏ…W§', '452202@oyoedu.ng', '8084162367', 'MERGO', 'OYO', '452202'),
(2203, '452203', 'úÏ…W§', '452203@oyoedu.ng', '8036868971', 'ANGLICAN MODEL COLLEGE', 'OYO', '452203'),
(2204, '452204', 'úÏ…W§', '452204@oyoedu.ng', '8146708967', 'REMARK SECONDARY SCHOOL', 'OYO', '452204'),
(2205, '452205', 'úÏ…W§', '452205@oyoedu.ng', '8062972818', 'GREAT ABOKE MEM. COLL.', 'OYO', '452205'),
(2206, '452206', 'úÏ…W§', '452206@oyoedu.ng', '7064820833', 'ADEBOLU COMP. COLLEGE', 'OYO', '452206'),
(2207, '452207', 'úÏ…W§', '452207@oyoedu.ng', '8160582713', 'OWODE COMM. GM. SCHOOL', 'OYO', '452207'),
(2208, '452208', 'úÏ…W§', '452208@oyoedu.ng', '7069528435', 'HEREIGNS INT.', 'OYO', '452208'),
(2209, '452209', 'úÏ…W§', '452209@oyoedu.ng', '8068713677', 'SOUN HIGH SCHOOL', 'OYO', '452209'),
(2210, '452210', 'úÏ…W§', '452210@oyoedu.ng', '8060276946', 'DOTWORD', 'OYO', '452210'),
(2211, '452211', 'úÏ…W§', '452211@oyoedu.ng', '8166340017', 'OLAOGUN COMP HIGH SCHOOL', 'OYO', '452211'),
(2212, '452212', 'úÏ…W§', '452212@oyoedu.ng', '8142618349', 'AHOYAYA GRAM. SCHOOL', 'OYO', '452212'),
(2213, '452213', 'úÏ…W§', '452213@oyoedu.ng', '9078188804', 'GOD\'S GENERAL ACADEMY', 'OYO', '452213'),
(2214, '452214', 'úÏ…W§', '452214@oyoedu.ng', '8037699581', 'AJIKE MODEL', 'OYO', '452214'),
(2215, '452215', 'úÏ…W§', '452215@oyoedu.ng', '8032207069', 'DOMINION COMP. SCHOOL', 'OYO', '452215'),
(2216, '452216', 'úÏ…W§', '452216@oyoedu.ng', '8146869399', 'LORD\'S MODEL COLLEGE', 'OYO', '452216'),
(2217, '452217', 'úÏ…W§', '452217@oyoedu.ng', '8066642031', 'BRIGTHER INT\'L SCHOOL ', 'OYO', '452217'),
(2218, '452218', 'úÏ…W§', '452218@oyoedu.ng', '8166957593', 'REDEEMER SEC. SCHOOL ', 'OYO', '452218'),
(2219, '452219', 'úÏ…W§', '452219@oyoedu.ng', '8168861686', 'ZOE COLLEGE', 'OYO', '452219'),
(2220, '452220', 'úÏ…W§', '452220@oyoedu.ng', '9069370328', 'RESSURECTION KODEL COLLEGE', 'OYO', '452220'),
(2221, '452221', 'úÏ…W§', '452221@oyoedu.ng', '8133890977', 'COMMUNITY HIGH SCHOOL', 'OYO', '452221'),
(2222, '452222', 'úÏ…W§', '452222@oyoedu.ng', '8125448666', 'OGB BAPTIST HIGH SCHOOL', 'OYO', '452222'),
(2223, '452223', 'úÏ…W§', '452223@oyoedu.ng', '8060171839', 'HAPPINESS HIGH SCHOOL', 'OYO', '452223'),
(2224, '452224', 'úÏ…W§', '452224@oyoedu.ng', '8100567234', 'AT-TAOHEED INT. GROUP OF SCH', 'OYO', '452224'),
(2225, '452225', 'úÏ…W§', '452225@oyoedu.ng', '8138810918', 'PRAISE CHAPEL COLLEGE OGB', 'OYO', '452225'),
(2226, '452226', 'úÏ…W§', '452226@oyoedu.ng', '7069687986', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452226'),
(2227, '452227', 'úÏ…W§', '452227@oyoedu.ng', '8038079421', 'OGBOMOSO HIGH SCHOOL', 'OYO', '452227'),
(2228, '452228', 'úÏ…W§', '452228@oyoedu.ng', '8030462851', 'TEMPLE BAPTIST SCHOOL', 'OYO', '452228'),
(2229, '452229', 'úÏ…W§', '452229@oyoedu.ng', '8036985320', 'OGBOMOSO GRAMMAR SCHOOL', 'OYO', '452229'),
(2230, '452230', 'úÏ…W§', '452230@oyoedu.ng', '7039829549', 'AHBARUDEEN COLLEGE', 'OYO', '452230'),
(2231, '452231', 'úÏ…W§', '452231@oyoedu.ng', '8063480942', 'OLAFUNMI COM. COLLEGE', 'OYO', '452231'),
(2232, '452232', 'úÏ…W§', '452232@oyoedu.ng', '8064944354', 'OGBOMOSO GRAMMAR SCHOOL', 'OYO', '452232'),
(2233, '452233', 'úÏ…W§', '452233@oyoedu.ng', '8135335798', 'COMMUNITY HIGH SCHOOL', 'OYO', '452233'),
(2234, '452234', 'úÏ…W§', '452234@oyoedu.ng', '8165278757', 'ORIOKE COMM. HIGH SCHOOL', 'OYO', '452234'),
(2235, '452235', 'úÏ…W§', '452235@oyoedu.ng', '8035256528', 'MAYDAY COLLEGE', 'OYO', '452235'),
(2236, '452236', 'úÏ…W§', '452236@oyoedu.ng', '9068676117', 'MILLENIUM ', 'OYO', '452236'),
(2237, '452237', 'úÏ…W§', '452237@oyoedu.ng', '8062199251', 'BEST LEGACY INT. ACADEMY', 'OYO', '452237'),
(2238, '452238', 'úÏ…W§', '452238@oyoedu.ng', '7060493210', 'ATIQA SEC. SCHOOL', 'OYO', '452238'),
(2239, '452239', 'úÏ…W§', '452239@oyoedu.ng', '7039400227', 'SOUN HGH SCHOOL ', 'OYO', '452239'),
(2240, '452240', 'úÏ…W§', '452240@oyoedu.ng', '8138552435', 'SMITH INTL BAPT ACADEMY', 'OYO', '452240'),
(2241, '452241', 'úÏ…W§', '452241@oyoedu.ng', '7033297237', 'ORI-OKE COM HIGH SCHOOL', 'OYO', '452241'),
(2242, '452242', 'úÏ…W§', '452242@oyoedu.ng', '7039535219', 'AMCO', 'OYO', '452242'),
(2243, '452243', 'úÏ…W§', '452243@oyoedu.ng', '7039535219', 'AMCO', 'OYO', '452243'),
(2244, '452244', 'úÏ…W§', '452244@oyoedu.ng', '7035673450', 'POWER AND GLORY COLLEGE', 'OYO', '452244'),
(2245, '452245', 'úÏ…W§', '452245@oyoedu.ng', '8039216433', 'JESUS ACADEMY', 'OYO', '452245'),
(2246, '452246', 'úÏ…W§', '452246@oyoedu.ng', '7030572022', 'MARYLAND COMP. COLLEGE', 'OYO', '452246'),
(2247, '452247', 'úÏ…W§', '452247@oyoedu.ng', '8034557650', 'DOTWORD', 'OYO', '452247'),
(2248, '452248', 'úÏ…W§', '452248@oyoedu.ng', '8166311734', 'MILLENIUM ', 'OYO', '452248'),
(2249, '452249', 'úÏ…W§', '452249@oyoedu.ng', '7012646703', 'DOTWORD COLLEGE', 'OYO', '452249'),
(2250, '452250', 'úÏ…W§', '452250@oyoedu.ng', '8132653915', 'COMMAND INT. ACADEMY ', 'OYO', '452250'),
(2251, '452251', 'úÏ…W§', '452251@oyoedu.ng', '8062886075', 'KINGDOM IMPACT COLLEGE', 'OYO', '452251'),
(2252, '452252', 'úÏ…W§', '452252@oyoedu.ng', '8032207069', 'GOD\'S GENERAL SEC. SCHOOL', 'OYO', '452252'),
(2253, '452253', 'úÏ…W§', '452253@oyoedu.ng', '8163012960', 'UCC COLLEGE', 'OYO', '452253'),
(2254, '452254', 'úÏ…W§', '452254@oyoedu.ng', '8136122075', 'REDEMPTION', 'OYO', '452254'),
(2255, '452255', 'úÏ…W§', '452255@oyoedu.ng', '8137930388', 'GOD\'S TIME COLLEGE', 'OYO', '452255'),
(2256, '452256', 'úÏ…W§', '452256@oyoedu.ng', '7064257531', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452256'),
(2257, '452257', 'úÏ…W§', '452257@oyoedu.ng', '8103949849', 'JUBILEE BAPTIST COLLEGE', 'OYO', '452257'),
(2258, '452258', 'úÏ…W§', '452258@oyoedu.ng', '8038559529', 'ANGLICAN GRAM. SCHOOL', 'OYO', '452258'),
(2259, '452259', 'úÏ…W§', '452259@oyoedu.ng', '7033435360', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452259'),
(2260, '452260', 'úÏ…W§', '452260@oyoedu.ng', '8067523714', 'COMFORTER COLLEGE', 'OYO', '452260'),
(2261, '452261', 'úÏ…W§', '452261@oyoedu.ng', '8104767271', 'ROYAL COLLEGE', 'OYO', '452261'),
(2262, '452262', 'úÏ…W§', '452262@oyoedu.ng', '8062312078', 'AMCO', 'OYO', '452262'),
(2263, '452263', 'úÏ…W§', '452263@oyoedu.ng', '8062312078', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452263'),
(2264, '452264', 'úÏ…W§', '452264@oyoedu.ng', '8066774634', 'MILLENIUM ', 'OYO', '452264'),
(2265, '452265', 'úÏ…W§', '452265@oyoedu.ng', '8104622662', 'PROMISE SEC. SCHOOL', 'OYO', '452265'),
(2266, '452266', 'úÏ…W§', '452266@oyoedu.ng', '8160935016', 'OGB GRAM. SCHOOL', 'OYO', '452266'),
(2267, '452267', 'úÏ…W§', '452267@oyoedu.ng', '7032312678', 'WESLEY COMP.SCHOOL', 'OYO', '452267'),
(2268, '452268', 'úÏ…W§', '452268@oyoedu.ng', '8038121281', 'JAF COM. HIGH SCHOOL', 'OYO', '452268'),
(2269, '452269', 'úÏ…W§', '452269@oyoedu.ng', '9132822116', 'MOLA INT. COLLEGE', 'OYO', '452269'),
(2270, '452270', 'úÏ…W§', '452270@oyoedu.ng', '8067904243', '', 'OYO', '452270'),
(2271, '452271', 'úÏ…W§', '452271@oyoedu.ng', '8132285052', 'MILLENIUM ', 'OYO', '452271'),
(2272, '452272', 'úÏ…W§', '452272@oyoedu.ng', '8062940609', 'POWER AND GLORY COLLEGE', 'OYO', '452272'),
(2273, '452273', 'úÏ…W§', '452273@oyoedu.ng', '8033633892', 'CHRIST COM SEC COLLEGE', 'OYO', '452273'),
(2274, '452274', 'úÏ…W§', '452274@oyoedu.ng', '9035378824', 'ADENIRAN MEM. GRA. SCHOOL', 'OYO', '452274'),
(2275, '452275', 'úÏ…W§', '452275@oyoedu.ng', '8060334643', 'ANGLICAN HIGH SCHOOL', 'OYO', '452275'),
(2276, '452276', 'úÏ…W§', '452276@oyoedu.ng', '7066515478', 'COMMUNITY HIGH SCHOOL', 'OYO ', '452276'),
(2277, '452277', 'úÏ…W§', '452277@oyoedu.ng', '8166994741', 'ROYAL COLLEGE', 'OYO', '452277'),
(2278, '452278', 'úÏ…W§', '452278@oyoedu.ng', '7031263896', 'ZOE', 'OYO', '452278'),
(2279, '452279', 'úÏ…W§', '452279@oyoedu.ng', '8076462315', 'U.C.C', 'OYO', '452279'),
(2280, '452280', 'úÏ…W§', '452280@oyoedu.ng', '7030053531', 'KINGS INT. SCHOOL', 'OYO', '452280'),
(2281, '452281', 'úÏ…W§', '452281@oyoedu.ng', '7063087267', 'RHEMAL SCHOOL', 'OYO', '452281'),
(2282, '452282', 'úÏ…W§', '452282@oyoedu.ng', '8069511855', 'SKYHIGH INT\'L SEC SCHOOL', 'OYO', '452282'),
(2283, '452283', 'úÏ…W§', '452283@oyoedu.ng', '8146896506', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452283'),
(2284, '452284', 'úÏ…W§', '452284@oyoedu.ng', '8068045891', 'MERGO BAPT COLLEGE OGBO', 'OYO', '452284'),
(2285, '452285', 'úÏ…W§', '452285@oyoedu.ng', '7030847859', 'SOUN HGH SCHOOL ', 'OYO', '452285'),
(2286, '452286', 'úÏ…W§', '452286@oyoedu.ng', '7032554255', 'AMICABLE HIGH SCHOOL', 'OYO', '452286'),
(2287, '452287', 'úÏ…W§', '452287@oyoedu.ng', '8060717585', 'OGB GRAM. SCHOOL', 'OYO', '452287'),
(2288, '452288', 'úÏ…W§', '452288@oyoedu.ng', '9019105476', 'ANGLICAN HIGH SCHOOL', 'OYO', '452288'),
(2289, '452289', 'úÏ…W§', '452289@oyoedu.ng', '8063394724', 'DECKER INT. SCHOOL', 'OYO', '452289'),
(2290, '452290', 'úÏ…W§', '452290@oyoedu.ng', '8108545036', 'UNITED SEC SCHOOL', 'OYO', '452290'),
(2291, '452291', 'úÏ…W§', '452291@oyoedu.ng', '8162859745', 'OWODE COMM. GM. SCHOOL', 'OYO', '452291'),
(2292, '452292', 'úÏ…W§', '452292@oyoedu.ng', '8165056957', 'ANTY AYO COLLEGE', 'OYO', '452292'),
(2293, '452293', 'úÏ…W§', '452293@oyoedu.ng', '8138555256', 'GOD\'S GENERAL ACADEMY', 'OYO', '452293'),
(2294, '452294', 'úÏ…W§', '452294@oyoedu.ng', '8032416028', 'GOODNEWS PROPH. COLLEGE', 'OYO', '452294'),
(2295, '452295', 'úÏ…W§', '452295@oyoedu.ng', '9039280800', 'MAYDAY COLLEGE', 'OYO', '452295'),
(2296, '452296', 'úÏ…W§', '452296@oyoedu.ng', '8133108352', 'GOMAL BAPTIST COLLEGE', 'OYO', '452296'),
(2297, '452297', 'úÏ…W§', '452297@oyoedu.ng', '8135569740', 'OWODE COMM. GM. SCHOOL', 'OYO', '452297'),
(2298, '452298', 'úÏ…W§', '452298@oyoedu.ng', '8067902408', 'JAF COM. HIGH SCHOOL', 'OYO', '452298'),
(2299, '452299', 'úÏ…W§', '452299@oyoedu.ng', '8162757830', 'MAYDAY COLLEGE', 'OYO', '452299'),
(2300, '452300', 'úÏ…W§', '452300@oyoedu.ng', '8038036178', 'OWODE COMM. GM. SCHOOL', 'OYO', '452300'),
(2301, '452301', 'úÏ…W§', '452301@oyoedu.ng', '9085627370', 'UPPER STANDARD COLLEGE', 'OYO', '452301'),
(2302, '452302', 'úÏ…W§', '452302@oyoedu.ng', '9061542234', 'MUSLIM COM. HIGH SCHOOL', 'OYO', '452302'),
(2303, '452303', 'úÏ…W§', '452303@oyoedu.ng', '8066540583', 'ROYAL INTL COLLEGE', 'EKITI', '452303'),
(2304, '452304', 'úÏ…W§', '452304@oyoedu.ng', '8067462953', 'CHRIST COMP. COLLEGE', 'OYO', '452304'),
(2305, '452305', 'úÏ…W§', '452305@oyoedu.ng', '8034344941', 'NURU-HAQ SEC. SCHOOL', 'OYO', '452305'),
(2306, '452306', 'úÏ…W§', '452306@oyoedu.ng', '8101094482', 'MESSIAH GRAMMAR INT.', 'OYO', '452306'),
(2307, '452307', 'úÏ…W§', '452307@oyoedu.ng', '9039509571', 'GOMAL BAPTIST COLLEGE', 'OYO', '452307'),
(2308, '452308', 'úÏ…W§', '452308@oyoedu.ng', '8066290041', 'JAF COM. HIGH SCHOOL', 'OYO', '452308'),
(2309, '452309', 'úÏ…W§', '452309@oyoedu.ng', '8035188760', 'ASH- SHAKUR', 'OSUN', '452309'),
(2310, '452310', 'úÏ…W§', '452310@oyoedu.ng', '8034304994', 'AMCO', 'OYO', '452310'),
(2311, '452311', 'úÏ…W§', '452311@oyoedu.ng', '9068083544', 'OLAFUNMI COM. COLLEGE', 'OYO', '452311'),
(2312, '452312', 'úÏ…W§', '452312@oyoedu.ng', '8038584639', 'ADUNOLA STANDARD SCHOOL', 'OYO', '452312'),
(2313, '452313', 'úÏ…W§', '452313@oyoedu.ng', '8062235323', 'TEMPLE', 'OYO', '452313'),
(2314, '452314', 'úÏ…W§', '452314@oyoedu.ng', '7038153453', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452314'),
(2315, '452315', 'úÏ…W§', '452315@oyoedu.ng', '7068854914', 'JUBILEE BAPTIST COLLEGE', 'OYO', '452315'),
(2316, '452316', 'úÏ…W§', '452316@oyoedu.ng', '8064433858', 'SOUN HIGH SCHOOL', 'OYO', '452316'),
(2317, '452317', 'úÏ…W§', '452317@oyoedu.ng', '8060137385', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452317'),
(2318, '452318', 'úÏ…W§', '452318@oyoedu.ng', '7031060884', 'AYEGUN COLLEGE', 'OYO', '452318'),
(2319, '452319', 'úÏ…W§', '452319@oyoedu.ng', '8064092083', 'GOMAL', 'OYO', '452319'),
(2320, '452320', 'úÏ…W§', '452320@oyoedu.ng', '8038620400', 'OGB GRAM. SCHOOL', 'OYO', '452320'),
(2321, '452321', 'úÏ…W§', '452321@oyoedu.ng', '8134041076', 'GOODNESS', 'OYO', '452321'),
(2322, '452322', 'úÏ…W§', '452322@oyoedu.ng', '9136544453', 'DOMINION SEC. SCHOOL', 'OYO', '452322'),
(2323, '452323', 'úÏ…W§', '452323@oyoedu.ng', '8100386975', 'DOMINIUM COMP. COLLEGE', 'OYO', '452323'),
(2324, '452324', 'úÏ…W§', '452324@oyoedu.ng', '8035222125', 'VICTORY LAND', 'OYO', '452324'),
(2325, '452325', 'úÏ…W§', '452325@oyoedu.ng', '8058381164', 'SMITH', 'OYO', '452325'),
(2326, '452326', 'úÏ…W§', '452326@oyoedu.ng', '8069276461', 'MERGO BAPT COLLEGE OGBO', 'OYO', '452326'),
(2327, '452327', 'úÏ…W§', '452327@oyoedu.ng', '9058475023', 'SKYHIGH INT\'L SEC SCHOOL', 'OYO', '452327'),
(2328, '452328', 'úÏ…W§', '452328@oyoedu.ng', '8166967269', 'MILLENIUM MODEL SCHOOL', 'OYO', '452328'),
(2329, '452329', 'úÏ…W§', '452329@oyoedu.ng', '7067013235', 'CHRTIST WAY HIGH SCHOOL', 'OYO', '452329'),
(2330, '452330', 'úÏ…W§', '452330@oyoedu.ng', '8136333067', 'COMMNITY GARMM SCHOOL', 'OYO', '452330'),
(2331, '452331', 'úÏ…W§', '452331@oyoedu.ng', '8060064253', 'AL-HAMEED COMPREHENSIVE', 'OYO', '452331'),
(2332, '452332', 'úÏ…W§', '452332@oyoedu.ng', '8166967269', 'MILLENIUM MODEL SCHOOL', 'OYO', '452332'),
(2333, '452333', 'úÏ…W§', '452333@oyoedu.ng', '7041894235', 'GRACE COMPREHESIVE', 'OYO', '452333'),
(2334, '452334', 'úÏ…W§', '452334@oyoedu.ng', '7068021034', 'OGBOMOSO GRAMMAR SCHOOL', 'OYO', '452334'),
(2335, '452335', 'úÏ…W§', '452335@oyoedu.ng', '8133354185', 'OGOMOSO GRAM. SCH.', 'OYO', '452335'),
(2336, '452336', 'úÏ…W§', '452336@oyoedu.ng', '7036741585', 'AMCO', 'OYO', '452336'),
(2337, '452337', 'úÏ…W§', '452337@oyoedu.ng', '9016227332', 'RHEMA', 'OYO', '452337'),
(2338, '452338', 'úÏ…W§', '452338@oyoedu.ng', '8100625531', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452338'),
(2339, '452339', 'úÏ…W§', '452339@oyoedu.ng', '8187876501', 'GRACE CITY COLLEGE', 'OYO', '452339'),
(2340, '452340', 'úÏ…W§', '452340@oyoedu.ng', '9035364138', 'MAYDAY COLLEGE', 'OYO', '452340'),
(2341, '452341', 'úÏ…W§', '452341@oyoedu.ng', '7056896345', 'MAYDAY COLLEGE', 'OYO', '452341'),
(2342, '452342', 'úÏ…W§', '452342@oyoedu.ng', '9050845738', 'OGB GRAMM SCHOOL', 'OYO', '452342'),
(2343, '452343', 'úÏ…W§', '452343@oyoedu.ng', '7030280635', 'AKBARUDEEN COLLEGE', 'OYO', '452343'),
(2344, '452344', 'úÏ…W§', '452344@oyoedu.ng', '8067409166', 'GOODNEWS', 'OYO', '452344'),
(2345, '452345', 'úÏ…W§', '452345@oyoedu.ng', '7083322457', 'POWER AND GLORY SCHOOL', 'OYO', '452345'),
(2346, '452346', 'úÏ…W§', '452346@oyoedu.ng', '8137468731', 'C. H. S. IREGBA', 'OYO', '452346'),
(2347, '452347', 'úÏ…W§', '452347@oyoedu.ng', '9067326574', 'GEORGE GREEN COLLEGE', 'OYO', '452347'),
(2348, '452348', 'úÏ…W§', '452348@oyoedu.ng', '8063188448', 'MERIT ACADEMY', 'OYO', '452348'),
(2349, '452349', 'úÏ…W§', '452349@oyoedu.ng', '9058451350', 'DOMINION SEC. SCHOOL', 'OYO', '452349'),
(2350, '452350', 'úÏ…W§', '452350@oyoedu.ng', '8066744344', 'KINGDOM IMPACT COLLEGE', 'OYO', '452350'),
(2351, '452351', 'úÏ…W§', '452351@oyoedu.ng', '8140315370', 'METHODIST SECONDARY SCHOOL', 'OYO', '452351'),
(2352, '452352', 'úÏ…W§', '452352@oyoedu.ng', '8133108752', 'REG COLLEGE  ', 'OYO', '452352'),
(2353, '452353', 'úÏ…W§', '452353@oyoedu.ng', '8133108352', 'REG COLLEGE  ', 'OYO', '452353'),
(2354, '452354', 'úÏ…W§', '452354@oyoedu.ng', '8066744344', 'KINGDOM IMPACT COLLEGE', 'OYO', '452354'),
(2355, '452355', 'úÏ…W§', '452355@oyoedu.ng', '8032477334', 'REMAC SCHOOL', 'OYO', '452355'),
(2356, '452356', 'úÏ…W§', '452356@oyoedu.ng', '7036741585', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452356'),
(2357, '452357', 'úÏ…W§', '452357@oyoedu.ng', '9131189505', 'MAYDAY COLLEGE', 'OYO', '452357'),
(2358, '452358', 'úÏ…W§', '452358@oyoedu.ng', '8062063073', 'ANGLICAN MODEL COLLEGE', 'OYO', '452358'),
(2359, '452359', 'úÏ…W§', '452359@oyoedu.ng', '8107121816', '', 'OYO', '452359'),
(2360, '452360', 'úÏ…W§', '452360@oyoedu.ng', '8032243016', 'SOUN HGH SCHOOL ', 'OYO', '452360'),
(2361, '452361', 'úÏ…W§', '452361@oyoedu.ng', '7055700070', 'DECKER INT. SCHOOL', 'OYO', '452361'),
(2362, '452362', 'úÏ…W§', '452362@oyoedu.ng', '7055700070', 'DECKER INT. SCHOOL', 'OYO', '452362'),
(2363, '452363', 'úÏ…W§', '452363@oyoedu.ng', '9084367113', 'AYEGUN COLLEGE', 'OYO', '452363'),
(2364, '452364', 'úÏ…W§', '452364@oyoedu.ng', '8130594373', 'OLAFUNMI COM. COLLEGE', 'OYO', '452364'),
(2365, '452365', 'úÏ…W§', '452365@oyoedu.ng', '8075484953', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452365'),
(2366, '452366', 'úÏ…W§', '452366@oyoedu.ng', '7068856518', 'MARYLAND CATH. GRAMM.', 'OYO', '452366'),
(2367, '452367', 'úÏ…W§', '452367@oyoedu.ng', '8100567234', 'BRIGHT FUTURE ACADEMY', 'OGUN', '452367'),
(2368, '452368', 'úÏ…W§', '452368@oyoedu.ng', '8060188873', 'MESSIAH GRAMMAR INT.', 'OYO', '452368'),
(2369, '452369', 'úÏ…W§', '452369@oyoedu.ng', '8039776274', 'RAHAMAT MODEL COLLEGE', 'OSUN', '452369'),
(2370, '452370', 'úÏ…W§', '452370@oyoedu.ng', '8066489611', 'PEN MODEL COLLEGE', 'OYO', '452370'),
(2371, '452371', 'úÏ…W§', '452371@oyoedu.ng', '8036188937', 'AJIKE SECONDARY SCHOOL', 'OYO', '452371'),
(2372, '452372', 'úÏ…W§', '452372@oyoedu.ng', '7030317981', 'PACIFIC ACADEMY ', 'OYO', '452372'),
(2373, '452373', 'úÏ…W§', '452373@oyoedu.ng', '8148784322', 'RESSURECTION KODEL COLLEGE', 'OYO', '452373'),
(2374, '452374', 'úÏ…W§', '452374@oyoedu.ng', '8069146931', 'AMCO', 'OYO', '452374'),
(2375, '452375', 'úÏ…W§', '452375@oyoedu.ng', '8035226039', 'NURUDEEN GRAM. SCHOOL', 'OYO', '452375'),
(2376, '452376', 'úÏ…W§', '452376@oyoedu.ng', '8067854950', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452376'),
(2377, '452377', 'úÏ…W§', '452377@oyoedu.ng', '8067902539', 'OWODE COMM. GM. SCHOOL', 'OYO', '452377'),
(2378, '452378', 'úÏ…W§', '452378@oyoedu.ng', '8060266567', 'MUSLIM SEC. SCHOOL', 'OYO', '452378'),
(2379, '452379', 'úÏ…W§', '452379@oyoedu.ng', '8067439593', 'AMICABLE HIGH SCHOOL', 'OYO', '452379'),
(2380, '452380', 'úÏ…W§', '452380@oyoedu.ng', '8028016374', 'DECKER INT. SCHOOL', 'OYO', '452380'),
(2381, '452381', 'úÏ…W§', '452381@oyoedu.ng', '7033672914', 'VICTORY BAP. COLLEGE', 'OYO', '452381'),
(2382, '452382', 'úÏ…W§', '452382@oyoedu.ng', '8034241126', 'AJIKE MODEL SCHOOL', 'OYO', '452382'),
(2383, '452383', 'úÏ…W§', '452383@oyoedu.ng', '9060960118', 'MILLENIUM ', 'OYO', '452383'),
(2384, '452384', 'úÏ…W§', '452384@oyoedu.ng', '8121375103', 'ZOE', 'OYO', '452384'),
(2385, '452385', 'úÏ…W§', '452385@oyoedu.ng', '7045956264', 'MERGO', 'OYO', '452385'),
(2386, '452386', 'úÏ…W§', '452386@oyoedu.ng', '8137405658', 'CHRIST THE KING', 'OSUN', '452386'),
(2387, '452387', 'úÏ…W§', '452387@oyoedu.ng', '8169161956', 'SMITH INTL BAPT ACADEMY', 'OYO', '452387'),
(2388, '452388', 'úÏ…W§', '452388@oyoedu.ng', '8069488834', 'OGB GRAMM SCHOOL', 'OYO', '452388'),
(2389, '452389', 'úÏ…W§', '452389@oyoedu.ng', '7068466029', '', 'OYO', '452389'),
(2390, '452390', 'úÏ…W§', '452390@oyoedu.ng', '8133353877', 'ADEBOLU COMP. COLLEGE', 'OYO', '452390'),
(2391, '452391', 'úÏ…W§', '452391@oyoedu.ng', '8081548553', 'OKIN HIGH SCHOOL', 'OYO', '452391'),
(2392, '452392', 'úÏ…W§', '452392@oyoedu.ng', '9045770817', 'SKYHIGH INT\'L SEC SCHOOL', 'OYO', '452392'),
(2393, '452393', 'úÏ…W§', '452393@oyoedu.ng', '8167691953', 'OWODE COMM. GM. SCHOOL', 'OYO', '452393'),
(2394, '452394', 'úÏ…W§', '452394@oyoedu.ng', '8063503684', 'DOTWORD', 'OYO', '452394'),
(2395, '452395', 'úÏ…W§', '452395@oyoedu.ng', '8060956458', 'CARETAKER COM. HIGH SCHOOL', 'OYO', '452395'),
(2396, '452396', 'úÏ…W§', '452396@oyoedu.ng', '7068856216', 'LICO', 'OYO', '452396'),
(2397, '452397', 'úÏ…W§', '452397@oyoedu.ng', '8038067929', 'ANSARUDEEN SEC SCHOOL', 'OYO', '452397'),
(2398, '452398', 'úÏ…W§', '452398@oyoedu.ng', '8132745344', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452398'),
(2399, '452399', 'úÏ…W§', '452399@oyoedu.ng', '7062267323', 'ZOE', 'OYO', '452399'),
(2400, '452400', 'úÏ…W§', '452400@oyoedu.ng', '8030754674', 'ALLAH\'S WILL COLLEGE', 'OYO', '452400'),
(2401, '452401', 'úÏ…W§', '452401@oyoedu.ng', '8064019293', 'HIS GRACE MODEL COLLEGE', 'OYO', '452401'),
(2402, '452402', 'úÏ…W§', '452402@oyoedu.ng', '8064331800', '', 'LAGOS', '452402'),
(2403, '452403', 'úÏ…W§', '452403@oyoedu.ng', '8036319076', 'COMFORTER COLLEGE', 'OYO', '452403'),
(2404, '452404', 'úÏ…W§', '452404@oyoedu.ng', '7030102916', 'OGB GRAM. SCHOOL', 'OYO', '452404'),
(2405, '452405', 'úÏ…W§', '452405@oyoedu.ng', '8106367909', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452405'),
(2406, '452406', 'úÏ…W§', '452406@oyoedu.ng', '8065950555', 'NURU-HAQ SEC. SCHOOL', 'OYO', '452406'),
(2407, '452407', 'úÏ…W§', '452407@oyoedu.ng', '7064316404', 'DOTWORD COMPR. COLLEGE', 'OYO', '452407'),
(2408, '452408', 'úÏ…W§', '452408@oyoedu.ng', '8068301302', 'OC COLLEGE', 'OYO', '452408'),
(2409, '452409', 'úÏ…W§', '452409@oyoedu.ng', '8132388787', 'AMCO', 'OYO', '452409'),
(2410, '452410', 'úÏ…W§', '452410@oyoedu.ng', '7030113815', 'ISLAMIC COLLEGE', 'OYO', '452410'),
(2411, '452411', 'úÏ…W§', '452411@oyoedu.ng', '8162457426', 'DIFINE FAVOUR SCHOOL', 'OYO', '452411'),
(2412, '452412', 'úÏ…W§', '452412@oyoedu.ng', '8086913238', 'MOLETE COMM HIGH SCHL', 'OYO', '452412'),
(2413, '452413', 'úÏ…W§', '452413@oyoedu.ng', '7062118930', 'ADENIRAN MEM. GRA. SCHOOL', 'OYO', '452413'),
(2414, '452414', 'úÏ…W§', '452414@oyoedu.ng', '8107293118', 'TEMPLE BAPTIST SCHOOL', 'OYO', '452414'),
(2415, '452415', 'úÏ…W§', '452415@oyoedu.ng', '8067206875', 'HAPPINESS HIGH SCHOOL', 'OY', '452415'),
(2416, '452416', 'úÏ…W§', '452416@oyoedu.ng', '8135971018', 'GOODNESS', 'OYO', '452416'),
(2417, '452417', 'úÏ…W§', '452417@oyoedu.ng', '7039582483', 'MAYDAY COLLEGE', 'OYO', '452417'),
(2418, '452418', 'úÏ…W§', '452418@oyoedu.ng', '8102020203', 'ASKUR SEC. SCHOOL', 'OYO', '452418'),
(2419, '452419', 'úÏ…W§', '452419@oyoedu.ng', '8032337570', 'MAYDAY COLLEGE', 'OYO', '452419'),
(2420, '452420', 'úÏ…W§', '452420@oyoedu.ng', '8131284231', 'AKBARUDEEN COLLEGE', 'OYO', '452420'),
(2421, '452421', 'úÏ…W§', '452421@oyoedu.ng', '9050845738', 'AN NUR SEC SCHOOL', 'OYO', '452421'),
(2422, '452422', 'úÏ…W§', '452422@oyoedu.ng', '8028016574', 'ST. FERDINALD GRAM.', 'OYO', '452422'),
(2423, '452423', 'úÏ…W§', '452423@oyoedu.ng', '8066345212', 'THE APOSTOLIC GRAM. SCHOOL', 'OYO', '452423'),
(2424, '452424', 'úÏ…W§', '452424@oyoedu.ng', '8103633221', 'AJIKE SECONDARY SCHOOL', 'OYO', '452424'),
(2425, '452425', 'úÏ…W§', '452425@oyoedu.ng', '8062304060', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452425'),
(2426, '452426', 'úÏ…W§', '452426@oyoedu.ng', '8066214023', 'OGB GRAMM SCHOOL', 'OYO', '452426'),
(2427, '452427', 'úÏ…W§', '452427@oyoedu.ng', '8068342997', 'NURUDEEN GRAM. SCHOOL', 'OYO', '452427'),
(2428, '452428', 'úÏ…W§', '452428@oyoedu.ng', '8166969202', 'ZION CHRISTIAN ACADEMY', 'OYO', '452428'),
(2429, '452429', 'úÏ…W§', '452429@oyoedu.ng', '8146641310', 'CHILD CENTER ACADEMY', 'OYO', '452429'),
(2430, '452430', 'úÏ…W§', '452430@oyoedu.ng', '8102282424', 'FUTURE LEADER', 'OYO', '452430'),
(2431, '452431', 'úÏ…W§', '452431@oyoedu.ng', '8038193297', 'GRACE KIDDIES SEC SCHOOL', 'OYO', '452431'),
(2432, '452432', 'úÏ…W§', '452432@oyoedu.ng', '7033293938', 'METHODIST SECONDARY SCHOOL', 'ONDO', '452432'),
(2433, '452433', 'úÏ…W§', '452433@oyoedu.ng', '8031812063', 'OWODE ACADEMY', 'OYO', '452433'),
(2434, '452434', 'úÏ…W§', '452434@oyoedu.ng', '7069665667', 'SMITH INTL BAPT ACADEMY', 'RIVER', '452434'),
(2435, '452435', 'úÏ…W§', '452435@oyoedu.ng', '7036388973', 'REG COLLEGE  ', 'OYO', '452435'),
(2436, '452436', 'úÏ…W§', '452436@oyoedu.ng', '8132320190', 'ALAMEEN COLLEGE', 'OYO', '452436'),
(2437, '452437', 'úÏ…W§', '452437@oyoedu.ng', '8067644647', 'UNITED COM. COLLEGE', 'OYO', '452437'),
(2438, '452438', 'úÏ…W§', '452438@oyoedu.ng', '8137355067', 'AJIKE SECONDARY SCHOOL', 'OYO', '452438'),
(2439, '452439', 'úÏ…W§', '452439@oyoedu.ng', '7036830132', 'ALHAQ GROUP SCHOOL', 'OYO', '452439'),
(2440, '452440', 'úÏ…W§', '452440@oyoedu.ng', '8143825588', 'MUSLIM COMP. HIGH SCHOOL', 'OYO', '452440'),
(2441, '452441', 'úÏ…W§', '452441@oyoedu.ng', '8064822186', 'MUSLIM COMP HIGH SCHOOL', 'OYO', '452441'),
(2442, '452442', 'úÏ…W§', '452442@oyoedu.ng', '8065087609', 'HIS GRACE MODEL COLLEGE', 'OYO', '452442'),
(2443, '452443', 'úÏ…W§', '452443@oyoedu.ng', '7037945127', 'DOTWORD', 'OYO', '452443'),
(2444, '452444', 'úÏ…W§', '452444@oyoedu.ng', '8137658491', 'SHEPHERD ACADEMY', 'OYO', '452444'),
(2445, '452445', 'úÏ…W§', '452445@oyoedu.ng', '7062284847', 'GOMAL', 'OYO', '452445'),
(2446, '452446', 'úÏ…W§', '452446@oyoedu.ng', '7055700070', 'DECKER INT. SCHOOL', 'OYO', '452446'),
(2447, '452447', 'úÏ…W§', '452447@oyoedu.ng', '7055700070', 'DECKER INT. SCHOOL', 'OYO', '452447'),
(2448, '452448', 'úÏ…W§', '452448@oyoedu.ng', '8037272755', 'MARYLAND CATH. GRAMM.', 'OYO', '452448'),
(2449, '452449', 'úÏ…W§', '452449@oyoedu.ng', '8137870725', 'CANNANLANU COMP. COLLEGE', 'OYO', '452449'),
(2450, '452450', 'úÏ…W§', '452450@oyoedu.ng', '8169496717', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452450'),
(2451, '452451', 'úÏ…W§', '452451@oyoedu.ng', '8032199700', 'MILLENIUM ', 'OYO', '452451'),
(2452, '452452', 'úÏ…W§', '452452@oyoedu.ng', '7063970496', 'HOSSANAH COLLEGE ILUJU', 'OYO', '452452'),
(2453, '452453', 'úÏ…W§', '452453@oyoedu.ng', '8169450860', 'OGBOMOSO HIGH SCHOOL', 'OYO', '452453'),
(2454, '452454', 'úÏ…W§', '452454@oyoedu.ng', '8067916412', 'DECKER INT. SCHOOL', 'OYO', '452454'),
(2455, '452455', 'úÏ…W§', '452455@oyoedu.ng', '7032061905', 'OLAFUNMI COM. COLLEGE', 'OYO', '452455'),
(2456, '452456', 'úÏ…W§', '452456@oyoedu.ng', '7032190817', 'MILLENIUM ', 'OYO', '452456'),
(2457, '452457', 'úÏ…W§', '452457@oyoedu.ng', '8065377683', 'BOMARK RESOURCE COLLEGE', 'OYO', '452457'),
(2458, '452458', 'úÏ…W§', '452458@oyoedu.ng', '8038559529', 'ANGLICAN GRAM. SCHOOL', 'OYO', '452458'),
(2459, '452459', 'úÏ…W§', '452459@oyoedu.ng', '7032336760', 'MOLETE COMM HIGH SCHL', 'OYO', '452459'),
(2460, '452460', 'úÏ…W§', '452460@oyoedu.ng', '8032397335', 'HIS GRACE MODEL COLLEGE', 'OYO', '452460'),
(2461, '452461', 'úÏ…W§', '452461@oyoedu.ng', '8036243281', 'CANNANLANU COMP. COLLEGE', 'OYO', '452461'),
(2462, '452462', 'úÏ…W§', '452462@oyoedu.ng', '9072845474', 'METHODIST SECONDARY SCHOOL', 'OYO', '452462'),
(2463, '452463', 'úÏ…W§', '452463@oyoedu.ng', '8039650520', 'SUCCESS LAND', 'OYO', '452463'),
(2464, '452464', 'úÏ…W§', '452464@oyoedu.ng', '8037287140', 'WISDOM MOEL COLLEGE', 'OYO', '452464'),
(2465, '452465', 'úÏ…W§', '452465@oyoedu.ng', '8136333067', 'COMMUNITY HIGH SCHOOL', 'OYO', '452465'),
(2466, '452466', 'úÏ…W§', '452466@oyoedu.ng', '8022507780', 'C&S MODEL COLLEGE', 'OYO', '452466'),
(2467, '452467', 'úÏ…W§', '452467@oyoedu.ng', '7065076685', 'JAF COM. HIGH SCHOOL', 'OYO', '452467'),
(2468, '452468', 'úÏ…W§', '452468@oyoedu.ng', '7034720498', '', 'OYO', '452468'),
(2469, '452469', 'úÏ…W§', '452469@oyoedu.ng', '7019045848', 'STAR COOPERATIVE ACADEMY', 'OYO', '452469'),
(2470, '452470', 'úÏ…W§', '452470@oyoedu.ng', '8080725869', 'MAYDAY MONTESSORI', 'OYO', '452470'),
(2471, '452471', 'úÏ…W§', '452471@oyoedu.ng', '8143090443', 'PROVIDENCE STAR ACADEMY', 'OYO', '452471'),
(2472, '452472', 'úÏ…W§', '452472@oyoedu.ng', '9070779830', 'CHILD CENTER ACADEMY', 'OYO', '452472'),
(2473, '452473', 'úÏ…W§', '452473@oyoedu.ng', '8033684591', 'DECKER INT. SCHOOL', 'OYO', '452473'),
(2474, '452474', 'úÏ…W§', '452474@oyoedu.ng', '8062180305', 'ROYAL COLLEGE', 'OYO', '452474'),
(2475, '452475', 'úÏ…W§', '452475@oyoedu.ng', '7031139798', 'MILLENIUM ', 'OYO', '452475'),
(2476, '452476', 'úÏ…W§', '452476@oyoedu.ng', '8083616313', 'AJIKE MODEL', 'OYO', '452476'),
(2477, '452477', 'úÏ…W§', '452477@oyoedu.ng', '8167166249', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452477'),
(2478, '452478', 'úÏ…W§', '452478@oyoedu.ng', '7066640829', 'ANGLICAN HIGH SCHOOL', 'OYO', '452478'),
(2479, '452479', 'úÏ…W§', '452479@oyoedu.ng', '7033739618', 'DOTWORD SEC SCHOOL', 'OYO', '452479'),
(2480, '452480', 'úÏ…W§', '452480@oyoedu.ng', '7033612006', 'UGOFAT SEC. SCHOOL', 'OYO', '452480'),
(2481, '452481', 'úÏ…W§', '452481@oyoedu.ng', '8038441519', 'GOODNEWS PROPH. COLLEGE', 'OYO', '452481'),
(2482, '452482', 'úÏ…W§', '452482@oyoedu.ng', '7036137721', 'COMFORTER', 'OYO', '452482'),
(2483, '452483', 'úÏ…W§', '452483@oyoedu.ng', '8160989154', 'ORIOKE COMM. HIGH SCHOOL', 'OYO', '452483'),
(2484, '452484', 'úÏ…W§', '452484@oyoedu.ng', '8168938087', 'LAOGUN MEM HIGH SCH', 'OYO', '452484'),
(2485, '452485', 'úÏ…W§', '452485@oyoedu.ng', '8034995371', 'ROYAL COLLEGE', 'OYO', '452485'),
(2486, '452486', 'úÏ…W§', '452486@oyoedu.ng', '8032983176', 'ISLAMIC COLLEGE', 'OYO', '452486'),
(2487, '452487', 'úÏ…W§', '452487@oyoedu.ng', '8103103218', 'AMCO', 'OYO', '452487'),
(2488, '452488', 'úÏ…W§', '452488@oyoedu.ng', '9074275244', 'GEORGE GREEN COLLEGE', 'OYO', '452488'),
(2489, '452489', 'úÏ…W§', '452489@oyoedu.ng', '7068354101', 'MUSLIM GRAM. SCHOOL', 'OYO', '452489'),
(2490, '452490', 'úÏ…W§', '452490@oyoedu.ng', '8136672606', 'OLAFUNMI COM. COLLEGE', 'OYO', '452490'),
(2491, '452491', 'úÏ…W§', '452491@oyoedu.ng', '8053541120', 'MILLENIUM ', 'OYO', '452491'),
(2492, '452492', 'úÏ…W§', '452492@oyoedu.ng', '8038242566', 'CHRIST THE KING', 'OYO', '452492'),
(2493, '452493', 'úÏ…W§', '452493@oyoedu.ng', '8053541120', 'MILLENIUM ', 'OYO', '452493'),
(2494, '452494', 'úÏ…W§', '452494@oyoedu.ng', '8068175813', 'AMCO', 'OYO', '452494'),
(2495, '452495', 'úÏ…W§', '452495@oyoedu.ng', '7069143292', 'OGBOMOSO GRAMMAR SCHOOL', 'OYO', '452495'),
(2496, '452496', 'úÏ…W§', '452496@oyoedu.ng', '7068514048', 'OLAFUNMI COM. COLLEGE', 'OYO', '452496'),
(2497, '452497', 'úÏ…W§', '452497@oyoedu.ng', '8034813609', 'WESLEY COMP.SCHOOL', 'OYO', '452497'),
(2498, '452498', 'úÏ…W§', '452498@oyoedu.ng', '8106930032', '', 'OYO', '452498'),
(2499, '452499', 'úÏ…W§', '452499@oyoedu.ng', '8132472541', 'OGB GRAM. SCHOOL', 'OYO', '452499'),
(2500, '452500', 'úÏ…W§', '452500@oyoedu.ng', '7030749967', 'COMMUNITY HIGH SCHOOL', 'OYO', '452500'),
(2501, '452501', 'úÏ…W§', '452501@oyoedu.ng', '8067916412', 'GOMAL', 'OYO', '452501'),
(2502, '452502', 'úÏ…W§', '452502@oyoedu.ng', '8066744497', 'MARYLAND GRAMMAR SCHOOL', 'OYO', '452502'),
(2503, '452503', 'úÏ…W§', '452503@oyoedu.ng', '8038571906', 'EMMANUEL AGBOOLA GRAM. SCH.', 'OYO', '452503'),
(2504, '452504', 'úÏ…W§', '452504@oyoedu.ng', '8038475843', 'ANGLICAN HIGH SCHOOL OGBO', 'OYO', '452504'),
(2505, '452505', 'úÏ…W§', '452505@oyoedu.ng', '8065982646', 'ADUKE GRP OF SCHOOL', 'OYO', '452505'),
(2506, '452506', 'úÏ…W§', '452506@oyoedu.ng', '9028497018', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452506'),
(2507, '452507', 'úÏ…W§', '452507@oyoedu.ng', '7068514048', 'JAF COM. HIGH SCHOOL', 'OYO', '452507'),
(2508, '452508', 'úÏ…W§', '452508@oyoedu.ng', '9041218438', 'ANGLICAN HIGH SCHOOL', 'OYO', '452508'),
(2509, '452509', 'úÏ…W§', '452509@oyoedu.ng', '8067251346', 'DECKER INT. SCHOOL', 'OYO', '452509'),
(2510, '452510', 'úÏ…W§', '452510@oyoedu.ng', '8067419594', 'ANGLICAN HIGH SCHOOL. OGBO', 'OYO', '452510'),
(2511, '452511', 'úÏ…W§', '452511@oyoedu.ng', '8037217452', 'MAYDAY COLLEGE', 'OYO', '452511'),
(2512, '452512', 'úÏ…W§', '452512@oyoedu.ng', '8135569740', 'ZOE', 'OYO', '452512'),
(2513, '452513', 'úÏ…W§', '452513@oyoedu.ng', '7032518196', 'MAYDAY COLLEGE', 'OYO', '452513'),
(2514, '452514', 'úÏ…W§', '452514@oyoedu.ng', '9022347071', 'DORTWORD', 'OYO', '452514'),
(2515, '452515', 'úÏ…W§', '452515@oyoedu.ng', '7068514048', 'ROYAL INT. COLLEGE', 'OYO', '452515'),
(2516, '452516', 'úÏ…W§', '452516@oyoedu.ng', '7030847859', 'SOUN HGH SCHOOL ', 'OYO', '452516'),
(2517, '452517', 'úÏ…W§', '452517@oyoedu.ng', '8062196001', 'MERIT ACADEMY', 'OYO', '452517'),
(2518, '452518', 'úÏ…W§', '452518@oyoedu.ng', '8139039860', 'CATHOLIC ', 'OYO', '452518'),
(2519, '452519', 'úÏ…W§', '452519@oyoedu.ng', '8066941922', 'MAYDAY COLLEGE', 'OYO', '452519'),
(2520, '452520', 'úÏ…W§', '452520@oyoedu.ng', '7033167851', 'MORENIKE COMPR HIGH SCH', 'OYO', '452520'),
(2521, '452521', 'úÏ…W§', '452521@oyoedu.ng', '7031201001', 'COMMUNITY HIGH SCHOOL', 'OYO', '452521'),
(2522, '452522', 'úÏ…W§', '452522@oyoedu.ng', '8062947643', 'OGBO HIGH SCHOOL', 'OYO', '452522'),
(2523, '452523', 'úÏ…W§', '452523@oyoedu.ng', '8143597102', 'BOMAK RESOURCES COLLEGE', 'OYO', '452523'),
(2524, '452524', 'úÏ…W§', '452524@oyoedu.ng', '8163050954', 'MILLENIUM ', 'OYO', '452524'),
(2525, '452525', 'úÏ…W§', '452525@oyoedu.ng', '8143597102', 'BOMAK RESOURCES COLLEGE', 'OYO', '452525'),
(2526, '452526', 'úÏ…W§', '452526@oyoedu.ng', '8163745420', 'COMPREHENSIVE SCE. SCHOOL', 'OYO', '452526'),
(2527, '452527', 'úÏ…W§', '452527@oyoedu.ng', '9035634256', 'JUBILEE BAPTIST COLLEGE', 'OYO', '452527'),
(2528, '452528', 'úÏ…W§', '452528@oyoedu.ng', '8030419407', 'SOUN HGH SCHOOL ', 'OYO', '452528'),
(2529, '452529', 'úÏ…W§', '452529@oyoedu.ng', '8037217836', 'DOTWORD', 'OYO', '452529'),
(2530, '452530', 'úÏ…W§', '452530@oyoedu.ng', '8063749460', 'HAPPINESS HIGH SCHOOL', 'OYO', '452530'),
(2531, '452531', 'úÏ…W§', '452531@oyoedu.ng', '8060568000', 'CARETAKER COM. HIGH SCHOOL', 'OYO', '452531'),
(2532, '452532', 'úÏ…W§', '452532@oyoedu.ng', '8064278090', 'HAPPINESS HIGH SCHOOL', 'OYO', '452532'),
(2533, '452533', 'úÏ…W§', '452533@oyoedu.ng', '8054895373', 'OGB GRAMM SCHOOL', 'OYO', '452533');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(2534, '452534', 'úÏ…W§', '452534@oyoedu.ng', '8075243941', 'OWODE COMM. GM. SCHOOL', 'OYO', '452534'),
(2535, '452535', 'úÏ…W§', '452535@oyoedu.ng', '8100824431', 'OKIN APA COMM HIGH SCHOOL', 'OYO', '452535'),
(2536, '452536', 'úÏ…W§', '452536@oyoedu.ng', '8125887646', 'UCC', 'OYO', '452536'),
(2537, '452537', 'úÏ…W§', '452537@oyoedu.ng', '8125887646', 'MILLENIUM ', 'OYO', '452537'),
(2538, '452538', 'úÏ…W§', '452538@oyoedu.ng', '8124312907', 'DOMINION COMP. COLLEGE', 'OYO', '452538'),
(2539, '452539', 'úÏ…W§', '452539@oyoedu.ng', '7043652078', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452539'),
(2540, '452540', 'úÏ…W§', '452540@oyoedu.ng', '', 'GOMAL', 'OYO', '452540'),
(2541, '452541', 'úÏ…W§', '452541@oyoedu.ng', '8065852263', 'OLAFUNMI COM. COLLEGE', 'OYO', '452541'),
(2542, '452542', 'úÏ…W§', '452542@oyoedu.ng', '8164379534', 'OLAFUNMI COM. COLLEGE', 'OYO', '452542'),
(2543, '452543', 'úÏ…W§', '452543@oyoedu.ng', '8030609245', 'MIGHTY MIRACLE', 'ONDO', '452543'),
(2544, '452544', 'úÏ…W§', '452544@oyoedu.ng', '8066390295', 'CHILD CENTER ACADEMY', 'OYO', '452544'),
(2545, '452545', 'úÏ…W§', '452545@oyoedu.ng', '8039652274', 'MAYDAY COLLEGE', 'OYO', '452545'),
(2546, '452546', 'úÏ…W§', '452546@oyoedu.ng', '8144664683', 'OGB GRAM. SCHOOL', 'OYO', '452546'),
(2547, '452547', 'úÏ…W§', '452547@oyoedu.ng', '8036268145', 'AJIKE SECONDARY SCHOOL', 'OYO', '452547'),
(2548, '452548', 'úÏ…W§', '452548@oyoedu.ng', '7030572022', 'HAPPINESS HIGH SCHOOL', 'OYO', '452548'),
(2549, '452549', 'úÏ…W§', '452549@oyoedu.ng', '8164210619', 'COMMUNITY HIGH SCHOOL', 'OYO', '452549'),
(2550, '452550', 'úÏ…W§', '452550@oyoedu.ng', '8062621810', 'GEORGE GREEN COLLEGE', 'OYO', '452550'),
(2551, '452551', 'úÏ…W§', '452551@oyoedu.ng', '7064269923', 'BEST LEGACY INT. ACADEMY', 'OYO', '452551'),
(2552, '452552', 'úÏ…W§', '452552@oyoedu.ng', '8138042460', 'ZOE', 'OYO', '452552'),
(2553, '452553', 'úÏ…W§', '452553@oyoedu.ng', '8034661297', 'AJIKE MODEL COLLEGE', 'OYO', '452553'),
(2554, '452554', 'úÏ…W§', '452554@oyoedu.ng', '7082099434', 'GREAT ABOKE MEM. COLL.', 'OYO', '452554'),
(2555, '452555', 'úÏ…W§', '452555@oyoedu.ng', '9053310517', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452555'),
(2556, '452556', 'úÏ…W§', '452556@oyoedu.ng', '8060420516', 'BAPTIST SEC. GRAM SCHOOL', 'OYO', '452556'),
(2557, '452557', 'úÏ…W§', '452557@oyoedu.ng', '7037979298', 'MILLENIUM ', 'OYO', '452557'),
(2558, '452558', 'úÏ…W§', '452558@oyoedu.ng', '7032190817', 'MILLENIUM ', 'OYO', '452558'),
(2559, '452559', 'úÏ…W§', '452559@oyoedu.ng', '8137611023', 'DOTWORD', 'OYO', '452559'),
(2560, '452560', 'úÏ…W§', '452560@oyoedu.ng', '8038304342', 'WESLEY COMP.SCHOOL', 'OYO', '452560'),
(2561, '452561', 'úÏ…W§', '452561@oyoedu.ng', '9025252350', 'CHRIST THE KING', 'OYO', '452561'),
(2562, '452562', 'úÏ…W§', '452562@oyoedu.ng', '8066744344', 'CHRIST THE KING', 'OYO', '452562'),
(2563, '452563', 'úÏ…W§', '452563@oyoedu.ng', '8043454755', 'GREAT CITY SECONDARY SCHOOL', 'OYO', '452563'),
(2564, '452564', 'úÏ…W§', '452564@oyoedu.ng', '8063061103', 'JOVAD', 'OYO', '452564'),
(2565, '452565', 'úÏ…W§', '452565@oyoedu.ng', '7054396602', 'DOTWORD ACADEMY', 'OYO', '452565'),
(2566, '452566', 'úÏ…W§', '452566@oyoedu.ng', '8054995487', 'MESSIAH GRAMMAR INT.', 'OYO', '452566'),
(2567, '452567', 'úÏ…W§', '452567@oyoedu.ng', '8038051376', 'AMCO', 'OYO', '452567'),
(2568, '452568', 'úÏ…W§', '452568@oyoedu.ng', '8107951186', 'ADENIRAN MEM. GRA. SCHOOL', 'OYO', '452568'),
(2569, '452569', 'úÏ…W§', '452569@oyoedu.ng', '8053820483', 'AYEGUN COLLEGE', 'OYO', '452569'),
(2570, '452570', 'úÏ…W§', '452570@oyoedu.ng', '8062962581', 'OWODE COMM. GM. SCHOOL', 'OYO', '452570'),
(2571, '452571', 'úÏ…W§', '452571@oyoedu.ng', '8064389121', 'OGBO GRAMM SCHL III', '', '452571'),
(2572, '452572', 'úÏ…W§', '452572@oyoedu.ng', '7032166029', 'JUBILEE BAPTIST COLLEGE', 'OYO', '452572'),
(2573, '452573', 'úÏ…W§', '452573@oyoedu.ng', '8107092466', 'CHRIST WAY HIGH SCHOOL', 'OYO', '452573'),
(2574, '452574', 'úÏ…W§', '452574@oyoedu.ng', '8033648087', 'MILLENIUM ', 'OYO', '452574'),
(2575, '452575', 'úÏ…W§', '452575@oyoedu.ng', '8024188366', 'GOMAL', 'OYO', '452575'),
(2576, '452576', 'úÏ…W§', '452576@oyoedu.ng', '8131160629', 'MILLENIUM ', 'OYO', '452576'),
(2577, '452577', 'úÏ…W§', '452577@oyoedu.ng', '9032829933', 'ADEDOYIN MODEL COLLEGE', 'OYO', '452577'),
(2578, '452578', 'úÏ…W§', '452578@oyoedu.ng', '8067358554', 'OWODE COMM. GM. SCHOOL', 'OYO', '452578'),
(2579, '452579', 'úÏ…W§', '452579@oyoedu.ng', '7065994131', 'OGB GRAM. SCHOOL', 'OYO', '452579'),
(2580, '452580', 'úÏ…W§', '452580@oyoedu.ng', '8062111417', 'DOMINION COMPR COLL', 'OYO', '452580'),
(2581, '452581', 'úÏ…W§', '452581@oyoedu.ng', '7046011799', 'METHODIST SECONDARY SCHOOL', 'OYO', '452581'),
(2582, '452582', 'úÏ…W§', '452582@oyoedu.ng', '8133360685', 'PETROS COLLEGE', 'OYO', '452582'),
(2583, '452583', 'úÏ…W§', '452583@oyoedu.ng', '8133360685', 'PETROS COLLEGE', 'OYO', '452583'),
(2584, '452584', 'úÏ…W§', '452584@oyoedu.ng', '8166467906', 'PETROS COLLEGE', 'OYO', '452584'),
(2585, '452585', 'úÏ…W§', '452585@oyoedu.ng', '8030464913', 'ABOKE MEM. SEC. SCHOOL', 'OYO', '452585'),
(2586, '452586', 'úÏ…W§', '452586@oyoedu.ng', '9077296348', 'MAY DAY', 'OYO', '452586'),
(2587, '452587', 'úÏ…W§', '452587@oyoedu.ng', '8160418099', 'CHILD CENTER ACADEMY', 'OYO', '452587'),
(2588, '452588', 'úÏ…W§', '452588@oyoedu.ng', '7031806326', 'RAMAT MODEL COLLEGE', 'OYO', '452588'),
(2589, '452589', 'úÏ…W§', '452589@oyoedu.ng', '7037812098', 'CHILD CENTER ACADEMY', 'OYO', '452589'),
(2590, '452590', 'úÏ…W§', '452590@oyoedu.ng', '8030859571', 'MAYDAY MONTESSORI', 'OYO', '452590'),
(2591, '452591', 'úÏ…W§', '452591@oyoedu.ng', '8066871552', 'ALLHUFAZZ ACADEMY', 'OYO', '452591'),
(2592, '452592', 'úÏ…W§', '452592@oyoedu.ng', '7046062416', 'REAMAT MODEL COLLEGE', 'OYO', '452592'),
(2593, '452593', 'úÏ…W§', '452593@oyoedu.ng', '8142904920', 'ADEBOLU COMP. COLLEGE', 'OYO', '452593'),
(2594, '452594', 'úÏ…W§', '452594@oyoedu.ng', '8162866872', 'AMCO', 'OYO', '452594'),
(2595, '452595', 'úÏ…W§', '452595@oyoedu.ng', '8084127511', 'SILOAM HIGH SCHOOL', 'OYO', '452595'),
(2596, '452596', 'úÏ…W§', '452596@oyoedu.ng', '8135971426', 'AL-HUFFAAZ ACADEMY', 'OYO', '452596'),
(2597, '452597', 'úÏ…W§', '452597@oyoedu.ng', '8134782344', 'KHABRARUDEEN COLLEGE SCH.', 'OYO', '452597'),
(2598, '452598', 'úÏ…W§', '452598@oyoedu.ng', '8105625444', 'OGB GRAMM SCHOOL', 'OYO', '452598'),
(2599, '452599', 'úÏ…W§', '452599@oyoedu.ng', '8167071262', 'UCC COLLEGE', 'OYO', '452599'),
(2600, '452600', 'úÏ…W§', '452600@oyoedu.ng', '7030702882', 'DOTWORD ACADEMY', 'OYO', '452600'),
(2601, '452601', 'úÏ…W§', '452601@oyoedu.ng', '8139260887', 'AL-AMEEN', 'OYO', '452601'),
(2602, '452602', 'úÏ…W§', '452602@oyoedu.ng', '8169021668', 'PRAISE CHAPEL COLLEGE OGB', 'OYO', '452602'),
(2603, '452603', 'úÏ…W§', '452603@oyoedu.ng', '8066427178', 'ZOE COLLEGE', 'OYO', '452603'),
(2604, '452604', 'úÏ…W§', '452604@oyoedu.ng', '8035243942', 'SMITH', 'OYO', '452604'),
(2605, '452605', 'úÏ…W§', '452605@oyoedu.ng', '8035243942', 'SMITH', 'OYO', '452605'),
(2606, '452606', 'úÏ…W§', '452606@oyoedu.ng', '8037970402', 'AL-HUFFAZAT', 'OYO', '452606'),
(2607, '452607', 'úÏ…W§', '452607@oyoedu.ng', '8137551622', 'UNITED COM. COLLEGE', 'OYO', '452607'),
(2608, '452608', 'úÏ…W§', '452608@oyoedu.ng', '7035615610', 'COMFORTER', 'OYO', '452608'),
(2609, '452609', 'úÏ…W§', '452609@oyoedu.ng', '7067204448', 'ORI OKE COMM HIGH SCHOOL', 'OYO', '452609'),
(2610, '452610', 'úÏ…W§', '452610@oyoedu.ng', '7067204448', 'ORIOKE COMM. HIGH SCHOOL', 'OYO', '452610'),
(2611, '452611', 'úÏ…W§', '452611@oyoedu.ng', '8102722661', 'GCI', 'OYO', '452611'),
(2612, '452612', 'úÏ…W§', '452612@oyoedu.ng', '9035402715', 'MUSLIM COMP HIGH SCHOOL', 'OYO', '452612'),
(2613, '452613', 'úÏ…W§', '452613@oyoedu.ng', '8160582713', 'MILLENIUM ', 'OYO', '452613'),
(2614, '452614', 'úÏ…W§', '452614@oyoedu.ng', '9074286751', 'DOTWORD', 'OYO', '452614'),
(2615, '452615', 'úÏ…W§', '452615@oyoedu.ng', '8129337714', 'AL-HUDDAH OGB', 'OYO', '452615'),
(2616, '452616', 'úÏ…W§', '452616@oyoedu.ng', '8137621291', 'AKHBRARUDEEN COLLEGE', 'OYO', '452616'),
(2617, '452617', 'úÏ…W§', '452617@oyoedu.ng', '8036804724', 'BEST LEGACY INT. ACADEMY', 'OYO', '452617'),
(2618, '452618', 'úÏ…W§', '452618@oyoedu.ng', '8060596404', 'AS-SHAKUR COM SCH', 'OYO', '452618'),
(2619, '452619', 'úÏ…W§', '452619@oyoedu.ng', '8036319076', 'BEST LEGACY INT. ACADEMY', 'OYO', '452619'),
(2620, '452620', 'úÏ…W§', '452620@oyoedu.ng', '7066823598', 'ISLAMIC COLLEGE', 'OYO', '452620'),
(2621, '452621', 'úÏ…W§', '452621@oyoedu.ng', '8030613535', 'AKHBRARUDEEN COLLEGE', 'OYO', '452621'),
(2622, '452622', 'úÏ…W§', '452622@oyoedu.ng', '8063101718', 'LAUTECH INT. COLLEGE', 'OYO', '452622'),
(2623, '642623', 'úÏ…W§', '642623@oyoedu.ng', '8071105144', 'I.D.G.S,ISEYIN', 'OYO', '642623'),
(2624, '642624', 'úÏ…W§', '642624@oyoedu.ng', '', 'GLORY INTL SCHL OF SCI.ISEYIN', 'OYO', '642624'),
(2625, '642625', 'úÏ…W§', '642625@oyoedu.ng', '8024091171', 'VIC.COLL,OKEHO', 'OYO', '642625'),
(2626, '642626', 'úÏ…W§', '642626@oyoedu.ng', '7055699195', 'VIC.COLL,OKEHO', 'OYO', '642626'),
(2627, '642627', 'úÏ…W§', '642627@oyoedu.ng', '7055699195', 'VIC.COLL,OKEHO', 'OYO', '642627'),
(2628, '642628', 'úÏ…W§', '642628@oyoedu.ng', '7055699195', 'VIC.COLL,OKEHO', 'OYO', '642628'),
(2629, '642629', 'úÏ…W§', '642629@oyoedu.ng', '8076311728', 'LIVINGSPRING,OKEHO', 'OYO', '642629'),
(2630, '642630', 'úÏ…W§', '642630@oyoedu.ng', '8076277839', 'LIVSPRING OKEHO', 'OYO', '642630'),
(2631, '642631', 'úÏ…W§', '642631@oyoedu.ng', '8076337171', 'O.I.G.S OKEHO', 'OYO', '642631'),
(2632, '642632', 'úÏ…W§', '642632@oyoedu.ng', '8039555728', 'SHA.ROSE SAKI', 'OYO', '642632'),
(2633, '642633', 'úÏ…W§', '642633@oyoedu.ng', '9038179648', 'O.I.G.S OKEHO', 'OYO', '642633'),
(2634, '642634', 'úÏ…W§', '642634@oyoedu.ng', '8026132286', 'O.I.G.S OKEHO', 'OYO', '642634'),
(2635, '642635', 'úÏ…W§', '642635@oyoedu.ng', '', 'O.I.G.S OKEHO', 'OYO', '642635'),
(2636, '642636', 'úÏ…W§', '642636@oyoedu.ng', '', 'O.I.G.S OKEHO', 'OYO', '642636'),
(2637, '642637', 'úÏ…W§', '642637@oyoedu.ng', '8089408503', 'AMA.GRACE OKEHO', 'OYO', '642637'),
(2638, '642638', 'úÏ…W§', '642638@oyoedu.ng', '8146364026', 'O.I.G.S OKEHO', 'OYO', '642638'),
(2639, '642639', 'úÏ…W§', '642639@oyoedu.ng', '7032795689', 'AMA.GRACE OKEHO', 'OYO', '642639'),
(2640, '642640', 'úÏ…W§', '642640@oyoedu.ng', '7060509321', 'O.I.G.S OKEHO', 'OYO', '642640'),
(2641, '642641', 'úÏ…W§', '642641@oyoedu.ng', '8149314712', 'O.I.G.S OKEHO', 'OYO', '642641'),
(2642, '642642', 'úÏ…W§', '642642@oyoedu.ng', '7039850400', 'A.D.S II OKEHO', 'OYO', '642642'),
(2643, '642643', 'úÏ…W§', '642643@oyoedu.ng', '', 'MUS.GRAM.SCH. ISEYIN', 'OYO', '642643'),
(2644, '642644', 'úÏ…W§', '642644@oyoedu.ng', '8024555263', 'ST.MICHEAL COL. OKEHO', 'OYO', '642644'),
(2645, '642645', 'úÏ…W§', '642645@oyoedu.ng', '8138574284', 'VIC.COLL,OKEHO', 'OYO', '642645'),
(2646, '642646', 'úÏ…W§', '642646@oyoedu.ng', '8169876899', 'ST.JOSEPH SCH IWERE-ILE', 'OYO', '642646'),
(2647, '642647', 'úÏ…W§', '642647@oyoedu.ng', '', 'GREATER LOVE SCH ISEYIN', 'OYO', '642647'),
(2648, '642648', 'úÏ…W§', '642648@oyoedu.ng', '8073891274', 'SAF COLLEGE ISEYIN', 'OYO', '642648'),
(2649, '642649', 'úÏ…W§', '642649@oyoedu.ng', '8038401343', 'SHABAB COLLEGE ISEYIN', 'OYO', '642649'),
(2650, '642650', 'úÏ…W§', '642650@oyoedu.ng', '7051657772', 'BAPT.HERT. COL.IWEREILE', 'OYO', '642650'),
(2651, '642651', 'úÏ…W§', '642651@oyoedu.ng', '8061607290', 'ASSURANCE COLLEGE', 'OGUN', '642651'),
(2652, '642652', 'úÏ…W§', '642652@oyoedu.ng', '9067090195', 'ADE-AYO INTLCOL.IGANA', 'OYO', '642652'),
(2653, '642653', 'úÏ…W§', '642653@oyoedu.ng', '7067793556', 'PREMIUM COL. ISEYIN', 'OYO', '642653'),
(2654, '642654', 'úÏ…W§', '642654@oyoedu.ng', '7067793556', 'PREMIUM COL. ISEYIN', 'OYO', '642654'),
(2655, '642655', 'úÏ…W§', '642655@oyoedu.ng', '8024995592', 'B.H.S OKEHO', 'OYO', '642655'),
(2656, '642656', 'úÏ…W§', '642656@oyoedu.ng', '7047230632', 'B.H.S OKEHO', 'OYO', '642656'),
(2657, '642657', 'úÏ…W§', '642657@oyoedu.ng', '8062860943', 'GREATER LOVE SCH ISEYIN', 'OYO', '642657'),
(2658, '642658', 'úÏ…W§', '642658@oyoedu.ng', '8167578438', 'MUS.GRAM.SCH. ISEYIN', 'OYO', '642658'),
(2659, '642659', 'úÏ…W§', '642659@oyoedu.ng', '8072952189', 'A.D.S I OKEHO', 'OYO', '642659'),
(2660, '642660', 'úÏ…W§', '642660@oyoedu.ng', '8087547287', 'B.H.S ILERO', 'OYO', '642660'),
(2661, '642661', 'úÏ…W§', '642661@oyoedu.ng', '8082127311', 'B.H.S ILERO', 'OYO', '642661'),
(2662, '642662', 'úÏ…W§', '642662@oyoedu.ng', '8087817455', 'B.H.S ILERO', 'OYO', '642662'),
(2663, '642663', 'úÏ…W§', '642663@oyoedu.ng', '7087825381', 'B.H.S ILERO', 'OYO', '642663'),
(2664, '642664', 'úÏ…W§', '642664@oyoedu.ng', '8080269704', 'B.H.S ILERO', 'OYO', '642664'),
(2665, '642665', 'úÏ…W§', '642665@oyoedu.ng', '7051947288', 'ONJO H,S OKEHO', 'OYO', '642665'),
(2666, '642666', 'úÏ…W§', '642666@oyoedu.ng', '8051137623', 'ST. JOSEPH SCH IWERELE', 'OYO', '642666'),
(2667, '642667', 'úÏ…W§', '642667@oyoedu.ng', '8050610419', 'VIC.COLL,OKEHO', 'OYO', '642667'),
(2668, '642668', 'úÏ…W§', '642668@oyoedu.ng', '7038319578', 'MUS.COM.H.S AYETORO-OKE', 'OYO', '642668'),
(2669, '642669', 'úÏ…W§', '642669@oyoedu.ng', '8124299877', 'AMA.GRACE OKEHO', 'KWARA', '642669'),
(2670, '642670', 'úÏ…W§', '642670@oyoedu.ng', '9036922452', 'AL-BALAGH MOD.COL.OKEHO', 'OYO', '642670'),
(2671, '642671', 'úÏ…W§', '642671@oyoedu.ng', '8106772884', 'B.H.S OKEHO', 'OYO', '642671'),
(2672, '642672', 'úÏ…W§', '642672@oyoedu.ng', '7034635556', 'A.U.D ILERO', 'OYO', '642672'),
(2673, '642673', 'úÏ…W§', '642673@oyoedu.ng', '7084581002', 'SAF COLLEGE ISEYIN', 'OYO', '642673'),
(2674, '642674', 'úÏ…W§', '642674@oyoedu.ng', '8050403679', 'LIVSPRING OKEHO', 'OYO', '642674'),
(2675, '642675', 'úÏ…W§', '642675@oyoedu.ng', '8106808098', 'O.I.G.S OKEHO', 'OYO', '642675'),
(2676, '642676', 'úÏ…W§', '642676@oyoedu.ng', '8054490282', 'THE DEN MOD. COL ISEYIN', 'OYO', '642676'),
(2677, '642677', 'úÏ…W§', '642677@oyoedu.ng', '8126380546', 'FAITH IMMA. ACA. IGBOHO', 'OYO', '642677'),
(2678, '642678', 'úÏ…W§', '642678@oyoedu.ng', '8027747979', 'KIDDIES PROSPECT COLLEGE', 'OYO', '642678'),
(2679, '642679', 'úÏ…W§', '642679@oyoedu.ng', '7055017329', 'ROYAL DIADEM COL.IGANGAN', 'OYO', '642679'),
(2680, '642680', 'úÏ…W§', '642680@oyoedu.ng', '8027391952', 'EKUNLE HIGH SCHOOL ISEYIN', 'OYO', '642680'),
(2681, '642681', 'úÏ…W§', '642681@oyoedu.ng', '8054887681', 'IRETIOGO BAPT.COL IGBOHO', 'OYO', '642681'),
(2682, '642682', 'úÏ…W§', '642682@oyoedu.ng', '8102728510', 'HIKMAH W. COLLEGE IGBOHO', 'OYO', '642682'),
(2683, '642683', 'úÏ…W§', '642683@oyoedu.ng', '8059406261', 'UNITED MUS. ACAD IGBOHO', 'OYO', '642683'),
(2684, '642684', 'úÏ…W§', '642684@oyoedu.ng', '8167239894', 'KIDDIES PROSPECT COLLEGE', 'OYO', '642684'),
(2685, '642685', 'úÏ…W§', '642685@oyoedu.ng', '8086569400', 'SHINNING STAR COL. IGBOHO', 'OYO', '642685'),
(2686, '642686', 'úÏ…W§', '642686@oyoedu.ng', '8027757165', 'SHA.ROSE SCHOOL AGO-ARE', 'OYO', '642686'),
(2687, '642687', 'úÏ…W§', '642687@oyoedu.ng', '8121673148', 'B.H.S OKEHO', 'EBONYI', '642687'),
(2688, '642688', 'úÏ…W§', '642688@oyoedu.ng', '8055775185', 'KILANI MODEL SCHOOL ISEYIN', 'OYO', '642688'),
(2689, '642689', 'úÏ…W§', '642689@oyoedu.ng', '7067689251', 'ALAMUWA GRAM.SCH ADODO', 'OYO', '642689'),
(2690, '642690', 'úÏ…W§', '642690@oyoedu.ng', '7068760083', 'JOPATHERA COLLEGE IKOTUN', 'OYO', '642690'),
(2691, '642691', 'úÏ…W§', '642691@oyoedu.ng', '8078022654', 'VIC.COLL,OKEHO', 'OYO', '642691'),
(2692, '642692', 'úÏ…W§', '642692@oyoedu.ng', '8078022654', 'LIVSPRING OKEHO', 'OYO', '642692'),
(2693, '642693', 'úÏ…W§', '642693@oyoedu.ng', '9054569845', 'SCHOLARS COLLEGE OKEHO', 'OYO', '642693'),
(2694, '642694', 'úÏ…W§', '642694@oyoedu.ng', '816632551', 'SHAPMAN COLLEGE IBADAN', '', '642694'),
(2695, '642695', 'úÏ…W§', '642695@oyoedu.ng', '7080972020', 'BAPTIST HIGH SCHOOL SAKI', 'OYO', '642695'),
(2696, '642696', 'úÏ…W§', '642696@oyoedu.ng', '7060699524', 'MODEL COLLEGE IKORODU ', 'CROSS RIVER', '642696'),
(2697, '642697', 'úÏ…W§', '642697@oyoedu.ng', '8163062814', '', 'OYO', '642697'),
(2698, '642698', 'úÏ…W§', '642698@oyoedu.ng', '', 'COM. GRAM. SCH ILADO SAGBO', 'OYO', '642698'),
(2699, '642699', 'úÏ…W§', '642699@oyoedu.ng', '8024908960', 'SCHOLARS COLLEGE OKEHO', 'OYO', '642699'),
(2700, '642700', 'úÏ…W§', '642700@oyoedu.ng', '8034162518', 'KILANI MODEL SCHOOL ISEYIN', 'OYO', '642700'),
(2701, '642701', 'úÏ…W§', '642701@oyoedu.ng', '8028573134', 'OKE-OGUN/OGBINTE OKEHO', 'OYO', '642701'),
(2702, '642702', 'úÏ…W§', '642702@oyoedu.ng', '8066081070', 'COM. GRAMMAR SCHOOL ILUA', 'OYO', '642702'),
(2703, '642703', 'úÏ…W§', '642703@oyoedu.ng', '8065243820', 'ISEMI-ILE GRAMMAR SCHOOL', 'OYO', '642703'),
(2704, '642704', 'úÏ…W§', '642704@oyoedu.ng', '7035300121', 'PROGRESSIVE GRA.SCH AWAYE', 'OYO', '642704'),
(2705, '642705', 'úÏ…W§', '642705@oyoedu.ng', '7035300121', 'PROGRESSIVE GRA.SCH AWAYE', 'OYO', '642705'),
(2706, '642706', 'úÏ…W§', '642706@oyoedu.ng', '8059783539', 'BLUE CRESCENT ISEYIN', 'OYO', '642706'),
(2707, '642707', 'úÏ…W§', '642707@oyoedu.ng', '7062794111', 'BAPTIST HIGH SCHOOL IGBOHO', 'OYO', '642707'),
(2708, '642708', 'úÏ…W§', '642708@oyoedu.ng', '8038147117', 'VIC.COLL,OKEHO', 'OYO', '642708'),
(2709, '642709', 'úÏ…W§', '642709@oyoedu.ng', '9152741693', '', 'OYO', '642709'),
(2710, '642710', 'úÏ…W§', '642710@oyoedu.ng', '8064844171', 'A.D.S OKEHO', 'OYO', '642710'),
(2711, '642711', 'úÏ…W§', '642711@oyoedu.ng', '9076129223', 'ACAD. FOR GRACE ADO-ODOOTA', 'OGUN', '642711'),
(2712, '642712', 'úÏ…W§', '642712@oyoedu.ng', '8028161995', 'OGUNLADE COLLEGE SURULERE L.', 'KWARA', '642712'),
(2713, '642713', 'úÏ…W§', '642713@oyoedu.ng', '8025531212', 'B.H.S OKEHO', 'OYO', '642713'),
(2714, '642714', 'úÏ…W§', '642714@oyoedu.ng', '8138097102', 'BAPTIST HIGH SCHOOL IGANNA', 'OYO', '642714'),
(2715, '642715', 'úÏ…W§', '642715@oyoedu.ng', '8027725633', 'BAPTIST HIGH SCHOOL IGANNA', 'OYO', '642715'),
(2716, '642716', 'úÏ…W§', '642716@oyoedu.ng', '8027725633', 'BAPTIST HIGH SCHOOL IGANNA', 'OYO', '642716'),
(2717, '642717', 'úÏ…W§', '642717@oyoedu.ng', '7035952840', 'ISMOG COMM.GRAM.SCH OKEHO', 'OYO', '642717'),
(2718, '642718', 'úÏ…W§', '642718@oyoedu.ng', '9024781899', 'MUS.COMMUNITY IGANNA', 'OYO', '642718'),
(2719, '642719', 'úÏ…W§', '642719@oyoedu.ng', '8050766339', 'GLORIOUS K&Q IBADAN', 'OYO', '642719'),
(2720, '642720', 'úÏ…W§', '642720@oyoedu.ng', '9045263403', 'IREPODUN COM. HIGH SCH ILERO', 'OYO', '642720'),
(2721, '642721', 'úÏ…W§', '642721@oyoedu.ng', '8035389216', 'SUNDORA S. SCHOOL IBADAN', 'OSUN', '642721'),
(2722, '642722', 'úÏ…W§', '642722@oyoedu.ng', '7051830328', 'FALOMO JNR HIGH SCH LAGOS', 'OYO', '642722'),
(2723, '642723', 'úÏ…W§', '642723@oyoedu.ng', '7066527185', 'DROG. SEC. SCHOOL ADOAWAYE', 'OYO', '642723'),
(2724, '642724', 'úÏ…W§', '642724@oyoedu.ng', '7066527185', 'DROG. SEC. SCHOOL ADOAWAYE', 'OYO', '642724'),
(2725, '642725', 'úÏ…W§', '642725@oyoedu.ng', '7033082215', 'ONJO H,S OKEHO', 'OYO', '642725'),
(2726, '642726', 'úÏ…W§', '642726@oyoedu.ng', '8038401343', '', 'OYO', '642726'),
(2727, '642727', 'úÏ…W§', '642727@oyoedu.ng', '8074571146', 'KILANI MODEL SCHOOL ISEYIN', 'OYO', '642727'),
(2728, '642728', 'úÏ…W§', '642728@oyoedu.ng', '8033166098', 'O.I.G.S OKEHO', 'OYO', '642728'),
(2729, '642729', 'úÏ…W§', '642729@oyoedu.ng', '8028250446', 'NEW GEN. COL. ILERO', 'OYO', '642729'),
(2730, '642730', 'úÏ…W§', '642730@oyoedu.ng', '8025959662', 'NEW GEN. COL. ILERO', 'OYO', '642730'),
(2731, '642731', 'úÏ…W§', '642731@oyoedu.ng', '8020511456', 'NEW GEN. COL. ILERO', 'OYO', '642731'),
(2732, '642732', 'úÏ…W§', '642732@oyoedu.ng', '8076422783', 'HALIMAT M COL ISEYIN', 'OYO', '642732'),
(2733, '642733', 'úÏ…W§', '642733@oyoedu.ng', '8136710469', 'COM. GRAMMAR SCHOOL OUT', 'OYO', '642733'),
(2734, '642734', 'úÏ…W§', '642734@oyoedu.ng', '8072247830', 'ISMOG COMM.GRAM.SCH OKEHO', 'OYO', '642734'),
(2735, '642735', 'úÏ…W§', '642735@oyoedu.ng', '8103989999', 'AMA.GRACE OKEHO', 'OYO', '642735'),
(2736, '642736', 'úÏ…W§', '642736@oyoedu.ng', '8052962517', 'BAPTIST HIGH SCHOOL IGANNA', 'OYO', '642736'),
(2737, '642737', 'úÏ…W§', '642737@oyoedu.ng', '8032566472', 'LIBERTY COLLEGE OYO', 'OYO', '642737'),
(2738, '642738', 'úÏ…W§', '642738@oyoedu.ng', '8101806788', 'PROGRESSIVE GRA.SCH AWAYE', 'OYO', '642738'),
(2739, '642739', 'úÏ…W§', '642739@oyoedu.ng', '8146063183', 'AMA.GRACE OKEHO', 'OYO', '642739'),
(2740, '642740', 'úÏ…W§', '642740@oyoedu.ng', '8025999155', 'ISMOG COMM.GRAM.SCH OKEHO', 'OYO', '642740'),
(2741, '642741', 'úÏ…W§', '642741@oyoedu.ng', '7032514668', 'VIC.COLL,OKEHO', 'OYO', '642741'),
(2742, '642742', 'úÏ…W§', '642742@oyoedu.ng', '7083972323', 'BSG AGO-ARE', 'OYO', '642742'),
(2743, '642743', 'úÏ…W§', '642743@oyoedu.ng', '9064840321', 'ADE-AYO INTLCOL.IGANA', 'OYO', '642743'),
(2744, '642744', 'úÏ…W§', '642744@oyoedu.ng', '8156140194', 'VIC.COLL,OKEHO', 'OYO', '642744'),
(2745, '642745', 'úÏ…W§', '642745@oyoedu.ng', '8168982386', 'AMA.GRACE OKEHO', 'OYO', '642745'),
(2746, '642746', 'úÏ…W§', '642746@oyoedu.ng', '8038092070', 'SAF COLLEGE ISEYIN', 'OYO', '642746'),
(2747, '642747', 'úÏ…W§', '642747@oyoedu.ng', '810486555', 'ONJO H,S OKEHO', 'OYO', '642747'),
(2748, '642748', 'úÏ…W§', '642748@oyoedu.ng', '8038262717', 'ISEYIN', 'OYO', '642748'),
(2749, '642749', 'úÏ…W§', '642749@oyoedu.ng', '8071245800', 'AL-HIKMAH COMP COL IGBOHO', 'OYO', '642749'),
(2750, '642750', 'úÏ…W§', '642750@oyoedu.ng', '9130620893', 'BAPTIST HIGH SCHOOL IGBOHO', 'OYO', '642750'),
(2751, '642751', 'úÏ…W§', '642751@oyoedu.ng', '81252727645', 'YN.NU ACADEMY IGBOHO', 'OYO', '642751'),
(2752, '642752', 'úÏ…W§', '642752@oyoedu.ng', '8051210421', 'ISMOG COMM.GRAM.SCH OKEHO', 'OYO', '642752'),
(2753, '642753', 'úÏ…W§', '642753@oyoedu.ng', '8100976097', 'B.H.S OKEHO', 'EBONYI', '642753'),
(2754, '642754', 'úÏ…W§', '642754@oyoedu.ng', '8109605329', 'KELANI COLLEGE, ISEYIN', 'OYO', '642754'),
(2755, '562755', 'úÏ…W§', '562755@oyoedu.ng', '7033011530', 'COMM..JUNIOR SEC SCHL OKEOLOLA OYO', 'OYO', '562755'),
(2756, '562756', 'úÏ…W§', '562756@oyoedu.ng', '7033011530', 'COMM..JUNIOR SEC SCHL OKEOLOLA OYO', 'OYO', '562756'),
(2757, '562757', 'úÏ…W§', '562757@oyoedu.ng', '7033011530', 'ALAAFIN HIGH SCH II, OYO', 'OYO', '562757'),
(2758, '562758', 'úÏ…W§', '562758@oyoedu.ng', '9045277091', 'FAVOURS MODEL COLLEGE', 'OYO', '562758'),
(2759, '562759', 'úÏ…W§', '562759@oyoedu.ng', '8162311781', 'COMM .HIGH SCH AWUMORO', 'OYO', '562759'),
(2760, '562760', 'úÏ…W§', '562760@oyoedu.ng', '7052162670', 'LADIGBOLU  GRAMM. SCHL.OYO ', 'OYO', '562760'),
(2761, '562761', 'úÏ…W§', '562761@oyoedu.ng', '8148976292', 'ZION PROGRESSIVE COLLEGE', 'OYO', '562761'),
(2762, '562762', 'úÏ…W§', '562762@oyoedu.ng', '8060150057', 'ATANDA BAPT.CHURCH SEC SCHL, ILORA', 'OYO', '562762'),
(2763, '562763', 'úÏ…W§', '562763@oyoedu.ng', '7035065605', 'OLIVET HIGH SCH OYO ', 'OYO', '562763'),
(2764, '562764', 'úÏ…W§', '562764@oyoedu.ng', '7083850650', 'ARMY CHIDREN SEC, SCH OYO', 'OYO', '562764'),
(2765, '562765', 'úÏ…W§', '562765@oyoedu.ng', '7083850650', 'ARMY CHIDREN SEC, SCH OYO', 'OYO', '562765'),
(2766, '562766', 'úÏ…W§', '562766@oyoedu.ng', '7068029507', 'GOLDEN VALLEY COLLEGE OYO', 'OYO', '562766'),
(2767, '562767', 'úÏ…W§', '562767@oyoedu.ng', '8034625854', 'MAASHA ALLAH COMP. COLLEGE OYO', 'OYO', '562767'),
(2768, '562768', 'úÏ…W§', '562768@oyoedu.ng', '8035548144', 'LIBERTY COLL,OYO', 'OYO', '562768'),
(2769, '562769', 'úÏ…W§', '562769@oyoedu.ng', '7083949690', 'DYNAMIC MODEL COLLEGE, OYO', 'OYO', '562769'),
(2770, '562770', 'úÏ…W§', '562770@oyoedu.ng', '8064405938', 'CRESCENT HEIGHTS,OYO ', 'OYO', '562770'),
(2771, '562771', 'úÏ…W§', '562771@oyoedu.ng', '8072675275', 'NATURE-NURTURE COMP. COLLEGE OYO', 'OYO', '562771'),
(2772, '562772', 'úÏ…W§', '562772@oyoedu.ng', '8145183650', 'AMRY CHIDREN SEC ,SCH, OYO', 'OYO', '562772'),
(2773, '562773', 'úÏ…W§', '562773@oyoedu.ng', '8034010529', 'OLIVET BAP. JUNIOR SCH, OYO', 'OYO', '562773'),
(2774, '562774', 'úÏ…W§', '562774@oyoedu.ng', '8034367586', 'GOOD NEWS COLLEGE OYO ', 'OYO', '562774'),
(2775, '562775', 'úÏ…W§', '562775@oyoedu.ng', '8072130230', 'GOD?S WISDOM INTERNATIONAL COLLEGE OYO ', 'OYO', '562775'),
(2776, '562776', 'úÏ…W§', '562776@oyoedu.ng', '7051235233', 'THE ENGMA COLL,OYO', 'OYO', '562776'),
(2777, '562777', 'úÏ…W§', '562777@oyoedu.ng', '7062905359', 'OLA-OLU BASIC SCHL,OYO', 'OYO ', '562777'),
(2778, '562778', 'úÏ…W§', '562778@oyoedu.ng', '8038336439', 'CHRIST THE CONERSTONE EMODEL COLL,OYO  ', 'OYO', '562778'),
(2779, '562779', 'úÏ…W§', '562779@oyoedu.ng', '8102121610', 'GOLDEN VALLEY COLLEGE,OYO ', 'OYO', '562779'),
(2780, '562780', 'úÏ…W§', '562780@oyoedu.ng', '8035170643', 'GOLDEN VALLEY COLLEGE , OYO ', 'OYO ', '562780'),
(2781, '562781', 'úÏ…W§', '562781@oyoedu.ng', '8054536977', 'AR-RUSHAD BASIC ISLAMIC  ACEDEMY', 'OYO ', '562781'),
(2782, '562782', 'úÏ…W§', '562782@oyoedu.ng', '8160106417', 'ORANYAN GRAM. SCH, OYO', 'OYO ', '562782'),
(2783, '562783', 'úÏ…W§', '562783@oyoedu.ng', '8160106417', 'ORANYAN GRAM.SCH, OYO', 'OYO', '562783'),
(2784, '562784', 'úÏ…W§', '562784@oyoedu.ng', '7037494041', 'FAVOURS MODEL COLLEGE OYO,', 'OYO', '562784'),
(2785, '562785', 'úÏ…W§', '562785@oyoedu.ng', '8065069382', 'FAVOURS MODEL COLLEGE OYO,', 'OYO', '562785'),
(2786, '562786', 'úÏ…W§', '562786@oyoedu.ng', '7037494041', 'FAVOURS MODEL COLLEGE, OYO.', 'OYO', '562786'),
(2787, '562787', 'úÏ…W§', '562787@oyoedu.ng', '8145849464', 'ARMY CHILDREN SEC, SCHL,OYO', 'OYO', '562787'),
(2788, '562788', 'úÏ…W§', '562788@oyoedu.ng', '8119991901', 'ARMY CHILDREN SEC. SCHL, OYO', 'OYO', '562788'),
(2789, '562789', 'úÏ…W§', '562789@oyoedu.ng', '8034719812', 'ARMY CHILDREN SEC.SCHL,OYO', 'OYO', '562789'),
(2790, '562790', 'úÏ…W§', '562790@oyoedu.ng', '9031894930', 'GOLDEN VALLEY COLLEGE, OYO.', 'OYO', '562790'),
(2791, '562791', 'úÏ…W§', '562791@oyoedu.ng', '8162097073', 'AANU OLORUNPO GODWIN COLL,OYO.', 'OYO', '562791'),
(2792, '562792', 'úÏ…W§', '562792@oyoedu.ng', '8071532297', 'ALAAFIN HIGH SCHL, OYO', 'OYO', '562792'),
(2793, '562793', 'úÏ…W§', '562793@oyoedu.ng', '8051566742', 'WINNERS INTERNATIONAL COLLEGE OYO', 'OYO', '562793'),
(2794, '562794', 'úÏ…W§', '562794@oyoedu.ng', '7055785463', 'ARMY CHILDREN SEC, SCHL OYO', 'OYO', '562794'),
(2795, '562795', 'úÏ…W§', '562795@oyoedu.ng', '8037223873', 'SHALOM BAPT, COLL, OYO.', 'OYO', '562795'),
(2796, '562796', 'úÏ…W§', '562796@oyoedu.ng', '7042263551', 'PROGRESSIVE ACADEMY OYO.', 'OYO', '562796'),
(2797, '562797', 'úÏ…W§', '562797@oyoedu.ng', '8030470753', 'ARMY CHILDREN SEC, SCHL. OYO', 'OYO', '562797'),
(2798, '562798', 'úÏ…W§', '562798@oyoedu.ng', '8132618363', 'SOUND MIND COMP. COLLEGE OYO.', 'OYO', '562798'),
(2799, '562799', 'úÏ…W§', '562799@oyoedu.ng', '8150501636', 'ARMY CHILDREN SEC, SCHL. OYO', 'OYO', '562799'),
(2800, '562800', 'úÏ…W§', '562800@oyoedu.ng', '8068615948', 'VICTORY OF GOD COLLEGE, OYO.', 'OYO', '562800'),
(2801, '562801', 'úÏ…W§', '562801@oyoedu.ng', '7059939799', 'ALWAQTU GROUP OF SCHL, OYO.  ', 'OYO', '562801'),
(2802, '562802', 'úÏ…W§', '562802@oyoedu.ng', '8054625431', 'PRIDE INTER, SEC SCHL, OYO.', 'OYO', '562802'),
(2803, '562803', 'úÏ…W§', '562803@oyoedu.ng', '7017181457', 'TA?AWWU?GROUP OF SCHL, OYO', 'OYO', '562803'),
(2804, '562804', 'úÏ…W§', '562804@oyoedu.ng', '8034275201', 'ST GABRIEL COMMERCIAL SCHL.', 'OYO', '562804'),
(2805, '562805', 'úÏ…W§', '562805@oyoedu.ng', '8038267641', 'IBADAN MARIT , MODEL COLL,OYO', 'OYO', '562805'),
(2806, '562806', 'úÏ…W§', '562806@oyoedu.ng', '8056749747', 'OLIVET BAPT. JUNIOR SCHL, OYO', 'OYO', '562806'),
(2807, '562807', 'úÏ…W§', '562807@oyoedu.ng', '9132821382', 'ISALE OYO COMM.SEC SCHL, OYO', 'OYO', '562807'),
(2808, '562808', 'úÏ…W§', '562808@oyoedu.ng', '7088613599', 'EAGLES BAPT. ACADEMY,OYO', 'OYO', '562808'),
(2809, '562809', 'úÏ…W§', '562809@oyoedu.ng', '7042842819', 'GOD?S KNOWLEDGE GROUP OF SCHL, OYO. ', 'OYO', '562809'),
(2810, '562810', 'úÏ…W§', '562810@oyoedu.ng', '7083928751', 'ORANYAN GRAM. SCHOOL, OYO', 'OYO', '562810'),
(2811, '562811', 'úÏ…W§', '562811@oyoedu.ng', '08159807961    08062', 'HAPPY CHILDREN COMP. SCHL, OYO.', 'OYO', '562811'),
(2812, '562812', 'úÏ…W§', '562812@oyoedu.ng', '8060816648', 'ILORA BAPT.GRAM. SCHL. OY ', 'OYO', '562812'),
(2813, '562813', 'úÏ…W§', '562813@oyoedu.ng', '7065258639', 'ADELEKE MEMORY, ALAGA OYO', 'OYO', '562813'),
(2814, '562814', 'úÏ…W§', '562814@oyoedu.ng', '8060242249', 'UNITY MODEL GROUP OF SCHL. OYO', 'OYO', '562814'),
(2815, '562815', 'úÏ…W§', '562815@oyoedu.ng', '7030001200', 'ORANYAN GRAM. SCHL. OYO', 'OYO', '562815'),
(2816, '562816', 'úÏ…W§', '562816@oyoedu.ng', '7018510023', 'RADIANT LIFE HEIGHT COLL, OYO.', 'OYO', '562816'),
(2817, '562817', 'úÏ…W§', '562817@oyoedu.ng', '8035777644', 'ADENIRAN MODEL COLL. OYO. ', 'OYO', '562817'),
(2818, '562818', 'úÏ…W§', '562818@oyoedu.ng', '8062147006', 'MARVEL RIPHATH COLLEGE, ILORA.', 'OYO', '562818'),
(2819, '562819', 'úÏ…W§', '562819@oyoedu.ng', '8167424121', 'RIGHT TRACK MODEL COLL, OYO', 'OYO', '562819'),
(2820, '562820', 'úÏ…W§', '562820@oyoedu.ng', '8035182467', 'NATURE- NURTURE COMP. COLLEGE OYO. ', 'OYO', '562820'),
(2821, '562821', 'úÏ…W§', '562821@oyoedu.ng', '8034662009', 'GOD?S BLESSING INTERNATIONAL COLL,OYO.', 'OYO', '562821'),
(2822, '562822', 'úÏ…W§', '562822@oyoedu.ng', '8066881405', 'HAPPY CHILDREN COMP. COLLEGE OYO', 'OYO', '562822'),
(2823, '562823', 'úÏ…W§', '562823@oyoedu.ng', '8038722447', 'CRESCENT HEIGHTS, OYO', 'OYO', '562823'),
(2824, '562824', 'úÏ…W§', '562824@oyoedu.ng', '8033779920', 'CRESCENT HEIGHTS , OYO.', 'OYO', '562824'),
(2825, '562825', 'úÏ…W§', '562825@oyoedu.ng', '7031856485', 'AR- RAHMAN                              ', 'OYO', '562825'),
(2826, '562826', 'úÏ…W§', '562826@oyoedu.ng', '8039618370', 'AGBOYE BAPT.MODELCOLL, OYO.', 'OYO', '562826'),
(2827, '562827', 'úÏ…W§', '562827@oyoedu.ng', '8055265385', 'FIRST GATE COLL,OYO. ', 'OYO', '562827'),
(2828, '562828', 'úÏ…W§', '562828@oyoedu.ng', '8038635851', 'GOD?S MERCY COMP.COLL,OYO.', 'OYO', '562828'),
(2829, '562829', 'úÏ…W§', '562829@oyoedu.ng', '7066623095', 'I.M.G. OYO', 'OYO', '562829'),
(2830, '562830', 'úÏ…W§', '562830@oyoedu.ng', '09O39918840', 'GATE WAY ACADEMY, OYO.', 'OYO', '562830'),
(2831, '562831', 'úÏ…W§', '562831@oyoedu.ng', '8072054309', 'SPED INTER?L SEC,SCHL, OYO.', 'OYO', '562831'),
(2832, '562832', 'úÏ…W§', '562832@oyoedu.ng', '9050047684', 'GOLDEN VALLEY ACADEMY ,OYO', 'OYO', '562832'),
(2833, '562833', 'úÏ…W§', '562833@oyoedu.ng', '8138705126', 'ALAAFIN HIGH SCH II, OYO', 'OYO', '562833'),
(2834, '562834', 'úÏ…W§', '562834@oyoedu.ng', '7062355672', 'FIRST BAPT. COLLEGE ,ILORA ', 'OYO', '562834'),
(2835, '562835', 'úÏ…W§', '562835@oyoedu.ng', '7062355672', 'FIRST BAPT. COLLEGE , ILORA', 'OYO', '562835'),
(2836, '562836', 'úÏ…W§', '562836@oyoedu.ng', '9043055625', 'ARMY CHILDREN SEC,SCHL, OYO. ', 'OYO', '562836'),
(2837, '562837', 'úÏ…W§', '562837@oyoedu.ng', '8053374559', 'A.D.S HIGH SCHL, OPAPA. OYO.', 'OYO', '562837'),
(2838, '562838', 'úÏ…W§', '562838@oyoedu.ng', '8093749055', 'ARMY CHILDREN SEC,SCHL,OYO.', 'OYO', '562838'),
(2839, '562839', 'úÏ…W§', '562839@oyoedu.ng', '8166501811', 'SHEIKH HADI COMP. COLL,OYO ', 'OYO', '562839'),
(2840, '562840', 'úÏ…W§', '562840@oyoedu.ng', '8166501811', 'SHEIKH HADI COMP.COLL,OYO', 'OYO', '562840'),
(2841, '562841', 'úÏ…W§', '562841@oyoedu.ng', '8034414663', 'SHALOM BAPT. COLL, SABO OYO. ', 'OYO', '562841'),
(2842, '562842', 'úÏ…W§', '562842@oyoedu.ng', '8165520406', 'CRYSTAL FIELD ACADEMY ,OYO', 'OYO', '562842'),
(2843, '562843', 'úÏ…W§', '562843@oyoedu.ng', '7057143071', 'SUCCESS INTER?L COLL ,OYO', 'OYO', '562843'),
(2844, '562844', 'úÏ…W§', '562844@oyoedu.ng', '8033996113', 'SUCCESS INTER?L COLL,OYO.', 'OYO', '562844'),
(2845, '562845', 'úÏ…W§', '562845@oyoedu.ng', '7060532550', 'SAF SEC, SCHL , ISEYIN ', 'OYO', '562845'),
(2846, '562846', 'úÏ…W§', '562846@oyoedu.ng', '7054880294', 'AS- SAABIQUUN COLLEGE, OYO ', 'OYO', '562846'),
(2847, '562847', 'úÏ…W§', '562847@oyoedu.ng', '9063666090', 'NEW DIMENSION COLLEGE, OYO', 'OYO', '562847'),
(2848, '562848', 'úÏ…W§', '562848@oyoedu.ng', '8035571677', 'NEW DIMENSION COLLEGE. OYO.', 'OYO', '562848'),
(2849, '562849', 'úÏ…W§', '562849@oyoedu.ng', '7059821007', 'NEW DIMENSION COLLEGE,OYO.', 'OYO', '562849'),
(2850, '562850', 'úÏ…W§', '562850@oyoedu.ng', '8142404448', 'ISALE OYO COMM.GRAM SCHL,OYO.', 'OYO', '562850'),
(2851, '562851', 'úÏ…W§', '562851@oyoedu.ng', '8149384430', 'ORANYAN GRAMMAR SCHL,OYO.', 'OYO', '562851'),
(2852, '562852', 'úÏ…W§', '562852@oyoedu.ng', '8149542088', 'SCRIPTURE UNION ACADEMY ,OYO', 'OYO', '562852'),
(2853, '562853', 'úÏ…W§', '562853@oyoedu.ng', '8155782667', 'COMM. HIGH SCHL,AWUMORO ,OYO', 'OYO', '562853'),
(2854, '562854', 'úÏ…W§', '562854@oyoedu.ng', '7063493674', 'ARMY CHILDREN SEC,SCHL OYO.', 'OYO', '562854'),
(2855, '562855', 'úÏ…W§', '562855@oyoedu.ng', '8033632885', 'KINGS DAVID?S IMMACULATE COLL, ISEYIN. ', 'OYO', '562855'),
(2856, '562856', 'úÏ…W§', '562856@oyoedu.ng', '7067194729', 'ARMY CHILDREN SEC,SCH OYO.', 'OYO', '562856'),
(2857, '562857', 'úÏ…W§', '562857@oyoedu.ng', '7025647366', 'NATURE-NUTURE COMP.COLL,OYO', 'OYO', '562857'),
(2858, '562858', 'úÏ…W§', '562858@oyoedu.ng', '8067351241', 'SPED INTERL, SEC.. SCHL OYO.', 'OYO', '562858'),
(2859, '562859', 'úÏ…W§', '562859@oyoedu.ng', '9038720466', 'WINNERS INTERL, COLL,OYO.', 'OYO', '562859'),
(2860, '562860', 'úÏ…W§', '562860@oyoedu.ng', '9038720466', 'WINNERS INTERL. COLL, OYO.', 'OYO', '562860'),
(2861, '562861', 'úÏ…W§', '562861@oyoedu.ng', '8068801013', 'OLIVET BAPT JUNIOR SCHL,OYO.', 'OYO', '562861'),
(2862, '562862', 'úÏ…W§', '562862@oyoedu.ng', '8076421599', 'ORANYAN GRAMMARS , SCHLII OYO.', 'OYO', '562862'),
(2863, '562863', 'úÏ…W§', '562863@oyoedu.ng', '8146629470', 'NISSI PROGRESSIVE GROUP OF SCHL, OYO. ', 'OYO', '562863'),
(2864, '562864', 'úÏ…W§', '562864@oyoedu.ng', '8066668263', 'AATAN COMP.COLLEGE,OYO.', 'OYO', '562864'),
(2865, '562865', 'úÏ…W§', '562865@oyoedu.ng', '7038600357', 'GOLDEN VALLEY ACADEMY,OYO.', 'OYO', '562865'),
(2866, '562866', 'úÏ…W§', '562866@oyoedu.ng', '8167345924', 'FIRST BAPTIST ACADEMY,OYO.', 'OYO', '562866'),
(2867, '562867', 'úÏ…W§', '562867@oyoedu.ng', '8163216832', 'MUSLIM COMP.COLLEGE OYO.', 'OYO', '562867'),
(2868, '562868', 'úÏ…W§', '562868@oyoedu.ng', '8038301465', 'GOLDEN VALLEY ACADEMY,OYO', 'OYO', '562868'),
(2869, '562869', 'úÏ…W§', '562869@oyoedu.ng', '7065624130', 'AANU- OLOHUNPO GODWIN COLL OYO ', 'OYO', '562869'),
(2870, '562870', 'úÏ…W§', '562870@oyoedu.ng', '7065624130', 'COMM. JUNIOR HIGH SCH OKE-OLOLA', 'OYO', '562870'),
(2871, '562871', 'úÏ…W§', '562871@oyoedu.ng', '8134553694', 'WINNERS INTERNATIONAL COLLEGE,OYO', 'OYO', '562871'),
(2872, '562872', 'úÏ…W§', '562872@oyoedu.ng', '8169777787', 'ADEJARE OLOYEDE HIGH SCH OYO', 'OYO', '562872'),
(2873, '562873', 'úÏ…W§', '562873@oyoedu.ng', '8066537379', 'PROGRESSIVE ACEDEMY,OYO', 'OYO', '562873'),
(2874, '562874', 'úÏ…W§', '562874@oyoedu.ng', '8155019451', 'BRIGTH  STAR  INTERNATIONAL  HIGH SCH OY', 'OYO', '562874'),
(2875, '562875', 'úÏ…W§', '562875@oyoedu.ng', '8060099865', 'ANGLICANL METH SEC. SCH OYO', 'OYO', '562875'),
(2876, '562876', 'úÏ…W§', '562876@oyoedu.ng', '7034499928', 'CRYSTALFIELD ACADEMY OYO', 'OYO', '562876'),
(2877, '562877', 'úÏ…W§', '562877@oyoedu.ng', '8067029378', 'LIVING STONE COLL, OYO', 'OYO', '562877'),
(2878, '562878', 'úÏ…W§', '562878@oyoedu.ng', '7025117769', 'NEW LIFE COM COLL OYO', 'OYO', '562878'),
(2879, '562879', 'úÏ…W§', '562879@oyoedu.ng', '8103527371', 'AMRY CHIDREN SECSCH OYO', 'OYO', '562879'),
(2880, '562880', 'úÏ…W§', '562880@oyoedu.ng', '8108704863', 'PLATINNUM COLL OYO', 'OYO', '562880'),
(2881, '562881', 'úÏ…W§', '562881@oyoedu.ng', '8137449252', 'GOLDEN VALLEY OYO ', 'OYO', '562881'),
(2882, '562882', 'úÏ…W§', '562882@oyoedu.ng', '8051868652', 'A.C.S.S, OYO', 'OYO', '562882'),
(2883, '562883', 'úÏ…W§', '562883@oyoedu.ng', '7067254564', 'A .C.S.S, OYO', 'OYO', '562883'),
(2884, '562884', 'úÏ…W§', '562884@oyoedu.ng', '814787676', 'VICTORY HIGH SCH OYO', 'OYO', '562884'),
(2885, '562885', 'úÏ…W§', '562885@oyoedu.ng', '9066411210', 'RADIAT LIFE COLL, OYO, ', 'OYO', '562885'),
(2886, '562886', 'úÏ…W§', '562886@oyoedu.ng', '8129350269', 'GOD?S KNOW COLLOYO', 'OYO', '562886'),
(2887, '562887', 'úÏ…W§', '562887@oyoedu.ng', '8109815762', 'SHELKH COM COLL, OYO', 'OYO', '562887'),
(2888, '562888', 'úÏ…W§', '562888@oyoedu.ng', '7042638110', 'SUPREEME  ACEDEMY  IBADAN', 'OYO', '562888'),
(2889, '562889', 'úÏ…W§', '562889@oyoedu.ng', '8034670410', 'ADELEKE MEMOYO', 'OYO', '562889'),
(2890, '562890', 'úÏ…W§', '562890@oyoedu.ng', '7031120963', 'CZION PROGRESSIVE  COLL,OYO', 'OYO', '562890'),
(2891, '562891', 'úÏ…W§', '562891@oyoedu.ng', '8057665735', 'A.C.S.S OYO', 'OYO', '562891'),
(2892, '562892', 'úÏ…W§', '562892@oyoedu.ng', '8139529658', 'ST.  BERNARDIWES GIRLGRAM SCH ', 'OYO', '562892'),
(2893, '562893', 'úÏ…W§', '562893@oyoedu.ng', '7030831741', 'ORANYAN GRAM SCH OYO', 'OYO', '562893'),
(2894, '562894', 'úÏ…W§', '562894@oyoedu.ng', '9026121949', 'COMM COMM SCH OYO  ', 'OYO', '562894'),
(2895, '562895', 'úÏ…W§', '562895@oyoedu.ng', '8137283194', 'AL-HIDAYAH COM COLL OYO', 'OYO', '562895'),
(2896, '562896', 'úÏ…W§', '562896@oyoedu.ng', '8137283194', 'AL-HIDAYAH COM COLL OYO', 'OYO', '562896'),
(2897, '562897', 'úÏ…W§', '562897@oyoedu.ng', '9034450572', 'YEMAT COLL, OYO', 'OYO', '562897'),
(2898, '562898', 'úÏ…W§', '562898@oyoedu.ng', '8035315739', 'ST. FRANCIS CATHOLIC  COLL OYO', 'OYO', '562898'),
(2899, '562899', 'úÏ…W§', '562899@oyoedu.ng', '8063188827', 'DAUSTAR COLL, OYO ', 'OYO', '562899'),
(2900, '562900', 'úÏ…W§', '562900@oyoedu.ng', '8160554647', 'SUCEESS COLL OYO', 'OYO', '562900'),
(2901, '562901', 'úÏ…W§', '562901@oyoedu.ng', '9071946413', 'CRYSTLIFIELD ACA,OYO ', 'OYO', '562901'),
(2902, '562902', 'úÏ…W§', '562902@oyoedu.ng', '9071956413', 'CRYSTLIFIELD ACA,OYO', 'OYO', '562902'),
(2903, '562903', 'úÏ…W§', '562903@oyoedu.ng', '7037977847', 'CRYSTLIFIELD ACA,OYO', 'OYO', '562903'),
(2904, '562904', 'úÏ…W§', '562904@oyoedu.ng', '8131870067', 'FAVOURS MODEL COLL SCH', 'OYO', '562904'),
(2905, '562905', 'úÏ…W§', '562905@oyoedu.ng', '8117889953', 'OLIVET BAPT OYO', 'OYO', '562905'),
(2906, '562906', 'úÏ…W§', '562906@oyoedu.ng', '070 377761590', 'ORANYANGRAMM, OYO', 'OYO', '562906'),
(2907, '562907', 'úÏ…W§', '562907@oyoedu.ng', '9056689561', 'ORANYAN GRAMM, OYO', 'OYO', '562907'),
(2908, '562908', 'úÏ…W§', '562908@oyoedu.ng', '8032452983', 'ORANYAN GRAMM , OYO', 'OYO', '562908'),
(2909, '562909', 'úÏ…W§', '562909@oyoedu.ng', '8037392569', 'SPED INTL, OYO', 'OYO', '562909'),
(2910, '562910', 'úÏ…W§', '562910@oyoedu.ng', '8076811820', 'ARISE AND SHINE ACADEMY OYO', 'OYO', '562910'),
(2911, '562911', 'úÏ…W§', '562911@oyoedu.ng', '8062316046', 'AATAN COMP.HIGH SCHL.OYO', 'OYO', '562911'),
(2912, '562912', 'úÏ…W§', '562912@oyoedu.ng', '8060294889', 'GOLDEN VALLEY COLL, OYO', 'OYO', '562912'),
(2913, '562913', 'úÏ…W§', '562913@oyoedu.ng', '8147443612', 'AKOLADE MEMORIAL COMP.COLLEGE, OYO', 'OYO', '562913'),
(2914, '562914', 'úÏ…W§', '562914@oyoedu.ng', '8063314445', 'ORANYAN GRAM.SCHL. OYO', 'OYO', '562914'),
(2915, '562915', 'úÏ…W§', '562915@oyoedu.ng', '8068236818', 'AKOLADE MEMORIAL COMP. COLLEGE, OYO', 'OYO', '562915'),
(2916, '562916', 'úÏ…W§', '562916@oyoedu.ng', '7019917821', 'COMM.JUNIOR SEC.SCHL.OKE OLOLA, OYO', 'OYO', '562916'),
(2917, '562917', 'úÏ…W§', '562917@oyoedu.ng', '8053601108', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '562917'),
(2918, '562918', 'úÏ…W§', '562918@oyoedu.ng', '9031903113', 'ORANYAN GRAM.SCHL.,OYO', 'OYO', '562918'),
(2919, '562919', 'úÏ…W§', '562919@oyoedu.ng', '8032146790', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '562919'),
(2920, '562920', 'úÏ…W§', '562920@oyoedu.ng', 'O8134135564', 'HIGHER GROUND INTERL. JUNIOR SCHL. OYO.', 'OYO', '562920'),
(2921, '562921', 'úÏ…W§', '562921@oyoedu.ng', '8068689057', 'HIGHER GROUND INTERL JUNIOR SCHL.OYO.', 'OYO', '562921'),
(2922, '562922', 'úÏ…W§', '562922@oyoedu.ng', '9068281165', 'THE ENIGMA COLLEGE, OYO.', 'OYO', '562922'),
(2923, '562923', 'úÏ…W§', '562923@oyoedu.ng', '8104106042', 'AATAN BAPT. COLLEGE, OYO', 'OYO', '562923'),
(2924, '562924', 'úÏ…W§', '562924@oyoedu.ng', '8056956459', 'SALAUDEEN COLLEGE, OYO', 'OYO', '562924'),
(2925, '562925', 'úÏ…W§', '562925@oyoedu.ng', '8067200030', 'AGBOYE COLLEGE,OYO', 'OYO', '562925'),
(2926, '562926', 'úÏ…W§', '562926@oyoedu.ng', '7032025353', 'SHALOM COLLEGE OYO', 'OYO', '562926'),
(2927, '562927', 'úÏ…W§', '562927@oyoedu.ng', '7065470289', 'LIVING STONE COLLEGE OYO', 'OYO', '562927'),
(2928, '562928', 'úÏ…W§', '562928@oyoedu.ng', '7065470289', 'LIVING STONE COLLEGE OYO', 'OYO', '562928'),
(2929, '562929', 'úÏ…W§', '562929@oyoedu.ng', '8073259085', 'MODEL COLLEGE ISEYIN', 'OYO', '562929'),
(2930, '562930', 'úÏ…W§', '562930@oyoedu.ng', '8062984492', 'K.C.G.SI ISEYIN', 'OYO', '562930'),
(2931, '562931', 'úÏ…W§', '562931@oyoedu.ng', '8039230133', 'OLIVET BAPT.JUNIOR HIGH SCHL,OYO', 'OYO', '562931'),
(2932, '562932', 'úÏ…W§', '562932@oyoedu.ng', '8165155816', 'ADS HIGH SCHL, OPAPA OYO', 'OYO', '562932'),
(2933, '562933', 'úÏ…W§', '562933@oyoedu.ng', '7051111862', 'AMBASSADOR\'S  ACADEMY OYO', 'OYO', '562933'),
(2934, '562934', 'úÏ…W§', '562934@oyoedu.ng', '9069300053', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '562934'),
(2935, '562935', 'úÏ…W§', '562935@oyoedu.ng', '8062582812', 'AATAN BAPT.COMP. HIGH SCHL, OYO', 'OYO', '562935'),
(2936, '562936', 'úÏ…W§', '562936@oyoedu.ng', '9034405377', 'ST.BERNADINE\'S GIRLS GRAM.SCHL,OYO', 'OYO', '562936'),
(2937, '562937', 'úÏ…W§', '562937@oyoedu.ng', '8132183245', 'MERIT MODEL COLLEGE OYO', 'OYO', '562937'),
(2938, '562938', 'úÏ…W§', '562938@oyoedu.ng', '8079021775', 'SOUNDMIND COMP.COLL, OYO', 'OYO', '562938'),
(2939, '562939', 'úÏ…W§', '562939@oyoedu.ng', '8166486542', 'ORANYAN GRAM. SCHOOL OYO', 'OYO', '562939'),
(2940, '562940', 'úÏ…W§', '562940@oyoedu.ng', '7089429450', 'ARMY CHILDREN SEC SCHL, OYO', 'OYO', '562940'),
(2941, '562941', 'úÏ…W§', '562941@oyoedu.ng', '8125978599', 'HAPPY CHILDREN COMP.COLLEGE OYO', 'OYO', '562941'),
(2942, '562942', 'úÏ…W§', '562942@oyoedu.ng', '8039174496', 'OLIVET BAPT.JUNIOR HIGH SCHOOL', 'OYO', '562942'),
(2943, '562943', 'úÏ…W§', '562943@oyoedu.ng', '8051543737', 'COMM.SEC SCHL OYO', 'OYO', '562943'),
(2944, '562944', 'úÏ…W§', '562944@oyoedu.ng', '8033871076', 'AYODELE MEMORIAL COLL. OYO', 'OYO', '562944'),
(2945, '562945', 'úÏ…W§', '562945@oyoedu.ng', '8052152258', 'SOUNDMIND COMP.COLL, OYO', 'OYO', '562945'),
(2946, '562946', 'úÏ…W§', '562946@oyoedu.ng', '8103462185', 'SOUNDMIND COMP.COLL, OYO', 'OYO', '562946'),
(2947, '562947', 'úÏ…W§', '562947@oyoedu.ng', '8105599920', 'ISALE OYO COM. GRAM. SCHL, OYO', 'OYO', '562947'),
(2948, '562948', 'úÏ…W§', '562948@oyoedu.ng', '8060635459', 'ZENITH COMP. COLL, OYO', 'OYO', '562948'),
(2949, '562949', 'úÏ…W§', '562949@oyoedu.ng', '8057684589', 'AJAYI CROWTHER UNIVERSITY COLL, OYO', 'OYO', '562949'),
(2950, '562950', 'úÏ…W§', '562950@oyoedu.ng', '7065741295', 'BRILLIANT COLLEGE OYO', 'OYO', '562950'),
(2951, '562951', 'úÏ…W§', '562951@oyoedu.ng', '8038538909', 'AL.AADI UNIQUE COLL, OYO', 'OSUN', '562951'),
(2952, '562952', 'úÏ…W§', '562952@oyoedu.ng', '8165037761', 'LADIGBOLU GRAM.SCHL II OYO', 'OYO', '562952'),
(2953, '562953', 'úÏ…W§', '562953@oyoedu.ng', '8119969912', 'NISSI PROGRESSIVE GROUP OF SCHL, OYO', 'OYO', '562953'),
(2954, '562954', 'úÏ…W§', '562954@oyoedu.ng', '8062550220', 'THE ENIGMA COLL, OYO', 'OYO', '562954'),
(2955, '562955', 'úÏ…W§', '562955@oyoedu.ng', '8132527631', 'ORANYAN GRAM SCHL, OYO', 'OYO', '562955'),
(2956, '562956', 'úÏ…W§', '562956@oyoedu.ng', '8062766230', 'THE ENIGMA COLL, OYO', 'OYO', '562956'),
(2957, '562957', 'úÏ…W§', '562957@oyoedu.ng', '8036984051', 'THE ENIGMA COLL, OYO', 'OYO', '562957'),
(2958, '562958', 'úÏ…W§', '562958@oyoedu.ng', '8065702890', 'AATAN BAPT. COMP.HIGH SCHL OYO', 'OYO', '562958'),
(2959, '562959', 'úÏ…W§', '562959@oyoedu.ng', '9069905619', 'ORANYAN GRAM. SCHL II OYO', 'OYO', '562959'),
(2960, '562960', 'úÏ…W§', '562960@oyoedu.ng', '9060685827', 'TA\'AWUNU JUNIOR SEC, SCHL,OYO', 'OYO', '562960'),
(2961, '562961', 'úÏ…W§', '562961@oyoedu.ng', '9037143727', 'TA\'AWUNU JUNIOR SEC. SCHL, OYO', 'OYO', '562961'),
(2962, '562962', 'úÏ…W§', '562962@oyoedu.ng', '9038451791', 'TA\'AWUNU JUNIOR SEC.SCHL, OYO', 'OYO', '562962'),
(2963, '562963', 'úÏ…W§', '562963@oyoedu.ng', '7037841434', 'CRYSTALFIELD ACADEMY OYO', 'OYO', '562963'),
(2964, '562964', 'úÏ…W§', '562964@oyoedu.ng', '7060527574', 'AJAYI CROWTHER UNIVERSITY COLL, OYOY', 'OYO', '562964'),
(2965, '562965', 'úÏ…W§', '562965@oyoedu.ng', '8066640995', 'COMM.GRAM. SCHL, OOLO', 'OYO', '562965'),
(2966, '562966', 'úÏ…W§', '562966@oyoedu.ng', '8034205685', 'OLIVET BAPT. JUNIOR HIGH SCHL, OYO', 'OYO', '562966'),
(2967, '562967', 'úÏ…W§', '562967@oyoedu.ng', '8168456627', 'A.C.S.S', 'OYO', '562967'),
(2968, '562968', 'úÏ…W§', '562968@oyoedu.ng', '8168456627', 'A.C.S.S', 'OYO', '562968'),
(2969, '562969', 'úÏ…W§', '562969@oyoedu.ng', '8060012154', 'AJAYI CROWTHER UNIVERSITY COLL, OYO', 'OYO', '562969'),
(2970, '562970', 'úÏ…W§', '562970@oyoedu.ng', '', 'MUSLIM COM. COLL,OYO', 'OYO', '562970'),
(2971, '562971', 'úÏ…W§', '562971@oyoedu.ng', '8138705126', 'ALAAFIN HIGH SCHL, OYO', 'OYO', '562971'),
(2972, '562972', 'úÏ…W§', '562972@oyoedu.ng', '8134342203', 'ISALE OYO COMM. GRAM. SCHL, OYO', 'OYO', '562972'),
(2973, '562973', 'úÏ…W§', '562973@oyoedu.ng', '9071393808', 'JIRAYO VOCATIONAL HIGH SCHL, OYO', 'OYO', '562973'),
(2974, '562974', 'úÏ…W§', '562974@oyoedu.ng', '', 'JIRAYO VOCATIONAL HIGH SCHL, OYO', 'OYO', '562974'),
(2975, '562975', 'úÏ…W§', '562975@oyoedu.ng', '8149243487', 'JIRAYO VOCATIONAL HIGH SCHL, OYO', 'OYO', '562975'),
(2976, '562976', 'úÏ…W§', '562976@oyoedu.ng', '8149243487', 'JIRAYO VOCATIONAL HIGH SCHL, OYO', 'OYO', '562976'),
(2977, '562977', 'úÏ…W§', '562977@oyoedu.ng', '7059477817', 'HAPPY CHILDREN COMP. COLL, OYO', 'OYO', '562977'),
(2978, '562978', 'úÏ…W§', '562978@oyoedu.ng', '8060083572', 'CRESCENT HEIGHT SCHOOL OYO', 'OYO', '562978'),
(2979, '562979', 'úÏ…W§', '562979@oyoedu.ng', '8164751265', 'THE ENIGMA COLL, OYO', 'OYO', '562979'),
(2980, '562980', 'úÏ…W§', '562980@oyoedu.ng', '9064186231', 'BREAKTHROUGH COLL, OYO', 'OYO', '562980'),
(2981, '562981', 'úÏ…W§', '562981@oyoedu.ng', '8101671731', 'COMM.HIGH OKEOLOLA OYO', 'OYO', '562981'),
(2982, '562982', 'úÏ…W§', '562982@oyoedu.ng', '8076094879', 'GOLDEN VALLEY OYO', 'OYO', '562982'),
(2983, '562983', 'úÏ…W§', '562983@oyoedu.ng', '8068776910', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '562983'),
(2984, '562984', 'úÏ…W§', '562984@oyoedu.ng', '8148843468', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '562984'),
(2985, '562985', 'úÏ…W§', '562985@oyoedu.ng', '8032953236', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '562985'),
(2986, '562986', 'úÏ…W§', '562986@oyoedu.ng', '8034649506', 'SPED, OYO', 'OYO', '562986'),
(2987, '562987', 'úÏ…W§', '562987@oyoedu.ng', '8060350273', 'AL-AMEEN COLL, OYO', 'OYO', '562987'),
(2988, '562988', 'úÏ…W§', '562988@oyoedu.ng', '8032450532', 'MORADEYO COLL, OYO', 'OYO', '562988'),
(2989, '562989', 'úÏ…W§', '562989@oyoedu.ng', '9055014102', 'ARISE&SHINE COLL, OYO', 'OYO', '562989'),
(2990, '562990', 'úÏ…W§', '562990@oyoedu.ng', '8158364824', 'DYNAMIC OYO', 'OYO', '562990'),
(2991, '562991', 'úÏ…W§', '562991@oyoedu.ng', '8158364824', 'DYNAMIC OYO', 'OYO', '562991'),
(2992, '562992', 'úÏ…W§', '562992@oyoedu.ng', '8135693201', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '562992'),
(2993, '562993', 'úÏ…W§', '562993@oyoedu.ng', '8036356046', 'A.C.S.S', 'OYO', '562993'),
(2994, '562994', 'úÏ…W§', '562994@oyoedu.ng', '8035571677', 'NEW DIMENSION OYO', 'OYO', '562994'),
(2995, '562995', 'úÏ…W§', '562995@oyoedu.ng', '8078029847', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '562995'),
(2996, '562996', 'úÏ…W§', '562996@oyoedu.ng', '8137970473', 'COMM.HIGH OKEOLOLA, OYO', 'OYO', '562996'),
(2997, '562997', 'úÏ…W§', '562997@oyoedu.ng', '8057712136', 'NEW LIFE COLL, OYO', 'OYO', '562997'),
(2998, '562998', 'úÏ…W§', '562998@oyoedu.ng', '7057728797', 'ROYAL GOLD MODEL COLL, OYO', 'OYO', '562998'),
(2999, '562999', 'úÏ…W§', '562999@oyoedu.ng', '8146428280', 'SOUNDMIND COLL, OYO', 'OYO', '562999'),
(3000, '563000', 'úÏ…W§', '563000@oyoedu.ng', '8062322615', 'ROYAL GOLD MODEL COLL, OYO', 'OYO', '563000'),
(3001, '563001', 'úÏ…W§', '563001@oyoedu.ng', '7055697529', 'ANG/METH JNR AJAGBA OYO', 'OYO', '563001'),
(3002, '563002', 'úÏ…W§', '563002@oyoedu.ng', '8051342269', 'IMMANUEL HIGH SCHL, OYO', 'OYO', '563002'),
(3003, '563003', 'úÏ…W§', '563003@oyoedu.ng', '8059890151', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563003'),
(3004, '563004', 'úÏ…W§', '563004@oyoedu.ng', '703881213', 'AL-AMEEN COMP. COLL,OYO', 'OYO', '563004'),
(3005, '563005', 'úÏ…W§', '563005@oyoedu.ng', '7068528218', 'GOLDEN FOUNDATION INTTER. COLL, OYO', 'OYO', '563005'),
(3006, '563006', 'úÏ…W§', '563006@oyoedu.ng', '8072440448', 'AATAN BAPT. COMP. HIGH SCHL, OYO', 'OYO', '563006'),
(3007, '563007', 'úÏ…W§', '563007@oyoedu.ng', '8100454385', 'AATAN BAPT.COMP. HIGH SCHL, OYO', 'OYO', '563007'),
(3008, '563008', 'úÏ…W§', '563008@oyoedu.ng', '8108825918', 'SUPREME COLL, OYO', 'OYO', '563008'),
(3009, '563009', 'úÏ…W§', '563009@oyoedu.ng', '7039063499', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563009'),
(3010, '563010', 'úÏ…W§', '563010@oyoedu.ng', '7039063499', 'ORANYAN GRAMM.SCHL OYO', 'OYO', '563010'),
(3011, '563011', 'úÏ…W§', '563011@oyoedu.ng', '8166354976', 'OLIVET BAPT.SCHOL OYO', 'OYO', '563011'),
(3012, '563012', 'úÏ…W§', '563012@oyoedu.ng', '9034651569', 'FAVOUR COLL, OYO', 'OYO', '563012'),
(3013, '563013', 'úÏ…W§', '563013@oyoedu.ng', '8140970969', 'PROGRESSIVE ACADEMY OYO', 'OYO', '563013'),
(3014, '563014', 'úÏ…W§', '563014@oyoedu.ng', '8034917362', 'AS-SAABIQUUN COLL, OYO', 'OYO', '563014');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(3015, '563015', 'úÏ…W§', '563015@oyoedu.ng', '8142482607', 'ORANYAN GRAMM SCH OYO', 'OYO', '563015'),
(3016, '563016', 'úÏ…W§', '563016@oyoedu.ng', '8079228336', 'AL-IMAN GROUP OF SCH OYO', 'OYO', '563016'),
(3017, '563017', 'úÏ…W§', '563017@oyoedu.ng', '9034940499', 'GOD\'S LIGHT COLL OYO', 'OYO', '563017'),
(3018, '563018', 'úÏ…W§', '563018@oyoedu.ng', '9034940499', 'GOD\'S LIGHT COLL OYO', 'OYO', '563018'),
(3019, '563019', 'úÏ…W§', '563019@oyoedu.ng', '8072380494', 'OLA-OLU BASIC SCHL OYO', 'OYO', '563019'),
(3020, '563020', 'úÏ…W§', '563020@oyoedu.ng', '7057230089', 'OLA-OLU BASIC SCHL OYO', 'OYO', '563020'),
(3021, '563021', 'úÏ…W§', '563021@oyoedu.ng', '8038565511', 'EMIRATE PRIVATE SCH OYO', 'OYO', '563021'),
(3022, '563022', 'úÏ…W§', '563022@oyoedu.ng', '8167748606', 'ORANYAN GRAM SCHL, OYO', 'OYO', '563022'),
(3023, '563023', 'úÏ…W§', '563023@oyoedu.ng', '8034648715', 'ANWR-UL ISLAM COLL OYO', 'OYO', '563023'),
(3024, '563024', 'úÏ…W§', '563024@oyoedu.ng', '8163939116', 'ORANYAN GRAM SCHL OYO', 'OYO', '563024'),
(3025, '563025', 'úÏ…W§', '563025@oyoedu.ng', '8165519712', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '563025'),
(3026, '563026', 'úÏ…W§', '563026@oyoedu.ng', '9077525782', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '563026'),
(3027, '563027', 'úÏ…W§', '563027@oyoedu.ng', '8127445647', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '563027'),
(3028, '563028', 'úÏ…W§', '563028@oyoedu.ng', '7037976945', 'ORANYAN GRAM.SCHL, OYO', 'OYO', '563028'),
(3029, '563029', 'úÏ…W§', '563029@oyoedu.ng', '8105916761', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563029'),
(3030, '563030', 'úÏ…W§', '563030@oyoedu.ng', '7033394095', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563030'),
(3031, '563031', 'úÏ…W§', '563031@oyoedu.ng', '8148803468', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563031'),
(3032, '563032', 'úÏ…W§', '563032@oyoedu.ng', '8136948959', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563032'),
(3033, '563033', 'úÏ…W§', '563033@oyoedu.ng', '9054820505', 'NEW ERA COLL, OYO', 'OYO', '563033'),
(3034, '563034', 'úÏ…W§', '563034@oyoedu.ng', '9054820505', 'NEW ERA COLL, OYO', 'OYO', '563034'),
(3035, '563035', 'úÏ…W§', '563035@oyoedu.ng', '', 'ADELEKE MEMORIAL ACADEMY OYO', 'OYO', '563035'),
(3036, '563036', 'úÏ…W§', '563036@oyoedu.ng', '8138551210', 'COMM.JNR.HIGH SCHL, OKEOLOLA OYO', 'OYO', '563036'),
(3037, '563037', 'úÏ…W§', '563037@oyoedu.ng', '8076914041', 'ARMY CHILD. SEC. SCHL, OYO', 'OYO', '563037'),
(3038, '563038', 'úÏ…W§', '563038@oyoedu.ng', '8069152089', 'DYNAMIC MODEL COLL, OYO', 'OYO', '563038'),
(3039, '563039', 'úÏ…W§', '563039@oyoedu.ng', '8065411911', 'SOUND MIND COLL, OYO', 'OGUN', '563039'),
(3040, '563040', 'úÏ…W§', '563040@oyoedu.ng', '8134552395', 'AL-WAQTU GROUP OF SCHL, OYO', 'OYO', '563040'),
(3041, '563041', 'úÏ…W§', '563041@oyoedu.ng', '8164630202', 'AL-WAQTU GROUP OF SCHL, OYO', 'OYO', '563041'),
(3042, '563042', 'úÏ…W§', '563042@oyoedu.ng', '8164690113', 'DYNAMIC MODEL COLL, OYO', 'OYO', '563042'),
(3043, '563043', 'úÏ…W§', '563043@oyoedu.ng', '9063781394', 'DYNAMIC MODEL COLL,OYO', 'OYO', '563043'),
(3044, '563044', 'úÏ…W§', '563044@oyoedu.ng', '9164882922', 'THE BEEL COLL, ISEYIN', 'OYO', '563044'),
(3045, '563045', 'úÏ…W§', '563045@oyoedu.ng', '9164882922', 'THE BEEL COLL, ISEYIN', 'OYO', '563045'),
(3046, '563046', 'úÏ…W§', '563046@oyoedu.ng', '8136054474', 'MARVELOUS COLL, OYO', 'OYO', '563046'),
(3047, '563047', 'úÏ…W§', '563047@oyoedu.ng', '8165604248', 'MARVELOUS COLL, OYO', 'OYO', '563047'),
(3048, '563048', 'úÏ…W§', '563048@oyoedu.ng', '8105141704', 'AL-IMAN COLL, OYO', 'OYO', '563048'),
(3049, '563049', 'úÏ…W§', '563049@oyoedu.ng', '8105141704', 'AL-IMAN COLL, OYO', 'OYO', '563049'),
(3050, '563050', 'úÏ…W§', '563050@oyoedu.ng', '7054234671', 'BEST KIDD. COLL, OYO', 'OYO', '563050'),
(3051, '563051', 'úÏ…W§', '563051@oyoedu.ng', '7137973031', 'GOLDEN VALLEY COLL, OYO', 'OYO', '563051'),
(3052, '563052', 'úÏ…W§', '563052@oyoedu.ng', '8137973031', 'GOLDEN VALLEY COLL, OYO', 'OYO', '563052'),
(3053, '563053', 'úÏ…W§', '563053@oyoedu.ng', '8030707477', 'ARMY CHILDREN SCHL, OYO', 'OYO', '563053'),
(3054, '563054', 'úÏ…W§', '563054@oyoedu.ng', '8053741980', 'COMM.SEC. SCHL, OKEOLOLA OYO', 'OYO', '563054'),
(3055, '563055', 'úÏ…W§', '563055@oyoedu.ng', '8057648431', 'OLIVET BAPT. JNR.HIGH SCHL, OYO', 'OYO', '563055'),
(3056, '563056', 'úÏ…W§', '563056@oyoedu.ng', '8109986094', 'GOLDEN VALLEY COLL, OYO', 'OYO', '563056'),
(3057, '563057', 'úÏ…W§', '563057@oyoedu.ng', '8033626309', 'AS-SAABIQUNN COLL, OYO', 'OYO', '563057'),
(3058, '563058', 'úÏ…W§', '563058@oyoedu.ng', '8109986094', 'OLIVET BAPT.JNR. HIGH SCHL, OYO', 'OYO', '563058'),
(3059, '563059', 'úÏ…W§', '563059@oyoedu.ng', '9034571021', 'DYNAMIC MODEL COLL, OYO', 'OYO', '563059'),
(3060, '563060', 'úÏ…W§', '563060@oyoedu.ng', '8077979860', 'DYNAMIC MODEL COLL, OYO', 'OYO', '563060'),
(3061, '563061', 'úÏ…W§', '563061@oyoedu.ng', '7010355500', 'DYNAMIC MODEL COLL, OYO', 'OYO', '563061'),
(3062, '563062', 'úÏ…W§', '563062@oyoedu.ng', '8032306740', 'BEST LEGACY SCH, OYO', 'OYO', '563062'),
(3063, '563063', 'úÏ…W§', '563063@oyoedu.ng', '7062613435', 'IMIS-OLUWA SCH, OYO', 'OYO', '563063'),
(3064, '563064', 'úÏ…W§', '563064@oyoedu.ng', '8135423102', 'IMIS-OLUWA SCH, OYO', 'OYO', '563064'),
(3065, '563065', 'úÏ…W§', '563065@oyoedu.ng', '8036231508', 'IMIS-OLUWA SCH,OYO', 'OYO', '563065'),
(3066, '563066', 'úÏ…W§', '563066@oyoedu.ng', '8155346264', 'IMIS-OLUWA SCHL OYO,', 'OYO', '563066'),
(3067, '563067', 'úÏ…W§', '563067@oyoedu.ng', '8087787132', 'IMIS-OLUWA SCHL, OYO', 'OYO', '563067'),
(3068, '563068', 'úÏ…W§', '563068@oyoedu.ng', '7037424792', 'IMIS-OLUWA SCHL, OYO', 'OYO', '563068'),
(3069, '563069', 'úÏ…W§', '563069@oyoedu.ng', '8112255126', 'IMIS-OLUWA SCHL, OYO', 'OYO', '563069'),
(3070, '563070', 'úÏ…W§', '563070@oyoedu.ng', '8091733291', 'IMIS-OLUWA SCHL,OYO', 'OYO', '563070'),
(3071, '563071', 'úÏ…W§', '563071@oyoedu.ng', '8034988099', 'OVERCOMERS COLL OYO', 'OYO', '563071'),
(3072, '563072', 'úÏ…W§', '563072@oyoedu.ng', '7039316186', 'ORANYAN GRAMM SCH ,OYO', 'OYO', '563072'),
(3073, '563073', 'úÏ…W§', '563073@oyoedu.ng', '8062699111', 'ALAFIN HIGH SCHL I OYO', 'OYO', '563073'),
(3074, '563074', 'úÏ…W§', '563074@oyoedu.ng', '8058180284', 'ORANYAN GRAMM SCHL OYO', 'OYO', '563074'),
(3075, '563075', 'úÏ…W§', '563075@oyoedu.ng', '7074077891', 'ORANYAN GRAM SCHL OYO', 'OYO', '563075'),
(3076, '563076', 'úÏ…W§', '563076@oyoedu.ng', '8071028411', 'MARVELLOUS COLL OYO', 'OYO', '563076'),
(3077, '563077', 'úÏ…W§', '563077@oyoedu.ng', '7052445079', 'MARVELLOUS COLL OYO', 'OYO', '563077'),
(3078, '563078', 'úÏ…W§', '563078@oyoedu.ng', 'O7O52445079', 'MARVELLOUS COLL OYO', 'OYO', '563078'),
(3079, '563079', 'úÏ…W§', '563079@oyoedu.ng', '81026692255', 'AANU-OLORUNPO GODWIN COLL OYO', 'OYO', '563079'),
(3080, '563080', 'úÏ…W§', '563080@oyoedu.ng', '8162308189', 'C ZION PROGRESSIVE COLL, OYO', 'OYO', '563080'),
(3081, '563081', 'úÏ…W§', '563081@oyoedu.ng', '8106805196', 'ROYAL GOLD MODEL COLL, OYO', 'OYO', '563081'),
(3082, '563082', 'úÏ…W§', '563082@oyoedu.ng', '8032468562', 'ORANYAN GRAM. SCH OYO', 'OYO', '563082'),
(3083, '563083', 'úÏ…W§', '563083@oyoedu.ng', '8032468562', 'ORANYAN  GRAM. SCHL, OYO', 'OYO', '563083'),
(3084, '563084', 'úÏ…W§', '563084@oyoedu.ng', '9017953061', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563084'),
(3085, '563085', 'úÏ…W§', '563085@oyoedu.ng', '', 'ADO COMM. HIGH SCH, ADOEKITI', 'OYO', '563085'),
(3086, '563086', 'úÏ…W§', '563086@oyoedu.ng', '8126490760', 'ISALE OYO COMMERCIAL SEC. SCHL, OYO', 'OYO', '563086'),
(3087, '563087', 'úÏ…W§', '563087@oyoedu.ng', '8037185919', 'ORANYAN GRAM. SCH, OYO', 'OYO', '563087'),
(3088, '563088', 'úÏ…W§', '563088@oyoedu.ng', '8037185919', 'ORANYAN GRAM. SCH, OYO', 'OYO', '563088'),
(3089, '563089', 'úÏ…W§', '563089@oyoedu.ng', '7063708802', 'FAITH INTER SCHL, OYO', 'OYO', '563089'),
(3090, '563090', 'úÏ…W§', '563090@oyoedu.ng', '9047033289', 'SHALOM BAP .COLL,  OYO', 'OYO', '563090'),
(3091, '563091', 'úÏ…W§', '563091@oyoedu.ng', '9017354763', 'PROGRESS HIGH SCH OYO', 'OYO', '563091'),
(3092, '563092', 'úÏ…W§', '563092@oyoedu.ng', '8039173402', 'ABDUL SALAM COM JNR SEC SCH OYO', 'OYO', '563092'),
(3093, '563093', 'úÏ…W§', '563093@oyoedu.ng', '8068348702', 'OLIVET BAPT. JNR. HIGH SCHL OYO', 'OYO', '563093'),
(3094, '563094', 'úÏ…W§', '563094@oyoedu.ng', '8068348702', 'ISALE OYO COMM. GRAM. SCHL, OYO', 'OYO', '563094'),
(3095, '563095', 'úÏ…W§', '563095@oyoedu.ng', '8068348702', 'ANG. METH. SEC. SCHL, OYO', 'OYO', '563095'),
(3096, '563096', 'úÏ…W§', '563096@oyoedu.ng', '8068348702', 'ROYAL GOLD MODEL COLLGE OYO', 'OYO', '563096'),
(3097, '563097', 'úÏ…W§', '563097@oyoedu.ng', '7030826614', 'AS-SAABUQUUN COLL OYO', 'OYO', '563097'),
(3098, '563098', 'úÏ…W§', '563098@oyoedu.ng', '8121483161', 'AR- AMAN D\'GREAT WAY INTERL. COLL, OYO', 'OYO', '563098'),
(3099, '563099', 'úÏ…W§', '563099@oyoedu.ng', '8050813374', 'PROGRESSIVE ACEDEMY OYO', 'OYO A', '563099'),
(3100, '563100', 'úÏ…W§', '563100@oyoedu.ng', '80623226675', 'GOD BLESSING INTER COLL, OYO', 'OYO', '563100'),
(3101, '563101', 'úÏ…W§', '563101@oyoedu.ng', '8144246318', 'GOD\'S BEHIND ME INTER COLL, OYO', 'OYO', '563101'),
(3102, '563102', 'úÏ…W§', '563102@oyoedu.ng', '', 'GOD\'S BLESSING INTER COLL, OYO', 'OYO', '563102'),
(3103, '563103', 'úÏ…W§', '563103@oyoedu.ng', '8163106429', 'AS-SAABUIQUNN COLL, OYO', 'OYO', '563103'),
(3104, '563104', 'úÏ…W§', '563104@oyoedu.ng', '8073130870', 'OLUYOLE GRAM. IBADAN', 'OYO', '563104'),
(3105, '563105', 'úÏ…W§', '563105@oyoedu.ng', '8073130870', 'OLUYOLE GRAM. IBADAN', 'oyo', '563105'),
(3106, '563106', 'úÏ…W§', '563106@oyoedu.ng', '8034773746', 'BRIGHT STAR COLL, OYO', 'OYO', '563106'),
(3107, '563107', 'úÏ…W§', '563107@oyoedu.ng', '8037525435', 'ANGILICAN SEC. SCHL, OYO', 'OYO', '563107'),
(3108, '563108', 'úÏ…W§', '563108@oyoedu.ng', '8059131191', 'COMM. HIGH SCHL, OKEOLOLA, OYO', 'OYO', '563108'),
(3109, '563109', 'úÏ…W§', '563109@oyoedu.ng', '9031138883', 'MARVELLOUS COLL, OYO', 'OYO', '563109'),
(3110, '563110', 'úÏ…W§', '563110@oyoedu.ng', '8106310433', 'AATAN BAPT. COMP. HIGH SCHL, OYO', 'OYO', '563110'),
(3111, '563111', 'úÏ…W§', '563111@oyoedu.ng', '8055920783', 'AATAN BAPT. COMP. HIGH SCHL, OYO', 'OYO', '563111'),
(3112, '563112', 'úÏ…W§', '563112@oyoedu.ng', '9033735548', 'WINNERS INTERL. COLL, OYO', 'OYO', '563112'),
(3113, '563113', 'úÏ…W§', '563113@oyoedu.ng', '8167166178', 'THE ENIGMA COLL, OYO', 'OYO', '563113'),
(3114, '563114', 'úÏ…W§', '563114@oyoedu.ng', '8072765618', 'DYNAMIC COLL, OYO', 'OYO', '563114'),
(3115, '563115', 'úÏ…W§', '563115@oyoedu.ng', '8083522504', 'DYNAMIC COLL, OYO', 'OYO', '563115'),
(3116, '563116', 'úÏ…W§', '563116@oyoedu.ng', '8037809770', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563116'),
(3117, '563117', 'úÏ…W§', '563117@oyoedu.ng', '8034802977', 'GOODNESS COLL, OYO', 'OYO', '563117'),
(3118, '563118', 'úÏ…W§', '563118@oyoedu.ng', '8066573584', 'ALAAFIN HIGH SCHL, OYO', 'OYO', '563118'),
(3119, '563119', 'úÏ…W§', '563119@oyoedu.ng', '8034019787', 'KELANI COLL, ISEYIN', 'OYO', '563119'),
(3120, '563120', 'úÏ…W§', '563120@oyoedu.ng', '8064386196', 'NEW ERA COLL, OYO', 'OYO', '563120'),
(3121, '563121', 'úÏ…W§', '563121@oyoedu.ng', '8120911857', 'ISALE OYO COMM. GRAM. SCHL, OYO', 'OYO', '563121'),
(3122, '563122', 'úÏ…W§', '563122@oyoedu.ng', '8101257398', 'ISALE OYO COMM. GRAM. SCHL, OYO', 'OYO', '563122'),
(3123, '563123', 'úÏ…W§', '563123@oyoedu.ng', '8165574074', 'ISALE OYO COMM. GRAM. SCHL, OYO', 'OYO', '563123'),
(3124, '563124', 'úÏ…W§', '563124@oyoedu.ng', '7055356733', 'SHALOM BAPT. COLL, OYO', 'OYO', '563124'),
(3125, '563125', 'úÏ…W§', '563125@oyoedu.ng', '7070578929', 'OLIVET BAPT. JNR. HIGH SCHL, OYO', 'OYO', '563125'),
(3126, '563126', 'úÏ…W§', '563126@oyoedu.ng', '8053741980', 'COMM.JNR. HIGH SCHL, OKEOLOLA', 'OYO', '563126'),
(3127, '563127', 'úÏ…W§', '563127@oyoedu.ng', '7032313702', 'COMM. SEC. SCHL, IDIOPE, OYO', 'OYO', '563127'),
(3128, '563128', 'úÏ…W§', '563128@oyoedu.ng', '8167600757', 'PRIME COLL, IBADAN', 'OYO', '563128'),
(3129, '563129', 'úÏ…W§', '563129@oyoedu.ng', '8078029847', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563129'),
(3130, '563130', 'úÏ…W§', '563130@oyoedu.ng', '7033304874', 'NOBLE ACADEMY GROUP OF SCHL, OYO', 'OYO', '563130'),
(3131, '563131', 'úÏ…W§', '563131@oyoedu.ng', '8060430350', 'ALAAFIN HIGH SCHL, OYO', 'OYO', '563131'),
(3132, '563132', 'úÏ…W§', '563132@oyoedu.ng', '8034648715', 'GOD\'S MERCY COMP.COLL, OYO', 'OYO', '563132'),
(3133, '563133', 'úÏ…W§', '563133@oyoedu.ng', '8069635854', 'GOD\'S MERCY COMP. COLL, OYO', 'OYO', '563133'),
(3134, '563134', 'úÏ…W§', '563134@oyoedu.ng', '8064598821', 'ARMY CHILDREN SEC, SCHL, OYO', 'OYO', '563134'),
(3135, '563135', 'úÏ…W§', '563135@oyoedu.ng', '8032318627', 'THE ENIGMA COLLEGE OYO', 'OYO', '563135'),
(3136, '563136', 'úÏ…W§', '563136@oyoedu.ng', '8166878140', 'ISALE OYO COMM. GRAM. SCHL, OYO', 'OYO', '563136'),
(3137, '563137', 'úÏ…W§', '563137@oyoedu.ng', '8134433565', 'AR-RAHMAN COLLEGE OYO', 'OYO', '563137'),
(3138, '563138', 'úÏ…W§', '563138@oyoedu.ng', '8134281447', 'GOD\'S MERCY COMP. SCHL, OYO', 'OYO', '563138'),
(3139, '563139', 'úÏ…W§', '563139@oyoedu.ng', '7037917847', 'CRYSTAL FIELD ACADEMY', 'OYO', '563139'),
(3140, '563140', 'úÏ…W§', '563140@oyoedu.ng', '9131963852', 'AANU OLORUNPO GODWIN COLL, OYO', 'OYO', '563140'),
(3141, '563141', 'úÏ…W§', '563141@oyoedu.ng', '8033704464', 'CROWN THE LIGHT IBADAN', 'ONDO', '563141'),
(3142, '563142', 'úÏ…W§', '563142@oyoedu.ng', '7062034652', 'ADEJARE OLOYEDE MEMORIAL COLL, OYO', 'OYO', '563142'),
(3143, '563143', 'úÏ…W§', '563143@oyoedu.ng', '9050618610', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563143'),
(3144, '563144', 'úÏ…W§', '563144@oyoedu.ng', '7064357601', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563144'),
(3145, '563145', 'úÏ…W§', '563145@oyoedu.ng', '8051321537', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563145'),
(3146, '563146', 'úÏ…W§', '563146@oyoedu.ng', '7032506229', 'COM. JNR.SEC SCHL, OYO', 'OYO', '563146'),
(3147, '563147', 'úÏ…W§', '563147@oyoedu.ng', '8126676588', 'ORANYAN GRAM.  SCHL,II, OYO', 'OYO', '563147'),
(3148, '563148', 'úÏ…W§', '563148@oyoedu.ng', '8060939827', 'ORANYAN GRAM. SCHL, II,OYO', 'OYO', '563148'),
(3149, '563149', 'úÏ…W§', '563149@oyoedu.ng', '8132440092', 'ARMY CHILDREN SEC, SCHL, OYO', 'OYO', '563149'),
(3150, '563150', 'úÏ…W§', '563150@oyoedu.ng', '8034483532', 'ORANYAN GRAM. SCHL, II OYO', 'OYO', '563150'),
(3151, '563151', 'úÏ…W§', '563151@oyoedu.ng', '8156697995', 'ORANYAN GRAM. SCHL I, OYO', 'OYO', '563151'),
(3152, '563152', 'úÏ…W§', '563152@oyoedu.ng', '8097257506', 'AL-KHALO GROUP OF SCHOOL OYO', 'OYO', '563152'),
(3153, '563153', 'úÏ…W§', '563153@oyoedu.ng', '8035923663', 'PLATINUM MODEL SCHL, OYO', 'OYO', '563153'),
(3154, '563154', 'úÏ…W§', '563154@oyoedu.ng', '8033772401', 'OVERCOMERS COLL, OYO', 'OYO', '563154'),
(3155, '563155', 'úÏ…W§', '563155@oyoedu.ng', '9036758287', 'GREAT ACHIEVER\'S GROUP OF SCHL, OYO', 'OYO', '563155'),
(3156, '563156', 'úÏ…W§', '563156@oyoedu.ng', '8032052297', 'ANWARUL ISLAM COLL, OYO', 'OYO', '563156'),
(3157, '563157', 'úÏ…W§', '563157@oyoedu.ng', '9051615992', 'COM.JNR SEC SCHL, OKEOLOLA, OYO', 'OYO', '563157'),
(3158, '563158', 'úÏ…W§', '563158@oyoedu.ng', '8035540285', 'GOD\'S MERCY COMP.COLL, OYO', 'OYO', '563158'),
(3159, '563159', 'úÏ…W§', '563159@oyoedu.ng', '8035540285', 'GOD\'S MERCY COMP. COLL, OYO', 'OYO', '563159'),
(3160, '563160', 'úÏ…W§', '563160@oyoedu.ng', '8035680940', 'AS SAABIQUUN COLL, OYO', 'OYO', '563160'),
(3161, '563161', 'úÏ…W§', '563161@oyoedu.ng', '8067712697', 'AR-RAHMAN D\' GATEWAY INTERL, SCHL, OYO', 'OYO', '563161'),
(3162, '563162', 'úÏ…W§', '563162@oyoedu.ng', '8149012425', 'COMM.JNR SEC. SCHL, OKEOLOLA OYO', 'OYO', '563162'),
(3163, '563163', 'úÏ…W§', '563163@oyoedu.ng', '8060802939', 'GOLDEN VALLEY COLLEGE , OYO', 'OYO', '563163'),
(3164, '563164', 'úÏ…W§', '563164@oyoedu.ng', '8079001499', 'BLESSING OF THE LORD COLLEGE OYO', 'OYO', '563164'),
(3165, '563165', 'úÏ…W§', '563165@oyoedu.ng', '8075569076', 'AS-SHAAFI COLL, OYO', 'OYO', '563165'),
(3166, '563166', 'úÏ…W§', '563166@oyoedu.ng', '8137739928', 'AS- SALAM COLL, OYO', 'OYO', '563166'),
(3167, '563167', 'úÏ…W§', '563167@oyoedu.ng', '8033890708', 'AGUNLOYE COLL, OYO', 'OYO', '563167'),
(3168, '563168', 'úÏ…W§', '563168@oyoedu.ng', '8033890708', 'AGUNLOYE COLL, OYO', 'OYO', '563168'),
(3169, '563169', 'úÏ…W§', '563169@oyoedu.ng', '8034765789', 'ILADO COMM. SCHL, ISEYIN', 'OYO', '563169'),
(3170, '563170', 'úÏ…W§', '563170@oyoedu.ng', '8136015710', 'LIBERTY OYO', 'OYO', '563170'),
(3171, '563171', 'úÏ…W§', '563171@oyoedu.ng', '8062292068', 'ROYAL GOLD MODEL COLLEGE, OYO', 'OYO', '563171'),
(3172, '563172', 'úÏ…W§', '563172@oyoedu.ng', '8073298639', 'AKOLADE MEMORIAL COMP.COLLEGE, OYO', 'OYO', '563172'),
(3173, '563173', 'úÏ…W§', '563173@oyoedu.ng', '', 'SOUND MIND COLL, OYO', 'OYO', '563173'),
(3174, '563174', 'úÏ…W§', '563174@oyoedu.ng', '8130265981', 'OLIVET JNR.HIGH SCHL, OYO', 'OYO', '563174'),
(3175, '563175', 'úÏ…W§', '563175@oyoedu.ng', '8066418581', 'NESTO COLLEGE OYO', 'OYO', '563175'),
(3176, '563176', 'úÏ…W§', '563176@oyoedu.ng', '7034234676', 'COMM. JNR.HIGH SCHL, OYO', 'OYO', '563176'),
(3177, '563177', 'úÏ…W§', '563177@oyoedu.ng', '8166413532', 'AGUGU GRAM.SCHL, IBADAN', 'OYO', '563177'),
(3178, '563178', 'úÏ…W§', '563178@oyoedu.ng', '8034294759', 'ANWAR-UL ISLAM COLL, OYO', 'OYO', '563178'),
(3179, '563179', 'úÏ…W§', '563179@oyoedu.ng', '8134294796', 'ARMY CHILDREN SEC. SCHL, OYO', 'OYO', '563179'),
(3180, '563180', 'úÏ…W§', '563180@oyoedu.ng', '7037593607', 'AR-RAHMAN D GATEWAY INTERL, OYO', 'OYO', '563180'),
(3181, '563181', 'úÏ…W§', '563181@oyoedu.ng', '8068971806', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563181'),
(3182, '563182', 'úÏ…W§', '563182@oyoedu.ng', '8033660751', 'OLIVET BAPT.JNR SCHL, OYO', 'OYO', '563182'),
(3183, '563183', 'úÏ…W§', '563183@oyoedu.ng', '8033660751', 'OLIVET BAPT. JNR SCHL, OYO', 'OYO', '563183'),
(3184, '563184', 'úÏ…W§', '563184@oyoedu.ng', '8058256173', 'AR-RAHMAN COLL, OYO', 'OYO', '563184'),
(3185, '563185', 'úÏ…W§', '563185@oyoedu.ng', '8066882476', 'HIGHER GROUND INTERL, JNR. SCHL, OYO', 'EBONYI', '563185'),
(3186, '563186', 'úÏ…W§', '563186@oyoedu.ng', '', 'SOUND MIND COMP. COLL, OYO', 'OYO', '563186'),
(3187, '563187', 'úÏ…W§', '563187@oyoedu.ng', '7033160643', 'FIRST BAPT.SEC. SCHL, ILORA', 'OYO', '563187'),
(3188, '563188', 'úÏ…W§', '563188@oyoedu.ng', '9037526439', 'ADEJARE OLOYEDE HIGH SCHL, OYO', 'OYO', '563188'),
(3189, '563189', 'úÏ…W§', '563189@oyoedu.ng', '8060616729', 'NATURE-NURTURE COMP.COLL, OYO', 'OYO', '563189'),
(3190, '563190', 'úÏ…W§', '563190@oyoedu.ng', '7067594922', 'ADELEKE MEMORIAL ACADEMY, OYO', 'OYO', '563190'),
(3191, '563191', 'úÏ…W§', '563191@oyoedu.ng', '7038848572', 'ANGLICAN METH.SEC, SCHL, OYO', 'OYO', '563191'),
(3192, '563192', 'úÏ…W§', '563192@oyoedu.ng', '8108220411', 'ORANYAN GRAM.SCHL,OYO', 'OYO', '563192'),
(3193, '563193', 'úÏ…W§', '563193@oyoedu.ng', '8064876620', 'AJAYI CROWTHER UNIVERSITY COLL, OYO', 'OYO', '563193'),
(3194, '563194', 'úÏ…W§', '563194@oyoedu.ng', '8064876620', 'AJAYI CROWTHER UNIVERSITY COLL,OYO', 'OYO', '563194'),
(3195, '563195', 'úÏ…W§', '563195@oyoedu.ng', '7055172079', 'JIRAYO VOCATIONAL HIGH SCHL,OYO', 'OYO', '563195'),
(3196, '563196', 'úÏ…W§', '563196@oyoedu.ng', '7069050479', 'NAHEEM SEC.SCHL,OYO', 'OYO', '563196'),
(3197, '563197', 'úÏ…W§', '563197@oyoedu.ng', '8106851833', 'WINNERS INTERL COLL,OYO', 'OYO', '563197'),
(3198, '563198', 'úÏ…W§', '563198@oyoedu.ng', '8053515976', 'ADELEKE MEMORIAL ACADEMY,OYO', 'OYO', '563198'),
(3199, '563199', 'úÏ…W§', '563199@oyoedu.ng', '8062147408', 'PROGRESSIVE COMP.COLL,OYO', 'OYO', '563199'),
(3200, '563200', 'úÏ…W§', '563200@oyoedu.ng', '8038261865', 'MIND BUILDER COLL,OYO', 'OYO', '563200'),
(3201, '563201', 'úÏ…W§', '563201@oyoedu.ng', '8078899884', 'AGBOYE BAPT COLL,OYO', 'OYO', '563201'),
(3202, '563202', 'úÏ…W§', '563202@oyoedu.ng', '7063413237', 'GOD\'S BEHIND GROUP OF SCHL,OYO', 'OYO', '563202'),
(3203, '563203', 'úÏ…W§', '563203@oyoedu.ng', '09065533161`', 'APONMADE HIGH SCHL,IBADAN', 'OYO', '563203'),
(3204, '563204', 'úÏ…W§', '563204@oyoedu.ng', '8038640148', 'SAINT FRANCIS CATHOLIC COLL,OYO', 'OYO', '563204'),
(3205, '563205', 'úÏ…W§', '563205@oyoedu.ng', '8074443380', 'EACOD COLL,OYO', 'OYO', '563205'),
(3206, '563206', 'úÏ…W§', '563206@oyoedu.ng', '8063832907', 'ORANYAN GRAM. SCHL II, OYO', 'OYO', '563206'),
(3207, '563207', 'úÏ…W§', '563207@oyoedu.ng', '8062621215', 'ORANYAN GRAM. SCHL II, OYO', 'OYO', '563207'),
(3208, '563208', 'úÏ…W§', '563208@oyoedu.ng', '7067576503', 'ANWAR- UR ISLAM COLL, OYO', 'OYO', '563208'),
(3209, '563209', 'úÏ…W§', '563209@oyoedu.ng', '8069033709', 'GOLDEN VALLEY COLL, OYO', 'OYO', '563209'),
(3210, '563210', 'úÏ…W§', '563210@oyoedu.ng', '8110388588', 'GOOD SUCCESS PRIVATE ACADEMY OYO', 'OYO', '563210'),
(3211, '563211', 'úÏ…W§', '563211@oyoedu.ng', '8067364605', 'AS-SAABIQUUN COLL, OYO', 'OYO', '563211'),
(3212, '563212', 'úÏ…W§', '563212@oyoedu.ng', '9036547944', 'NISSI PROGRESSIVE GROUP OF SCHOOL OYO', 'OYO', '563212'),
(3213, '563213', 'úÏ…W§', '563213@oyoedu.ng', '8100582870', 'SOUNDMIND COMP, COLL, OYO', 'OYO', '563213'),
(3214, '563214', 'úÏ…W§', '563214@oyoedu.ng', '', 'FORTUNE COLL, OYO', 'OYO', '563214'),
(3215, '563215', 'úÏ…W§', '563215@oyoedu.ng', '8104958826', 'SA-SHAAFI COLL, OYO', 'OYO', '563215'),
(3216, '563216', 'úÏ…W§', '563216@oyoedu.ng', '8079510788', 'MUSLIM COMP. COLL, OYO', 'OYO', '563216'),
(3217, '563217', 'úÏ…W§', '563217@oyoedu.ng', '8085749440', 'SHALOM COLL, OYO', 'OYO', '563217'),
(3218, '563218', 'úÏ…W§', '563218@oyoedu.ng', '8034072201', 'SALAHUDDEEN COLL, OYO', 'OYO', '563218'),
(3219, '563219', 'úÏ…W§', '563219@oyoedu.ng', '8033996656', 'INTEGRITY COLL, OYO', 'OYO', '563219'),
(3220, '563220', 'úÏ…W§', '563220@oyoedu.ng', '7059828846', 'ADENIRAN MODEL COLL, OYO', 'OYO', '563220'),
(3221, '563221', 'úÏ…W§', '563221@oyoedu.ng', '7056380311', 'FORTUNE MODEL COLL, OYO', 'OYO', '563221'),
(3222, '563222', 'úÏ…W§', '563222@oyoedu.ng', '8061526773', 'WINNER\'S INTERL COLL, OYO', 'OYO', '563222'),
(3223, '563223', 'úÏ…W§', '563223@oyoedu.ng', '8085749440', 'SHALOM BAPT. COLL, OYO', 'OYO', '563223'),
(3224, '563224', 'úÏ…W§', '563224@oyoedu.ng', '8035741665', 'COMM. HIGH SCHL,AGBAJA OYO', 'OYO', '563224'),
(3225, '563225', 'úÏ…W§', '563225@oyoedu.ng', '8035741665', 'LADIGBOLU GRAM. SCHL, OYO', 'OYO', '563225'),
(3226, '563226', 'úÏ…W§', '563226@oyoedu.ng', '8061253957', 'GOD FIRST INTERL. HIGH SCHL, OYO', 'OYO', '563226'),
(3227, '563227', 'úÏ…W§', '563227@oyoedu.ng', '8061253957', 'GOD FIRST INTERL, HIGH SCHL, OYO', 'OYO', '563227'),
(3228, '563228', 'úÏ…W§', '563228@oyoedu.ng', '8160994550', 'ARMY CHILDREN SEC. SCHL, OYO', 'OYO', '563228'),
(3229, '563229', 'úÏ…W§', '563229@oyoedu.ng', '8054181785', 'ALAAFIN HIGH SCHL II, OYO', 'OYO', '563229'),
(3230, '563230', 'úÏ…W§', '563230@oyoedu.ng', '7064447596', 'THE ENIGMA COLL, OYO', 'OYO', '563230'),
(3231, '563231', 'úÏ…W§', '563231@oyoedu.ng', '8056522848', 'FORTUNE MODEL COLL, OYO', 'OYO', '563231'),
(3232, '563232', 'úÏ…W§', '563232@oyoedu.ng', '8090821777', 'NURUL-ISLAMIYYA GRAM. SCHL, OYO', 'OYO', '563232'),
(3233, '563233', 'úÏ…W§', '563233@oyoedu.ng', '8032372989', 'KUDETI IB.MUSLIM COMP. COLL, OYO', 'OYO', '563233'),
(3234, '563234', 'úÏ…W§', '563234@oyoedu.ng', '8060083572', 'AHMAD GROUP OF SCHOOL AGBAD, LAGOS', 'OYO', '563234'),
(3235, '563235', 'úÏ…W§', '563235@oyoedu.ng', '8138916956', 'ANWAR-UR ISILAM SENIOR SEC. SCHL, OYO', 'OYO', '563235'),
(3236, '563236', 'úÏ…W§', '563236@oyoedu.ng', '8061253957', 'GOD FIRST HIGH SCHL, OYO', 'OYO', '563236'),
(3237, '563237', 'úÏ…W§', '563237@oyoedu.ng', '8066151171', 'JIRAYO COLL, OYO', 'OYO', '563237'),
(3238, '563238', 'úÏ…W§', '563238@oyoedu.ng', '8063189163', 'FIRST BAPTIST COLL, ILORA', 'OYO', '563238'),
(3239, '563239', 'úÏ…W§', '563239@oyoedu.ng', '8144131844', 'DYNAMIC COLLEGE OYO', 'OYO', '563239'),
(3240, '563240', 'úÏ…W§', '563240@oyoedu.ng', '7062355672', 'AL-AMEEN GROUP OF SCHL, OYO', 'OYO', '563240'),
(3241, '563241', 'úÏ…W§', '563241@oyoedu.ng', '8035272113', 'MORNING STAR GROUP OF SCHL, OYO', 'OYO', '563241'),
(3242, '563242', 'úÏ…W§', '563242@oyoedu.ng', '8078195286', 'MORNING STAR GROUP OF SCHL, OYO', 'OYO', '563242'),
(3243, '563243', 'úÏ…W§', '563243@oyoedu.ng', '8036549491', 'AATAN COMP.SCHL, OYO', 'OYO', '563243'),
(3244, '563244', 'úÏ…W§', '563244@oyoedu.ng', '8051358201', 'MORNING STAR GROUP OF SCHL, OYO', 'OYO', '563244'),
(3245, '563245', 'úÏ…W§', '563245@oyoedu.ng', '9050034155', 'ADENIRAN COLLEGE OYO', 'OYO', '563245'),
(3246, '563246', 'úÏ…W§', '563246@oyoedu.ng', '8039774778', 'ST.BERNARDINE\'S GIRLS OYO', 'OYO', '563246'),
(3247, '563247', 'úÏ…W§', '563247@oyoedu.ng', '8075042930', 'NAHEEM SEC. SCHL, OYO', 'OYO', '563247'),
(3248, '563248', 'úÏ…W§', '563248@oyoedu.ng', '8035243060', 'AL-AMEEN COMP. HIGH SCHL, OYO', 'OYO', '563248'),
(3249, '563249', 'úÏ…W§', '563249@oyoedu.ng', '8035243060', 'AL-AMEEN COMP.HIGH SCHL, OYO', 'OYO', '563249'),
(3250, '563250', 'úÏ…W§', '563250@oyoedu.ng', '8035076329', 'OLIVET HEIGHT SCHL II, OYO', 'OYO', '563250'),
(3251, '563251', 'úÏ…W§', '563251@oyoedu.ng', '7038814083', 'OLA-OLU COLLEGE OYO', 'OYO', '563251'),
(3252, '563252', 'úÏ…W§', '563252@oyoedu.ng', '8144657472', 'ISALE OYO COMM.GRAM. SCHL, OYO', 'OYO', '563252'),
(3253, '563253', 'úÏ…W§', '563253@oyoedu.ng', '8109867224', 'INTEGRITY MODEL COLL, OYO', 'OYO', '563253'),
(3254, '563254', 'úÏ…W§', '563254@oyoedu.ng', '7033957813', 'IMM.BAPT. SCHL, OYO', 'OYO', '563254'),
(3255, '563255', 'úÏ…W§', '563255@oyoedu.ng', '8069625722', 'CRESENT COLLEGE OYO', 'OYO', '563255'),
(3256, '563256', 'úÏ…W§', '563256@oyoedu.ng', '7069727273', 'MIND BUILDER COLL, OYO', 'OYO', '563256'),
(3257, '563257', 'úÏ…W§', '563257@oyoedu.ng', '8032567859', 'GOD\'S MERCY COMP.COLL, OYO', 'OYO', '563257'),
(3258, '563258', 'úÏ…W§', '563258@oyoedu.ng', '8135804010', 'ORANYAN GRAM. SCHL, OYO', 'OYO', '563258'),
(3259, '563259', 'úÏ…W§', '563259@oyoedu.ng', '9032523335', 'ROYAL RACE GROUP OF SCHL, OYO', 'OYO', '563259'),
(3260, '563260', 'úÏ…W§', '563260@oyoedu.ng', '7059599966', 'SOUND MIND COMP. COLL, OYO', 'OYO', '563260'),
(3261, '563261', 'úÏ…W§', '563261@oyoedu.ng', '7051039288', 'ADELEKE MEMORIAL ACADEMY OYO', 'OYO', '563261'),
(3262, '563262', 'úÏ…W§', '563262@oyoedu.ng', '', '', 'OYO', '563262'),
(3263, '563263', 'úÏ…W§', '563263@oyoedu.ng', '', '', '', '563263'),
(3264, '563264', 'úÏ…W§', '563264@oyoedu.ng', '9074009397', 'LIBRARY OF KNOWLEDGE GROUP OF SCHL, OYO', 'OYO', '563264'),
(3265, '563265', 'úÏ…W§', '563265@oyoedu.ng', '8057233954', 'GLORIFY THY NAME COMP. COLL, OYO', 'OYO', '563265'),
(3266, '563266', 'úÏ…W§', '563266@oyoedu.ng', '7033974412', 'IMG GRAM. SCHL, IBADAN', 'OYO', '563266'),
(3267, '563267', 'úÏ…W§', '563267@oyoedu.ng', '8164659301', 'ST. BERNARDINES GIRLS GRAM. SCHL, OYO', 'OYO', '563267'),
(3268, '563268', 'úÏ…W§', '563268@oyoedu.ng', '9022098209', 'ST. BERNARDINES GIRLS GRAM SCHL, OYO', 'OYO', '563268'),
(3269, '563269', 'úÏ…W§', '563269@oyoedu.ng', '7084722582', 'GLORY INTERL. COLL, OYO', 'OYO', '563269'),
(3270, '563270', 'úÏ…W§', '563270@oyoedu.ng', '8102618136', 'GLORY INTERL. COLL, OYO', 'OYO', '563270'),
(3271, '563271', 'úÏ…W§', '563271@oyoedu.ng', '8183451154', 'GLORY INTERL, COLL, OYO', 'OYO', '563271'),
(3272, '563272', 'úÏ…W§', '563272@oyoedu.ng', '8168808539', 'BRIGHT STAR INTERL, HIGH SCHL, OYO', 'OYO', '563272'),
(3273, '563273', 'úÏ…W§', '563273@oyoedu.ng', '8035731921', 'ARMY CHILDREN SEC. SCHL, OYO', 'OYO', '563273'),
(3274, '563274', 'úÏ…W§', '563274@oyoedu.ng', '8035731921', 'ARMY CHILDREN SEC. SCHL, OYO', 'OYO', '563274'),
(3275, '563275', 'úÏ…W§', '563275@oyoedu.ng', '7031819826', 'YEMIGHT INTERL, GRP OF SCHL, OYO', 'OYO', '563275'),
(3276, '563276', 'úÏ…W§', '563276@oyoedu.ng', '7031819826', 'YEMIGHT INTERL, GRP OF SCHL, OYO', 'OYO', '563276'),
(3277, '563277', 'úÏ…W§', '563277@oyoedu.ng', '9070701034', 'SHALOM BAPT. COLL, OYO', 'OYO', '563277'),
(3278, '563278', 'úÏ…W§', '563278@oyoedu.ng', '8132645053', 'OBA ADEYEMI HIGH SCHL, OYO', 'OYO', '563278'),
(3279, '563279', 'úÏ…W§', '563279@oyoedu.ng', '7069389217', 'AR-ROSHAD BASIC&ISLAMIC OYO', 'OYO', '563279'),
(3280, '563280', 'úÏ…W§', '563280@oyoedu.ng', '8057536190', 'ANWAR-UR ISLAM COLL, OYO', 'OYO', '563280'),
(3281, '563281', 'úÏ…W§', '563281@oyoedu.ng', '8134342282', 'SHIFAUL FUAD ACADEMY IBADAN', 'OYO', '563281'),
(3282, '563282', 'úÏ…W§', '563282@oyoedu.ng', '8138335403', 'GOD\'S MERCY COMP. COLL, OYO', 'OYO', '563282'),
(3283, '563283', 'úÏ…W§', '563283@oyoedu.ng', '8069810790', 'GOD\'S MERCY COMP. COLL, OYO', 'OYO', '563283'),
(3284, '563284', 'úÏ…W§', '563284@oyoedu.ng', '8077315217', 'ALAAFIN HIGH SCHL, OYO', 'OYO', '563284'),
(3285, '563285', 'úÏ…W§', '563285@oyoedu.ng', '8168279124', 'YEMIGHT INTERL, SCHL, OYO', 'OYO', '563285'),
(3286, '563286', 'úÏ…W§', '563286@oyoedu.ng', '9039918840', 'COMM.HIGH DUR, OYO', 'OYO', '563286'),
(3287, '563287', 'úÏ…W§', '563287@oyoedu.ng', '8068229386', 'AKOLADE MEMORIAL COLL, OYO', 'OYO', '563287'),
(3288, '563288', 'úÏ…W§', '563288@oyoedu.ng', '8148987358', 'SHALOM BAPT. COLL,OYO', 'OYO', '563288'),
(3289, '563289', 'úÏ…W§', '563289@oyoedu.ng', '8062464890', 'SHALOM BAPT, COLL, OYO', 'OYO', '563289'),
(3290, '563290', 'úÏ…W§', '563290@oyoedu.ng', '8036852750', 'SPED INTERL. SEC, SCHL, OYO', 'OYO', '563290'),
(3291, '563291', 'úÏ…W§', '563291@oyoedu.ng', '8063711177', 'UNITY MODEL GROUP OF SCHL, OYO', 'OYO', '563291'),
(3292, '563292', 'úÏ…W§', '563292@oyoedu.ng', '8060911183', 'HAPPY DAY SEC. SCHL, OYO', 'OYO', '563292'),
(3293, '563293', 'úÏ…W§', '563293@oyoedu.ng', '8060911183', 'HAPPY DAY SEC. SCHL, OYO', 'OYO', '563293'),
(3294, '563294', 'úÏ…W§', '563294@oyoedu.ng', '8036852750', 'ROYAL MODEL COLL. OYO', 'OYO', '563294'),
(3295, '563295', 'úÏ…W§', '563295@oyoedu.ng', '8135374404', 'DAYS STAR COLL., OYO', 'BENUE', '563295'),
(3296, '563296', 'úÏ…W§', '563296@oyoedu.ng', '7063163445', 'LADIGBOLU GRAMM. SCH. OYO', 'OYO', '563296'),
(3297, '563297', 'úÏ…W§', '563297@oyoedu.ng', '9071114401', 'FIRST GATE COLL. OYO', 'OYO', '563297'),
(3298, '563298', 'úÏ…W§', '563298@oyoedu.ng', '8030407747', 'ALAAFIN HIGH SCH. OYO', 'OYO', '563298'),
(3299, '563299', 'úÏ…W§', '563299@oyoedu.ng', '8139643307', 'GOD\'S MERCY COMP. COLL., OYO', 'OYO', '563299'),
(3300, '563300', 'úÏ…W§', '563300@oyoedu.ng', '8034867603', 'BRAIN POINT COLL. OYO', 'OYO', '563300'),
(3301, '563301', 'úÏ…W§', '563301@oyoedu.ng', '8034867603', 'ST. BERNARDINES GIRLS COLL., OYO', 'OYO', '563301'),
(3302, '563302', 'úÏ…W§', '563302@oyoedu.ng', '8072607262', 'ISALE OYO COMM. GRAMM SCH. OYO', 'OYO', '563302'),
(3303, '563303', 'úÏ…W§', '563303@oyoedu.ng', '7034214894', 'ALMADEENA COLL. OGBOMOSO', 'OYO', '563303'),
(3304, '563304', 'úÏ…W§', '563304@oyoedu.ng', '8035775083', 'COMM. HIGH SCH., OYO', 'OYO', '563304'),
(3305, '563305', 'úÏ…W§', '563305@oyoedu.ng', '7054585301', 'GLORY GLORY LORD HIGH SCH., OYO', 'OYO', '563305'),
(3306, '563306', 'úÏ…W§', '563306@oyoedu.ng', '8057536190', 'ANWAR-UL ISLAM COLL. OYO', 'OYO', '563306'),
(3307, '563307', 'úÏ…W§', '563307@oyoedu.ng', '8149224886', 'BRIGHT STAR COLL. OYO', 'OYO', '563307'),
(3308, '563308', 'úÏ…W§', '563308@oyoedu.ng', '8035663272', 'BEST LEGACY SEC SCH. AWE', 'OYO', '563308'),
(3309, '563309', 'úÏ…W§', '563309@oyoedu.ng', '8141135377', 'AMBASADOR ACADEMY. OYO', 'OYO', '563309'),
(3310, '563310', 'úÏ…W§', '563310@oyoedu.ng', '8050473204', 'COMM JUN. HIGH SCH. OKEOLOLA, OYO', 'OYO', '563310'),
(3311, '563311', 'úÏ…W§', '563311@oyoedu.ng', '8034680998', 'OLIVET BAPTIST HIGH SCH., OYO', 'OYO', '563311'),
(3312, '563312', 'úÏ…W§', '563312@oyoedu.ng', '7077288035', 'GOLDEN VALLEY COLL. OYO', 'OYO', '563312'),
(3313, '563313', 'úÏ…W§', '563313@oyoedu.ng', '8163179322', 'HEPHZIBAH COLL. IBAFO, OGUN STATE', 'OGUN', '563313'),
(3314, '563314', 'úÏ…W§', '563314@oyoedu.ng', '7033070545', 'HAPPINESS COMP. COLL., OYO', 'OYO', '563314'),
(3315, '563315', 'úÏ…W§', '563315@oyoedu.ng', '8050218274', 'ROYAL RACE GROUP OF SCH.', 'OYO', '563315'),
(3316, '563316', 'úÏ…W§', '563316@oyoedu.ng', '8163999882', 'AL-FATHIU(VICTORY) COMP. COLL., OYO', 'OYO', '563316'),
(3317, '563317', 'úÏ…W§', '563317@oyoedu.ng', '7035491638', 'TAAWUNU GRP. OF SCH. OYO', 'OYO', '563317'),
(3318, '563318', 'úÏ…W§', '563318@oyoedu.ng', '7061140193', 'LADIGBOLU GRAM. SCH., OYO', 'OYO', '563318'),
(3319, '563319', 'úÏ…W§', '563319@oyoedu.ng', '8109640317', 'ST. BERNARDINES GIRLS GRAM. SCH. OYO', 'OYO', '563319'),
(3320, '563320', 'úÏ…W§', '563320@oyoedu.ng', '7069128591', 'EXCEL INTERNATIONAL COLL.', 'OYO', '563320'),
(3321, '563321', 'úÏ…W§', '563321@oyoedu.ng', '8061253869', 'FAITH INTERNATIONAL COLL., OYO', 'OYO', '563321'),
(3322, '563322', 'úÏ…W§', '563322@oyoedu.ng', '7089798840', 'THE ENIGMA COLL. OYO', 'OYO', '563322'),
(3323, '563323', 'úÏ…W§', '563323@oyoedu.ng', '8134118618', 'OLIVET BAPTIST HIGH SCH., OYO', 'OYO', '563323'),
(3324, '563324', 'úÏ…W§', '563324@oyoedu.ng', '8076603737', 'ADELEKE MEMORIAL ACADEMY, OYO', 'OYO', '563324'),
(3325, '563325', 'úÏ…W§', '563325@oyoedu.ng', '8062381487', 'ANWAR-UL ISLAM COLL., OYO', 'OYO', '563325'),
(3326, '563326', 'úÏ…W§', '563326@oyoedu.ng', '7033614141', 'SPED INTER. OYO', 'OYO', '563326'),
(3327, '563327', 'úÏ…W§', '563327@oyoedu.ng', '8131197324', 'AL FATHIU COMP. COLL., OYO', 'OYO', '563327'),
(3328, '323328', 'úÏ…W§', '323328@oyoedu.ng', '8032989291', 'ASEDA PRIVATE SCHOOL', 'OYO', '323328'),
(3329, '323329', 'úÏ…W§', '323329@oyoedu.ng', '8032989291', 'ASEDA SCHOOL OF SCIENCE', 'OYO', '323329'),
(3330, '323330', 'úÏ…W§', '323330@oyoedu.ng', '8132633291', 'MTHODIST SEC.SCH.', 'EKITI', '323330'),
(3331, '323331', 'úÏ…W§', '323331@oyoedu.ng', '8038266203', 'ARMY DAY SEC.SCH', 'OYO', '323331'),
(3332, '323332', 'úÏ…W§', '323332@oyoedu.ng', '8072932349', 'SEGUSSOL PRIVATE SCH.', 'OYO', '323332'),
(3333, '323333', 'úÏ…W§', '323333@oyoedu.ng', '8161852761', 'SANKAY COLLEGE ', 'OYO', '323333'),
(3334, '323334', 'úÏ…W§', '323334@oyoedu.ng', '8056606068', 'SAMLAW COLLEGE', 'OYO', '323334'),
(3335, '323335', 'úÏ…W§', '323335@oyoedu.ng', '8056606068', 'SAMLAW COLLEGE', 'OYO', '323335'),
(3336, '323336', 'úÏ…W§', '323336@oyoedu.ng', '8069557534', 'SAMLAW COLLEGE', 'OYO', '323336'),
(3337, '323337', 'úÏ…W§', '323337@oyoedu.ng', '8034661026', 'GRACE POINT COLLEGE', 'OYO', '323337'),
(3338, '323338', 'úÏ…W§', '323338@oyoedu.ng', '7039673886', 'HALLMARK ACADEMY', 'OYO', '323338'),
(3339, '323339', 'úÏ…W§', '323339@oyoedu.ng', '8034193164', 'CHS LALEYE', 'OYO', '323339'),
(3340, '323340', 'úÏ…W§', '323340@oyoedu.ng', '8056616775', '', 'OYO', '323340'),
(3341, '323341', 'úÏ…W§', '323341@oyoedu.ng', '7065389705', 'GRATE GRACE', 'OYO', '323341'),
(3342, '323342', 'úÏ…W§', '323342@oyoedu.ng', '8166663005', 'IDEAL COLLEGE', 'OSUN', '323342'),
(3343, '323343', 'úÏ…W§', '323343@oyoedu.ng', '8156697861', 'ABADINA GRAMM. SCH.', 'OSUN', '323343'),
(3344, '323344', 'úÏ…W§', '323344@oyoedu.ng', '8050909723', 'BOY\'S HIGH SCH.', 'EDO', '323344'),
(3345, '323345', 'úÏ…W§', '323345@oyoedu.ng', '7055995544', 'SANGO HIGH SCH.', 'OYO', '323345'),
(3346, '323346', 'úÏ…W§', '323346@oyoedu.ng', '8032468425', 'BESLY', 'OSUN', '323346'),
(3347, '323347', 'úÏ…W§', '323347@oyoedu.ng', '8032468425', 'T.L OYESINA', 'OYO', '323347'),
(3348, '323348', 'úÏ…W§', '323348@oyoedu.ng', '8068510162', 'DAVID JOEL', 'OYO', '323348'),
(3349, '323349', 'úÏ…W§', '323349@oyoedu.ng', '8052287126', 'SUNDORA COLLEGE', 'OGUN', '323349'),
(3350, '323350', 'úÏ…W§', '323350@oyoedu.ng', '7033736483', 'GLORIOUS KING &QUEEN', 'OYO', '323350'),
(3351, '323351', 'úÏ…W§', '323351@oyoedu.ng', '9037841530', '', 'OYO', '323351'),
(3352, '323352', 'úÏ…W§', '323352@oyoedu.ng', '8055821965', 'COMM.SEC.SCH.ADEGBAYI', 'OYO', '323352'),
(3353, '323353', 'úÏ…W§', '323353@oyoedu.ng', '8169621575', 'SUPREME EXC.AC.', 'OYO', '323353'),
(3354, '323354', 'úÏ…W§', '323354@oyoedu.ng', '8068253836', 'LANTERN PRIVAYE SCH.', 'OYO', '323354'),
(3355, '323355', 'úÏ…W§', '323355@oyoedu.ng', '8032313378', 'PARAGON COLLEGE', 'OYO', '323355'),
(3356, '323356', 'úÏ…W§', '323356@oyoedu.ng', '9059814014', 'KOLADE OLAPERIMGOS', 'OYO', '323356'),
(3357, '323357', 'úÏ…W§', '323357@oyoedu.ng', '7032368472', 'OJOO HIGH SCH.', 'OYO', '323357'),
(3358, '323358', 'úÏ…W§', '323358@oyoedu.ng', '8115658717', 'CLASSIC AKOBO', 'OYO', '323358'),
(3359, '323359', 'úÏ…W§', '323359@oyoedu.ng', '8030481529', 'IYANU OLUWA N/P', 'OYO', '323359'),
(3360, '323360', 'úÏ…W§', '323360@oyoedu.ng', '8034437660', 'CAC GRAM.SCH,IB.', 'OYO', '323360'),
(3361, '323361', 'úÏ…W§', '323361@oyoedu.ng', '8034437660', 'DELIGHT N/P SCH.IB.', 'OYO', '323361'),
(3362, '323362', 'úÏ…W§', '323362@oyoedu.ng', '8037992374', 'BLUE RIBBON WIRE&CABLE', 'OYO', '323362'),
(3363, '323363', 'úÏ…W§', '323363@oyoedu.ng', '8068146549', 'METHODIST SEC SCH.GANGANSI', 'OYO', '323363'),
(3364, '323364', 'úÏ…W§', '323364@oyoedu.ng', '8035032047', 'NOBLE FOUNDATION COLL.', 'OYO', '323364'),
(3365, '323365', 'úÏ…W§', '323365@oyoedu.ng', '8062269381', 'CHS OLAOGUN', 'OYO', '323365'),
(3366, '323366', 'úÏ…W§', '323366@oyoedu.ng', '8034821364', 'HIS GLORY SEC .SCH.', 'OYO', '323366'),
(3367, '323367', 'úÏ…W§', '323367@oyoedu.ng', '7058104910', 'TOP BRAIN COMP.H.SCH.', 'OYO', '323367'),
(3368, '323368', 'úÏ…W§', '323368@oyoedu.ng', '8059344219', 'SANKAY COLLEGE ', 'OYO', '323368'),
(3369, '323369', 'úÏ…W§', '323369@oyoedu.ng', '7065831632', 'ST.DAVIDS GRAMM.SCH', 'EKITI', '323369'),
(3370, '323370', 'úÏ…W§', '323370@oyoedu.ng', '7039079386', 'IFESOWAPO CHS', 'OYO', '323370'),
(3371, '323371', 'úÏ…W§', '323371@oyoedu.ng', '8139471847', 'ROYAL  DIADEM', 'OYO', '323371'),
(3372, '323372', 'úÏ…W§', '323372@oyoedu.ng', '8148771221', 'TO GOD BE THE GLORY', 'OGUN', '323372'),
(3373, '323373', 'úÏ…W§', '323373@oyoedu.ng', '8035787251', 'ODA OBA CHS', 'ONDO', '323373'),
(3374, '323374', 'úÏ…W§', '323374@oyoedu.ng', '8030537369', 'AL-KITAB MODEL SEC.SCH.', 'OYO', '323374'),
(3375, '323375', 'úÏ…W§', '323375@oyoedu.ng', '8062283519', 'QIBLAH HIGH SCH IB.', 'OYO', '323375'),
(3376, '323376', 'úÏ…W§', '323376@oyoedu.ng', '8062283519', 'QIBLAH HIGH SCH IB.', 'OYO', '323376'),
(3377, '323377', 'úÏ…W§', '323377@oyoedu.ng', '8050948733', 'AL-KIDAM', 'OYO', '323377'),
(3378, '323378', 'úÏ…W§', '323378@oyoedu.ng', '8035222115', 'AL-HIKMAN', 'OYO', '323378'),
(3379, '323379', 'úÏ…W§', '323379@oyoedu.ng', '8062283619', 'QIBLAH HIGH SCH IB.', 'OYO', '323379'),
(3380, '323380', 'úÏ…W§', '323380@oyoedu.ng', '8062283619', 'QIBLAH HIGH SCH IB.', 'OYO', '323380'),
(3381, '323381', 'úÏ…W§', '323381@oyoedu.ng', '8056010258', 'ASEDA PRIVATE SCH. OF SCIENCE', 'OYO', '323381'),
(3382, '323382', 'úÏ…W§', '323382@oyoedu.ng', '7037216212', 'ABIKE GROUP OF SCH.', 'OYO', '323382'),
(3383, '323383', 'úÏ…W§', '323383@oyoedu.ng', '9065713738', 'BRIGHT STAR', 'EKITI', '323383'),
(3384, '323384', 'úÏ…W§', '323384@oyoedu.ng', '8030645766', 'MUFLIUM HIGH SCH.', 'OYO', '323384'),
(3385, '323385', 'úÏ…W§', '323385@oyoedu.ng', '8038761801', 'REBOTH CITADEL OF KNOWLEDGE', 'OGUN', '323385'),
(3386, '323386', 'úÏ…W§', '323386@oyoedu.ng', '8057120355', 'ISEYIN DISTRICT', 'OYO', '323386'),
(3387, '323387', 'úÏ…W§', '323387@oyoedu.ng', '8135016436', 'NOBLE FOUNDATION COLL.', 'OYO', '323387'),
(3388, '323388', 'úÏ…W§', '323388@oyoedu.ng', '9020835367', 'DARUL-IKMOH', 'OYO', '323388'),
(3389, '323389', 'úÏ…W§', '323389@oyoedu.ng', '8072792390', 'FUTURE PEACE MODEL COLL.', 'OYO', '323389'),
(3390, '323390', 'úÏ…W§', '323390@oyoedu.ng', '8053061018', 'PRECIOUS INT.MODEL COL.', 'OYO', '323390'),
(3391, '323391', 'úÏ…W§', '323391@oyoedu.ng', '7088266792', 'GOD\'S FAVOURPRIVATE SCH.', 'KWARA', '323391'),
(3392, '323392', 'úÏ…W§', '323392@oyoedu.ng', '8056190595', 'GLORIOUS JOY COLLEGE', 'OYO', '323392'),
(3393, '323393', 'úÏ…W§', '323393@oyoedu.ng', '7032549963', '', 'OYO', '323393'),
(3394, '323394', 'úÏ…W§', '323394@oyoedu.ng', '8073833731', '', 'OYO', '323394'),
(3395, '323395', 'úÏ…W§', '323395@oyoedu.ng', '9021367755', '', 'EKITI', '323395'),
(3396, '323396', 'úÏ…W§', '323396@oyoedu.ng', '8038033091', '', 'KWARA', '323396'),
(3397, '323397', 'úÏ…W§', '323397@oyoedu.ng', '8035831380', '', 'OYO', '323397'),
(3398, '323398', 'úÏ…W§', '323398@oyoedu.ng', '8035831380', '', 'OYO', '323398'),
(3399, '323399', 'úÏ…W§', '323399@oyoedu.ng', '8066850645', '', 'OYO', '323399'),
(3400, '323400', 'úÏ…W§', '323400@oyoedu.ng', '8035667704', 'AHOYAYA GRAMM.SCH.', 'OYO', '323400'),
(3401, '323401', 'úÏ…W§', '323401@oyoedu.ng', '7015620477', 'AMOO COLLEGE', 'OYO', '323401'),
(3402, '323402', 'úÏ…W§', '323402@oyoedu.ng', '8161197127', 'ST.SAR  COLLEGE', 'OSUN', '323402'),
(3403, '323403', 'úÏ…W§', '323403@oyoedu.ng', '9016969612', 'CLOFAM PRIVATE SCH.', 'OYO', '323403'),
(3404, '323404', 'úÏ…W§', '323404@oyoedu.ng', '7039467335', 'IFELODUN GRAM,SCH.', 'OYO', '323404'),
(3405, '323405', 'úÏ…W§', '323405@oyoedu.ng', '8033557290', 'FAITH FOUNDATION', 'OYO', '323405'),
(3406, '323406', 'úÏ…W§', '323406@oyoedu.ng', '8058316636', 'PRINCE OF PEACE', 'OYO', '323406'),
(3407, '323407', 'úÏ…W§', '323407@oyoedu.ng', '8150378040', 'EXCEPTIONAL GRP OF SCH.', 'OYO', '323407'),
(3408, '323408', 'úÏ…W§', '323408@oyoedu.ng', '8118982659', 'DIVINE RUTH COLLEGE', 'OYO', '323408'),
(3409, '323409', 'úÏ…W§', '323409@oyoedu.ng', '8110808313', '', 'OYO', '323409'),
(3410, '323410', 'úÏ…W§', '323410@oyoedu.ng', '8136634008', '', 'OYO', '323410'),
(3411, '323411', 'úÏ…W§', '323411@oyoedu.ng', '8054354239', 'BEST', 'OYO', '323411'),
(3412, '323412', 'úÏ…W§', '323412@oyoedu.ng', '8034994164', 'QIBLAH HIGH SCH.IB.', 'OYO', '323412'),
(3413, '323413', 'úÏ…W§', '323413@oyoedu.ng', '8076872936', 'AL-KIBAT MODEL IB.', 'OYO', '323413'),
(3414, '323414', 'úÏ…W§', '323414@oyoedu.ng', '8060184363', 'SUPREME ACADEMY,IB.', 'OYO', '323414'),
(3415, '323415', 'úÏ…W§', '323415@oyoedu.ng', '9069683802', 'ALAYANDE EMMANUEL JUNIOR SEC.', 'OYO', '323415'),
(3416, '323416', 'úÏ…W§', '323416@oyoedu.ng', '8134367172', 'CARITAS', 'OYO', '323416'),
(3417, '323417', 'úÏ…W§', '323417@oyoedu.ng', '8078621054', 'OLA OLU SCH.', 'OYO', '323417'),
(3418, '323418', 'úÏ…W§', '323418@oyoedu.ng', '7081960171', 'TOPBRAIN SCH.', 'OYO', '323418'),
(3419, '323419', 'úÏ…W§', '323419@oyoedu.ng', '8067031913', 'CHS OLANLA', 'OYO', '323419'),
(3420, '323420', 'úÏ…W§', '323420@oyoedu.ng', '8059199060', 'UNIQUE MODEL  COLLEGE', 'OSUN', '323420'),
(3421, '323421', 'úÏ…W§', '323421@oyoedu.ng', '8061609316', 'CHS OGBERE', 'OYO', '323421'),
(3422, '323422', 'úÏ…W§', '323422@oyoedu.ng', '8126653455', '', 'OYO', '323422'),
(3423, '323423', 'úÏ…W§', '323423@oyoedu.ng', '7025714524', 'HEPPHZIBAH COLLEGE', 'OYO', '323423'),
(3424, '323424', 'úÏ…W§', '323424@oyoedu.ng', '7011397007', 'IWOKOTO C/S MONIYA', 'OYO', '323424'),
(3425, '323425', 'úÏ…W§', '323425@oyoedu.ng', '8132932464', 'CHS MONIYA', 'OYO', '323425'),
(3426, '323426', 'úÏ…W§', '323426@oyoedu.ng', '8132932464', 'CHS MONIYA', 'OYO', '323426'),
(3427, '323427', 'úÏ…W§', '323427@oyoedu.ng', '8053085215', 'TMM SEC. SCH.', 'OYO', '323427'),
(3428, '323428', 'úÏ…W§', '323428@oyoedu.ng', '8169237124', 'HOPEE INT.SCH.', 'OYO', '323428'),
(3429, '323429', 'úÏ…W§', '323429@oyoedu.ng', '8136068912', 'COMM.SEC.SCH.ADEGBAYI', 'OYO', '323429'),
(3430, '323430', 'úÏ…W§', '323430@oyoedu.ng', '8080513261', 'OLIVET BAPTIST H/S OYO', 'OSUN', '323430'),
(3431, '323431', 'úÏ…W§', '323431@oyoedu.ng', '7033163373', 'INTEGRITY ACADEMY', 'OSUN', '323431'),
(3432, '323432', 'úÏ…W§', '323432@oyoedu.ng', '8026801961', 'EMMA ELSHADDAI SEC. SCH.', 'EKITI', '323432'),
(3433, '323433', 'úÏ…W§', '323433@oyoedu.ng', '8034549567', 'QUANTUM LEAP COMPETENCE SCH.', 'OYO', '323433'),
(3434, '323434', 'úÏ…W§', '323434@oyoedu.ng', '8038551934', 'FEDERAL GIRLS COLLEGE,IPETUMODU', 'OYO', '323434'),
(3435, '323435', 'úÏ…W§', '323435@oyoedu.ng', '', 'FEDERAL GIRLS COLLEGE,IPETUMODU', 'OYO', '323435'),
(3436, '323436', 'úÏ…W§', '323436@oyoedu.ng', '8052253011', 'COMMUNITY HIGH SCH ALAPATA ONI', 'OYO', '323436'),
(3437, '323437', 'úÏ…W§', '323437@oyoedu.ng', '8055295926', 'AMAZING GRACE', 'OYO', '323437'),
(3438, '323438', 'úÏ…W§', '323438@oyoedu.ng', '8021113441', 'COMMAND DAY SEC SCH.', 'OYO', '323438'),
(3439, '323439', 'úÏ…W§', '323439@oyoedu.ng', '8030885273', 'IYANA C H S IBD', 'OYO', '323439'),
(3440, '323440', 'úÏ…W§', '323440@oyoedu.ng', '7045463711', 'EJIOBA HIGH SCH', 'OSUN', '323440'),
(3441, '323441', 'úÏ…W§', '323441@oyoedu.ng', '7059337436', 'WISDOM POT HIGH SCH', 'OYO', '323441'),
(3442, '323442', 'úÏ…W§', '323442@oyoedu.ng', '8052464954', 'AL-IHSAN ACADEMY', 'OYO', '323442'),
(3443, '323443', 'úÏ…W§', '323443@oyoedu.ng', '8072657868', 'ST.ANNE SCH IBADAN', 'OYO', '323443'),
(3444, '323444', 'úÏ…W§', '323444@oyoedu.ng', '7033672914', 'VICTORY BAPT.SCH', 'OYO', '323444'),
(3445, '323445', 'úÏ…W§', '323445@oyoedu.ng', '8033931503', 'DIVINE GRACE SCH', 'OGUN', '323445'),
(3446, '323446', 'úÏ…W§', '323446@oyoedu.ng', '8055255846', 'AL-HIKMAH COLLEGE', 'OYO', '323446'),
(3447, '323447', 'úÏ…W§', '323447@oyoedu.ng', '7033685078', '', 'OSUN', '323447'),
(3448, '323448', 'úÏ…W§', '323448@oyoedu.ng', '9023213895', '', 'OYO', '323448'),
(3449, '323449', 'úÏ…W§', '323449@oyoedu.ng', '8056703159', 'DOUBLE MAJOR COLLEGE', 'OYO', '323449'),
(3450, '323450', 'úÏ…W§', '323450@oyoedu.ng', '8057468816', 'AL-WAJUD SCH IBADAN', 'OYO', '323450'),
(3451, '323451', 'úÏ…W§', '323451@oyoedu.ng', '8051155117', 'LIKEAND SCHOOL', 'OYO', '323451'),
(3452, '323452', 'úÏ…W§', '323452@oyoedu.ng', '9033307174', 'C H S IWO ROAD IBADAN', 'OYO', '323452'),
(3453, '323453', 'úÏ…W§', '323453@oyoedu.ng', '7014390395', 'MIRACLE OF GOD COLLEGE', 'OYO', '323453'),
(3454, '323454', 'úÏ…W§', '323454@oyoedu.ng', '8076402333', 'COMMUNITY HIGH SCHOOL ,OMIYALE', 'OYO', '323454'),
(3455, '323455', 'úÏ…W§', '323455@oyoedu.ng', '8076402333', 'COMMUNITY HIGH SCHOOL ,OMIYALE', 'OYO', '323455'),
(3456, '323456', 'úÏ…W§', '323456@oyoedu.ng', '9067418101', 'COMMUNITY GRAMM.SAWMILL', 'OYO', '323456'),
(3457, '323457', 'úÏ…W§', '323457@oyoedu.ng', '8053658173', 'KOLE ARORO', 'OYO', '323457'),
(3458, '323458', 'úÏ…W§', '323458@oyoedu.ng', '8033716023', 'FRANCIS (M)', 'OYO', '323458'),
(3459, '323459', 'úÏ…W§', '323459@oyoedu.ng', '8032287273', 'MIN. OF EDUCATION', 'ONDO', '323459'),
(3460, '323460', 'úÏ…W§', '323460@oyoedu.ng', '7030262424', 'BIOKU ALADUN', 'OYO', '323460'),
(3461, '323461', 'úÏ…W§', '323461@oyoedu.ng', '8105677312', 'SAMUEL PRIVATE SCH.', 'OYO', '323461'),
(3462, '323462', 'úÏ…W§', '323462@oyoedu.ng', '8156571761', 'FETAH GROUP OF SCH.', 'OYO', '323462'),
(3463, '323463', 'úÏ…W§', '323463@oyoedu.ng', '8053031630', 'DARUS SALAM COLL.', 'OYO', '323463'),
(3464, '323464', 'úÏ…W§', '323464@oyoedu.ng', '703939810', 'APOMU GRAM.', 'OSUN', '323464'),
(3465, '323465', 'úÏ…W§', '323465@oyoedu.ng', '8065097032', 'AMAZING GRACE', 'EKITI', '323465'),
(3466, '323466', 'úÏ…W§', '323466@oyoedu.ng', '7089968613', 'ROYALPATHFINDER', 'OYO', '323466'),
(3467, '323467', 'úÏ…W§', '323467@oyoedu.ng', '8127774839', 'AS-SOBOUR COLL.IB.', 'OYO', '323467'),
(3468, '323468', 'úÏ…W§', '323468@oyoedu.ng', '7038249727', 'MILESTONE', 'OSUN', '323468'),
(3469, '323469', 'úÏ…W§', '323469@oyoedu.ng', '8026289653', 'TOP INTERNATIONAL SCH.', 'OYO', '323469'),
(3470, '323470', 'úÏ…W§', '323470@oyoedu.ng', '8107812544', '', 'OYO', '323470'),
(3471, '323471', 'úÏ…W§', '323471@oyoedu.ng', '8055933703', 'SHINING GLORY SCH.', 'OYO', '323471'),
(3472, '323472', 'úÏ…W§', '323472@oyoedu.ng', '7062383012', 'IBADAN CITY HIGH SCHOOL ACADEMY', 'OYO', '323472'),
(3473, '273473', 'úÏ…W§', '273473@oyoedu.ng', '7067859979', 'HOLY TRINITY', 'OYO', '273473'),
(3474, '273474', 'úÏ…W§', '273474@oyoedu.ng', '8052290876', 'QUEEN OF APOSTEL', 'OYO', '273474'),
(3475, '273475', 'úÏ…W§', '273475@oyoedu.ng', '8038274272', 'INTEGRITY CRESTIVE', 'OYO', '273475'),
(3476, '273476', 'úÏ…W§', '273476@oyoedu.ng', '                    ', 'INTEGRITY CRESTIVE', 'OYO', '273476'),
(3477, '273477', 'úÏ…W§', '273477@oyoedu.ng', '8035036201', 'OYO STATE COMP', 'OYO', '273477'),
(3478, '273478', 'úÏ…W§', '273478@oyoedu.ng', '8053036313', 'GOFAMINT SCH', 'OYO', '273478'),
(3479, '273479', 'úÏ…W§', '273479@oyoedu.ng', '8107051438', 'DYNOLINKS GLOBAL', 'EKITI', '273479'),
(3480, '273480', 'úÏ…W§', '273480@oyoedu.ng', '8053787940', 'THE HEART COLLEGE', 'EKITI', '273480'),
(3481, '273481', 'úÏ…W§', '273481@oyoedu.ng', '8034558331', 'DAVIES COLLEGE', 'OYO', '273481'),
(3482, '273482', 'úÏ…W§', '273482@oyoedu.ng', '8038107980', 'SUMMIT COMP COLLEGE', 'OYO', '273482'),
(3483, '273483', 'úÏ…W§', '273483@oyoedu.ng', '8100636319', 'RICHDEL MODEL COLLEGE', 'OYO', '273483'),
(3484, '273484', 'úÏ…W§', '273484@oyoedu.ng', '8038382286', 'ELSHADAI', 'OYO', '273484'),
(3485, '273485', 'úÏ…W§', '273485@oyoedu.ng', '8053615525', 'I.G.G.S II', 'OYO', '273485'),
(3486, '373486', 'úÏ…W§', '373486@oyoedu.ng', '8055958917', 'COMM SCH OLAOGUN', 'OYO', '373486'),
(3487, '273487', 'úÏ…W§', '273487@oyoedu.ng', '9073084240', 'METHODIST GRA SCH', 'OSUN', '273487'),
(3488, '273488', 'úÏ…W§', '273488@oyoedu.ng', '8030422099', 'ABADINA GRAR SCH', 'OYO', '273488'),
(3489, '273489', 'úÏ…W§', '273489@oyoedu.ng', '8033521336', 'AL-EEMAAN COLL', 'OYO', '273489'),
(3490, '273490', 'úÏ…W§', '273490@oyoedu.ng', '8033521336', 'AL-EEMAAN COLL', 'OYO', '273490'),
(3491, '273491', 'úÏ…W§', '273491@oyoedu.ng', '8033857213', 'RIDIAALULAAH COLL', 'OYO', '273491'),
(3492, '373492', 'úÏ…W§', '373492@oyoedu.ng', '8057642149', 'GRACE AND GLORY COLLEGE', 'ONDO', '373492'),
(3493, '273493', 'úÏ…W§', '273493@oyoedu.ng', '8037204244', 'GRACE AND GLORY COLLEGE', 'OYO', '273493'),
(3494, '273494', 'úÏ…W§', '273494@oyoedu.ng', '8034308520', 'RUBIESTNER COLLEGE', 'KWARA', '273494'),
(3495, '373495', 'úÏ…W§', '373495@oyoedu.ng', '8034401117', 'KSA PRIVATE', 'OYO', '373495'),
(3496, '273496', 'úÏ…W§', '273496@oyoedu.ng', '8055200038', 'FORWARD EVER', 'OSUN', '273496');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(3497, '273497', 'úÏ…W§', '273497@oyoedu.ng', '8034685908', 'COMMAND SEC SCH MOKOLA', 'OYO', '273497'),
(3498, '273498', 'úÏ…W§', '273498@oyoedu.ng', '8057113840', 'SUMMIT COMP COLLEGE', 'OYO', '273498'),
(3499, '273499', 'úÏ…W§', '273499@oyoedu.ng', '8101509701', 'LOYOLA COLLEGE', 'OYO', '273499'),
(3500, '273500', 'úÏ…W§', '273500@oyoedu.ng', '8061151858', 'AMAZING GRACE', 'OYO', '273500'),
(3501, '273501', 'úÏ…W§', '273501@oyoedu.ng', '8059338261', 'EVERGREEN COMP COLL.', 'OSUN', '273501'),
(3502, '273502', 'úÏ…W§', '273502@oyoedu.ng', '8062275131', 'THE LIGHT ACADEMY', 'OYO', '273502'),
(3503, '273503', 'úÏ…W§', '273503@oyoedu.ng', '8034804447', 'HIGHLANDER COLLEGE', 'OYO', '273503'),
(3504, '273504', 'úÏ…W§', '273504@oyoedu.ng', '8060179055', 'NESAM INT COLL', 'OYO', '273504'),
(3505, '273505', 'úÏ…W§', '273505@oyoedu.ng', '8033558490', 'BLESSED REHOBOTH COLL', 'OSUN', '273505'),
(3506, '273506', 'úÏ…W§', '273506@oyoedu.ng', '8157150377', 'ABIMBOLA EXCEL', 'OYO', '273506'),
(3507, '273507', 'úÏ…W§', '273507@oyoedu.ng', '8038549423', 'BEULAH ACADEMY', 'OGUN', '273507'),
(3508, '273508', 'úÏ…W§', '273508@oyoedu.ng', '8056016891', 'RIDUALLAH COMP COLL', 'OYO', '273508'),
(3509, '273509', 'úÏ…W§', '273509@oyoedu.ng', '9057777968', 'QUATUN LEAP', 'OYO', '273509'),
(3510, '373510', 'úÏ…W§', '373510@oyoedu.ng', '8064048337', 'GLOBAL', 'OYO', '373510'),
(3511, '273511', 'úÏ…W§', '273511@oyoedu.ng', '8082927443', 'A.G.S.A', 'OYO', '273511'),
(3512, '273512', 'úÏ…W§', '273512@oyoedu.ng', '8032564032', 'COMM. GRA. SCH.', 'OYO', '273512'),
(3513, '273513', 'úÏ…W§', '273513@oyoedu.ng', '8037473205', 'DAARULHIKNAH', 'OYO', '273513'),
(3514, '273514', 'úÏ…W§', '273514@oyoedu.ng', '8160615226', 'COMM DAY SCH', 'OYO', '273514'),
(3515, '273515', 'úÏ…W§', '273515@oyoedu.ng', '8106652407', 'OPEN HEAVENS', 'OYO', '273515'),
(3516, '373516', 'úÏ…W§', '373516@oyoedu.ng', '8149221529', 'ABIMBOLA EXCEL', 'OYO', '373516'),
(3517, '273517', 'úÏ…W§', '273517@oyoedu.ng', '8034991501', 'BAPTIST MODEL', 'OYO', '273517'),
(3518, '273518', 'úÏ…W§', '273518@oyoedu.ng', '8116373730', 'CARITAS', 'OYO', '273518'),
(3519, '273519', 'úÏ…W§', '273519@oyoedu.ng', '8062319481', 'KINSLEY SPRING', 'OYO', '273519'),
(3520, '273520', 'úÏ…W§', '273520@oyoedu.ng', '8092683576', 'THE VOICE OF GOD', 'OYO', '273520'),
(3521, '273521', 'úÏ…W§', '273521@oyoedu.ng', '8054008712', 'OYO MODEL COMP COLL', 'OYO', '273521'),
(3522, '273522', 'úÏ…W§', '273522@oyoedu.ng', '7068848933', 'DOMINION COMP SCH', 'OYO', '273522'),
(3523, '273523', 'úÏ…W§', '273523@oyoedu.ng', '8033879807', 'DOMINION COMP SCH', 'EKITI', '273523'),
(3524, '273524', 'úÏ…W§', '273524@oyoedu.ng', '8035231230', 'QUEENS SCH', 'OYO', '273524'),
(3525, '273525', 'úÏ…W§', '273525@oyoedu.ng', '8035697542', 'CLEVER LAND COLLEGE', 'OYO', '273525'),
(3526, '273526', 'úÏ…W§', '273526@oyoedu.ng', '8055956505', 'UPPER STANDARD COLLEGE', 'OYO', '273526'),
(3527, '273527', 'úÏ…W§', '273527@oyoedu.ng', '8154826665', 'UPPER STANDARD COLLEGE', 'OYO', '273527'),
(3528, '273528', 'úÏ…W§', '273528@oyoedu.ng', '7018169646', 'BISHOP ALINYELE', 'OYO', '273528'),
(3529, '273529', 'úÏ…W§', '273529@oyoedu.ng', '7035134744', 'DIVINE ACUMEN', 'OYO', '273529'),
(3530, '273530', 'úÏ…W§', '273530@oyoedu.ng', '8073819126', 'MERIT COMP', 'OSUN', '273530'),
(3531, '273531', 'úÏ…W§', '273531@oyoedu.ng', '7057160440', 'CARITAS SEC. SCH', 'OYO', '273531'),
(3532, '273532', 'úÏ…W§', '273532@oyoedu.ng', '8163635976', 'GODS HERITAGE', 'OYO', '273532'),
(3533, '273533', 'úÏ…W§', '273533@oyoedu.ng', '7065574655', 'V.A.A OXFORD', 'OYO', '273533'),
(3534, '273534', 'úÏ…W§', '273534@oyoedu.ng', '7034594624', 'WISDOM SEAT', 'OYO', '273534'),
(3535, '273535', 'úÏ…W§', '273535@oyoedu.ng', '8035325001', 'HILLCRESH HIGH SCH', 'OYO', '273535'),
(3536, '273536', 'úÏ…W§', '273536@oyoedu.ng', '8154062479', 'HILLCRESH HIGH SCH', 'OYO', '273536'),
(3537, '273537', 'úÏ…W§', '273537@oyoedu.ng', '8034726079', 'HIGHER HIGHT COLLEGE', 'OYO', '273537'),
(3538, '273538', 'úÏ…W§', '273538@oyoedu.ng', '8053135534', 'ORITAMEFA BAPTIST MODEL', 'OGUN', '273538'),
(3539, '273539', 'úÏ…W§', '273539@oyoedu.ng', '8101889232', 'QUEENS SCH', 'OYO', '273539'),
(3540, '273540', 'úÏ…W§', '273540@oyoedu.ng', '9069294788', 'CEDARS HEIGHT', 'OYO', '273540'),
(3541, '273541', 'úÏ…W§', '273541@oyoedu.ng', '8056127813', 'YEJIDE GIRLS', 'OYO', '273541'),
(3542, '273542', 'úÏ…W§', '273542@oyoedu.ng', '8022069216', 'LASTING GLORY COMP SCH', 'OYO', '273542'),
(3543, '273543', 'úÏ…W§', '273543@oyoedu.ng', '8060404459', 'SUMMIT COMP SCH', 'OYO', '273543'),
(3544, '273544', 'úÏ…W§', '273544@oyoedu.ng', '8076125826', 'ADESINA COLLEGE', 'OYO', '273544'),
(3545, '273545', 'úÏ…W§', '273545@oyoedu.ng', '8176773353', 'EMESTH CHRIST', 'OGUN', '273545'),
(3546, '273546', 'úÏ…W§', '273546@oyoedu.ng', '8023928611', 'SOLAM MODEL', 'OYO', '273546'),
(3547, '273547', 'úÏ…W§', '273547@oyoedu.ng', '8061136808', 'GREATER GLORY', 'OYO', '273547'),
(3548, '273548', 'úÏ…W§', '273548@oyoedu.ng', '7080700039', 'EVER GREEN COMP COLL', 'EKITI', '273548'),
(3549, '273549', 'úÏ…W§', '273549@oyoedu.ng', '8023254959', 'GOODNEWS', 'OSUN', '273549'),
(3550, '273550', 'úÏ…W§', '273550@oyoedu.ng', '8056526372', 'CARITAS', 'OYO', '273550'),
(3551, '273551', 'úÏ…W§', '273551@oyoedu.ng', '8067112961', 'AANU-OLU COLLEGE', 'OYO', '273551'),
(3552, '273552', 'úÏ…W§', '273552@oyoedu.ng', '9079684148', 'IKIRE MUSLIM GRA', 'OYO', '273552'),
(3553, '273553', 'úÏ…W§', '273553@oyoedu.ng', '9015546510', 'JESUS THE ROCK', 'OYO', '273553'),
(3554, '273554', 'úÏ…W§', '273554@oyoedu.ng', '8059163407', 'ALIATAB ACADEMY', 'OYO', '273554'),
(3555, '273555', 'úÏ…W§', '273555@oyoedu.ng', '8055949915', 'GOLDEN GATE', 'OSUN', '273555'),
(3556, '273556', 'úÏ…W§', '273556@oyoedu.ng', '8187276644', 'KINGDOM MANDATE', 'OYO', '273556'),
(3557, '273557', 'úÏ…W§', '273557@oyoedu.ng', '8169710867', 'JOINT HEIR SEC SCH', 'ONDO', '273557'),
(3558, '273558', 'úÏ…W§', '273558@oyoedu.ng', '8034401117', 'PRESTIGE INT COLLEGE', 'OYO', '273558'),
(3559, '273559', 'úÏ…W§', '273559@oyoedu.ng', '8186349191', 'THYWILL COLLEGE', 'OYO', '273559'),
(3560, '273560', 'úÏ…W§', '273560@oyoedu.ng', '8136916002', 'METHODIST GRA SCH', 'OYO', '273560'),
(3561, '373561', 'úÏ…W§', '373561@oyoedu.ng', '8033560350', 'FOUNDATION COLLEGE', 'OYO', '373561'),
(3562, '273562', 'úÏ…W§', '273562@oyoedu.ng', '9038232132', 'ORITOTE HIGH SCH', 'OYO', '273562'),
(3563, '273563', 'úÏ…W§', '273563@oyoedu.ng', '8060667910', 'SPRINGS OF WISDOM', 'OYO', '273563'),
(3564, '273564', 'úÏ…W§', '273564@oyoedu.ng', '7034812482', 'GREAT GRACE ACEDEMY', 'OYO', '273564'),
(3565, '273565', 'úÏ…W§', '273565@oyoedu.ng', '8060129112', 'MIGHTY GRACE', 'OYO', '273565'),
(3566, '273566', 'úÏ…W§', '273566@oyoedu.ng', '8055200788', 'LAGELU GRA SCH', 'OYO', '273566'),
(3567, '273567', 'úÏ…W§', '273567@oyoedu.ng', '8168947304', 'JEJE MEMORIAL SCH', 'OYO', '273567'),
(3568, '373568', 'úÏ…W§', '373568@oyoedu.ng', '8064490380', 'SOLID FOUNDATION', 'OYO', '373568'),
(3569, '273569', 'úÏ…W§', '273569@oyoedu.ng', '8088158834', 'THE SCEPTRE SCIENCE', 'DELTA', '273569'),
(3570, '273570', 'úÏ…W§', '273570@oyoedu.ng', '8067144181', 'DE -AYO INT COLLEGE', 'OGUN', '273570'),
(3571, '273571', 'úÏ…W§', '273571@oyoedu.ng', '8034776990', 'C.G.S RINGRD', 'OYO', '273571'),
(3572, '273572', 'úÏ…W§', '273572@oyoedu.ng', '8033683643', 'THE ARABIAN COLLEGE', 'OYO', '273572'),
(3573, '273573', 'úÏ…W§', '273573@oyoedu.ng', '8035588333', 'MODESTY EXCEL', 'OYO', '273573'),
(3574, '273574', 'úÏ…W§', '273574@oyoedu.ng', '8029964500', 'ORITAMEFA BAPTIST MODEL', 'OYO', '273574'),
(3575, '273575', 'úÏ…W§', '273575@oyoedu.ng', '8054222041', 'CIFMAN COLLEGE', 'OYO', '273575'),
(3576, '273576', 'úÏ…W§', '273576@oyoedu.ng', '8028794988', 'GLORIOUS COLLEGE', 'OSUN ', '273576'),
(3577, '273577', 'úÏ…W§', '273577@oyoedu.ng', '8036699329', 'ROYAL GENERATION', 'AKAWIBO', '273577'),
(3578, '273578', 'úÏ…W§', '273578@oyoedu.ng', '8068145445', 'BODIJA ASHI BAP', 'OYO', '273578'),
(3579, '273579', 'úÏ…W§', '273579@oyoedu.ng', '8038038394', 'SAMARAJ ACADEMY', 'OYO', '273579'),
(3580, '273580', 'úÏ…W§', '273580@oyoedu.ng', '8034555341', 'PRECIOUS ROCK', 'OGUN', '273580'),
(3581, '273581', 'úÏ…W§', '273581@oyoedu.ng', '7085822610', 'G.C.I APATA', 'OYO', '273581'),
(3582, '373582', 'úÏ…W§', '373582@oyoedu.ng', '7085822610', 'LINKRIGHT COLLEGE', 'OYO', '373582'),
(3583, '273583', 'úÏ…W§', '273583@oyoedu.ng', '8027081369', 'LINKRIGHT COLLEGE', 'OYO', '273583'),
(3584, '273584', 'úÏ…W§', '273584@oyoedu.ng', '7036939215', 'SUMMIT COMP', 'OYO', '273584'),
(3585, '273585', 'úÏ…W§', '273585@oyoedu.ng', '8165037393', 'SUMMIT COMP', 'OYO', '273585'),
(3586, '273586', 'úÏ…W§', '273586@oyoedu.ng', '7036939215', 'SUMMIT COMP', 'OYO', '273586'),
(3587, '273587', 'úÏ…W§', '273587@oyoedu.ng', '7036939215', 'SUMMIT COMP', 'OSUN', '273587'),
(3588, '273588', 'úÏ…W§', '273588@oyoedu.ng', '9050518854', 'ASSURANCE HIGH SCH', 'OYO', '273588'),
(3589, '273589', 'úÏ…W§', '273589@oyoedu.ng', '8030828287', 'ASSURANCE HIGH SCH', 'OYO', '273589'),
(3590, '273590', 'úÏ…W§', '273590@oyoedu.ng', '9028195808', 'IBNU TAEWYAH', 'OYO', '273590'),
(3591, '273591', 'úÏ…W§', '273591@oyoedu.ng', '7081563450', 'ALBARKA GROUP', 'OYO', '273591'),
(3592, '273592', 'úÏ…W§', '273592@oyoedu.ng', '8054009342', 'STAR COMP COLLEG', 'OYO', '273592'),
(3593, '273593', 'úÏ…W§', '273593@oyoedu.ng', '8023820638', 'ABIMBOLA EXCEL', 'OYO', '273593'),
(3594, '273594', 'úÏ…W§', '273594@oyoedu.ng', '8052065895', 'ICAGS 2', 'OYO', '273594'),
(3595, '273595', 'úÏ…W§', '273595@oyoedu.ng', '8032728626', 'O.B.H.S', 'OYO', '273595'),
(3596, '273596', 'úÏ…W§', '273596@oyoedu.ng', '8030757627', 'LIFE CARE COLLEGE', 'OYO', '273596'),
(3597, '273597', 'úÏ…W§', '273597@oyoedu.ng', '8134936741', 'STEPPING STONE', 'OYO', '273597'),
(3598, '273598', 'úÏ…W§', '273598@oyoedu.ng', '8092120646', 'REGINA JAMES', 'OYO', '273598'),
(3599, '273599', 'úÏ…W§', '273599@oyoedu.ng', '8055122164', 'CRYSTAL BLESSING', 'OYO', '273599'),
(3600, '273600', 'úÏ…W§', '273600@oyoedu.ng', '8104257210', 'SUMMIT COMP', 'OYO', '273600'),
(3601, '273601', 'úÏ…W§', '273601@oyoedu.ng', '8104257210', 'SUMMIT COMP', 'OYO', '273601'),
(3602, '273602', 'úÏ…W§', '273602@oyoedu.ng', '8059801069', 'CGS EGBADE', 'OYO', '273602'),
(3603, '273603', 'úÏ…W§', '273603@oyoedu.ng', '7039296001', 'CARISTAS SEC', 'OYO', '273603'),
(3604, '273604', 'úÏ…W§', '273604@oyoedu.ng', '7039296001', 'CARISTAS SEC', 'OYO', '273604'),
(3605, '273605', 'úÏ…W§', '273605@oyoedu.ng', '8034657156', 'AGAPE GROUP', 'IMO', '273605'),
(3606, '273606', 'úÏ…W§', '273606@oyoedu.ng', '8030677607', 'AL-GHAYAT COLLEGE', 'OYO', '273606'),
(3607, '273607', 'úÏ…W§', '273607@oyoedu.ng', '7030128002', 'KINGSLEY SPRING COLL', 'OYO', '273607'),
(3608, '273608', 'úÏ…W§', '273608@oyoedu.ng', '8023654135', 'AGBEDE JUNIOR', 'OYO', '273608'),
(3609, '273609', 'úÏ…W§', '273609@oyoedu.ng', '8034629645', 'EVERGREEN HIGH SCH', 'OYO', '273609'),
(3610, '273610', 'úÏ…W§', '273610@oyoedu.ng', '8059419699', 'EXCELENT ACADEMY', 'OYO', '273610'),
(3611, '273611', 'úÏ…W§', '273611@oyoedu.ng', '8077788063', 'POTTERS HOUSE', 'OYO', '273611'),
(3612, '273612', 'úÏ…W§', '273612@oyoedu.ng', '8033840889', 'STEPPING STONE', 'OYO', '273612'),
(3613, '273613', 'úÏ…W§', '273613@oyoedu.ng', '8039355150', 'ESCA COLLEGE', 'OSUN', '273613'),
(3614, '273614', 'úÏ…W§', '273614@oyoedu.ng', '8055518060', 'CARISTAS SEC', 'OYO', '273614'),
(3615, '273615', 'úÏ…W§', '273615@oyoedu.ng', '8037059378', 'OMOLOLA WISDOM', 'OYO', '273615'),
(3616, '373616', 'úÏ…W§', '373616@oyoedu.ng', '8136129233', 'ADONAI GRAMMER SCH', 'OYO', '373616'),
(3617, '273617', 'úÏ…W§', '273617@oyoedu.ng', '8065827108', 'IB GRAMMER SCH', 'OYO', '273617'),
(3618, '273618', 'úÏ…W§', '273618@oyoedu.ng', '9025955632', 'SUPREME EXCEL. ACADEMY', 'OSUN', '273618'),
(3619, '273619', 'úÏ…W§', '273619@oyoedu.ng', '7038256144', 'GLORIOUS COLLEGE', 'OYO', '273619'),
(3620, '273620', 'úÏ…W§', '273620@oyoedu.ng', '7038256144', 'GLORIOUS COLLEGE', 'OYO', '273620'),
(3621, '273621', 'úÏ…W§', '273621@oyoedu.ng', '8179133045', 'ALALEEM MODEL SCH', 'OYO', '273621'),
(3622, '273622', 'úÏ…W§', '273622@oyoedu.ng', '8179133045', 'ALALEEM MODEL SCH', 'OYO', '273622'),
(3623, '273623', 'úÏ…W§', '273623@oyoedu.ng', '8102619934', 'BETHEL CITY', 'OYO', '273623'),
(3624, '273624', 'úÏ…W§', '273624@oyoedu.ng', '8102231835', 'THE NOBEL STAND', 'OYO', '273624'),
(3625, '273625', 'úÏ…W§', '273625@oyoedu.ng', '8114196647', 'TUNMOISE COMP', 'OYO', '273625'),
(3626, '273626', 'úÏ…W§', '273626@oyoedu.ng', '8105409643', 'GOVT. SEC SCH', 'OYO', '273626'),
(3627, '273627', 'úÏ…W§', '273627@oyoedu.ng', '8072931349', 'SEGMOR MODEL', 'OYO', '273627'),
(3628, '273628', 'úÏ…W§', '273628@oyoedu.ng', '8113536176', 'MIRROR OF GOD', 'ONDO', '273628'),
(3629, '273629', 'úÏ…W§', '273629@oyoedu.ng', '8033783354', 'QUEEN SCH AJATA', 'OYO', '273629'),
(3630, '273630', 'úÏ…W§', '273630@oyoedu.ng', '8067438202', 'ADESINA COLLEGE', 'OSUN', '273630'),
(3631, '273631', 'úÏ…W§', '273631@oyoedu.ng', '7037261994', 'SAWIA GOVT', 'OYO', '273631'),
(3632, '273632', 'úÏ…W§', '273632@oyoedu.ng', '9050191942', 'BAPTIST MODEL IWO RD.', 'OSUN', '273632'),
(3633, '273633', 'úÏ…W§', '273633@oyoedu.ng', '7037503192', 'PROVAIENCE', 'EKITI', '273633'),
(3634, '273634', 'úÏ…W§', '273634@oyoedu.ng', '8077270509', 'BLESSED FOUNDATION', 'OYO', '273634'),
(3635, '273635', 'úÏ…W§', '273635@oyoedu.ng', '8077270509', 'BLESSED FOUNDATION', 'OYO', '273635'),
(3636, '273636', 'úÏ…W§', '273636@oyoedu.ng', '9067431240', 'FUTURE COMP', 'OYO', '273636'),
(3637, '273637', 'úÏ…W§', '273637@oyoedu.ng', '9049728924', 'ENODAS SCH', 'OYO', '273637'),
(3638, '273638', 'úÏ…W§', '273638@oyoedu.ng', '8033935468', 'ADEWUNI MEM', 'OYO', '273638'),
(3639, '273639', 'úÏ…W§', '273639@oyoedu.ng', '8033714097', 'CITADEL', 'OYO', '273639'),
(3640, '273640', 'úÏ…W§', '273640@oyoedu.ng', '7059595669', 'COMM GRA SCH', 'OYO', '273640'),
(3641, '273641', 'úÏ…W§', '273641@oyoedu.ng', '8076004963', 'DARASIMI GROUP OF SCH', 'OYO', '273641'),
(3642, '273642', 'úÏ…W§', '273642@oyoedu.ng', '8066494483', 'ROYAL CHILD', 'OYO', '273642'),
(3643, '273643', 'úÏ…W§', '273643@oyoedu.ng', '8032071164', 'GENESIS', 'OYO', '273643'),
(3644, '273644', 'úÏ…W§', '273644@oyoedu.ng', '7061610541', 'TOP CROWN COLLEGE', 'OYO', '273644'),
(3645, '273645', 'úÏ…W§', '273645@oyoedu.ng', '8054048407', 'ICA', 'OYO', '273645'),
(3646, '273646', 'úÏ…W§', '273646@oyoedu.ng', '8033971007', 'UPPER STANDARD COLLEGE', 'OYO', '273646'),
(3647, '273647', 'úÏ…W§', '273647@oyoedu.ng', '8034290004', 'CANAAN CITY', 'OYO', '273647'),
(3648, '273648', 'úÏ…W§', '273648@oyoedu.ng', '8053595344', 'CANAAN CITY', '', '273648'),
(3649, '273649', 'úÏ…W§', '273649@oyoedu.ng', '903901621', 'OLUNDE COMM', 'OYO', '273649'),
(3650, '273650', 'úÏ…W§', '273650@oyoedu.ng', '8034719997', 'OYO STATE COMP', 'OYO', '273650'),
(3651, '273651', 'úÏ…W§', '273651@oyoedu.ng', '8055838290', 'ADEM SEC SCH', 'OYO', '273651'),
(3652, '273652', 'úÏ…W§', '273652@oyoedu.ng', '8039382483', 'LYDEB COMP', 'OYO', '273652'),
(3653, '273653', 'úÏ…W§', '273653@oyoedu.ng', '8078984694', 'OYSCO MODEL', 'OYO', '273653'),
(3654, '273654', 'úÏ…W§', '273654@oyoedu.ng', '8055936192', 'GODS GRACE', 'OYO', '273654'),
(3655, '273655', 'úÏ…W§', '273655@oyoedu.ng', '8056427851', 'GODS GRACE', 'OYO', '273655'),
(3656, '273656', 'úÏ…W§', '273656@oyoedu.ng', '8116964163', 'SUPREME COLLEGE', 'OYO', '273656'),
(3657, '273657', 'úÏ…W§', '273657@oyoedu.ng', '8116964163', 'SUPREME COLLEGE', 'OYO', '273657'),
(3658, '273658', 'úÏ…W§', '273658@oyoedu.ng', '7052626065', 'JESUS THE ROCK', 'OYO', '273658'),
(3659, '273659', 'úÏ…W§', '273659@oyoedu.ng', '7035673149', 'GOVT. SEC SCH', 'OYO', '273659'),
(3660, '273660', 'úÏ…W§', '273660@oyoedu.ng', '8106756856', 'RICHDEL MODEL COLLEGE', 'KWARA', '273660'),
(3661, '273661', 'úÏ…W§', '273661@oyoedu.ng', '8055052082', 'MARVELOUS ', 'OYO', '273661'),
(3662, '273662', 'úÏ…W§', '273662@oyoedu.ng', '8077468736', 'ADINI INT. SCH', 'OYO', '273662'),
(3663, '273663', 'úÏ…W§', '273663@oyoedu.ng', '8103204870', 'AL-IHSAN ACADEMY', 'OYO', '273663'),
(3664, '273664', 'úÏ…W§', '273664@oyoedu.ng', '8032637398', 'AL-QOUUIY', 'OYO', '273664'),
(3665, '273665', 'úÏ…W§', '273665@oyoedu.ng', '8032637398', 'GOVT SEC', 'OYO', '273665'),
(3666, '273666', 'úÏ…W§', '273666@oyoedu.ng', '8059914618', 'OMOIE JNR SEC', 'OYO', '273666'),
(3667, '273667', 'úÏ…W§', '273667@oyoedu.ng', '8144114258', 'ABADINA COLLEGE', 'OYO', '273667'),
(3668, '273668', 'úÏ…W§', '273668@oyoedu.ng', '7051328043', 'ALL SOULS HIGH', 'OYO', '273668'),
(3669, '273669', 'úÏ…W§', '273669@oyoedu.ng', '8052828100', 'IGBOORA GRA SCH', 'OYO', '273669'),
(3670, '273670', 'úÏ…W§', '273670@oyoedu.ng', '81079324522', 'GODS HERITAGE', 'OYO', '273670'),
(3671, '273671', 'úÏ…W§', '273671@oyoedu.ng', '8105640009', 'ROCKY FOUNDATION', 'OYO', '273671'),
(3672, '273672', 'úÏ…W§', '273672@oyoedu.ng', '8023842242', 'ASEGUN COMP', 'OYO', '273672'),
(3673, '273673', 'úÏ…W§', '273673@oyoedu.ng', '8055866913', 'IBRAHIM', 'OYO', '273673'),
(3674, '273674', 'úÏ…W§', '273674@oyoedu.ng', '8132665626', 'QUEEN SCH AJATA', 'OYO', '273674'),
(3675, '273675', 'úÏ…W§', '273675@oyoedu.ng', '8136349288', 'REGINA JAMES', 'OYO', '273675'),
(3676, '273676', 'úÏ…W§', '273676@oyoedu.ng', '8032600475', 'REGINA JAMES', 'OYO', '273676'),
(3677, '273677', 'úÏ…W§', '273677@oyoedu.ng', '8032600475', 'CALVARY GRACE', 'OYO', '273677'),
(3678, '273678', 'úÏ…W§', '273678@oyoedu.ng', '8131235257', 'GOODNEWS', 'OYO', '273678'),
(3679, '273679', 'úÏ…W§', '273679@oyoedu.ng', '8078305289', 'CATOLIC ISENIN', 'OYO', '273679'),
(3680, '273680', 'úÏ…W§', '273680@oyoedu.ng', '8058353388', 'GLORY FIELD', 'OYO', '273680'),
(3681, '273681', 'úÏ…W§', '273681@oyoedu.ng', '8064478541', 'RICHDEL MODEL COLLEGE', 'OYO', '273681'),
(3682, '273682', 'úÏ…W§', '273682@oyoedu.ng', '8057965498', 'RICHDEL MODEL COLLEGE', 'OYO', '273682'),
(3683, '273683', 'úÏ…W§', '273683@oyoedu.ng', '9064401584', 'DECREE INT', 'OSUN', '273683'),
(3684, '273684', 'úÏ…W§', '273684@oyoedu.ng', '7084392111', 'METHODIST GRA SCH', 'EDO', '273684'),
(3685, '273685', 'úÏ…W§', '273685@oyoedu.ng', '9073440687', 'AL-TAKBIRAIGD', 'OYO', '273685'),
(3686, '273686', 'úÏ…W§', '273686@oyoedu.ng', '8146284530', 'DISTINCT JUBILEE', 'OYO', '273686'),
(3687, '273687', 'úÏ…W§', '273687@oyoedu.ng', '8077833329', 'BISHOP PHILIPS', 'OYO', '273687'),
(3688, '273688', 'úÏ…W§', '273688@oyoedu.ng', '8054456082', 'MACMAN COLLEGE', 'EDO', '273688'),
(3689, '273689', 'úÏ…W§', '273689@oyoedu.ng', '8122795128', 'ARIYODNT', 'OYO', '273689'),
(3690, '273690', 'úÏ…W§', '273690@oyoedu.ng', '8136397312', 'FLIER INT SCH', 'OYO', '273690'),
(3691, '273691', 'úÏ…W§', '273691@oyoedu.ng', '8036713181', 'ALL AGES COLLEGE', 'OYO', '273691'),
(3692, '273692', 'úÏ…W§', '273692@oyoedu.ng', '8132682867', 'LOISEM PRIVATE', 'OYO', '273692'),
(3693, '273693', 'úÏ…W§', '273693@oyoedu.ng', '8073230281', 'IGBOORA HIGH SCH', 'OYO', '273693'),
(3694, '273694', 'úÏ…W§', '273694@oyoedu.ng', '8035777323', 'SUCCESS CARE', 'OYO', '273694'),
(3695, '273695', 'úÏ…W§', '273695@oyoedu.ng', '7053995207', 'GOD\'S GRACE', 'OYO', '273695'),
(3696, '273696', 'úÏ…W§', '273696@oyoedu.ng', '7019661364', 'CHRIST LIFE COLLEGE', 'OYO', '273696'),
(3697, '273697', 'úÏ…W§', '273697@oyoedu.ng', '8078294470', 'COGNITIVE', 'EDO', '273697'),
(3698, '273698', 'úÏ…W§', '273698@oyoedu.ng', '8038224793', 'U.D.G.S', 'OSUN', '273698'),
(3699, '273699', 'úÏ…W§', '273699@oyoedu.ng', '7035310545', 'CONFIDENCE ACADEMY', 'OYO', '273699'),
(3700, '273700', 'úÏ…W§', '273700@oyoedu.ng', '9039020041', 'SMABLGF COLLEGE', 'OYO', '273700'),
(3701, '273701', 'úÏ…W§', '273701@oyoedu.ng', '7031363328', 'GUARVERD GROUP', 'OYO', '273701'),
(3702, '273702', 'úÏ…W§', '273702@oyoedu.ng', '8122786911', 'ECWA MODEL', 'OGUN', '273702'),
(3703, '273703', 'úÏ…W§', '273703@oyoedu.ng', '8053226337', 'BAPTIST MODEL IWO RD.', 'OYO', '273703'),
(3704, '273704', 'úÏ…W§', '273704@oyoedu.ng', '8077455310', 'LANTEN JUNIOR', 'OYO', '273704'),
(3705, '273705', 'úÏ…W§', '273705@oyoedu.ng', '8038629199', 'TIMELI HIGH SCH', 'OYO', '273705'),
(3706, '273706', 'úÏ…W§', '273706@oyoedu.ng', '7061962899', 'IMPART COLLEGE', 'OYO', '273706'),
(3707, '273707', 'úÏ…W§', '273707@oyoedu.ng', '9031781328', 'VICTORY GROUP', 'OYO', '273707'),
(3708, '273708', 'úÏ…W§', '273708@oyoedu.ng', '8034665613', 'VICTORY GROUP', 'OYO', '273708'),
(3709, '273709', 'úÏ…W§', '273709@oyoedu.ng', '8038060874', 'BEACON TOTAL', 'OYO', '273709'),
(3710, '273710', 'úÏ…W§', '273710@oyoedu.ng', '8035290926', 'AL-GHAYAT COLLEGE', 'OYO', '273710'),
(3711, '273711', 'úÏ…W§', '273711@oyoedu.ng', '8055306989', 'ACHIEVER COMP', 'OYO', '273711'),
(3712, '273712', 'úÏ…W§', '273712@oyoedu.ng', '8033779822', 'BEULAH ACADEMY', 'OYO', '273712'),
(3713, '273713', 'úÏ…W§', '273713@oyoedu.ng', '8023259876', 'JESUS THE ROCK', 'OSUN', '273713'),
(3714, '273714', 'úÏ…W§', '273714@oyoedu.ng', '8088423280', 'BAPTIST MODEL ', 'OYO', '273714'),
(3715, '273715', 'úÏ…W§', '273715@oyoedu.ng', '8077270509', 'GENESIS FOUNDATION', 'OYO', '273715'),
(3716, '273716', 'úÏ…W§', '273716@oyoedu.ng', '8030757627', 'COMMAND SEC SCH MOKOLA', 'OYO', '273716'),
(3717, '273717', 'úÏ…W§', '273717@oyoedu.ng', '7084504670', 'GLORY FIELD', 'OYO', '273717'),
(3718, '273718', 'úÏ…W§', '273718@oyoedu.ng', '8130582627', 'IMPACT MODEL COLL', 'OYO', '273718'),
(3719, '273719', 'úÏ…W§', '273719@oyoedu.ng', '9012886472', 'OLAD MODEL', 'OYO', '273719'),
(3720, '273720', 'úÏ…W§', '273720@oyoedu.ng', '9062215002', 'ICAGS 2', 'OYO', '273720'),
(3721, '273721', 'úÏ…W§', '273721@oyoedu.ng', '8149272842', 'EMMATOLY COLLEGE', 'OGUN', '273721'),
(3722, '273722', 'úÏ…W§', '273722@oyoedu.ng', '8059445207', 'QUEEN SCH APATA', 'OGUN', '273722'),
(3723, '273723', 'úÏ…W§', '273723@oyoedu.ng', '8074499455', 'HILL CREST HIGH SCH', 'OYO', '273723'),
(3724, '273724', 'úÏ…W§', '273724@oyoedu.ng', '8023408162', 'MORET COMP COLLEGE', 'OYO', '273724'),
(3725, '273725', 'úÏ…W§', '273725@oyoedu.ng', '7030329164', 'NESTO COLLEGE', 'OYO', '273725'),
(3726, '273726', 'úÏ…W§', '273726@oyoedu.ng', '8056714046', 'ABIMBOLA EXCEL', 'OYO', '273726'),
(3727, '373727', 'úÏ…W§', '373727@oyoedu.ng', '8035665510', 'BAPTIST MODEL IWO RD.', 'OYO', '373727'),
(3728, '273728', 'úÏ…W§', '273728@oyoedu.ng', '', 'LIFESTAR FIG ACADEMY', 'OGUN', '273728'),
(3729, '273729', 'úÏ…W§', '273729@oyoedu.ng', '8060667910', 'GLORY COMP SCH', 'OYO', '273729'),
(3730, '273730', 'úÏ…W§', '273730@oyoedu.ng', '8130374950', 'BOTEF INT COLL', 'OYO', '273730'),
(3731, '273731', 'úÏ…W§', '273731@oyoedu.ng', '8160148156', 'CLEVER LAND COLLEGE', 'OYO', '273731'),
(3732, '273732', 'úÏ…W§', '273732@oyoedu.ng', '8109807183', 'ARK OF GOD', 'OYO', '273732'),
(3733, '273733', 'úÏ…W§', '273733@oyoedu.ng', '8162460349', 'ARK OF GOD', 'OYO', '273733'),
(3734, '273734', 'úÏ…W§', '273734@oyoedu.ng', '8033812362', 'SEBTECT IB', 'OYO', '273734'),
(3735, '273735', 'úÏ…W§', '273735@oyoedu.ng', '80333812362', 'SEBTER IB.', 'OYO', '273735'),
(3736, '273736', 'úÏ…W§', '273736@oyoedu.ng', '8052472914', 'GOVT SCH SCH JNR 2', 'OYO', '273736'),
(3737, '273737', 'úÏ…W§', '273737@oyoedu.ng', '9029442201', 'ECWA MODEL', 'OGUN', '273737'),
(3738, '273738', 'úÏ…W§', '273738@oyoedu.ng', '8071868913', 'AL-IMIN', 'OYO', '273738'),
(3739, '273739', 'úÏ…W§', '273739@oyoedu.ng', '8139670935', 'ADEJARE INT SCH', 'OYO', '273739'),
(3740, '373740', 'úÏ…W§', '373740@oyoedu.ng', '8052310445', 'SEGAS COMP', 'OYO', '373740'),
(3741, '273741', 'úÏ…W§', '273741@oyoedu.ng', '8034807605', 'SYNERGY COLLEGE', 'OYO', '273741'),
(3742, '273742', 'úÏ…W§', '273742@oyoedu.ng', '8038076568', 'LOYOLA COLLEGE', 'OYO', '273742'),
(3743, '273743', 'úÏ…W§', '273743@oyoedu.ng', '8153039141', 'HELPING COLLEGE', 'OYO', '273743'),
(3744, '273744', 'úÏ…W§', '273744@oyoedu.ng', '8034269201', 'EXBHRAIM BAP', 'OYO', '273744'),
(3745, '273745', 'úÏ…W§', '273745@oyoedu.ng', '8036379487', 'AL-ILMIN COMP', 'OYO', '273745'),
(3746, '273746', 'úÏ…W§', '273746@oyoedu.ng', '7019661364', 'A.C.G.S', 'OYO', '273746'),
(3747, '273747', 'úÏ…W§', '273747@oyoedu.ng', '9014468078', 'POLICE SEC SCH', 'OSUN', '273747'),
(3748, '273748', 'úÏ…W§', '273748@oyoedu.ng', '8052022332', 'ABIMBOLA EXCEL COLLEGE', 'OYO', '273748'),
(3749, '273749', 'úÏ…W§', '273749@oyoedu.ng', '8064450775', 'AL-KITAB MOD3L', 'OYO', '273749'),
(3750, '273750', 'úÏ…W§', '273750@oyoedu.ng', '8027526503', 'STAR COMP COLLEG', 'OYO', '273750'),
(3751, '273751', 'úÏ…W§', '273751@oyoedu.ng', '8028632827', 'GOVT SEC SCH', 'OYO', '273751'),
(3752, '273752', 'úÏ…W§', '273752@oyoedu.ng', '8033049048', 'ANU-OLU COMP', 'OYO', '273752'),
(3753, '273753', 'úÏ…W§', '273753@oyoedu.ng', '8118871542', 'AACG SCH', 'OYO', '273753'),
(3754, '273754', 'úÏ…W§', '273754@oyoedu.ng', '8118871542', 'ANU-OLU COMP', 'OYO', '273754'),
(3755, '273755', 'úÏ…W§', '273755@oyoedu.ng', '8051018769', 'CAC GRAMMER', 'OYO', '273755'),
(3756, '273756', 'úÏ…W§', '273756@oyoedu.ng', '8038064115', 'GLORIOUS COLLEGE', 'OYO', '273756'),
(3757, '273757', 'úÏ…W§', '273757@oyoedu.ng', '8029009151', 'TRIUMPH COLLEGE', 'EKITI', '273757'),
(3758, '273758', 'úÏ…W§', '273758@oyoedu.ng', '8108866375', 'OLUFUMI COLL', 'EKITI', '273758'),
(3759, '273759', 'úÏ…W§', '273759@oyoedu.ng', '8071059124', 'TRIOLAS COLLEGE', 'OYO', '273759'),
(3760, '273760', 'úÏ…W§', '273760@oyoedu.ng', '8058582636', 'C.H.S.J', 'OYO', '273760'),
(3761, '273761', 'úÏ…W§', '273761@oyoedu.ng', '8038457760', 'UMUL DURA HIGH', 'OYO', '273761'),
(3762, '273762', 'úÏ…W§', '273762@oyoedu.ng', '8037225571', 'GENESIS FOUNDATION', 'OYO', '273762'),
(3763, '273763', 'úÏ…W§', '273763@oyoedu.ng', '8037225571', 'GENESIS FOUNDATION', 'OYO', '273763'),
(3764, '273764', 'úÏ…W§', '273764@oyoedu.ng', '8073682305', 'HIGH FLYER', 'EDO', '273764'),
(3765, '273765', 'úÏ…W§', '273765@oyoedu.ng', '8064485921', 'IBNU TAEWYAH', 'OYO', '273765'),
(3766, '273766', 'úÏ…W§', '273766@oyoedu.ng', '8064485921', 'IBNU TAEWYAH', 'OYO', '273766'),
(3767, '273767', 'úÏ…W§', '273767@oyoedu.ng', '8064485921', 'IBNU TAEWYAH', 'OYO', '273767'),
(3768, '273768', 'úÏ…W§', '273768@oyoedu.ng', '8023489456', 'COMP HIGH SCH', 'OYO', '273768'),
(3769, '273769', 'úÏ…W§', '273769@oyoedu.ng', '8165387524', 'BAABU-ROVYAAN', 'OYO', '273769'),
(3770, '273770', 'úÏ…W§', '273770@oyoedu.ng', '8165387524', 'BAABU-ROVYAAN', 'OYO', '273770'),
(3771, '273771', 'úÏ…W§', '273771@oyoedu.ng', '8165387524', 'BAABU-ROVYAAN', 'OYO', '273771'),
(3772, '273772', 'úÏ…W§', '273772@oyoedu.ng', '8126441278', 'ONA ARA REGENT', 'OYO', '273772'),
(3773, '273773', 'úÏ…W§', '273773@oyoedu.ng', '7063684711', 'EMUBASSY COLLEGE', 'OYO', '273773'),
(3774, '373774', 'úÏ…W§', '373774@oyoedu.ng', '8075632434', 'SAMKAY COLLEGE', 'OYO', '373774'),
(3775, '273775', 'úÏ…W§', '273775@oyoedu.ng', '8080846325', 'GRACE FIELD COLLEGE', 'OYO', '273775'),
(3776, '273776', 'úÏ…W§', '273776@oyoedu.ng', '8057783133', 'A MAKERS COLLEGE', 'OYO', '273776'),
(3777, '273777', 'úÏ…W§', '273777@oyoedu.ng', '8067438082', 'LANTEM JUNIOR', 'OYO', '273777'),
(3778, '273778', 'úÏ…W§', '273778@oyoedu.ng', '8060689115', 'JESLORD HIGH', 'OSUN', '273778'),
(3779, '273779', 'úÏ…W§', '273779@oyoedu.ng', '8051540524', 'O.H.S', 'OYO', '273779'),
(3780, '273780', 'úÏ…W§', '273780@oyoedu.ng', '8037735260', 'ISD COMP', 'OYO', '273780'),
(3781, '273781', 'úÏ…W§', '273781@oyoedu.ng', '8024035573', 'GOVT SEC SCH JNR', 'OYO', '273781'),
(3782, '273782', 'úÏ…W§', '273782@oyoedu.ng', '8034121978', 'CHRISTIAN MODEL', 'OSUN', '273782'),
(3783, '273783', 'úÏ…W§', '273783@oyoedu.ng', '8160126161', 'GRACE LAND HEIGHT', 'OYO', '273783'),
(3784, '273784', 'úÏ…W§', '273784@oyoedu.ng', '8038228601', 'LANTEM JUNIOR', 'OYO', '273784'),
(3785, '273785', 'úÏ…W§', '273785@oyoedu.ng', '803465088', 'BAPTIST MISSION', 'OYO', '273785'),
(3786, '273786', 'úÏ…W§', '273786@oyoedu.ng', '8052464954', 'AL-LIMAN ACADEMY', 'OYO', '273786'),
(3787, '273787', 'úÏ…W§', '273787@oyoedu.ng', '7069666149', 'COMFORT UPWARD', 'OYO', '273787'),
(3788, '273788', 'úÏ…W§', '273788@oyoedu.ng', '8067662071', 'LOYOLA COLLEGE', 'OYO', '273788'),
(3789, '273789', 'úÏ…W§', '273789@oyoedu.ng', '8056626916', 'DIVINE RULER COLLEGE', 'OYO', '273789'),
(3790, '273790', 'úÏ…W§', '273790@oyoedu.ng', '8055210771', 'RESTORATION MODEL', 'OSUN', '273790'),
(3791, '273791', 'úÏ…W§', '273791@oyoedu.ng', '8163277098', 'THE COMFORTER', 'OYO', '273791'),
(3792, '273792', 'úÏ…W§', '273792@oyoedu.ng', '8036284269', 'IMIN GRA SCH', 'OYO', '273792'),
(3793, '273793', 'úÏ…W§', '273793@oyoedu.ng', '7039755216', 'FRONT MODEL COLLEGE', 'OSUN', '273793'),
(3794, '273794', 'úÏ…W§', '273794@oyoedu.ng', '8024127745', 'FRONT MODEL COLLEGE', 'OYO', '273794'),
(3795, '273795', 'úÏ…W§', '273795@oyoedu.ng', '8059050995', 'SUMMIT COMP COLLEGE', 'KWARA', '273795'),
(3796, '273796', 'úÏ…W§', '273796@oyoedu.ng', '8059050995', 'I.G.S', 'KWARA', '273796'),
(3797, '273797', 'úÏ…W§', '273797@oyoedu.ng', '7064303938', 'MERIT COMP HIGH', 'OYO', '273797'),
(3798, '273798', 'úÏ…W§', '273798@oyoedu.ng', '8036284269', 'IMIN GRA SCH', 'OYO', '273798'),
(3799, '373799', 'úÏ…W§', '373799@oyoedu.ng', '8155957947', 'QIBLAH', 'EKITI', '373799'),
(3800, '273800', 'úÏ…W§', '273800@oyoedu.ng', '8033569396', 'CEDAR HIGH', 'OYO', '273800'),
(3801, '273801', 'úÏ…W§', '273801@oyoedu.ng', '7011515921', 'FAVOURNET COLLEGE', 'OYO', '273801'),
(3802, '273802', 'úÏ…W§', '273802@oyoedu.ng', '8062876686', 'THE PEARL COLL', 'OYO', '273802'),
(3803, '273803', 'úÏ…W§', '273803@oyoedu.ng', '8130693469', 'THE ROCK', 'OYO', '273803'),
(3804, '273804', 'úÏ…W§', '273804@oyoedu.ng', '8130693469', 'THE ROCK', 'OYO', '273804'),
(3805, '273805', 'úÏ…W§', '273805@oyoedu.ng', '8121444079', 'HIGHER HEIGHT', 'OYO', '273805'),
(3806, '273806', 'úÏ…W§', '273806@oyoedu.ng', '8067229486', 'EDUCATIONAL LEGACY', 'OYO', '273806'),
(3807, '273807', 'úÏ…W§', '273807@oyoedu.ng', '8034332822', 'SUMMIT COMP COLLEGE', 'OYO', '273807'),
(3808, '273808', 'úÏ…W§', '273808@oyoedu.ng', '8157415941', 'AGUGU HIGH SCH', 'OYO', '273808'),
(3809, '273809', 'úÏ…W§', '273809@oyoedu.ng', '8038772855', 'AWAWU ISLAM', 'OYO', '273809'),
(3810, '273810', 'úÏ…W§', '273810@oyoedu.ng', '', 'CHRIST LOVE', '', '273810'),
(3811, '273811', 'úÏ…W§', '273811@oyoedu.ng', '8038232749', 'DISTINCT  JUBILEE', 'KWARA', '273811'),
(3812, '273812', 'úÏ…W§', '273812@oyoedu.ng', '8057190763', 'LIFE HIGH SCHOOL', 'OSUN', '273812'),
(3813, '273813', 'úÏ…W§', '273813@oyoedu.ng', '8104536631', 'C.H.S ALAKIA', 'OYO', '273813'),
(3814, '273814', 'úÏ…W§', '273814@oyoedu.ng', '7036481193', 'DISTINCTION COLLEGE', 'OYO', '273814'),
(3815, '273815', 'úÏ…W§', '273815@oyoedu.ng', '8037270755', 'ASSALAMU UNIQUE', 'OYO', '273815'),
(3816, '273816', 'úÏ…W§', '273816@oyoedu.ng', '8057163291', 'INTELLECTUAL COLL', 'OYO', '273816'),
(3817, '273817', 'úÏ…W§', '273817@oyoedu.ng', '8073199964', 'I.C.A', 'OYO', '273817'),
(3818, '273818', 'úÏ…W§', '273818@oyoedu.ng', '7035024111', 'LOYOLA COLLEGE', 'EKITI', '273818'),
(3819, '273819', 'úÏ…W§', '273819@oyoedu.ng', '8032442837', 'OJOO HIGH SCH', 'OSUN', '273819'),
(3820, '373820', 'úÏ…W§', '373820@oyoedu.ng', '7068323064', 'AL-QUDDUS', 'OYO', '373820'),
(3821, '273821', 'úÏ…W§', '273821@oyoedu.ng', '8035359796', 'LEGACY COLLEGE', 'OYO', '273821'),
(3822, '273822', 'úÏ…W§', '273822@oyoedu.ng', '8035359796', 'COMP BAPTIST', 'OYO', '273822'),
(3823, '273823', 'úÏ…W§', '273823@oyoedu.ng', '8023851521', 'ROCKY FOUNDATION', 'OYO', '273823'),
(3824, '273824', 'úÏ…W§', '273824@oyoedu.ng', '8066449917', 'ST. MICHEAL MODEL', 'OYO', '273824'),
(3825, '273825', 'úÏ…W§', '273825@oyoedu.ng', '8023348494', 'BEST WAY JAGUN', 'OYO', '273825'),
(3826, '273826', 'úÏ…W§', '273826@oyoedu.ng', '8023348494', '', 'OYO', '273826'),
(3827, '273827', 'úÏ…W§', '273827@oyoedu.ng', '816648034', 'EVERGREEN HIGH SCH', 'OYO', '273827'),
(3828, '273828', 'úÏ…W§', '273828@oyoedu.ng', '8059372637', 'AL-QALAM', 'OYO', '273828'),
(3829, '273829', 'úÏ…W§', '273829@oyoedu.ng', '8033739192', 'NEW LIFE COMP', 'OYO', '273829'),
(3830, '273830', 'úÏ…W§', '273830@oyoedu.ng', '8038530551', 'QUEEN OF APOSTEL', 'OGUN', '273830'),
(3831, '273831', 'úÏ…W§', '273831@oyoedu.ng', '8163428233', 'ESSENCE PRIVATE', 'OYO', '273831'),
(3832, '273832', 'úÏ…W§', '273832@oyoedu.ng', '9041240534', 'POSITIVE INTENT', 'OYO', '273832'),
(3833, '273833', 'úÏ…W§', '273833@oyoedu.ng', '8031300783', 'AL-HUDAM GROUP', 'OYO', '273833'),
(3834, '273834', 'úÏ…W§', '273834@oyoedu.ng', '8138528989', 'F.G.C OGBOMOSHO', 'OYO', '273834'),
(3835, '273835', 'úÏ…W§', '273835@oyoedu.ng', '8035714677', 'LOYOLA COLLEGE', 'OSUN', '273835'),
(3836, '273836', 'úÏ…W§', '273836@oyoedu.ng', '7061136284', 'SUMMIT COMP COLLEGE', 'OYO', '273836'),
(3837, '273837', 'úÏ…W§', '273837@oyoedu.ng', '8162585098', 'LIFE HIGH SCHOOL', 'OYO', '273837'),
(3838, '273838', 'úÏ…W§', '273838@oyoedu.ng', '8132665626', 'IBRAHIN & ABEKE', 'OYO', '273838'),
(3839, '273839', 'úÏ…W§', '273839@oyoedu.ng', '8053054432', 'BLESSED COMP', 'OYO', '273839'),
(3840, '273840', 'úÏ…W§', '273840@oyoedu.ng', '8030437089', 'FRONTINER', 'OYO', '273840'),
(3841, '273841', 'úÏ…W§', '273841@oyoedu.ng', '8034877556', 'SUNKEM COLLEGE', 'OYO', '273841'),
(3842, '273842', 'úÏ…W§', '273842@oyoedu.ng', '7066865308', 'ORILE-ILAGUN COMP', 'OGUN', '273842'),
(3843, '273843', 'úÏ…W§', '273843@oyoedu.ng', '8033857136', 'DIVINE ACUMEN', 'OYO', '273843'),
(3844, '273844', 'úÏ…W§', '273844@oyoedu.ng', '8053822924', 'PREMIER PRIVATE', 'OYO', '273844'),
(3845, '273845', 'úÏ…W§', '273845@oyoedu.ng', '7055244501', 'HUDAHLLAHI', 'OYO', '273845'),
(3846, '273846', 'úÏ…W§', '273846@oyoedu.ng', '8032974807', 'IBADAN PROMINENT', 'OGUN', '273846'),
(3847, '373847', 'úÏ…W§', '373847@oyoedu.ng', '8073203069', 'HOLY TRINITY', 'OYO', '373847'),
(3848, '273848', 'úÏ…W§', '273848@oyoedu.ng', '8033803364', 'IMON COLLEGE', 'OYO', '273848'),
(3849, '273849', 'úÏ…W§', '273849@oyoedu.ng', '8052431912', 'THE GUIDANCE', 'OYO', '273849'),
(3850, '273850', 'úÏ…W§', '273850@oyoedu.ng', '8165932777', 'ADONIA ADVANCED', 'OYO', '273850'),
(3851, '273851', 'úÏ…W§', '273851@oyoedu.ng', '7056818530', 'VICTORY GROUP', 'OYO', '273851'),
(3852, '273852', 'úÏ…W§', '273852@oyoedu.ng', '8034665461', 'LORD SCHOOL', 'EKITI', '273852'),
(3853, '373853', 'úÏ…W§', '373853@oyoedu.ng', '8100857552', 'ENIOLA INT COLLEGE', 'OYO', '373853'),
(3854, '273854', 'úÏ…W§', '273854@oyoedu.ng', '7035801359', 'AL-HAIYU MODEL', 'OYO', '273854'),
(3855, '273855', 'úÏ…W§', '273855@oyoedu.ng', '8099777122', 'FOUNTAIN INT', 'OSUN', '273855'),
(3856, '273856', 'úÏ…W§', '273856@oyoedu.ng', '8053462924', 'OLD YOLOLA COLLEGE', 'OYO', '273856'),
(3857, '273857', 'úÏ…W§', '273857@oyoedu.ng', '7037845784', 'SHIELD SCHOOL', 'EKITI', '273857'),
(3858, '373858', 'úÏ…W§', '373858@oyoedu.ng', '8026391207', 'ADENISI MODEL', 'OYO', '373858'),
(3859, '273859', 'úÏ…W§', '273859@oyoedu.ng', '8065551255', 'C.H.S', 'EKITI', '273859'),
(3860, '273860', 'úÏ…W§', '273860@oyoedu.ng', '8052021262', 'EVERGREEN HIGH SCH', 'OYO', '273860'),
(3861, '373861', 'úÏ…W§', '373861@oyoedu.ng', '8030766662', 'UMMI HIGH SCH', 'OSUN', '373861'),
(3862, '273862', 'úÏ…W§', '273862@oyoedu.ng', '9063803440', 'COMM GRA SCH', 'OYO', '273862'),
(3863, '273863', 'úÏ…W§', '273863@oyoedu.ng', '8165653932', 'FAITH ACADEMY', 'OYO', '273863'),
(3864, '273864', 'úÏ…W§', '273864@oyoedu.ng', '8038295886', 'RIANANVLLAH COLL', 'OYO', '273864'),
(3865, '373865', 'úÏ…W§', '373865@oyoedu.ng', '9068833889', 'AMBASADOR COLL', 'OYO', '373865'),
(3866, '273866', 'úÏ…W§', '273866@oyoedu.ng', '8095816138', 'ABIMBOLA EXCEL', 'OYO', '273866'),
(3867, '273867', 'úÏ…W§', '273867@oyoedu.ng', '8109540398', 'ABIMBOLA EXCEL', 'OYO', '273867'),
(3868, '273868', 'úÏ…W§', '273868@oyoedu.ng', '8055844985', 'QUEEN SAT IB', 'OYO', '273868'),
(3869, '273869', 'úÏ…W§', '273869@oyoedu.ng', '7015895059', 'PORIAB COLL', 'OYO', '273869'),
(3870, '273870', 'úÏ…W§', '273870@oyoedu.ng', '8076793640', 'HANEEF INT', 'OYO', '273870'),
(3871, '273871', 'úÏ…W§', '273871@oyoedu.ng', '8062226153', 'HANEEF INT', 'OYO', '273871'),
(3872, '373872', 'úÏ…W§', '373872@oyoedu.ng', '8051062421', 'IYANUOLUWA', 'OYO', '373872'),
(3873, '273873', 'úÏ…W§', '273873@oyoedu.ng', '7036827394', 'OLAJIDE ISLAMIC', 'OYO', '273873'),
(3874, '273874', 'úÏ…W§', '273874@oyoedu.ng', '8034364514', 'JOY TO THE WISE', 'ONDO', '273874'),
(3875, '273875', 'úÏ…W§', '273875@oyoedu.ng', '8057066979', 'SUMURAT', 'OYO', '273875'),
(3876, '273876', 'úÏ…W§', '273876@oyoedu.ng', '7056778929', 'DOMINION', 'OYO', '273876'),
(3877, '273877', 'úÏ…W§', '273877@oyoedu.ng', '8039451946', 'ST. LUKE COLLEGE', 'OYO', '273877'),
(3878, '273878', 'úÏ…W§', '273878@oyoedu.ng', '8039451946', 'EFFECTIVE ACADEMY', 'OYO', '273878'),
(3879, '273879', 'úÏ…W§', '273879@oyoedu.ng', '8039451946', 'EFFECTIVE ACADEMY', 'OYO', '273879'),
(3880, '273880', 'úÏ…W§', '273880@oyoedu.ng', '8052152226', 'CARITAS SEC. SCH', 'OYO', '273880'),
(3881, '273881', 'úÏ…W§', '273881@oyoedu.ng', '7032737712', 'JESLORD HIGH', 'OYO', '273881'),
(3882, '273882', 'úÏ…W§', '273882@oyoedu.ng', '7032737712', 'COMM OGUNGBA', 'OYO', '273882'),
(3883, '373883', 'úÏ…W§', '373883@oyoedu.ng', '8062780175', 'AS ALAM MODEL', 'OYO', '373883'),
(3884, '273884', 'úÏ…W§', '273884@oyoedu.ng', '8052005327', 'EXCELLERS COMP', 'OYO', '273884'),
(3885, '273885', 'úÏ…W§', '273885@oyoedu.ng', '8156963650', 'ARMY BARACKS', 'OYO', '273885'),
(3886, '273886', 'úÏ…W§', '273886@oyoedu.ng', '8060627068', 'RICHDEL MODEL COLLEGE', 'OYO', '273886'),
(3887, '273887', 'úÏ…W§', '273887@oyoedu.ng', '8050734054', 'HERITAGE COMP', 'OYO', '273887'),
(3888, '273888', 'úÏ…W§', '273888@oyoedu.ng', '8033540584', 'CENFEX HIGH', 'OYO', '273888'),
(3889, '273889', 'úÏ…W§', '273889@oyoedu.ng', '8038087644', '', 'OYO', '273889'),
(3890, '373890', 'úÏ…W§', '373890@oyoedu.ng', '8030756952', 'ADONAI COMP', 'OSUN', '373890'),
(3891, '273891', 'úÏ…W§', '273891@oyoedu.ng', '8162266737', 'LOYOLA COLLEGE', 'OYO', '273891'),
(3892, '373892', 'úÏ…W§', '373892@oyoedu.ng', '8029467835', 'FIRM FOUNDATION', 'EKITI', '373892'),
(3893, '273893', 'úÏ…W§', '273893@oyoedu.ng', '7039457451', 'IBRAHIM COMP', 'OYO', '273893'),
(3894, '273894', 'úÏ…W§', '273894@oyoedu.ng', '9053007313', 'HANEEF INT', 'OYO', '273894'),
(3895, '273895', 'úÏ…W§', '273895@oyoedu.ng', '8066464932', 'F.G.C OGBOMOSHO', 'OYO', '273895'),
(3896, '273896', 'úÏ…W§', '273896@oyoedu.ng', '8028808435', 'MOLETE BAPTIST', 'OYO', '273896'),
(3897, '273897', 'úÏ…W§', '273897@oyoedu.ng', '9033360609', 'EXCELLENT MODEL', 'OYO', '273897'),
(3898, '273898', 'úÏ…W§', '273898@oyoedu.ng', '8035172353', 'ARMY DAY SCH', 'OYO', '273898'),
(3899, '373899', 'úÏ…W§', '373899@oyoedu.ng', '8034579066', 'AS-SALAM', 'OSUN', '373899'),
(3900, '273900', 'úÏ…W§', '273900@oyoedu.ng', '8100051455', 'CARITAS SEC. SCH', 'OYO', '273900'),
(3901, '273901', 'úÏ…W§', '273901@oyoedu.ng', '8055232517', 'TYH RAHMAN COLL', 'OYO', '273901'),
(3902, '273902', 'úÏ…W§', '273902@oyoedu.ng', '8073131122', 'BEST BRAIN', 'ONDO', '273902'),
(3903, '273903', 'úÏ…W§', '273903@oyoedu.ng', '8054042116', 'DAARUL-HIKMAH', 'OYO', '273903'),
(3904, '273904', 'úÏ…W§', '273904@oyoedu.ng', '8038313624', 'ROYAL DIADEM', 'OYO', '273904'),
(3905, '273905', 'úÏ…W§', '273905@oyoedu.ng', '8077172986', 'LOYOLA COLLEGE', 'OYO', '273905'),
(3906, '273906', 'úÏ…W§', '273906@oyoedu.ng', '8066062805', 'ADURA INT', 'OYO', '273906'),
(3907, '273907', 'úÏ…W§', '273907@oyoedu.ng', '9020576196', 'CARITAS SEC. SCH', 'OYO', '273907'),
(3908, '273908', 'úÏ…W§', '273908@oyoedu.ng', '7061140795', 'NEW COVENANT', 'OYO', '273908'),
(3909, '273909', 'úÏ…W§', '273909@oyoedu.ng', '7058464563', 'QUEEN OF APOSTEL', 'OYO', '273909'),
(3910, '273910', 'úÏ…W§', '273910@oyoedu.ng', '8051421947', 'OLAJIDE ISLAMIC', 'OYO', '273910'),
(3911, '273911', 'úÏ…W§', '273911@oyoedu.ng', '8153807316', 'OLAJIDE ISLAMIC', 'OYO', '273911'),
(3912, '273912', 'úÏ…W§', '273912@oyoedu.ng', '7068077272', 'FUTURE COMP', 'OYO', '273912'),
(3913, '273913', 'úÏ…W§', '273913@oyoedu.ng', '8056505575', 'INDEPENDENCE', 'OYO', '273913'),
(3914, '273914', 'úÏ…W§', '273914@oyoedu.ng', '8027812154', 'THE ZENITH', 'OYO', '273914'),
(3915, '273915', 'úÏ…W§', '273915@oyoedu.ng', '8165744198', 'EMIFUNMI COLL', 'OSUN', '273915'),
(3916, '273916', 'úÏ…W§', '273916@oyoedu.ng', '7030261351', 'ORE OFEOLUWA', 'OYO', '273916'),
(3917, '273917', 'úÏ…W§', '273917@oyoedu.ng', '7032456117', 'IBRAHIM COMP', 'OYO', '273917'),
(3918, '273918', 'úÏ…W§', '273918@oyoedu.ng', '7032456117', 'HELPLINE COLLEGE', 'OYO', '273918'),
(3919, '273919', 'úÏ…W§', '273919@oyoedu.ng', '8137106633', 'GOSPEL FAITH MISSION', 'OYO', '273919'),
(3920, '273920', 'úÏ…W§', '273920@oyoedu.ng', '7069495699', 'GIRLS FOUNDATION', 'OYO', '273920'),
(3921, '273921', 'úÏ…W§', '273921@oyoedu.ng', '7031184910', 'FOUNTAIN INT', 'OYO', '273921'),
(3922, '273922', 'úÏ…W§', '273922@oyoedu.ng', '8038474831', 'OLIVE BRANCH', 'OYO', '273922'),
(3923, '273923', 'úÏ…W§', '273923@oyoedu.ng', '8169427707', 'BRIGHT FUTURE', 'EKITI', '273923'),
(3924, '273924', 'úÏ…W§', '273924@oyoedu.ng', '8129584968', 'IKOLABA GRAMMER', 'OYO', '273924'),
(3925, '273925', 'úÏ…W§', '273925@oyoedu.ng', '8074141819', 'CARITAS SEC. SCH', 'OYO', '273925'),
(3926, '273926', 'úÏ…W§', '273926@oyoedu.ng', '8076767864', 'ZEALOUS UNIQUE', 'OYO', '273926'),
(3927, '273927', 'úÏ…W§', '273927@oyoedu.ng', '8122160385', 'JESUS THE ROCK', 'OYO', '273927'),
(3928, '273928', 'úÏ…W§', '273928@oyoedu.ng', '8055447555', 'DAY SPRING', 'OYO', '273928'),
(3929, '273929', 'úÏ…W§', '273929@oyoedu.ng', '8054259054', 'DIVINE COLLEGE', 'OYO', '273929'),
(3930, '273930', 'úÏ…W§', '273930@oyoedu.ng', '9056218903', 'COM HIGH SCH', 'OYO', '273930'),
(3931, '273931', 'úÏ…W§', '273931@oyoedu.ng', '8132633310', 'FUTURE TREASURE', 'EDO', '273931'),
(3932, '273932', 'úÏ…W§', '273932@oyoedu.ng', '8022094108', 'GODS CANOPY', 'OYO', '273932'),
(3933, '273933', 'úÏ…W§', '273933@oyoedu.ng', '8034583251', 'FUTURE TREASURE', 'OSUN', '273933'),
(3934, '273934', 'úÏ…W§', '273934@oyoedu.ng', '8074238720', 'COMM DAY SCH', 'OYO', '273934'),
(3935, '273935', 'úÏ…W§', '273935@oyoedu.ng', '8161609436', 'FUTURE TREAURE', 'ONDO', '273935'),
(3936, '273936', 'úÏ…W§', '273936@oyoedu.ng', '8161609436', 'FUTTURE TREASURE', 'ONDO', '273936'),
(3937, '273937', 'úÏ…W§', '273937@oyoedu.ng', '8176575203', 'IIBRAHIM COMP', 'OYO', '273937'),
(3938, '273938', 'úÏ…W§', '273938@oyoedu.ng', '9033593656', 'RICHDEL MODEL COLLEGE', 'OYO', '273938'),
(3939, '273939', 'úÏ…W§', '273939@oyoedu.ng', '8037211343', 'HONEY INT SCH', 'OYO', '273939'),
(3940, '273940', 'úÏ…W§', '273940@oyoedu.ng', '8034901759', 'BODMAS', 'OSUN', '273940'),
(3941, '273941', 'úÏ…W§', '273941@oyoedu.ng', '8051540524', 'G.J.C.K', 'OYO', '273941'),
(3942, '273942', 'úÏ…W§', '273942@oyoedu.ng', '8025041107', 'GOVT SEC SCH', 'OYO', '273942'),
(3943, '273943', 'úÏ…W§', '273943@oyoedu.ng', '7039180441', 'AUNTY AYO COMP', 'OYO', '273943'),
(3944, '373944', 'úÏ…W§', '373944@oyoedu.ng', '7036939215', 'ASANKE COMP', 'OYO', '373944'),
(3945, '273945', 'úÏ…W§', '273945@oyoedu.ng', '8132882816', 'GRACELAND HEIGHT', 'OYO', '273945'),
(3946, '273946', 'úÏ…W§', '273946@oyoedu.ng', '8056139893', 'CARITAS SEC. SCH', 'LAGOS', '273946'),
(3947, '273947', 'úÏ…W§', '273947@oyoedu.ng', '7048578973', 'METHODIST COLLEGE', 'EKITI', '273947'),
(3948, '273948', 'úÏ…W§', '273948@oyoedu.ng', '8035875923', 'HIS KINGDOM HIGH', 'OSUN', '273948'),
(3949, '273949', 'úÏ…W§', '273949@oyoedu.ng', '8034966393', 'PEACE INT. COLL', 'OYO', '273949'),
(3950, '273950', 'úÏ…W§', '273950@oyoedu.ng', '8066546313', 'IMG OKE', 'OYO', '273950'),
(3951, '273951', 'úÏ…W§', '273951@oyoedu.ng', '8030460947', 'SUNSHINE', 'OYO', '273951'),
(3952, '273952', 'úÏ…W§', '273952@oyoedu.ng', '8035231730', 'MUFLIHUN HIGH', 'OYO', '273952'),
(3953, '273953', 'úÏ…W§', '273953@oyoedu.ng', '7031981471', 'SHARON ROSE', 'OYO', '273953'),
(3954, '273954', 'úÏ…W§', '273954@oyoedu.ng', '8130717960', 'EVERGREEN HIGH SCH', 'OYO', '273954'),
(3955, '273955', 'úÏ…W§', '273955@oyoedu.ng', '8079672251', 'HIS MAJESTY COLLEGE', 'OYO', '273955'),
(3956, '273956', 'úÏ…W§', '273956@oyoedu.ng', '9017436683', 'AMAZING GRACE', 'OYO', '273956'),
(3957, '273957', 'úÏ…W§', '273957@oyoedu.ng', '7085850101', '', 'OYO', '273957'),
(3958, '273958', 'úÏ…W§', '273958@oyoedu.ng', '7088296110', 'ADESINA COLLEGE', 'KOGI', '273958'),
(3959, '273959', 'úÏ…W§', '273959@oyoedu.ng', '80945927008', 'TREASURE COLLEGE', 'OYO', '273959'),
(3960, '273960', 'úÏ…W§', '273960@oyoedu.ng', '8136916996', 'PRECIOUS SEED', 'OYO', '273960'),
(3961, '273961', 'úÏ…W§', '273961@oyoedu.ng', '8166037712', 'EXCELLENT MODEL', 'OYO', '273961'),
(3962, '273962', 'úÏ…W§', '273962@oyoedu.ng', '7051530239', 'C.S.S KUMAPAYI', 'OYO', '273962'),
(3963, '273963', 'úÏ…W§', '273963@oyoedu.ng', '7088375055', 'CARITAS SEC. SCH', 'OYO', '273963'),
(3964, '273964', 'úÏ…W§', '273964@oyoedu.ng', '7088375055', 'ROCK OF AGES', 'OYO', '273964'),
(3965, '273965', 'úÏ…W§', '273965@oyoedu.ng', '8057871709', 'ROCK OF AGES', 'OYO', '273965'),
(3966, '273966', 'úÏ…W§', '273966@oyoedu.ng', '9036653964', 'AL-EEMAN', 'OYO', '273966'),
(3967, '273967', 'úÏ…W§', '273967@oyoedu.ng', '8106913700', 'HIGH-CLASS', 'OYO', '273967'),
(3968, '273968', 'úÏ…W§', '273968@oyoedu.ng', '8134017907', 'TMM GROUP OF SCH', 'LAGOS', '273968'),
(3969, '273969', 'úÏ…W§', '273969@oyoedu.ng', '8056069920', 'ALL AGES COLLEGE', 'OYO', '273969'),
(3970, '273970', 'úÏ…W§', '273970@oyoedu.ng', '8075612471', 'NURU ISLAMIA', 'OYO', '273970'),
(3971, '273971', 'úÏ…W§', '273971@oyoedu.ng', '8052156971', 'NURU ISLAMIA', 'OYO', '273971'),
(3972, '273972', 'úÏ…W§', '273972@oyoedu.ng', '8058238250', 'SUMMIT COMP COLLEGE', 'OYO', '273972'),
(3973, '273973', 'úÏ…W§', '273973@oyoedu.ng', '9054783657', 'OLUYORO GIRLS', 'OSUN', '273973'),
(3974, '273974', 'úÏ…W§', '273974@oyoedu.ng', '8102838521', 'STEPPING STONES', 'OGUN', '273974'),
(3975, '273975', 'úÏ…W§', '273975@oyoedu.ng', '8094592753', 'ALL GRACE INT', 'OYO', '273975'),
(3976, '273976', 'úÏ…W§', '273976@oyoedu.ng', '8051572462', 'BRIGHT FUTURE', 'OYO', '273976'),
(3977, '273977', 'úÏ…W§', '273977@oyoedu.ng', '8109739121', 'IBADAN CITY MODEL', 'OSUN', '273977'),
(3978, '273978', 'úÏ…W§', '273978@oyoedu.ng', '7061599615', 'MOUNT SINAH COLLEGE', 'OYO', '273978'),
(3979, '273979', 'úÏ…W§', '273979@oyoedu.ng', '8167508018', 'ALAYANDE', 'OYO', '273979'),
(3980, '273980', 'úÏ…W§', '273980@oyoedu.ng', '8053381709', 'PATH FINDER COLLEGE', 'OYO', '273980'),
(3981, '273981', 'úÏ…W§', '273981@oyoedu.ng', '7063524010', 'TAKBIN COLLEGE', 'OYO', '273981'),
(3982, '273982', 'úÏ…W§', '273982@oyoedu.ng', '8169852020', 'BEST BRAIN', 'OYO', '273982'),
(3983, '273983', 'úÏ…W§', '273983@oyoedu.ng', '9052686241', 'CARITAS SEC. SCH', 'EKITI', '273983'),
(3984, '273984', 'úÏ…W§', '273984@oyoedu.ng', '8055533747', 'BOTEF INT COLLEGE', 'OYO', '273984'),
(3985, '273985', 'úÏ…W§', '273985@oyoedu.ng', '8030706693', 'BETHEL COLLEGE', 'OYO', '273985'),
(3986, '273986', 'úÏ…W§', '273986@oyoedu.ng', '8106559751', '', 'OYO', '273986'),
(3987, '273987', 'úÏ…W§', '273987@oyoedu.ng', '8034381732', 'GODS SOLID', 'OYO', '273987'),
(3988, '273988', 'úÏ…W§', '273988@oyoedu.ng', '8108018810', 'ARMY BARACKS GRAMA', 'OYO', '273988'),
(3989, '273989', 'úÏ…W§', '273989@oyoedu.ng', '8145112445', 'HILL TOP HIGH', 'OYO', '273989'),
(3990, '273990', 'úÏ…W§', '273990@oyoedu.ng', '8052268760', 'I.I.H. SERVNOW', 'OYO', '273990'),
(3991, '273991', 'úÏ…W§', '273991@oyoedu.ng', '8160169492', 'VALIANT COLLEGEE', 'OYO', '273991'),
(3992, '273992', 'úÏ…W§', '273992@oyoedu.ng', '8077585042', 'OLORUNDA COMM', 'OYO', '273992'),
(3993, '273993', 'úÏ…W§', '273993@oyoedu.ng', '8033994579', 'COMFORT COLLEGE', 'EBONYI', '273993'),
(3994, '273994', 'úÏ…W§', '273994@oyoedu.ng', '7036308222', 'FALOVE GREAT', 'OGUN', '273994'),
(3995, '273995', 'úÏ…W§', '273995@oyoedu.ng', '8054040146', 'FIRST BAPTIST ACADEMY', 'OYO', '273995'),
(3996, '273996', 'úÏ…W§', '273996@oyoedu.ng', '8058336905', 'KINGS CHILDREN', 'OYO', '273996'),
(3997, '273997', 'úÏ…W§', '273997@oyoedu.ng', '8058336905', 'KINGS CHILDREN', 'OYO', '273997'),
(3998, '273998', 'úÏ…W§', '273998@oyoedu.ng', '8079687092', 'ROYAL STAR COLLEGE', 'OYO', '273998'),
(3999, '273999', 'úÏ…W§', '273999@oyoedu.ng', '7062783890', 'PRECIOUS SEED', 'OYO', '273999'),
(4000, '274000', 'úÏ…W§', '274000@oyoedu.ng', '8051017533', 'CARITAS SEC. SCH', 'OYO', '274000'),
(4001, '274001', 'úÏ…W§', '274001@oyoedu.ng', '8066470530', 'MORNING STAR', 'OYO', '274001'),
(4002, '274002', 'úÏ…W§', '274002@oyoedu.ng', '8053022315', 'OLATUNDUN COLLEGE', 'OSUN', '274002'),
(4003, '274003', 'úÏ…W§', '274003@oyoedu.ng', '8035184997', 'KIDDY-VILLE', 'OSUN', '274003'),
(4004, '274004', 'úÏ…W§', '274004@oyoedu.ng', '8054320672', 'BISPOH FAITH', 'OSUN', '274004'),
(4005, '274005', 'úÏ…W§', '274005@oyoedu.ng', '8032195021', 'BEULAH LAND', 'OYO', '274005'),
(4006, '274006', 'úÏ…W§', '274006@oyoedu.ng', '8028839210', 'BRIGHT COLLEGE', 'OYO', '274006'),
(4007, '274007', 'úÏ…W§', '274007@oyoedu.ng', '8039338593', 'OYO COMP', 'OGUN', '274007'),
(4008, '274008', 'úÏ…W§', '274008@oyoedu.ng', '7031363453', 'M.H SCH', 'OYO', '274008'),
(4009, '274009', 'úÏ…W§', '274009@oyoedu.ng', '7065537602', 'GOVT COLLEGE JNR', 'OGUN', '274009'),
(4010, '274010', 'úÏ…W§', '274010@oyoedu.ng', '8060517864', 'G.C.I JNR', 'OYO', '274010'),
(4011, '274011', 'úÏ…W§', '274011@oyoedu.ng', '7039708733', 'PEACE INT. COLL', 'OYO', '274011'),
(4012, '274012', 'úÏ…W§', '274012@oyoedu.ng', '8034300485', 'COMFORT STARD', 'OYO', '274012'),
(4013, '274013', 'úÏ…W§', '274013@oyoedu.ng', '8038144044', 'TREASURE ISLAMIC', 'OYO', '274013'),
(4014, '274014', 'úÏ…W§', '274014@oyoedu.ng', '8035030113', 'MARIANY COLLEGE', 'OSUN', '274014'),
(4015, '274015', 'úÏ…W§', '274015@oyoedu.ng', '8059820526', 'METHODIST COLLEGE', 'OYO', '274015');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(4016, '274016', 'úÏ…W§', '274016@oyoedu.ng', '8066464932', 'ORITAMEFA BAPTIST MODEL', 'OYO', '274016'),
(4017, '274017', 'úÏ…W§', '274017@oyoedu.ng', '8024238975', 'GLORIOUS COLLEGE', 'OYO', '274017'),
(4018, '274018', 'úÏ…W§', '274018@oyoedu.ng', '8167783092', 'GOVT SEC SCH', 'OYO', '274018'),
(4019, '274019', 'úÏ…W§', '274019@oyoedu.ng', '7030172035', 'FEDERAL GOV\'T', 'EKITI', '274019'),
(4020, '274020', 'úÏ…W§', '274020@oyoedu.ng', '8060067916', 'GOV\'T SEC SCH', 'OYO', '274020'),
(4021, '274021', 'úÏ…W§', '274021@oyoedu.ng', '8030704946', 'DAVID JOEL', 'OYO', '274021'),
(4022, '274022', 'úÏ…W§', '274022@oyoedu.ng', '7086045007', 'OLAOLUWA GROUP', 'OYO', '274022'),
(4023, '274023', 'úÏ…W§', '274023@oyoedu.ng', '9071663012', 'AM FM GOD', 'OYO', '274023'),
(4024, '274024', 'úÏ…W§', '274024@oyoedu.ng', '8156198489', 'ORE-OFE ACADEMY', 'OYO', '274024'),
(4025, '274025', 'úÏ…W§', '274025@oyoedu.ng', '8130820311', 'OMOLADE', 'OYO', '274025'),
(4026, '274026', 'úÏ…W§', '274026@oyoedu.ng', '8154307404', 'GLORIOUS COLLEGE', 'OYO', '274026'),
(4027, '274027', 'úÏ…W§', '274027@oyoedu.ng', '7088375055', 'ISCORE MODEL', 'OYO', '274027'),
(4028, '374028', 'úÏ…W§', '374028@oyoedu.ng', '8147840711', 'LOYOLA COLLEGE', 'OYO', '374028'),
(4029, '274029', 'úÏ…W§', '274029@oyoedu.ng', '7033670171', 'PEACE LAND COLLEGE', 'OSUN', '274029'),
(4030, '274030', 'úÏ…W§', '274030@oyoedu.ng', '7037846871', 'ABIMBOLA EXCEL', 'OYO', '274030'),
(4031, '274031', 'úÏ…W§', '274031@oyoedu.ng', '8166004467', 'GODS BLESSING', 'BENUE', '274031'),
(4032, '274032', 'úÏ…W§', '274032@oyoedu.ng', '9066702816', 'GRACELAND HEIGHT', 'OYO', '274032'),
(4033, '274033', 'úÏ…W§', '274033@oyoedu.ng', '8033845735', 'ADESINA COLLEGE', 'OYO', '274033'),
(4034, '274034', 'úÏ…W§', '274034@oyoedu.ng', '80694641406', 'ADESINA COLLEGE', 'OYO', '274034'),
(4035, '274035', 'úÏ…W§', '274035@oyoedu.ng', '8053507445', 'ELEYELE SEC SCH', 'BENUE', '274035'),
(4036, '274036', 'úÏ…W§', '274036@oyoedu.ng', '7036053125', 'DAVID JOEL', 'OYO', '274036'),
(4037, '274037', 'úÏ…W§', '274037@oyoedu.ng', '7055812135', 'OROGUN GRAM SCH', 'OYO', '274037'),
(4038, '274038', 'úÏ…W§', '274038@oyoedu.ng', '803294565', 'ADURA INT MODEL', 'OYO', '274038'),
(4039, '274039', 'úÏ…W§', '274039@oyoedu.ng', '70863935', 'GRAND WATER', 'EDO', '274039'),
(4040, '274040', 'úÏ…W§', '274040@oyoedu.ng', '8034382434', '', 'OYO', '274040'),
(4041, '374041', 'úÏ…W§', '374041@oyoedu.ng', '9058363160', 'FAMOUS J', 'OYO', '374041'),
(4042, '274042', 'úÏ…W§', '274042@oyoedu.ng', '8146297078', 'PENVILLE SCH', 'OYO', '274042'),
(4043, '274043', 'úÏ…W§', '274043@oyoedu.ng', '8034291748', 'RODIYAH GROUP', 'OYO', '274043'),
(4044, '274044', 'úÏ…W§', '274044@oyoedu.ng', '7019609282', 'GOV\'T SEC SCH JNR', 'OYO', '274044'),
(4045, '274045', 'úÏ…W§', '274045@oyoedu.ng', '8122556763', 'LOYOLA COLLEGE', 'OYO', '274045'),
(4046, '274046', 'úÏ…W§', '274046@oyoedu.ng', '8033814348', 'OLORUNDA COMM', 'OYO', '274046'),
(4047, '274047', 'úÏ…W§', '274047@oyoedu.ng', '7050840400', 'THE APOSTOLIC', 'LAGOS', '274047'),
(4048, '274048', 'úÏ…W§', '274048@oyoedu.ng', '8137921314', 'ARABIC SCH', 'OYO', '274048'),
(4049, '274049', 'úÏ…W§', '274049@oyoedu.ng', '8138493398', 'TREASURE ISLAMIC', 'OYO', '274049'),
(4050, '274050', 'úÏ…W§', '274050@oyoedu.ng', '8058195897', 'OLIVET BAPTIST', 'OYO', '274050'),
(4051, '274051', 'úÏ…W§', '274051@oyoedu.ng', '8023226731', 'ALLIEEMAN', 'OYO', '274051'),
(4052, '274052', 'úÏ…W§', '274052@oyoedu.ng', '7031549591', 'GLOBAL COLLEGE', 'OSUN', '274052'),
(4053, '274053', 'úÏ…W§', '274053@oyoedu.ng', '8055203723', 'GREAT FAME MODEL', 'OSUN', '274053'),
(4054, '274054', 'úÏ…W§', '274054@oyoedu.ng', '8065164468', 'PROVIDENCE HIGH SCH', 'OYO', '274054'),
(4055, '274055', 'úÏ…W§', '274055@oyoedu.ng', '8033870149', 'HIS KINGDOM HIGH', 'OYO', '274055'),
(4056, '274056', 'úÏ…W§', '274056@oyoedu.ng', '8034029619', 'SURE FOUNDATION', 'KOGI', '274056'),
(4057, '274057', 'úÏ…W§', '274057@oyoedu.ng', '7037846871', 'RIDWANUKAH', 'OYO', '274057'),
(4058, '274058', 'úÏ…W§', '274058@oyoedu.ng', '8034029619', 'ORITOKE HIGH', 'OYO', '274058'),
(4059, '374059', 'úÏ…W§', '374059@oyoedu.ng', '7065319298', 'MARINI SCH', 'OYO', '374059'),
(4060, '274060', 'úÏ…W§', '274060@oyoedu.ng', '8052786291', 'COMMAND DAY SCH', 'OYO', '274060'),
(4061, '274061', 'úÏ…W§', '274061@oyoedu.ng', '8052786291', 'COMMAND DAY SCH', 'OYO', '274061'),
(4062, '274062', 'úÏ…W§', '274062@oyoedu.ng', '8053593426', 'COMMAND DAY SCH', 'OYO', '274062'),
(4063, '274063', 'úÏ…W§', '274063@oyoedu.ng', '8024970700', 'C.H.S SAWIA', 'DELTA', '274063'),
(4064, '274064', 'úÏ…W§', '274064@oyoedu.ng', '8080415252', 'HIGHER HEIGHT', 'OYO', '274064'),
(4065, '274065', 'úÏ…W§', '274065@oyoedu.ng', '9094394363', 'C.H.H.S', 'CROSS R', '274065'),
(4066, '274066', 'úÏ…W§', '274066@oyoedu.ng', '9063773691', 'QUEEN SCHOOL', 'OYO', '274066'),
(4067, '274067', 'úÏ…W§', '274067@oyoedu.ng', '8023681650', 'GOD IS ABLE COLLEGE', 'OYO', '274067'),
(4068, '274068', 'úÏ…W§', '274068@oyoedu.ng', '7035904374', 'ALMIGHTY GROUP', 'KOGI', '274068'),
(4069, '374069', 'úÏ…W§', '374069@oyoedu.ng', '8108596699', 'MANY SPRING', 'OGUN', '374069'),
(4070, '274070', 'úÏ…W§', '274070@oyoedu.ng', '7067182651', 'ISABATUBEEN', 'OYO', '274070'),
(4071, '274071', 'úÏ…W§', '274071@oyoedu.ng', '8151064847', 'OYO STATE MODEL', 'OYO', '274071'),
(4072, '274072', 'úÏ…W§', '274072@oyoedu.ng', '8146952754', 'OLAD MODEL', 'OSUN', '274072'),
(4073, '274073', 'úÏ…W§', '274073@oyoedu.ng', '8032195513', 'IMPACT MODEL COLL', 'OYO', '274073'),
(4074, '274074', 'úÏ…W§', '274074@oyoedu.ng', '9070912651', 'ULTIMATE SCH', 'OYO', '274074'),
(4075, '274075', 'úÏ…W§', '274075@oyoedu.ng', '8076743034', 'ULTIMATE SCH', 'OYO', '274075'),
(4076, '274076', 'úÏ…W§', '274076@oyoedu.ng', '8154727867', 'PRECIOUS', 'OYO', '274076'),
(4077, '274077', 'úÏ…W§', '274077@oyoedu.ng', '8033257862', 'PEACELAND', 'OYO', '274077'),
(4078, '274078', 'úÏ…W§', '274078@oyoedu.ng', '8033257862', 'PEACELAND', 'EDO', '274078'),
(4079, '274079', 'úÏ…W§', '274079@oyoedu.ng', '8155328129', 'OYO STATE MODEL', 'OYO', '274079'),
(4080, '274080', 'úÏ…W§', '274080@oyoedu.ng', '9012137589', 'JESUS THE ROCK', 'OSUN', '274080'),
(4081, '274081', 'úÏ…W§', '274081@oyoedu.ng', '8080940670', 'GOD\'S CHILDREN', 'OSUN', '274081'),
(4082, '274082', 'úÏ…W§', '274082@oyoedu.ng', '8052670649', 'LAGELU GRAM', 'OYO', '274082'),
(4083, '274083', 'úÏ…W§', '274083@oyoedu.ng', '8032239669', 'TOP INT COLLEGE', 'OSUN', '274083'),
(4084, '374084', 'úÏ…W§', '374084@oyoedu.ng', '7050202632', 'GLORIOUS COLLEGE', 'OSUN', '374084'),
(4085, '274085', 'úÏ…W§', '274085@oyoedu.ng', '8033840905', 'LANFAS COLLEGE', 'OYO', '274085'),
(4086, '274086', 'úÏ…W§', '274086@oyoedu.ng', '', 'GOV\'T SEC SCH', 'OYO', '274086'),
(4087, '274087', 'úÏ…W§', '274087@oyoedu.ng', '7038433670', 'GOODNESS AND MERCY', 'OYO', '274087'),
(4088, '274088', 'úÏ…W§', '274088@oyoedu.ng', '9058041100', 'LAGELU GRAM', 'OYO', '274088'),
(4089, '274089', 'úÏ…W§', '274089@oyoedu.ng', '9058041100', 'AUNTY AYO COMP', 'OYO', '274089'),
(4090, '274090', 'úÏ…W§', '274090@oyoedu.ng', '8128223914', 'SHAMMAH ACADEMY', 'OYO', '274090'),
(4091, '274091', 'úÏ…W§', '274091@oyoedu.ng', '8054535405', 'MCMC', 'OYO', '274091'),
(4092, '274092', 'úÏ…W§', '274092@oyoedu.ng', '8054535405', 'MCMC', 'OYO', '274092'),
(4093, '274093', 'úÏ…W§', '274093@oyoedu.ng', '8036969479', 'SUNSHINE INT HIGH', 'OYO', '274093'),
(4094, '274094', 'úÏ…W§', '274094@oyoedu.ng', '8035736752', 'KINGDOM LIFE', 'OSUN', '274094'),
(4095, '274095', 'úÏ…W§', '274095@oyoedu.ng', '8104026588', 'GREATER GLORY', 'OYO', '274095'),
(4096, '274096', 'úÏ…W§', '274096@oyoedu.ng', '7059431263', 'CHALSEDIONY', 'OYO', '274096'),
(4097, '274097', 'úÏ…W§', '274097@oyoedu.ng', '7059431263', 'CHALSEDIONY', 'OYO', '274097'),
(4098, '274098', 'úÏ…W§', '274098@oyoedu.ng', '80714568427', 'DOMINION COLL.', 'OYO', '274098'),
(4099, '274099', 'úÏ…W§', '274099@oyoedu.ng', '8032446991', 'ITESIWAJU COMM.', 'OYO', '274099'),
(4100, '274100', 'úÏ…W§', '274100@oyoedu.ng', '8033812547', 'NEW LIFE COMP.', 'OYO', '274100'),
(4101, '274101', 'úÏ…W§', '274101@oyoedu.ng', '8059574040', 'AS-SALAM', 'OYO', '274101'),
(4102, '274102', 'úÏ…W§', '274102@oyoedu.ng', '8108908690', 'FIRST FOUNDATION', 'LAGOS', '274102'),
(4103, '274103', 'úÏ…W§', '274103@oyoedu.ng', '7058682580', 'AN-NUR MODEL', 'OYO', '274103'),
(4104, '274104', 'úÏ…W§', '274104@oyoedu.ng', '8159765128', 'JOFIAINT MODEL', 'OYO', '274104'),
(4105, '274105', 'úÏ…W§', '274105@oyoedu.ng', '7083468073', 'EVERGREEN HIGH SCH', 'OYO', '274105'),
(4106, '274106', 'úÏ…W§', '274106@oyoedu.ng', '9032962503', 'ROCK OF SALVATION', 'OSUN', '274106'),
(4107, '274107', 'úÏ…W§', '274107@oyoedu.ng', '8035032442', 'PREMIUM COLL.', 'OYO', '274107'),
(4108, '274108', 'úÏ…W§', '274108@oyoedu.ng', '7016717192', 'DIVINE SCHOOL', 'OYO', '274108'),
(4109, '274109', 'úÏ…W§', '274109@oyoedu.ng', '8060654964', 'IMG AGODI', 'OYO', '274109'),
(4110, '274110', 'úÏ…W§', '274110@oyoedu.ng', '7033213607', 'FORTUNATE COLL.', 'OYO', '274110'),
(4111, '274111', 'úÏ…W§', '274111@oyoedu.ng', '8066611494', 'CSSP', 'OYO', '274111'),
(4112, '274112', 'úÏ…W§', '274112@oyoedu.ng', '8020930068', 'METHODIST', 'OSUN', '274112'),
(4113, '274113', 'úÏ…W§', '274113@oyoedu.ng', '8038175860', 'JESUS THE ROCK', 'OYO', '274113'),
(4114, '274114', 'úÏ…W§', '274114@oyoedu.ng', '7051554844', 'NEW COVENANT', 'OYO', '274114'),
(4115, '274115', 'úÏ…W§', '274115@oyoedu.ng', '8057926271', 'HAMONAB MODEL', 'OYO', '274115'),
(4116, '274116', 'úÏ…W§', '274116@oyoedu.ng', '8055817630', 'IBC ACADEMY', 'OYO', '274116'),
(4117, '274117', 'úÏ…W§', '274117@oyoedu.ng', '9070912651', 'ULTIMATE SCH', 'OYO', '274117'),
(4118, '274118', 'úÏ…W§', '274118@oyoedu.ng', '8103597136', 'LORD`S FAVOUR', 'OYO', '274118'),
(4119, '274119', 'úÏ…W§', '274119@oyoedu.ng', '8168576477', 'DE MIGHTY INT.', 'OYO', '274119'),
(4120, '274120', 'úÏ…W§', '274120@oyoedu.ng', '8168576477', 'DE MIGHTY INCT.', 'OYO', '274120'),
(4121, '274121', 'úÏ…W§', '274121@oyoedu.ng', '8074504063', 'CALEEPHA MODEL', 'OYO', '274121'),
(4122, '274122', 'úÏ…W§', '274122@oyoedu.ng', '8034603465', 'ELEKURO HIGH ', 'OYO', '274122'),
(4123, '274123', 'úÏ…W§', '274123@oyoedu.ng', '8034042163', 'OYO STATE MODEL', 'OYO', '274123'),
(4124, '274124', 'úÏ…W§', '274124@oyoedu.ng', '8034241667', 'THE SPRING OF KNOWLEDGE', 'OYO', '274124'),
(4125, '374125', 'úÏ…W§', '374125@oyoedu.ng', '9067455223', ' LANTEM PRIVATE ', 'OYO', '374125'),
(4126, '274126', 'úÏ…W§', '274126@oyoedu.ng', '9067455223', 'LANTEM PRIVATE', 'OSUN', '274126'),
(4127, '274127', 'úÏ…W§', '274127@oyoedu.ng', '8052237112', 'I.C.H.S(JNR)', 'OYO', '274127'),
(4128, '274128', 'úÏ…W§', '274128@oyoedu.ng', '9034849757', 'PREMIUM STANDARD', 'OYO', '274128'),
(4129, '274129', 'úÏ…W§', '274129@oyoedu.ng', '8159544330', 'ADONAI ADVANCE', 'OYO', '274129'),
(4130, '274130', 'úÏ…W§', '274130@oyoedu.ng', '9063975330', 'TOP CROWN COLL.', 'OYO', '274130'),
(4131, '274131', 'úÏ…W§', '274131@oyoedu.ng', '8069630844', 'PRECIOUS CORNER', 'OSUN', '274131'),
(4132, '274132', 'úÏ…W§', '274132@oyoedu.ng', '8069630844', 'PRECIUOS CORNER', 'OYO', '274132'),
(4133, '274133', 'úÏ…W§', '274133@oyoedu.ng', '7034878905', 'EDUCARE GROUP', 'OYO', '274133'),
(4134, '274134', 'úÏ…W§', '274134@oyoedu.ng', '8056219192', 'THE PARAGON', 'OYO', '274134'),
(4135, '274135', 'úÏ…W§', '274135@oyoedu.ng', '9070912651', 'ULTIMATE SCH', 'OYO', '274135'),
(4136, '274136', 'úÏ…W§', '274136@oyoedu.ng', '8035156010', 'CALVARY GRACE', 'OYO', '274136'),
(4137, '274137', 'úÏ…W§', '274137@oyoedu.ng', '80101026419', 'DIVINE SOLUTION', 'OYO', '274137'),
(4138, '274138', 'úÏ…W§', '274138@oyoedu.ng', '9052957426', 'GRACE LAND ', 'OSUN', '274138'),
(4139, '274139', 'úÏ…W§', '274139@oyoedu.ng', '80206252', 'COMM. GRAM. SCH. AMULOKO', 'EKITI', '274139'),
(4140, '274140', 'úÏ…W§', '274140@oyoedu.ng', '8055915047', 'AL-HAQQU', 'OYO', '274140'),
(4141, '274141', 'úÏ…W§', '274141@oyoedu.ng', '8058241624', 'RICHDEL MODEL COLLEGE', 'OYO', '274141'),
(4142, '274142', 'úÏ…W§', '274142@oyoedu.ng', '7012717758', 'C.A.C GRAM SCH', 'OYO', '274142'),
(4143, '274143', 'úÏ…W§', '274143@oyoedu.ng', '8080799741', 'BIOKU COMM', 'OYO', '274143'),
(4144, '274144', 'úÏ…W§', '274144@oyoedu.ng', '7066528569', 'QUANNMLEAP', 'OYO', '274144'),
(4145, '274145', 'úÏ…W§', '274145@oyoedu.ng', '8054077633', 'AL-IKHLAS', 'OYO', '274145'),
(4146, '274146', 'úÏ…W§', '274146@oyoedu.ng', '8034077633', 'AL-IKHLAS', 'OYO', '274146'),
(4147, '274147', 'úÏ…W§', '274147@oyoedu.ng', '8058984831', 'IBSDC', 'OYO', '274147'),
(4148, '274148', 'úÏ…W§', '274148@oyoedu.ng', '8020395115', 'H.A.J(AN-NUR)', 'OYO', '274148'),
(4149, '274149', 'úÏ…W§', '274149@oyoedu.ng', '8114781198', 'ARROQEEB', 'OYO', '274149'),
(4150, '274150', 'úÏ…W§', '274150@oyoedu.ng', '8052922509', 'IKOLABA GRAMMER', 'OYO', '274150'),
(4151, '274151', 'úÏ…W§', '274151@oyoedu.ng', '8161378452', 'OWO-OLUWA', 'OYO', '274151'),
(4152, '274152', 'úÏ…W§', '274152@oyoedu.ng', '8154302408', 'AGUGU HIGH SCH', 'OYO', '274152'),
(4153, '274153', 'úÏ…W§', '274153@oyoedu.ng', '8056128520', 'ITESIWAJU COMM.', 'OYO', '274153'),
(4154, '274154', 'úÏ…W§', '274154@oyoedu.ng', '7010734594', 'COMM. SEC. SCH.', 'OYO', '274154'),
(4155, '274155', 'úÏ…W§', '274155@oyoedu.ng', '706268487', 'S.A.G.H II', 'OYO', '274155'),
(4156, '274156', 'úÏ…W§', '274156@oyoedu.ng', '8062744067', 'NEW FOCUS', 'OYO', '274156'),
(4157, '274157', 'úÏ…W§', '274157@oyoedu.ng', '7067237617', 'JESUS THE ROCK', 'OYO', '274157'),
(4158, '274158', 'úÏ…W§', '274158@oyoedu.ng', '9070912651', 'ULTIMATE SCH', 'OYO', '274158'),
(4159, '274159', 'úÏ…W§', '274159@oyoedu.ng', '9012850992', 'HILL TOP HIGH', 'OSUN', '274159'),
(4160, '274160', 'úÏ…W§', '274160@oyoedu.ng', '8103116702', 'DE ALPHA  COLL.', 'OYO', '274160'),
(4161, '274161', 'úÏ…W§', '274161@oyoedu.ng', '8035238774', 'GOVT. SEC. SCH. JNR', 'OYO', '274161'),
(4162, '274162', 'úÏ…W§', '274162@oyoedu.ng', '8117743308', 'ABADINA COLL.', 'OYO', '274162'),
(4163, '274163', 'úÏ…W§', '274163@oyoedu.ng', '7059168253', 'NDNPS', 'OYO', '274163'),
(4164, '274164', 'úÏ…W§', '274164@oyoedu.ng', '8027852849', 'EGBE JUNIOR', 'LAGOS', '274164'),
(4165, '274165', 'úÏ…W§', '274165@oyoedu.ng', '8052029688', 'NOBLE FOUNDATION', 'OSUN', '274165'),
(4166, '274166', 'úÏ…W§', '274166@oyoedu.ng', '8023297399', 'FUTURE MODEL', 'EDO', '274166'),
(4167, '274167', 'úÏ…W§', '274167@oyoedu.ng', '8073864359', 'RIDWANUKAH', 'OYO', '274167'),
(4168, '374168', 'úÏ…W§', '374168@oyoedu.ng', '9018004369', 'ACADEMIC', 'OYO', '374168'),
(4169, '274169', 'úÏ…W§', '274169@oyoedu.ng', '9055987070', 'THE FOUNDATION', 'OYO', '274169'),
(4170, '274170', 'úÏ…W§', '274170@oyoedu.ng', '8023421548', 'DE LIGHT ACADEMY', 'EDO', '274170'),
(4171, '274171', 'úÏ…W§', '274171@oyoedu.ng', '8064219826', 'SCEPTRE COLL.', 'OYO', '274171'),
(4172, '274172', 'úÏ…W§', '274172@oyoedu.ng', '9018984547', 'CITADEL ISLAMIC', 'OYO', '274172'),
(4173, '374173', 'úÏ…W§', '374173@oyoedu.ng', '', 'POWER FIELDS', 'OYO', '374173'),
(4174, '274174', 'úÏ…W§', '274174@oyoedu.ng', '8069528066', 'OLUANDE HEIGHT', 'OSUN', '274174'),
(4175, '274175', 'úÏ…W§', '274175@oyoedu.ng', '7011050508', 'G C I', 'OYO', '274175'),
(4176, '274176', 'úÏ…W§', '274176@oyoedu.ng', '8033571573', 'RIDWANLAHI', 'OYO', '274176'),
(4177, '274177', 'úÏ…W§', '274177@oyoedu.ng', '8066266710', 'BIMOTO CLASSIC', 'OYO', '274177'),
(4178, '374178', 'úÏ…W§', '374178@oyoedu.ng', '8056151183', 'ABIMBOLA EXCEL', 'OYO', '374178'),
(4179, '274179', 'úÏ…W§', '274179@oyoedu.ng', '8053762460', 'BEST WAY FOUNDATION', 'OYO', '274179'),
(4180, '274180', 'úÏ…W§', '274180@oyoedu.ng', '9051021788', '', 'OSUN', '274180'),
(4181, '274181', 'úÏ…W§', '274181@oyoedu.ng', '7035273716', 'ALAHO COMM. GRAMMER SCH.', 'OYO', '274181'),
(4182, '374182', 'úÏ…W§', '374182@oyoedu.ng', '8078270761', 'GREAT WINNERS', 'OYO', '374182'),
(4183, '274183', 'úÏ…W§', '274183@oyoedu.ng', '8101514043', 'ABUNDANT MODEL', 'OYO', '274183'),
(4184, '274184', 'úÏ…W§', '274184@oyoedu.ng', '8055784669', 'BOLANLE WINNER COLL.', 'OYO', '274184'),
(4185, '274185', 'úÏ…W§', '274185@oyoedu.ng', '8037787660', 'MINARET HIGH', 'OYO', '274185'),
(4186, '274186', 'úÏ…W§', '274186@oyoedu.ng', '8025312265', 'THE ROYAL COLL.', 'OYO', '274186'),
(4187, '274187', 'úÏ…W§', '274187@oyoedu.ng', '8059681347', 'ISLIMILAHI GROUP', 'OYO', '274187'),
(4188, '274188', 'úÏ…W§', '274188@oyoedu.ng', '8056329933', 'FAITH EXCEL', 'OYO', '274188'),
(4189, '274189', 'úÏ…W§', '274189@oyoedu.ng', '7030405867', 'THE NOBLE STAND', 'OYO', '274189'),
(4190, '374190', 'úÏ…W§', '374190@oyoedu.ng', '8058121496', 'ROCKY FOUNDATION', 'OYO', '374190'),
(4191, '274191', 'úÏ…W§', '274191@oyoedu.ng', '9033898411', 'ANAMS INT. COLL.', 'EKITI', '274191'),
(4192, '274192', 'úÏ…W§', '274192@oyoedu.ng', '8038338233', 'STAR COMP. SCH.', 'OYO', '274192'),
(4193, '274193', 'úÏ…W§', '274193@oyoedu.ng', '7065314956', 'FOUNDATION COLL.', 'OYO', '274193'),
(4194, '274194', 'úÏ…W§', '274194@oyoedu.ng', '8076304207', 'GALAXY INT. COLL.', 'OYO', '274194'),
(4195, '274195', 'úÏ…W§', '274195@oyoedu.ng', '8052111773', 'ABADINA COLLEGE', 'OYO', '274195'),
(4196, '274196', 'úÏ…W§', '274196@oyoedu.ng', '8028893872', 'MERCYLAND COLLEGE', 'OYO', '274196'),
(4197, '374197', 'úÏ…W§', '374197@oyoedu.ng', '8052432149', 'AL-AMEEN GROUP', 'OYO', '374197'),
(4198, '274198', 'úÏ…W§', '274198@oyoedu.ng', '8052432149', 'AL-AMEEN GROUP', 'OYO', '274198'),
(4199, '274199', 'úÏ…W§', '274199@oyoedu.ng', '9030873507', 'THE CROWN COLL.', 'OSUN', '274199'),
(4200, '274200', 'úÏ…W§', '274200@oyoedu.ng', '8058141502', 'I.M.G SCH. OJE', 'OYO', '274200'),
(4201, '274201', 'úÏ…W§', '274201@oyoedu.ng', '7026916945', 'GREATNESS OF GOD', 'OYO', '274201'),
(4202, '274202', 'úÏ…W§', '274202@oyoedu.ng', '7062308628', 'BISHOP PHILLIP', 'OYO', '274202'),
(4203, '274203', 'úÏ…W§', '274203@oyoedu.ng', '8070789531', 'BISHOP PHILLIP', 'OYO', '274203'),
(4204, '274204', 'úÏ…W§', '274204@oyoedu.ng', '8030715495', 'BASHORUN HIGH', 'OYO', '274204'),
(4205, '274205', 'úÏ…W§', '274205@oyoedu.ng', '8033838418', 'COMMAND DAY SEC.', 'OYO', '274205'),
(4206, '274206', 'úÏ…W§', '274206@oyoedu.ng', '8036149382', 'ALAMEEN GROUP', 'OGUN', '274206'),
(4207, '274207', 'úÏ…W§', '274207@oyoedu.ng', '8137848907', 'ENI-IWA SCH.', 'OSUN', '274207'),
(4208, '274208', 'úÏ…W§', '274208@oyoedu.ng', '8063936694', 'C.G.S', 'OSUN', '274208'),
(4209, '274209', 'úÏ…W§', '274209@oyoedu.ng', '8059322929', 'O.C.G.S', 'OYO', '274209'),
(4210, '274210', 'úÏ…W§', '274210@oyoedu.ng', '8056127813', 'LASTING GLORY COMP SCH', 'OYO', '274210'),
(4211, '274211', 'úÏ…W§', '274211@oyoedu.ng', '8023408162', 'MORET COMP COLLEGE', 'OYO', '274211'),
(4212, '274212', 'úÏ…W§', '274212@oyoedu.ng', '8166638453', 'STATE JUNIOR', 'OYO', '274212'),
(4213, '274213', 'úÏ…W§', '274213@oyoedu.ng', '8030715495', 'BASHORUN HIGH', 'OYO', '274213'),
(4214, '274214', 'úÏ…W§', '274214@oyoedu.ng', '8035646569', 'IBARA BAPTIST', 'OGUN', '274214'),
(4215, '274215', 'úÏ…W§', '274215@oyoedu.ng', '8160599059', 'PERFECT ASSURANCE', 'OGUN', '274215'),
(4216, '274216', 'úÏ…W§', '274216@oyoedu.ng', '805490078', 'IBADAN CITY ACA', 'OYO', '274216'),
(4217, '274217', 'úÏ…W§', '274217@oyoedu.ng', '8071913224', 'BEST MODEL', 'OYO', '274217'),
(4218, '274218', 'úÏ…W§', '274218@oyoedu.ng', '8057978309', 'IMG APATA', 'OYO', '274218'),
(4219, '274219', 'úÏ…W§', '274219@oyoedu.ng', '7012165358', 'ITESIWAJU COMM.', 'OYO', '274219'),
(4220, '274220', 'úÏ…W§', '274220@oyoedu.ng', '8052461009', 'AMINAT INTER', 'OGUN', '274220'),
(4221, '274221', 'úÏ…W§', '274221@oyoedu.ng', '8169699563', 'BOLADE COLLEGE', 'OYO', '274221'),
(4222, '274222', 'úÏ…W§', '274222@oyoedu.ng', '8077045136', 'RARE GEMS HIGH', 'OYO', '274222'),
(4223, '374223', 'úÏ…W§', '374223@oyoedu.ng', '7038952228', 'HEZDEB COLLEGE', 'OYO', '374223'),
(4224, '374224', 'úÏ…W§', '374224@oyoedu.ng', '8037512842', 'T.A.G.H.S', 'OSUN', '374224'),
(4225, '374225', 'úÏ…W§', '374225@oyoedu.ng', '8057334124', 'YEJIDE GIRLS', 'OYO', '374225'),
(4226, '374226', 'úÏ…W§', '374226@oyoedu.ng', '8055177772', 'AL-KHAER ISLAMIC', 'OGUN', '374226'),
(4227, '374227', 'úÏ…W§', '374227@oyoedu.ng', '8053058889', 'SUMMIT COMP COLLEGE', 'OYO', '374227'),
(4228, '374228', 'úÏ…W§', '374228@oyoedu.ng', '7070912651', 'UNTIMATE', 'OYO', '374228'),
(4229, '374229', 'úÏ…W§', '374229@oyoedu.ng', '8033883699', 'MERCYLAND COLLEGE', 'OSUN', '374229'),
(4230, '374230', 'úÏ…W§', '374230@oyoedu.ng', '8072458291', 'CHRIST CHURCH', 'OSUN', '374230'),
(4231, '374231', 'úÏ…W§', '374231@oyoedu.ng', '8028990808', 'BEYLAH ACADEMY', 'OYO', '374231'),
(4232, '374232', 'úÏ…W§', '374232@oyoedu.ng', '9152751828', 'QUEENS SCHOOL', 'OYO', '374232'),
(4233, '374233', 'úÏ…W§', '374233@oyoedu.ng', '8033800406', 'GOD\'S MERCY', 'OYO', '374233'),
(4234, '374234', 'úÏ…W§', '374234@oyoedu.ng', '8053447385', 'RICHDEL MODEL COLLEGE', 'OYO', '374234'),
(4235, '374235', 'úÏ…W§', '374235@oyoedu.ng', '8039123737', 'BEST WAY MODEL', 'OYO', '374235'),
(4236, '374236', 'úÏ…W§', '374236@oyoedu.ng', '8032170936', 'KINGSLOYE ACA', 'OYO', '374236'),
(4237, '374237', 'úÏ…W§', '374237@oyoedu.ng', '8071655411', 'GOD\'S STARS', 'OYO', '374237'),
(4238, '374238', 'úÏ…W§', '374238@oyoedu.ng', '8060811933', 'COMM HIGH SCH', 'OYO', '374238'),
(4239, '374239', 'úÏ…W§', '374239@oyoedu.ng', '8030995636', 'FRONT MODEL', 'OSUN', '374239'),
(4240, '374240', 'úÏ…W§', '374240@oyoedu.ng', '8121528637', 'ITESIWAJU COMM.', 'OYO', '374240'),
(4241, '374241', 'úÏ…W§', '374241@oyoedu.ng', '701401176', 'I.M.G. GRAM', 'OYO', '374241'),
(4242, '374242', 'úÏ…W§', '374242@oyoedu.ng', '8053078031', 'JUMOKOL', 'OSUN', '374242'),
(4243, '374243', 'úÏ…W§', '374243@oyoedu.ng', '8038549997', 'MOLETE BAPTIST', 'OYO', '374243'),
(4244, '374244', 'úÏ…W§', '374244@oyoedu.ng', '7057754366', 'ICAN ACADEMY', 'OYO', '374244'),
(4245, '374245', 'úÏ…W§', '374245@oyoedu.ng', '8036001542', 'BISHOP PHILLIP', 'OYO', '374245'),
(4246, '374246', 'úÏ…W§', '374246@oyoedu.ng', '7062609398', 'ETERNAL JOY', 'OYO', '374246'),
(4247, '374247', 'úÏ…W§', '374247@oyoedu.ng', '8086161718', 'WINNER ACADEMY', 'OYO', '374247'),
(4248, '374248', 'úÏ…W§', '374248@oyoedu.ng', '7063970789', 'SAF SECONDARY', 'OSUN', '374248'),
(4249, '374249', 'úÏ…W§', '374249@oyoedu.ng', '7064303938', 'MERIT COMP  HIGH SCH', 'OYO', '374249'),
(4250, '374250', 'úÏ…W§', '374250@oyoedu.ng', '8054226608', 'CG SCH', 'OYO', '374250'),
(4251, '374251', 'úÏ…W§', '374251@oyoedu.ng', '7056571721', 'AL-KAREEM', 'OYO', '374251'),
(4252, '374252', 'úÏ…W§', '374252@oyoedu.ng', '8059566608', 'AL-KAREEM', 'OYO', '374252'),
(4253, '374253', 'úÏ…W§', '374253@oyoedu.ng', '7068256662', 'KINGDOM GLORY', 'OYO', '374253'),
(4254, '374254', 'úÏ…W§', '374254@oyoedu.ng', '9039270354', 'GLOBAL COLLEGE', 'OYO', '374254'),
(4255, '374255', 'úÏ…W§', '374255@oyoedu.ng', '8142429720', 'C.T.Y MODEL', 'OYO', '374255'),
(4256, '374256', 'úÏ…W§', '374256@oyoedu.ng', '8115838913', 'C.T.Y MODEL', 'OGUN', '374256'),
(4257, '374257', 'úÏ…W§', '374257@oyoedu.ng', '8056852796', 'BADAM CITY ACADEMY', 'OYO', '374257'),
(4258, '374258', 'úÏ…W§', '374258@oyoedu.ng', '8134975544', 'OLUANDE HEIGHT', 'OYO', '374258'),
(4259, '374259', 'úÏ…W§', '374259@oyoedu.ng', '8033957778', 'POTTERS PRIVATE', 'OGUN', '374259'),
(4260, '374260', 'úÏ…W§', '374260@oyoedu.ng', '7050609526', 'OCHS JNR', 'OYO', '374260'),
(4261, '374261', 'úÏ…W§', '374261@oyoedu.ng', '8138643362', 'ST. PATRICK GRAM', 'OYO', '374261'),
(4262, '374262', 'úÏ…W§', '374262@oyoedu.ng', '8037286763', 'BOLANIE COLLEGE', 'OYO', '374262'),
(4263, '374263', 'úÏ…W§', '374263@oyoedu.ng', '8138481435', 'O.C.H.S', 'OYO', '374263'),
(4264, '374264', 'úÏ…W§', '374264@oyoedu.ng', '7037617562', 'C.A.C GRAM SCH', 'OYO', '374264'),
(4265, '374265', 'úÏ…W§', '374265@oyoedu.ng', '7064727159', 'RIGHT VISION', 'OYO', '374265'),
(4266, '374266', 'úÏ…W§', '374266@oyoedu.ng', '8033611428', 'AMAZING GRACE', 'OYO', '374266'),
(4267, '374267', 'úÏ…W§', '374267@oyoedu.ng', '8062510247', 'ABLE COLLEGE', 'OYO', '374267'),
(4268, '374268', 'úÏ…W§', '374268@oyoedu.ng', '8068291184', 'CHRIST LIFE COLLEGE', 'OYO', '374268'),
(4269, '374269', 'úÏ…W§', '374269@oyoedu.ng', '8059471618', 'IBADAN CITY ACADEMY', 'OYO', '374269'),
(4270, '374270', 'úÏ…W§', '374270@oyoedu.ng', '8055154346', 'IBADAN CITY ACADEMY', 'OYO', '374270'),
(4271, '374271', 'úÏ…W§', '374271@oyoedu.ng', '8075014888', 'OLUMIDE COMM SEC', 'OYO', '374271'),
(4272, '374272', 'úÏ…W§', '374272@oyoedu.ng', '8101010756', 'HUDALLAHI ISLAMIC', 'OYO', '374272'),
(4273, '374273', 'úÏ…W§', '374273@oyoedu.ng', '8101010756', 'HUDALLAHI ISLAMIC', 'OYO', '374273'),
(4274, '374274', 'úÏ…W§', '374274@oyoedu.ng', '8101010756', 'HUDALLAHI ISLAMIC', 'OYO', '374274'),
(4275, '374275', 'úÏ…W§', '374275@oyoedu.ng', '8055934050', 'AMBIMBOLA EXCEL', 'OYO', '374275'),
(4276, '374276', 'úÏ…W§', '374276@oyoedu.ng', '7037116324', 'ADEDAMOLA COLL', 'OYO', '374276'),
(4277, '374277', 'úÏ…W§', '374277@oyoedu.ng', '7035024203', 'COM. HIGH', 'OYO', '374277'),
(4278, '374278', 'úÏ…W§', '374278@oyoedu.ng', '8077799026', 'STARTLITE COLLEGE', 'OSUN', '374278'),
(4279, '374279', 'úÏ…W§', '374279@oyoedu.ng', '8062070806', 'IKEREKY COMM', 'OYO', '374279'),
(4280, '374280', 'úÏ…W§', '374280@oyoedu.ng', '7039666110', 'ITESIWAJU COMM.', 'OSUN', '374280'),
(4281, '374281', 'úÏ…W§', '374281@oyoedu.ng', '8038443518', 'GOD THE PACESETTER', 'ONDO', '374281'),
(4282, '374282', 'úÏ…W§', '374282@oyoedu.ng', '8065539434', 'JUMAH COMP', 'OYO', '374282'),
(4283, '374283', 'úÏ…W§', '374283@oyoedu.ng', '8168668168', 'SUMMIT COMP COLLEGE', 'OYO', '374283'),
(4284, '374284', 'úÏ…W§', '374284@oyoedu.ng', '8160575611', 'M.H.S.T', 'OYO', '374284'),
(4285, '374285', 'úÏ…W§', '374285@oyoedu.ng', '8142949131', 'A.O.C.G.S', 'OYO', '374285'),
(4286, '374286', 'úÏ…W§', '374286@oyoedu.ng', '9135082467', 'HAMEEF INT ACA', 'OYO', '374286'),
(4287, '374287', 'úÏ…W§', '374287@oyoedu.ng', '8156572308', 'HAMEEF INT ACA', 'OYO', '374287'),
(4288, '374288', 'úÏ…W§', '374288@oyoedu.ng', '8054179904', 'ANANS ROYAL', 'OYO', '374288'),
(4289, '374289', 'úÏ…W§', '374289@oyoedu.ng', '8023260225', 'RICHDEL MODEL COLLEGE', 'OYO', '374289'),
(4290, '374290', 'úÏ…W§', '374290@oyoedu.ng', '8168602111', 'APETE MODEL', 'OYO', '374290'),
(4291, '374291', 'úÏ…W§', '374291@oyoedu.ng', '8105134667', 'APETE MODEL', 'OYO', '374291'),
(4292, '374292', 'úÏ…W§', '374292@oyoedu.ng', '8102987942', 'LANFAMS', 'OYO', '374292'),
(4293, '374293', 'úÏ…W§', '374293@oyoedu.ng', '8156230673', 'BIOKU ALAADUN', 'OYO', '374293'),
(4294, '374294', 'úÏ…W§', '374294@oyoedu.ng', '8035978993', 'HIS KINGDOM ', 'OYO', '374294'),
(4295, '374295', 'úÏ…W§', '374295@oyoedu.ng', '8069813025', 'ORITAMEFA BAPTIST MODEL', 'OYO', '374295'),
(4296, '374296', 'úÏ…W§', '374296@oyoedu.ng', '8058522122', 'THE RIGHT ACHIEVER', 'ONDO', '374296'),
(4297, '374297', 'úÏ…W§', '374297@oyoedu.ng', '8056549426', 'DAVID JOEL', 'OYO', '374297'),
(4298, '374298', 'úÏ…W§', '374298@oyoedu.ng', '8052492028', 'UMMU QURA HIGH', 'OYO', '374298'),
(4299, '374299', 'úÏ…W§', '374299@oyoedu.ng', '8059784007', 'OYO STATE COMP', 'OYO', '374299'),
(4300, '374300', 'úÏ…W§', '374300@oyoedu.ng', '9058260268', 'OYO STATE MODEL', 'OYO', '374300'),
(4301, '374301', 'úÏ…W§', '374301@oyoedu.ng', '8132441914', 'GOVT JNR SCH', 'KWARA', '374301'),
(4302, '374302', 'úÏ…W§', '374302@oyoedu.ng', '7032122335', 'LOYOLA COLLEGE', 'OSUN', '374302'),
(4303, '374303', 'úÏ…W§', '374303@oyoedu.ng', '8039288377', 'AL-AWAAL COMP', 'OYO', '374303'),
(4304, '374304', 'úÏ…W§', '374304@oyoedu.ng', '8067339058', 'ST. ANTONY GRAM.', 'ONDO', '374304'),
(4305, '374305', 'úÏ…W§', '374305@oyoedu.ng', '8035381401', 'IJEBU IFE COMM', 'OGUN', '374305'),
(4306, '374306', 'úÏ…W§', '374306@oyoedu.ng', '8058865026', 'JOY/PEACE SEC', 'ONDO', '374306'),
(4307, '374307', 'úÏ…W§', '374307@oyoedu.ng', '8125126131', 'JESUS THE ROCK', 'OYO', '374307'),
(4308, '374308', 'úÏ…W§', '374308@oyoedu.ng', '7033387429', 'SAADERUNMU', 'OYO', '374308'),
(4309, '374309', 'úÏ…W§', '374309@oyoedu.ng', '8056978536', 'REHOBOTH HIGH', 'OYO', '374309'),
(4310, '374310', 'úÏ…W§', '374310@oyoedu.ng', '9029615998', 'GLORIOUS COLLEGE', 'OSUN', '374310'),
(4311, '374311', 'úÏ…W§', '374311@oyoedu.ng', '8061529027', 'PEACE INT COLL', 'OYO', '374311'),
(4312, '374312', 'úÏ…W§', '374312@oyoedu.ng', '8073423532', 'ABIMBOLA EXCEL', 'OYO', '374312'),
(4313, '374313', 'úÏ…W§', '374313@oyoedu.ng', '8056542094', 'ARIYO INT COLL', 'ONDO', '374313'),
(4314, '374314', 'úÏ…W§', '374314@oyoedu.ng', '8133877062', 'GLORIOUS COLLEGE', 'OYO', '374314'),
(4315, '374315', 'úÏ…W§', '374315@oyoedu.ng', '8078512612', 'AL-AMEEN GROUP', 'OYO', '374315'),
(4316, '374316', 'úÏ…W§', '374316@oyoedu.ng', '9033386638', 'ABLE CONCEPT SCH', 'OYO', '374316'),
(4317, '374317', 'úÏ…W§', '374317@oyoedu.ng', '8135975035', 'ECWA  MODEL', 'OYO', '374317'),
(4318, '374318', 'úÏ…W§', '374318@oyoedu.ng', '8032730770', 'PEACE INT COLL', 'OSUN', '374318'),
(4319, '374319', 'úÏ…W§', '374319@oyoedu.ng', '8052238357', 'GOD\'S CARE MODEL', 'OYO', '374319'),
(4320, '374320', 'úÏ…W§', '374320@oyoedu.ng', '8056956831', 'AL-HJAMAH COMP SCHL.', 'OYO', '374320'),
(4321, '374321', 'úÏ…W§', '374321@oyoedu.ng', '8061524677', 'GOVT JNR SCH', 'OSUN', '374321'),
(4322, '374322', 'úÏ…W§', '374322@oyoedu.ng', '9060838500', 'DOMINION HIGH SCH', 'OYO', '374322'),
(4323, '374323', 'úÏ…W§', '374323@oyoedu.ng', '8029101280', 'COMM HIGH SCH', 'OYO', '374323'),
(4324, '374324', 'úÏ…W§', '374324@oyoedu.ng', '8071539339', 'OLUMIDE COMM SEC', 'OYO', '374324'),
(4325, '374325', 'úÏ…W§', '374325@oyoedu.ng', '9071741753', 'GALAXY INT. COLL.', 'OYO', '374325'),
(4326, '374326', 'úÏ…W§', '374326@oyoedu.ng', '8059976939', 'KANZUL-FATE COLLEGE', 'OYO', '374326'),
(4327, '374327', 'úÏ…W§', '374327@oyoedu.ng', '8056542094', 'ARIYO INT COLL', 'ONDO', '374327'),
(4328, '374328', 'úÏ…W§', '374328@oyoedu.ng', '8033537920', 'FAITH FOUNDATION', 'OYO', '374328'),
(4329, '374329', 'úÏ…W§', '374329@oyoedu.ng', '8183830159', 'DANIEL COLLEGE', 'OYO', '374329'),
(4330, '374330', 'úÏ…W§', '374330@oyoedu.ng', '8022338368', 'BRILLIANT HIGH SCH', 'OYO', '374330'),
(4331, '374331', 'úÏ…W§', '374331@oyoedu.ng', '7065970232', 'BISHOP AKINYELE', 'OSUN', '374331'),
(4332, '374332', 'úÏ…W§', '374332@oyoedu.ng', '8055665264', 'HOLY GRACE INT', 'OYO', '374332'),
(4333, '374333', 'úÏ…W§', '374333@oyoedu.ng', '901071416', 'METHODIST JNR SCH', 'OYO', '374333'),
(4334, '374334', 'úÏ…W§', '374334@oyoedu.ng', '8066916465', 'O.C.S.S', 'OSUN', '374334'),
(4335, '374335', 'úÏ…W§', '374335@oyoedu.ng', '8034489291', 'HIGHER HIGHT', 'OYO', '374335'),
(4336, '374336', 'úÏ…W§', '374336@oyoedu.ng', '8075056144', 'HIGHER HIGHT', 'OYO', '374336'),
(4337, '374337', 'úÏ…W§', '374337@oyoedu.ng', '8035748385', 'GREAT WINNERS', 'EKITI', '374337'),
(4338, '374338', 'úÏ…W§', '374338@oyoedu.ng', '8113068725', 'ST. LOUIS MOKOLA', 'OYO', '374338'),
(4339, '374339', 'úÏ…W§', '374339@oyoedu.ng', '7069205883', 'INT SCH ABIOLA', 'OYO', '374339'),
(4340, '374340', 'úÏ…W§', '374340@oyoedu.ng', '8034936682', 'I.C.A', 'OYO', '374340'),
(4341, '374341', 'úÏ…W§', '374341@oyoedu.ng', '8056683714', 'SUCCESS COLLEGE', 'OYO', '374341'),
(4342, '374342', 'úÏ…W§', '374342@oyoedu.ng', '8034992034', 'SALAM GROUP', 'OYO', '374342'),
(4343, '374343', 'úÏ…W§', '374343@oyoedu.ng', '8054265968', 'ADESINA COLLEGE', 'OYO', '374343'),
(4344, '374344', 'úÏ…W§', '374344@oyoedu.ng', '7059958214', 'AGGS', 'OYO', '374344'),
(4345, '374345', 'úÏ…W§', '374345@oyoedu.ng', '8057514187', 'LOYOLA COLLEGE', 'OYO', '374345'),
(4346, '374346', 'úÏ…W§', '374346@oyoedu.ng', '9131424014', 'ST. PETER GRAMM.', 'OYO', '374346'),
(4347, '374347', 'úÏ…W§', '374347@oyoedu.ng', '8053446514', 'ASSOLIHUN MODEL', 'OYO', '374347'),
(4348, '374348', 'úÏ…W§', '374348@oyoedu.ng', '8180197525', 'CLEVELAND COLLEGE', 'OYO', '374348'),
(4349, '374349', 'úÏ…W§', '374349@oyoedu.ng', '8023425227', 'METHODIST JNR SCH', 'OYO', '374349'),
(4350, '374350', 'úÏ…W§', '374350@oyoedu.ng', '8038046132', 'ABUNDANT MODEL', 'OYO', '374350'),
(4351, '374351', 'úÏ…W§', '374351@oyoedu.ng', '8107075599', 'GREATER HEIGHT', 'OSUN', '374351'),
(4352, '374352', 'úÏ…W§', '374352@oyoedu.ng', '8034269948', 'COMMAND DAY SEC.', 'OYO', '374352'),
(4353, '374353', 'úÏ…W§', '374353@oyoedu.ng', '8038523719', 'SANVIC MIRACLE', 'OYO', '374353'),
(4354, '374354', 'úÏ…W§', '374354@oyoedu.ng', '8140474058', 'I.C.A', 'OYO', '374354'),
(4355, '374355', 'úÏ…W§', '374355@oyoedu.ng', '8054791269', 'CITADEL ISLAMIC', 'OYO', '374355'),
(4356, '374356', 'úÏ…W§', '374356@oyoedu.ng', '8052402980', 'CITADEL ISLAMIC', 'OYO', '374356'),
(4357, '374357', 'úÏ…W§', '374357@oyoedu.ng', '8063613105', 'COMM GRAM SCH', 'OYO', '374357'),
(4358, '374358', 'úÏ…W§', '374358@oyoedu.ng', '8068970001', 'FIRDAUS GATE', 'OYO', '374358'),
(4359, '374359', 'úÏ…W§', '374359@oyoedu.ng', '8055613767', 'ROYAL DIADEM', 'OYO', '374359'),
(4360, '374360', 'úÏ…W§', '374360@oyoedu.ng', '8056210372', 'FGGC OYO', 'OYO', '374360'),
(4361, '374361', 'úÏ…W§', '374361@oyoedu.ng', '8063356852', 'RICHDEL MODEL COLLEGE', 'OYO', '374361'),
(4362, '374362', 'úÏ…W§', '374362@oyoedu.ng', '8035849968', 'KEFORT INT COLL', 'OYO', '374362'),
(4363, '274363', 'úÏ…W§', '274363@oyoedu.ng', '8052278221', 'EYINNI HIGH SCH', 'OYO', '274363'),
(4364, '274364', 'úÏ…W§', '274364@oyoedu.ng', '8069317042', 'GLOBAL COLLEGE', 'OYO', '274364'),
(4365, '374365', 'úÏ…W§', '374365@oyoedu.ng', '8033819111', 'FOSAG COLLEGE', 'OYO', '374365'),
(4366, '374366', 'úÏ…W§', '374366@oyoedu.ng', '8132961598', 'OFFAADEDOKUN', 'OYO', '374366'),
(4367, '374367', 'úÏ…W§', '374367@oyoedu.ng', '8132961598', 'ANGLICAN GRAM', 'OYO', '374367'),
(4368, '374368', 'úÏ…W§', '374368@oyoedu.ng', '8074916720', 'AMBASSADOR GROUP', 'OYO', '374368'),
(4369, '374369', 'úÏ…W§', '374369@oyoedu.ng', '8056176547', 'EYINNI HIGH SCH', 'OYO', '374369'),
(4370, '374370', 'úÏ…W§', '374370@oyoedu.ng', '8039306930', 'MUSLIM MODEL', 'OYO', '374370'),
(4371, '374371', 'úÏ…W§', '374371@oyoedu.ng', '8052755053', 'MARVELOUS G', 'OYO', '374371'),
(4372, '374372', 'úÏ…W§', '374372@oyoedu.ng', '8030705098', 'SCEPTRE COLL.', 'OYO', '374372'),
(4373, '374373', 'úÏ…W§', '374373@oyoedu.ng', '8055075859', 'AL-HASSAN INT', 'OYO', '374373'),
(4374, '374374', 'úÏ…W§', '374374@oyoedu.ng', '7066456399', 'GOVT. SEC. SCH. JNR', 'OYO', '374374'),
(4375, '374375', 'úÏ…W§', '374375@oyoedu.ng', '8033431827', 'GOVT SEC SCH ORITA', 'OYO', '374375'),
(4376, '374376', 'úÏ…W§', '374376@oyoedu.ng', '8034344344', 'BAPTIST ACADEMY', 'ZAMFARA', '374376'),
(4377, '374377', 'úÏ…W§', '374377@oyoedu.ng', '', 'AL-AEMAN SCH', 'OYO', '374377'),
(4378, '374378', 'úÏ…W§', '374378@oyoedu.ng', '8054583088', 'CROWN HEIGHTS', 'OYO', '374378'),
(4379, '374379', 'úÏ…W§', '374379@oyoedu.ng', '8032067340', 'LIBERTY SEC SCH', 'OSUN', '374379'),
(4380, '374380', 'úÏ…W§', '374380@oyoedu.ng', '8079854185', 'AYOBAMI AL-IKODDS', 'OYO', '374380'),
(4381, '374381', 'úÏ…W§', '374381@oyoedu.ng', '8063242676', 'AYOBAMI AL-IKODDS', 'OYO', '374381'),
(4382, '374382', 'úÏ…W§', '374382@oyoedu.ng', '9031822165', 'JOINT-HEIRS SEC', 'OYO', '374382'),
(4383, '374383', 'úÏ…W§', '374383@oyoedu.ng', '8030776413', 'LOVE OF GOD COLL.', 'OYO', '374383'),
(4384, '374384', 'úÏ…W§', '374384@oyoedu.ng', '8065565153', 'FGGC OYO', 'OGUN', '374384'),
(4385, '374385', 'úÏ…W§', '374385@oyoedu.ng', '8053513345', 'FRONT RUNNERS', 'OGUN', '374385'),
(4386, '374386', 'úÏ…W§', '374386@oyoedu.ng', '8053513345', 'OLUNDE COMM. SEC SCH', 'OYO', '374386'),
(4387, '374387', 'úÏ…W§', '374387@oyoedu.ng', '8056411334', 'ELETA HIGH SCH', 'OYO', '374387'),
(4388, '374388', 'úÏ…W§', '374388@oyoedu.ng', '8034032621', 'ABUNDANT MODEL', 'OYO', '374388'),
(4389, '374389', 'úÏ…W§', '374389@oyoedu.ng', '9028802355', 'IGBOELERIN GRAM SCH', 'OYO', '374389'),
(4390, '374390', 'úÏ…W§', '374390@oyoedu.ng', '7041766833', 'IGBOELERIN GRAM SCH', 'OYO', '374390'),
(4391, '374391', 'úÏ…W§', '374391@oyoedu.ng', '8053462436', 'AIM MAICERS COLLEGE', 'OYO', '374391'),
(4392, '374392', 'úÏ…W§', '374392@oyoedu.ng', '8053595350', 'BIOKU ALAADUN', 'OSUN', '374392'),
(4393, '374393', 'úÏ…W§', '374393@oyoedu.ng', '9027990928', 'AL-UMMAH MODEL', 'OYO', '374393'),
(4394, '374394', 'úÏ…W§', '374394@oyoedu.ng', '8074295051', 'FORESIGHT  HIGH SCH', 'OYO', '374394'),
(4395, '374395', 'úÏ…W§', '374395@oyoedu.ng', '8140783985', 'DAARUL-HIKMAH', 'OYO', '374395'),
(4396, '374396', 'úÏ…W§', '374396@oyoedu.ng', '7037303530', 'GOVT JNR SCH', 'OYO', '374396'),
(4397, '374397', 'úÏ…W§', '374397@oyoedu.ng', '8038673461', 'IKOLABA GRAMMER', 'OYO', '374397'),
(4398, '374398', 'úÏ…W§', '374398@oyoedu.ng', '8032207129', 'BEVLAH ACADEMY', 'OYO', '374398'),
(4399, '374399', 'úÏ…W§', '374399@oyoedu.ng', '9061198346', 'AL-QAWYY', 'OYO', '374399'),
(4400, '374400', 'úÏ…W§', '374400@oyoedu.ng', '8052111773', 'TAGOS', 'OYO', '374400'),
(4401, '374401', 'úÏ…W§', '374401@oyoedu.ng', '8059465451', 'FRONT MODEL', 'OYO', '374401'),
(4402, '374402', 'úÏ…W§', '374402@oyoedu.ng', '7054330245', 'FOSAIG COLLEGE', 'OYO', '374402'),
(4403, '374403', 'úÏ…W§', '374403@oyoedu.ng', '8120555667', 'GOVT JNR SCH', 'OYO', '374403'),
(4404, '374404', 'úÏ…W§', '374404@oyoedu.ng', '8057293027', 'DOT MIST COLLEGE', 'OYO', '374404'),
(4405, '374405', 'úÏ…W§', '374405@oyoedu.ng', '8063220385', 'GOD\'S BILLONARE', 'OYO', '374405'),
(4406, '374406', 'úÏ…W§', '374406@oyoedu.ng', '8038254792', 'COMMAND DAY SEC.', 'OYO', '374406'),
(4407, '374407', 'úÏ…W§', '374407@oyoedu.ng', '8075457263', 'MAFERISK COLL.', 'OYO', '374407'),
(4408, '374408', 'úÏ…W§', '374408@oyoedu.ng', '8102939998', 'M.L.G.H.S', 'OYO', '374408'),
(4409, '374409', 'úÏ…W§', '374409@oyoedu.ng', '810293998', 'CARITAS SEC. SCH', 'OYO', '374409'),
(4410, '374410', 'úÏ…W§', '374410@oyoedu.ng', '8033800467', 'COMMAND DAY SEC.', 'OYO', '374410'),
(4411, '374411', 'úÏ…W§', '374411@oyoedu.ng', '8072716263', 'ARABIC SCH', 'OYO', '374411'),
(4412, '374412', 'úÏ…W§', '374412@oyoedu.ng', '8064858784', 'MUFUDANHUNT', 'OYO', '374412'),
(4413, '374413', 'úÏ…W§', '374413@oyoedu.ng', '8169933769', 'FORESIGHT  HIGH SCH', 'OYO', '374413'),
(4414, '374414', 'úÏ…W§', '374414@oyoedu.ng', '8051573981', 'AL-AMEEN GROUP', 'OYO', '374414'),
(4415, '374415', 'úÏ…W§', '374415@oyoedu.ng', '8028945223', 'EXCELLENT ACADEMY', 'OYO', '374415'),
(4416, '374416', 'úÏ…W§', '374416@oyoedu.ng', '8166370728', 'MADIBO ISLAMIC MODEL', 'OYO', '374416'),
(4417, '374417', 'úÏ…W§', '374417@oyoedu.ng', '9075046459', 'URBAN DAY SEC SCH', 'KOGI', '374417'),
(4418, '374418', 'úÏ…W§', '374418@oyoedu.ng', '8112110958', 'COMMUNITY SEC SCH', 'OYO', '374418'),
(4419, '374419', 'úÏ…W§', '374419@oyoedu.ng', '8057871709', 'AL-EEMAN SCH OF SCI', 'OYO', '374419'),
(4420, '374420', 'úÏ…W§', '374420@oyoedu.ng', '8033431827', 'COMMAND DAY SEC.', 'OYO', '374420'),
(4421, '374421', 'úÏ…W§', '374421@oyoedu.ng', '7030124833', 'ROYAL SEEDACA', 'EKITI', '374421'),
(4422, '374422', 'úÏ…W§', '374422@oyoedu.ng', '8101689055', 'TA\'AWANN GROUP', 'OYO', '374422'),
(4423, '374423', 'úÏ…W§', '374423@oyoedu.ng', '9095056459', '', 'KOGI', '374423'),
(4424, '374424', 'úÏ…W§', '374424@oyoedu.ng', '8060173243', 'APERIN OWIYEKE', 'OSUN', '374424'),
(4425, '374425', 'úÏ…W§', '374425@oyoedu.ng', '8155644196', 'LOYOLA COLLEGE', 'OYO', '374425'),
(4426, '374426', 'úÏ…W§', '374426@oyoedu.ng', '8075575750', 'AM-FIA GOD\'S GRACE COLL', 'OYO', '374426'),
(4427, '374427', 'úÏ…W§', '374427@oyoedu.ng', '8146335479', 'OLUBADAN JNR', 'OYO', '374427'),
(4428, '374428', 'úÏ…W§', '374428@oyoedu.ng', '8056666767', 'ALSAN ACADEMY', 'OYO', '374428'),
(4429, '374429', 'úÏ…W§', '374429@oyoedu.ng', '8102528931', 'COMM. GRAMMER', 'OYO', '374429'),
(4430, '374430', 'úÏ…W§', '374430@oyoedu.ng', '9032514654', 'URBAN DAY SEC SCH', 'OYO', '374430'),
(4431, '374431', 'úÏ…W§', '374431@oyoedu.ng', '8132556048', 'PROVIDENCE SCH', 'OYO', '374431'),
(4432, '374432', 'úÏ…W§', '374432@oyoedu.ng', '8030423397', 'FED GOVT SCH', 'OYO', '374432'),
(4433, '374433', 'úÏ…W§', '374433@oyoedu.ng', '8038551934', 'FED GOVT SCH', 'OYO', '374433'),
(4434, '374434', 'úÏ…W§', '374434@oyoedu.ng', '8026351414', 'CITY MODEL COLL.', 'OYO', '374434'),
(4435, '374435', 'úÏ…W§', '374435@oyoedu.ng', '9068249146', 'ALHAQQU COLL', 'OYO', '374435'),
(4436, '374436', 'úÏ…W§', '374436@oyoedu.ng', '8102406618', 'QUANTUM LEAP', 'OSUN', '374436'),
(4437, '374437', 'úÏ…W§', '374437@oyoedu.ng', '7066528569', 'CENTEX HIGH SCH', 'OYO', '374437'),
(4438, '374438', 'úÏ…W§', '374438@oyoedu.ng', '8059820526', 'METHODIST JNR SCH', 'OYO', '374438'),
(4439, '374439', 'úÏ…W§', '374439@oyoedu.ng', '8051144121', 'MOLUSI COLL.', 'OGUN', '374439'),
(4440, '374440', 'úÏ…W§', '374440@oyoedu.ng', '8078422412', 'MOLUSI COLL.', 'OGUN', '374440'),
(4441, '374441', 'úÏ…W§', '374441@oyoedu.ng', '813454777', 'IBADAN GRAMMER', 'OYO', '374441'),
(4442, '374442', 'úÏ…W§', '374442@oyoedu.ng', '8035794763', 'RICHDEL MODEL COLLEGE', 'OYO', '374442'),
(4443, '374443', 'úÏ…W§', '374443@oyoedu.ng', '8089629652', 'ABBEY TECH', 'OYO', '374443'),
(4444, '374444', 'úÏ…W§', '374444@oyoedu.ng', '8035359796', 'LEGACY', 'OYO', '374444'),
(4445, '374445', 'úÏ…W§', '374445@oyoedu.ng', '8035359796', 'BAPTIST EJIOKU', 'OYO', '374445'),
(4446, '374446', 'úÏ…W§', '374446@oyoedu.ng', '8024399718', 'AGUGU HIGH SCH', 'OYO', '374446'),
(4447, '374447', 'úÏ…W§', '374447@oyoedu.ng', '8051802839', 'DAARUL-HIKMAH', 'OYO', '374447'),
(4448, '374448', 'úÏ…W§', '374448@oyoedu.ng', '8132838851', 'AYAMA MONTESSORI', 'OYO', '374448'),
(4449, '374449', 'úÏ…W§', '374449@oyoedu.ng', '8034379915', 'METHODIST JNR SCH', 'OYO', '374449'),
(4450, '374450', 'úÏ…W§', '374450@oyoedu.ng', '8034370015', 'METHODIST JNR SCH', 'OYO', '374450'),
(4451, '374451', 'úÏ…W§', '374451@oyoedu.ng', '8033546941', 'IFELODUN JNR', 'OSUN', '374451'),
(4452, '374452', 'úÏ…W§', '374452@oyoedu.ng', '8034907919', 'NESAM', 'DELTA', '374452'),
(4453, '374453', 'úÏ…W§', '374453@oyoedu.ng', '9026854391', 'SIT COLLEGE', 'OYO', '374453'),
(4454, '374454', 'úÏ…W§', '374454@oyoedu.ng', '8143347730', 'AL-AMEEN GROUP', 'OYO', '374454'),
(4455, '374455', 'úÏ…W§', '374455@oyoedu.ng', '8138326126', 'IBADAN CITY ACADEMY', 'OYO', '374455'),
(4456, '374456', 'úÏ…W§', '374456@oyoedu.ng', '8035767676', 'KINDOM BASE', 'OYO', '374456'),
(4457, '374457', 'úÏ…W§', '374457@oyoedu.ng', '8122160385', 'AL-MARIAM COLLEGE', 'OYO', '374457'),
(4458, '374458', 'úÏ…W§', '374458@oyoedu.ng', '8037473205', '', 'OYO', '374458'),
(4459, '374459', 'úÏ…W§', '374459@oyoedu.ng', '8093820065', 'COMMUNITY ABONDE', 'OYO', '374459'),
(4460, '374460', 'úÏ…W§', '374460@oyoedu.ng', '8060091158', 'PROVIDENCE SCH', 'OSUN', '374460'),
(4461, '374461', 'úÏ…W§', '374461@oyoedu.ng', '8063936694', 'GCI', 'EKITI', '374461'),
(4462, '374462', 'úÏ…W§', '374462@oyoedu.ng', '8035195320', 'THE PROFICIENT ACADEMY', 'OSUN', '374462'),
(4463, '374463', 'úÏ…W§', '374463@oyoedu.ng', '7038413935', 'IMPERIAL INT', 'OYO', '374463'),
(4464, '374464', 'úÏ…W§', '374464@oyoedu.ng', '8055753361', 'EDUCATION COLLEGE', 'OYO', '374464'),
(4465, '374465', 'úÏ…W§', '374465@oyoedu.ng', '8034110174', 'I.M.G GRAM.', 'OYO', '374465'),
(4466, '374466', 'úÏ…W§', '374466@oyoedu.ng', '8062824322', 'MODEL COLLEGE', 'OYO', '374466'),
(4467, '374467', 'úÏ…W§', '374467@oyoedu.ng', '', 'TRIPLE ACADEMY', 'OYO', '374467'),
(4468, '374468', 'úÏ…W§', '374468@oyoedu.ng', '8062824322', 'GOD\'S FOUNDATION', '', '374468'),
(4469, '374469', 'úÏ…W§', '374469@oyoedu.ng', '7038296021', 'WINNER COLLEGE', 'EKITI', '374469'),
(4470, '374470', 'úÏ…W§', '374470@oyoedu.ng', '8020774907', '', 'OYO', '374470'),
(4471, '374471', 'úÏ…W§', '374471@oyoedu.ng', '8058154133', 'ABLE CONCEPT SCH', 'OYO', '374471'),
(4472, '374472', 'úÏ…W§', '374472@oyoedu.ng', '8057905497', 'KOLADE PRIVATE', 'OYO', '374472'),
(4473, '374473', 'úÏ…W§', '374473@oyoedu.ng', '8051656621', 'TRANSFORMATION', 'EKITI', '374473'),
(4474, '374474', 'úÏ…W§', '374474@oyoedu.ng', '7068584412', 'EXCELLERS COLLEGE', 'OYO', '374474'),
(4475, '374475', 'úÏ…W§', '374475@oyoedu.ng', '8032518818', 'RIDWANULLAH', 'OYO', '374475'),
(4476, '374476', 'úÏ…W§', '374476@oyoedu.ng', '9021009844', 'KINGSLEY SPRING', 'OYO', '374476'),
(4477, '374477', 'úÏ…W§', '374477@oyoedu.ng', '7037368738', 'S.S INT', 'DELTA', '374477'),
(4478, '374478', 'úÏ…W§', '374478@oyoedu.ng', '8035230479', 'METHODIST JNR SCH', 'OYO', '374478'),
(4479, '374479', 'úÏ…W§', '374479@oyoedu.ng', '8035230479', 'AL-BARKA GROUP', 'OYO', '374479'),
(4480, '374480', 'úÏ…W§', '374480@oyoedu.ng', '8033126386', 'AL-BARKA GROUP', 'OYO', '374480'),
(4481, '374481', 'úÏ…W§', '374481@oyoedu.ng', '8069059201', 'OLATUNDUN MODEL', 'OSUN', '374481'),
(4482, '374482', 'úÏ…W§', '374482@oyoedu.ng', '8057014896', 'ALAPATA ONIREKE', 'OYO', '374482'),
(4483, '374483', 'úÏ…W§', '374483@oyoedu.ng', '8063174645', 'MONATAN HIGH', 'OYO', '374483'),
(4484, '374484', 'úÏ…W§', '374484@oyoedu.ng', '8063174645', 'ADVERTIST JNR', 'OSUN', '374484'),
(4485, '374485', 'úÏ…W§', '374485@oyoedu.ng', '8025058251', 'CHRIST LIFE COLLEGE', 'OSUN', '374485'),
(4486, '374486', 'úÏ…W§', '374486@oyoedu.ng', '9079423817', 'DOMINION INT', 'OSUN', '374486'),
(4487, '374487', 'úÏ…W§', '374487@oyoedu.ng', '803717636', 'HOLY CROWN COLLEGE', 'OYO', '374487'),
(4488, '374488', 'úÏ…W§', '374488@oyoedu.ng', '8074363138', 'ROYAL DIADEM', 'OYO', '374488'),
(4489, '374489', 'úÏ…W§', '374489@oyoedu.ng', '8039197155', 'ISABATUDEEN GIRLS', 'OYO', '374489'),
(4490, '374490', 'úÏ…W§', '374490@oyoedu.ng', '8132045313', 'MOUNT SINAI', 'ONDO', '374490'),
(4491, '374491', 'úÏ…W§', '374491@oyoedu.ng', '8053194669', 'JALAD MODEL SCH', 'OYO', '374491'),
(4492, '374492', 'úÏ…W§', '374492@oyoedu.ng', '8059570134', 'LOYOLA COLLEGE', 'OYO', '374492'),
(4493, '374493', 'úÏ…W§', '374493@oyoedu.ng', '8027576776', 'HELPLINE', 'OYO', '374493'),
(4494, '374494', 'úÏ…W§', '374494@oyoedu.ng', '8027576776', 'ARI COLLEGE', 'OYO', '374494'),
(4495, '374495', 'úÏ…W§', '374495@oyoedu.ng', '8026145659', 'ARI COLLEGE', 'OYO', '374495'),
(4496, '374496', 'úÏ…W§', '374496@oyoedu.ng', '8164574491', 'DAYSPRING ACA', 'OYO', '374496'),
(4497, '374497', 'úÏ…W§', '374497@oyoedu.ng', '9053494376', 'GLORIOUS COLLEGE', 'OYO', '374497'),
(4498, '374498', 'úÏ…W§', '374498@oyoedu.ng', '80339918476', 'DADEJO SCH ', 'LAGOS', '374498'),
(4499, '374499', 'úÏ…W§', '374499@oyoedu.ng', '8153537177', 'COMP COLLEGE', 'OYO', '374499'),
(4500, '374500', 'úÏ…W§', '374500@oyoedu.ng', '8055068925', 'AL BARIVAR COM', 'OYO', '374500'),
(4501, '374501', 'úÏ…W§', '374501@oyoedu.ng', '9054200743', 'IBADAN GRAMMER', 'OSUN', '374501'),
(4502, '374502', 'úÏ…W§', '374502@oyoedu.ng', '8169010209', 'GRACE ROYAL', 'OYO', '374502'),
(4503, '374503', 'úÏ…W§', '374503@oyoedu.ng', '9034622996', 'SECOND HOME COLLEGE', 'OYO', '374503'),
(4504, '374504', 'úÏ…W§', '374504@oyoedu.ng', '8034691226', 'HIS KINGDOM HIGH', 'OYO', '374504'),
(4505, '374505', 'úÏ…W§', '374505@oyoedu.ng', '7046489813', 'OKE OGBERE COLL', 'OYO', '374505'),
(4506, '374506', 'úÏ…W§', '374506@oyoedu.ng', '8034988641', 'AUNTY JOY MODEL', 'OYO', '374506'),
(4507, '374507', 'úÏ…W§', '374507@oyoedu.ng', '8136345346', 'PIONEER COLLEGE', 'OYO', '374507'),
(4508, '374508', 'úÏ…W§', '374508@oyoedu.ng', '8055369570', 'TOGEM', 'OYO', '374508'),
(4509, '374509', 'úÏ…W§', '374509@oyoedu.ng', '8032450710', 'PACESETTER COM', 'OYO', '374509'),
(4510, '374510', 'úÏ…W§', '374510@oyoedu.ng', '7035393902', 'ABADINA COLLEGE', 'OYO', '374510'),
(4511, '374511', 'úÏ…W§', '374511@oyoedu.ng', '7057111199', 'AL-QUARRAA COL', 'OYO', '374511'),
(4512, '374512', 'úÏ…W§', '374512@oyoedu.ng', '8038090386', 'ACHIEVER EXCEL', 'OYO', '374512'),
(4513, '374513', 'úÏ…W§', '374513@oyoedu.ng', '8038090386', 'IBADAN CITY ACA', 'OYO', '374513'),
(4514, '374514', 'úÏ…W§', '374514@oyoedu.ng', '8175983043', 'SUMMIT COMP COLLEGE', 'OYO', '374514'),
(4515, '374515', 'úÏ…W§', '374515@oyoedu.ng', '8052434095', 'TOP CLEM MODEL', 'OYO', '374515'),
(4516, '374516', 'úÏ…W§', '374516@oyoedu.ng', '8055214094', 'PRIME COLLEGE IYANA CHURCH', 'OGUN', '374516'),
(4517, '374517', 'úÏ…W§', '374517@oyoedu.ng', '8069080125', 'ST. JAME CATH', 'ANAMBR', '374517'),
(4518, '374518', 'úÏ…W§', '374518@oyoedu.ng', '803881905', 'ROYAL DIADEM', 'OYO', '374518'),
(4519, '374519', 'úÏ…W§', '374519@oyoedu.ng', '8067742374', 'SALVATION GATE COLLEGE', 'OYO', '374519'),
(4520, '374520', 'úÏ…W§', '374520@oyoedu.ng', '8057628284', 'OMOWUMI COLLEGE', 'OYO', '374520'),
(4521, '374521', 'úÏ…W§', '374521@oyoedu.ng', '8035719831', 'OYO STATE MODEL', 'ONDO', '374521'),
(4522, '374522', 'úÏ…W§', '374522@oyoedu.ng', '8053930549', 'ADESINA COLLEGE', 'OYO', '374522'),
(4523, '374523', 'úÏ…W§', '374523@oyoedu.ng', '8038836126', 'DIVINE SUCCESS COLL', 'OYO', '374523'),
(4524, '374524', 'úÏ…W§', '374524@oyoedu.ng', '8071184814', 'GOD WITH US SEC SCHL IB.', 'OSUN', '374524'),
(4525, '374525', 'úÏ…W§', '374525@oyoedu.ng', '8134572185', 'GOD WITH US SEC SCHL IB.', 'OSUN', '374525'),
(4526, '734526', 'úÏ…W§', '734526@oyoedu.ng', '8134356933', 'AL-HIKMAH NODEL COLLEGE IDERE', 'OYO', '734526'),
(4527, '734527', 'úÏ…W§', '734527@oyoedu.ng', '9068974925', 'AL-HIKMAH NODEL COLLEGE IDERE', 'OYO', '734527'),
(4528, '734528', 'úÏ…W§', '734528@oyoedu.ng', '8073712981', 'FLOURISHLAND PRIVATE SCHOOL', 'OYO', '734528'),
(4529, '734529', 'úÏ…W§', '734529@oyoedu.ng', '9068784191', 'OKEDERE HIGH SCHOOL, IDERE', 'OYO', '734529'),
(4530, '734530', 'úÏ…W§', '734530@oyoedu.ng', '7040272971', 'HIS GRACE HIGH SCH. IDERE', 'OYO', '734530'),
(4531, '734531', 'úÏ…W§', '734531@oyoedu.ng', '7056915147', 'SUCCESS MUSLIM COLLRGE IGANGAN', 'OYO', '734531'),
(4532, '734532', 'úÏ…W§', '734532@oyoedu.ng', '8147822932', 'ITORI COMPREHENSIVE HIGH SCHL AB.', 'OYO', '734532'),
(4533, '734533', 'úÏ…W§', '734533@oyoedu.ng', '7031390144', 'HOPECREST COLLEGE IDERE', 'OYO', '734533'),
(4534, '734534', 'úÏ…W§', '734534@oyoedu.ng', '9054635885', 'NAWARUDEEN GRAM. SCH. IGBOORA', 'OYO', '734534');
INSERT INTO `student` (`stdid`, `stdname`, `stdpassword`, `emailid`, `contactno`, `address`, `city`, `pincode`) VALUES
(4535, '454535', 'úÏ…W§', '454535@oyoedu.ng', '8034209779', 'SAMSUDEEN GRAMM SCHOOL', 'OYO', '454535'),
(4536, '454536', 'úÏ…W§', '454536@oyoedu.ng', '7031167884', 'AL-HAQ FOCUS GRP OF SCHL', 'OYO', '454536'),
(4537, '454537', 'úÏ…W§', '454537@oyoedu.ng', '8036234963', 'AL-HUFFAZ ACADEMY', 'OYO', '454537'),
(4538, '454538', 'úÏ…W§', '454538@oyoedu.ng', '8066886772', 'IYA OJE COMM HIGH SCHL', 'OYO', '454538'),
(4539, '454539', 'úÏ…W§', '454539@oyoedu.ng', '7030191433', 'HOLY COMP COLLEGE, AIPO', 'OYO', '454539'),
(4540, '454540', 'úÏ…W§', '454540@oyoedu.ng', '7062389398', 'SOUN HIGH SCHOOL', 'OYO', '454540'),
(4541, '454541', 'úÏ…W§', '454541@oyoedu.ng', '9068094805', 'LORD\'S MODEL COLLEGE', 'OYO', '454541'),
(4542, '454542', 'úÏ…W§', '454542@oyoedu.ng', '8030510775', 'AL-FAIZ MUSLIM COLLEGE', 'OYO', '454542'),
(4543, '454543', 'úÏ…W§', '454543@oyoedu.ng', '8133026172', 'ALLAH\'S WILL SEC SCHOOL', 'OYO', '454543'),
(4544, '454544', 'úÏ…W§', '454544@oyoedu.ng', '8136245364', 'MESSIAH COLLEGE', 'OYO', '454544'),
(4545, '454545', 'úÏ…W§', '454545@oyoedu.ng', '8135301451', 'ZOE COLLEGE', 'OYO', '454545'),
(4546, '454546', 'úÏ…W§', '454546@oyoedu.ng', '9021897955', 'MESSIAH COLLEGE', 'OYO', '454546'),
(4547, '454547', 'úÏ…W§', '454547@oyoedu.ng', '8069701698', 'MUSLIM GRAMM SCHOOL', 'OYO', '454547'),
(4548, '454548', 'úÏ…W§', '454548@oyoedu.ng', '8026388434', 'OGBO GRAMM SCHOOL', 'OYO', '454548'),
(4549, '454549', 'úÏ…W§', '454549@oyoedu.ng', '8037673617', 'AT-TAHOEED GRP OF SCHL', 'OYO', '454549'),
(4550, '454550', 'úÏ…W§', '454550@oyoedu.ng', '8067409166', 'GOOD NEWS SEC. SCHL', 'OYO', '454550'),
(4551, '454551', 'úÏ…W§', '454551@oyoedu.ng', '8166301936', 'ZOE COLLEGE', 'OSUN', '454551'),
(4552, '454552', 'úÏ…W§', '454552@oyoedu.ng', '7039012327', 'GOD\'S GIFT SEC SCHOOL', 'OYO', '454552'),
(4553, '454553', 'úÏ…W§', '454553@oyoedu.ng', '8066639748', 'MAYDAY COLLEGE', 'OYO', '454553'),
(4554, '454554', 'úÏ…W§', '454554@oyoedu.ng', '7049089941', 'MAYDAY COLLEGE', 'OYO', '454554'),
(4555, '454555', 'úÏ…W§', '454555@oyoedu.ng', '8036319078', 'COMFORTER SCHOOL', 'OYO', '454555'),
(4556, '454556', 'úÏ…W§', '454556@oyoedu.ng', '8126447426', 'GREAT CITY COLLEGE', 'OYO', '454556'),
(4557, '454557', 'úÏ…W§', '454557@oyoedu.ng', '8062700868', 'AJIBARE COM. HIGH SCHL', 'OYO', '454557'),
(4558, '454558', 'úÏ…W§', '454558@oyoedu.ng', '8062700868', 'AJIBARE COM. HIGH SCHL', 'OYO', '454558'),
(4559, '454559', 'úÏ…W§', '454559@oyoedu.ng', '8058889810', 'ORI OKE COMM GRAM SCHL', 'OYO', '454559'),
(4560, '454560', 'úÏ…W§', '454560@oyoedu.ng', '7066067874', 'REMARK SCHOOL', 'OYO', '454560'),
(4561, '454561', 'úÏ…W§', '454561@oyoedu.ng', '9060561532', 'GREAT CITY COLLEGE', 'OYO', '454561'),
(4562, '454562', 'úÏ…W§', '454562@oyoedu.ng', '8166301946', 'GOD FIRST COLLEGE, IDI ORO', 'OYO', '454562'),
(4563, '454563', 'úÏ…W§', '454563@oyoedu.ng', '7069527252', 'THE REDEMPTION COLLEGE', 'OYO', '454563'),
(4564, '454564', 'úÏ…W§', '454564@oyoedu.ng', '8037597048', 'MORENIKE COMP HIGH SCHL', 'OYO', '454564'),
(4565, '454565', 'úÏ…W§', '454565@oyoedu.ng', '7037619600', 'MORENIKE COMP HIGH SCHL', 'OYO', '454565'),
(4566, '454566', 'úÏ…W§', '454566@oyoedu.ng', '7066634967', 'CARETAKER COMM HIGH SCHL', 'OYO', '454566'),
(4567, '454567', 'úÏ…W§', '454567@oyoedu.ng', '8034619036', 'ZOE COLLEGE', 'OYO', '454567'),
(4568, '454568', 'úÏ…W§', '454568@oyoedu.ng', '8037486833', 'MIGHTY MIRACLE COLLEGE', 'OYO', '454568'),
(4569, '454569', 'úÏ…W§', '454569@oyoedu.ng', '9013140713', 'BAPT GRAM SCHL AJAWA', 'OYO', '454569'),
(4570, '454570', 'úÏ…W§', '454570@oyoedu.ng', '7082210669', 'GREAT CITY COLLEGE', 'OYO', '454570'),
(4571, '454571', 'úÏ…W§', '454571@oyoedu.ng', '8168305737', 'MARYLAND CATH GRAM SCHL', 'OYO', '454571'),
(4572, '454572', 'úÏ…W§', '454572@oyoedu.ng', '8031557859', 'GOMA BAPTISTCOLLEGE', 'OYO', '454572'),
(4573, '454573', 'úÏ…W§', '454573@oyoedu.ng', '8061305015', 'MILLENIUM MODEL SCHL', 'OYO', '454573'),
(4574, '454574', 'úÏ…W§', '454574@oyoedu.ng', '9056200200', 'MILLENIUM MODEL SCHL', 'OYO', '454574'),
(4575, '454575', 'úÏ…W§', '454575@oyoedu.ng', '7043355985', 'GOMA BAPTISTCOLLEGE', 'OYO', '454575'),
(4576, '454576', 'úÏ…W§', '454576@oyoedu.ng', '7060981520', 'OGBO GRAMM SCHOOL', 'OYO', '454576'),
(4577, '454577', 'úÏ…W§', '454577@oyoedu.ng', '8069306809', 'ARE AGO HIGH SCHOOL', 'OYO', '454577'),
(4578, '454578', 'úÏ…W§', '454578@oyoedu.ng', '8072224939', 'TEMPLE INT. BAP. ACADEMY', 'OYO', '454578'),
(4579, '454579', 'úÏ…W§', '454579@oyoedu.ng', '8034619036', 'ZOE COLLEGE', 'OYO', '454579'),
(4580, '454580', 'úÏ…W§', '454580@oyoedu.ng', '8036319078', 'COMFORTER SCHOOL', 'OYO', '454580'),
(4581, '454581', 'úÏ…W§', '454581@oyoedu.ng', '8105702827', 'REMARK SCHOOL', 'OYO', '454581'),
(4582, '314582', 'úÏ…W§', '314582@oyoedu.ng', '812771', 'BISIRE HIGH SCHOOL', 'KWARA', '314582'),
(4583, '214583', 'úÏ…W§', '214583@oyoedu.ng', '8024204498', 'TMM MODEL SCHOOL', 'OYO', '214583'),
(4584, '214584', 'úÏ…W§', '214584@oyoedu.ng', '8051280225', 'SHEIKH IBRAHIM COMPREHENSIVE COLLEGE', 'OYO', '214584'),
(4585, '214585', 'úÏ…W§', '214585@oyoedu.ng', '8051280225', 'SHEIKH IBRAHIM COMPREHENSIVE COLLEGE', 'OYO', '214585'),
(4586, '214586', 'úÏ…W§', '214586@oyoedu.ng', '8051280225', 'SHEIKH IBRAHIM COMPREHENSIVE COLLEGE', 'OYO', '214586'),
(4587, '324587', 'úÏ…W§', '324587@oyoedu.ng', '8036976405', 'GREATER GLORY COLL.', 'OYO ', '324587'),
(4588, '324588', 'úÏ…W§', '324588@oyoedu.ng', '7062383012', 'IB. CITY HIGH SCHOOL', 'OYO ', '324588'),
(4589, '324589', 'úÏ…W§', '324589@oyoedu.ng', '8101182914', 'AL-IHSAN COOLLEGE ', 'KWARA', '324589'),
(4590, '324590', 'úÏ…W§', '324590@oyoedu.ng', '8167223785', 'ELITH COLLEGE IB.', 'OYO ', '324590'),
(4591, '324591', 'úÏ…W§', '324591@oyoedu.ng', '8057242497', 'AL-HIQMA ', 'OYO ', '324591'),
(4592, '324592', 'úÏ…W§', '324592@oyoedu.ng', '8056148820', 'AN-NUR MODEL SCH.', 'OYO ', '324592'),
(4593, '324593', 'úÏ…W§', '324593@oyoedu.ng', '8075456932', 'MERIT COMP. COLL.', 'OYO ', '324593'),
(4594, '324594', 'úÏ…W§', '324594@oyoedu.ng', '8033780941', 'OLUNDE COM. SEC SCH.', 'OYO ', '324594'),
(4595, '324595', 'úÏ…W§', '324595@oyoedu.ng', '7013332377', 'ADEM GROUP OF SCH.', 'OYO ', '324595'),
(4596, '324596', 'úÏ…W§', '324596@oyoedu.ng', '8034824404', 'ITUNU HIGH SCH.', 'OYO ', '324596'),
(4597, '324597', 'úÏ…W§', '324597@oyoedu.ng', '8034824404', 'BESLEY SCH. MONIYA', 'OYO ', '324597'),
(4598, '324598', 'úÏ…W§', '324598@oyoedu.ng', '8035660390', 'ADH-DHIKR', 'OYO ', '324598'),
(4599, '324599', 'úÏ…W§', '324599@oyoedu.ng', '8070581737', 'LIVING MIRACLE INT. SCH.', 'OYO ', '324599'),
(4600, '324600', 'úÏ…W§', '324600@oyoedu.ng', '7052563994', 'AL-AMEEN INT. SCH.', 'EDO', '324600'),
(4601, '324601', 'úÏ…W§', '324601@oyoedu.ng', '8061161551', 'ROCK OF AGES', 'OYO ', '324601'),
(4602, '324602', 'úÏ…W§', '324602@oyoedu.ng', '8057039435', '', 'OYO ', '324602'),
(4603, '324603', 'úÏ…W§', '324603@oyoedu.ng', '8033930545', '', 'OYO', '324603'),
(4604, '324604', 'úÏ…W§', '324604@oyoedu.ng', '8035624769', 'HAPPINESS COMP. COLL.', 'OYO', '324604'),
(4605, '324605', 'úÏ…W§', '324605@oyoedu.ng', '8032457432', '', 'OYO', '324605'),
(4606, '324606', 'úÏ…W§', '324606@oyoedu.ng', '7054025583', 'IDO', 'OGUN', '324606'),
(4607, '324607', 'úÏ…W§', '324607@oyoedu.ng', '8059367660', 'OGUN WATER SIDE', 'EKITI', '324607'),
(4608, '324608', 'úÏ…W§', '324608@oyoedu.ng', '8030786095', 'CLASSIC COLLEGE ', 'OGUN', '324608'),
(4609, '324609', 'úÏ…W§', '324609@oyoedu.ng', '9091185666', 'TIP TOP INTERNATIONAL', 'OYO', '324609'),
(4610, '324610', 'úÏ…W§', '324610@oyoedu.ng', '8131518830', 'LANTEM PRIVATE SCH.', 'OYO', '324610'),
(4611, '324611', 'úÏ…W§', '324611@oyoedu.ng', '8138412244', 'FAITH TRIUMPH', 'DELTA', '324611'),
(4612, '324612', 'úÏ…W§', '324612@oyoedu.ng', '7031237339', '', 'OYO', '324612'),
(4613, '324613', 'úÏ…W§', '324613@oyoedu.ng', '8062618691', 'BESLEY COLLEGE', 'OYO', '324613'),
(4614, '324614', 'úÏ…W§', '324614@oyoedu.ng', '7060104723', '', 'OYO', '324614'),
(4615, '324615', 'úÏ…W§', '324615@oyoedu.ng', '8134800987', 'ATAGBA COMMUNITY', 'OYO', '324615'),
(4616, '324616', 'úÏ…W§', '324616@oyoedu.ng', '8134800987', 'ATAGBA COMMUNITY', 'OYO', '324616'),
(4617, '324617', 'úÏ…W§', '324617@oyoedu.ng', '8063031410', 'IJOKODO COMMUNTY SCH.', 'OYO', '324617'),
(4618, '324618', 'úÏ…W§', '324618@oyoedu.ng', '8052432192', 'COMM.  SEC. SCH. OLUNDE', 'OYO', '324618'),
(4619, '324619', 'úÏ…W§', '324619@oyoedu.ng', '8052432192', 'COMM.  SEC. SCH. OLUNDE', 'OYO', '324619'),
(4620, '324620', 'úÏ…W§', '324620@oyoedu.ng', '8029464059', 'GRACELAND VINE COLL.', 'OYO', '324620'),
(4621, '324621', 'úÏ…W§', '324621@oyoedu.ng', '7033052860', 'MAKU GRAMMAR SCH.', 'OYO', '324621'),
(4622, '324622', 'úÏ…W§', '324622@oyoedu.ng', '8055821588', 'BAPTIST MEDICAL SAKI', 'OYO', '324622'),
(4623, '324623', 'úÏ…W§', '324623@oyoedu.ng', '8152105160', 'KING MODEL COLL.', 'OYO', '324623'),
(4624, '324624', 'úÏ…W§', '324624@oyoedu.ng', '7084560406', 'COMMUNITY ODOOBAM', 'OYO', '324624'),
(4625, '324625', 'úÏ…W§', '324625@oyoedu.ng', '8139703846', 'CHRIST CHURCH HIGH SCH.', 'OYO', '324625'),
(4626, '324626', 'úÏ…W§', '324626@oyoedu.ng', '7065703658', 'EVIDENCE OF GRACE ASS. ', 'OYO', '324626'),
(4627, '324627', 'úÏ…W§', '324627@oyoedu.ng', '7062397759', 'GOODLY HERITAGE FIDITI', 'OYO', '324627'),
(4628, '324628', 'úÏ…W§', '324628@oyoedu.ng', '8116802104', 'OLAJIDE', 'OYO', '324628'),
(4629, '324629', 'úÏ…W§', '324629@oyoedu.ng', '', '', 'OYO', '324629'),
(4630, '384630', 'úÏ…W§', '384630@oyoedu.ng', '8064557785', 'ISLAMIC EMBASSY COLLEGE ', 'OYO', '384630'),
(4631, '384631', 'úÏ…W§', '384631@oyoedu.ng', '9012496345', 'IGBO-ELERIN', 'OYO', '384631'),
(4632, '384632', 'úÏ…W§', '384632@oyoedu.ng', '7036918112', 'IGBO-ELERIN', 'OSUN', '384632'),
(4633, '384633', 'úÏ…W§', '384633@oyoedu.ng', '8038383111', 'IGBO-ELERIN', 'OYO', '384633'),
(4634, '384634', 'úÏ…W§', '384634@oyoedu.ng', '8161202756', 'IGBO-ELERIN', 'OYO', '384634'),
(4635, '384635', 'úÏ…W§', '384635@oyoedu.ng', '8038383111', 'IGBO-ELERIN', 'OYO', '384635'),
(4636, '384636', 'úÏ…W§', '384636@oyoedu.ng', '8030671055', 'IGBO-ELERIN', 'OYO', '384636'),
(4637, '384637', 'úÏ…W§', '384637@oyoedu.ng', '7039053615', 'IGBO-ELERIN', 'EKITI', '384637'),
(4638, '384638', 'úÏ…W§', '384638@oyoedu.ng', '8038534586', 'IGBO-ELERIN', 'OYO', '384638'),
(4639, '384639', 'úÏ…W§', '384639@oyoedu.ng', '8074483900', 'IGBO-ELERIN', 'OYO', '384639'),
(4640, '384640', 'úÏ…W§', '384640@oyoedu.ng', '8060724743', 'IGBO-ELERIN', 'OYO', '384640'),
(4641, '384641', 'úÏ…W§', '384641@oyoedu.ng', '8077923637', 'IGBO-ELERIN', 'OYO', '384641'),
(4642, '384642', 'úÏ…W§', '384642@oyoedu.ng', '8106095321', 'IGBO-ELERIN', 'OYO', '384642'),
(4643, '384643', 'úÏ…W§', '384643@oyoedu.ng', '7047346025', 'IGBO-ELERIN', 'OYO', '384643'),
(4644, '384644', 'úÏ…W§', '384644@oyoedu.ng', '8160517897', 'IGBO-ELERIN', 'OYO', '384644'),
(4645, '384645', 'úÏ…W§', '384645@oyoedu.ng', '8169345258', 'IGBO-ELERIN', 'OYO', '384645'),
(4646, '384646', 'úÏ…W§', '384646@oyoedu.ng', '8088059692', 'IGBO-ELERIN', 'OYO', '384646'),
(4647, '384647', 'úÏ…W§', '384647@oyoedu.ng', '8055900445', 'IGBO-ELERIN', 'OYO', '384647'),
(4648, '384648', 'úÏ…W§', '384648@oyoedu.ng', '8135739771', 'IGBO-ELERIN', 'OYO', '384648'),
(4649, '384649', 'úÏ…W§', '384649@oyoedu.ng', '7049567998', 'IGBO-ELERIN', 'OYO', '384649'),
(4650, '384650', 'úÏ…W§', '384650@oyoedu.ng', '', 'IGBO-ELERIN', 'OYO', '384650'),
(4651, '384651', 'úÏ…W§', '384651@oyoedu.ng', '7038573802', 'IGBO-ELERIN', 'OYO', '384651'),
(4652, '384652', 'úÏ…W§', '384652@oyoedu.ng', '7059395982', 'IGBO-ELERIN', 'OYO', '384652'),
(4653, '384653', 'úÏ…W§', '384653@oyoedu.ng', '8066301563', 'IGBO-ELERIN', 'OYO', '384653'),
(4654, '384654', 'úÏ…W§', '384654@oyoedu.ng', '8033656285', 'IGBO-ELERIN', 'OYO', '384654'),
(4655, '384655', 'úÏ…W§', '384655@oyoedu.ng', '8034987510', 'IGBO-ELERIN', 'OYO', '384655'),
(4656, '384656', 'úÏ…W§', '384656@oyoedu.ng', '8060887099', 'IGBO-ELERIN', 'OYO', '384656'),
(4657, '384657', 'úÏ…W§', '384657@oyoedu.ng', '8184123419', 'IGBO-ELERIN', 'OSUN', '384657'),
(4658, '384658', 'úÏ…W§', '384658@oyoedu.ng', '', 'IGBO-ELERIN', 'OSUN ', '384658'),
(4659, '384659', 'úÏ…W§', '384659@oyoedu.ng', '8052429898', 'IGBO-ELERIN', 'OYO', '384659'),
(4660, '384660', 'úÏ…W§', '384660@oyoedu.ng', '8163055412', 'IGBO-ELERIN', 'OYO', '384660'),
(4661, '384661', 'úÏ…W§', '384661@oyoedu.ng', '8063243564', 'IGBO-ELERIN', 'DELTA', '384661'),
(4662, '384662', 'úÏ…W§', '384662@oyoedu.ng', '8136768276', 'IGBO-ELERIN', 'CROSS RIVER', '384662'),
(4663, '384663', 'úÏ…W§', '384663@oyoedu.ng', '', 'OKE ADO BAPT. COMP. COLLEGE', 'OSUN', '384663'),
(4664, '384664', 'úÏ…W§', '384664@oyoedu.ng', '8062202201', 'FORTUNATE COLLEGE  ', 'OYO', '384664'),
(4665, '384665', 'úÏ…W§', '384665@oyoedu.ng', '9039395007', 'IGBO-ELERIN', 'OYO', '384665'),
(4666, '384666', 'úÏ…W§', '384666@oyoedu.ng', '8056971286', 'EXCELLERS COMPREHENSIVE COLLEGE', 'OYO', '384666'),
(4667, '384667', 'úÏ…W§', '384667@oyoedu.ng', '8038513681', 'EXCELLERS COMPREHENSIVE COLLEGE', 'OYO', '384667'),
(4668, '384668', 'úÏ…W§', '384668@oyoedu.ng', '8075418153', 'EXCELLERS COMPREHENSIVE COLLEGE', 'OSUN', '384668'),
(4669, '384669', 'úÏ…W§', '384669@oyoedu.ng', '8055331840', 'IGBO-ELERIN', 'OYO ', '384669'),
(4670, '384670', 'úÏ…W§', '384670@oyoedu.ng', '8141873906', 'IGBO-ELERIN', 'ONDO ', '384670'),
(4671, '384671', 'úÏ…W§', '384671@oyoedu.ng', '8060660664', 'IGBO-ELERIN', 'ONDO ', '384671'),
(4672, '384672', 'úÏ…W§', '384672@oyoedu.ng', '8060998049', 'IGBO-ELERIN', 'OSUN ', '384672'),
(4673, '384673', 'úÏ…W§', '384673@oyoedu.ng', '8112121241', 'IGBO-ELERIN', 'OYO ', '384673'),
(4674, '384674', 'úÏ…W§', '384674@oyoedu.ng', '8038528315', 'IGBO-ELERIN', 'OYO', '384674'),
(4675, '384675', 'úÏ…W§', '384675@oyoedu.ng', '', 'IGBO-ELERIN', 'OYO', '384675'),
(4676, '384676', 'úÏ…W§', '384676@oyoedu.ng', '8122344257', 'IGBO-ELERIN', 'OYO ', '384676'),
(4677, '384677', 'úÏ…W§', '384677@oyoedu.ng', '8038513681', 'EXCELLERS COMPREHENSIVE COLLEGE', 'KWARA', '384677'),
(4678, '384678', 'úÏ…W§', '384678@oyoedu.ng', '', '', 'OSUN ', '384678'),
(4679, '384679', 'úÏ…W§', '384679@oyoedu.ng', '', '', 'OSUN ', '384679'),
(4680, '384680', 'úÏ…W§', '384680@oyoedu.ng', '', 'COMM. SEC. SCH. AGUGU', 'OYO ', '384680'),
(4681, '384681', 'úÏ…W§', '384681@oyoedu.ng', '8112121241', 'IGBO-ELERIN', 'OYO ', '384681'),
(4682, '384682', 'úÏ…W§', '384682@oyoedu.ng', '8131929059', 'IGBO-ELERIN', 'ONDO ', '384682'),
(4683, '384683', 'úÏ…W§', '384683@oyoedu.ng', '8024995445', 'BEACON TOTAL COLLEGE', 'OYO ', '384683'),
(4684, '384684', 'úÏ…W§', '384684@oyoedu.ng', '9077140611', 'LALUPON COMM. GRAMMAR SCH. ', 'OYO ', '384684'),
(4685, '384685', 'úÏ…W§', '384685@oyoedu.ng', '9077140611', 'LALUPON COMM. GRAMMAR SCH. ', 'OYO ', '384685'),
(4686, '384686', 'úÏ…W§', '384686@oyoedu.ng', '8072657868', 'ST. ANNES MOLETE', 'OYO ', '384686'),
(4687, '384687', 'úÏ…W§', '384687@oyoedu.ng', '8062870523', 'BOLFAITH INTEGRA GENIUS SCHOOL ', 'OYO ', '384687'),
(4688, '384688', 'úÏ…W§', '384688@oyoedu.ng', '8033058342', 'IGBO-ELERIN', 'OYO ', '384688'),
(4689, '384689', 'úÏ…W§', '384689@oyoedu.ng', '8137588365', 'IGBO-ELERIN', 'OYO ', '384689'),
(4690, '384690', 'úÏ…W§', '384690@oyoedu.ng', '8037176454', '', 'OYO ', '384690'),
(4691, '384691', 'úÏ…W§', '384691@oyoedu.ng', '8027069241', 'IKRAH HIGH SCH. ', 'OYO ', '384691'),
(4692, '384692', 'úÏ…W§', '384692@oyoedu.ng', '8073664600', 'AMAZING GRACE', 'OYO ', '384692'),
(4693, '384693', 'úÏ…W§', '384693@oyoedu.ng', '8073664600', 'AMAZING GRACE', 'OYO ', '384693'),
(4694, '384694', 'úÏ…W§', '384694@oyoedu.ng', '8149488539', 'FAITH FOUNDATION COLLEGE', 'OYO ', '384694'),
(4695, '384695', 'úÏ…W§', '384695@oyoedu.ng', '8070496847', 'DIVINE GROUP OF SCHOOL ', 'OYO ', '384695'),
(4696, '384696', 'úÏ…W§', '384696@oyoedu.ng', '8035366873', 'IGBO-ELERIN', 'OSUN', '384696'),
(4697, '384697', 'úÏ…W§', '384697@oyoedu.ng', '8126424015', 'IGBO-ELERIN', 'OYO ', '384697'),
(4698, '384698', 'úÏ…W§', '384698@oyoedu.ng', '9131847386', 'IGBO-ELERIN', 'OYO ', '384698'),
(4699, '384699', 'úÏ…W§', '384699@oyoedu.ng', '', '', 'OYO ', '384699'),
(4700, '384700', 'úÏ…W§', '384700@oyoedu.ng', '8062207032', '', 'OYO ', '384700'),
(4701, '384701', 'úÏ…W§', '384701@oyoedu.ng', '8057142028', 'UNIQUE COLLEGE', 'OYO ', '384701'),
(4702, '384702', 'úÏ…W§', '384702@oyoedu.ng', '8057142028', 'GUARVERD COLL.', 'OLUYOLE ', '384702'),
(4703, '384703', 'úÏ…W§', '384703@oyoedu.ng', '8057142028', 'ST. ANNES COLL. ', 'OLUYOLE ', '384703'),
(4704, '384704', 'úÏ…W§', '384704@oyoedu.ng', '8057142028', 'ADENDUM COLL. ', 'OYO OLUYOLE ', '384704'),
(4705, '384705', 'úÏ…W§', '384705@oyoedu.ng', '8036334154', 'GREATER GLORY COLL. ', 'OYO', '384705'),
(4706, '384706', 'úÏ…W§', '384706@oyoedu.ng', '8036334154', 'GREATER GLORY COLL. ', 'OYO', '384706'),
(4707, '384707', 'úÏ…W§', '384707@oyoedu.ng', '8054519561', 'FULFILLED SHINNING STAR ', 'OYO', '384707'),
(4708, '384708', 'úÏ…W§', '384708@oyoedu.ng', '8054519561', 'FULFILLED SHINNING STAR ', 'OYO', '384708'),
(4709, '384709', 'úÏ…W§', '384709@oyoedu.ng', '8055442468', 'IGBO-ELERIN', 'OYO', '384709'),
(4710, '384710', 'úÏ…W§', '384710@oyoedu.ng', '9028802355', 'IGBO-ELERIN', 'OYO', '384710'),
(4711, '384711', 'úÏ…W§', '384711@oyoedu.ng', '7030425403', 'IGBO-ELERIN', 'OYO', '384711'),
(4712, '384712', 'úÏ…W§', '384712@oyoedu.ng', '8060887099', 'IGBO-ELERIN', 'OYO', '384712'),
(4713, '384713', 'úÏ…W§', '384713@oyoedu.ng', '8057473265', 'DAARUL-HIMAH COLL. ', 'OYO', '384713'),
(4714, '384714', 'úÏ…W§', '384714@oyoedu.ng', '', 'AL-HALIM UNIQUE GROUP ', '', '384714'),
(4715, '384715', 'úÏ…W§', '384715@oyoedu.ng', '8109112573', 'IGBO-ELERIN', 'OYO', '384715'),
(4716, '384716', 'úÏ…W§', '384716@oyoedu.ng', '7031359561', 'IGBO-ELERIN', 'OYO', '384716'),
(4717, '384717', 'úÏ…W§', '384717@oyoedu.ng', '8074967010', 'IGBO-ELERIN', 'OYO', '384717'),
(4718, '384718', 'úÏ…W§', '384718@oyoedu.ng', '7080371185', 'IGBO-ELERIN', 'OYO', '384718'),
(4719, '384719', 'úÏ…W§', '384719@oyoedu.ng', '8025118039', 'IGBO-ELERIN', 'OYO', '384719'),
(4720, '384720', 'úÏ…W§', '384720@oyoedu.ng', '7035407274', 'IGBO-ELERIN', 'OYO', '384720'),
(4721, '384721', 'úÏ…W§', '384721@oyoedu.ng', '9032425942', 'IGBO-ELERIN', 'OYO', '384721'),
(4722, '384722', 'úÏ…W§', '384722@oyoedu.ng', '7068263570', 'IGBO-ELERIN', 'OYO', '384722'),
(4723, '384723', 'úÏ…W§', '384723@oyoedu.ng', '8051539352', 'IGBO-ELERIN', 'OYO', '384723'),
(4724, '384724', 'úÏ…W§', '384724@oyoedu.ng', '8033277398', 'IGBO-ELERIN', 'OYO', '384724'),
(4725, '384725', 'úÏ…W§', '384725@oyoedu.ng', '7034336666', 'COMM. SEC. SCH. ADEGBAYI', 'OYO', '384725'),
(4726, '384726', 'úÏ…W§', '384726@oyoedu.ng', '7034336666', 'ICAN ACADEMY OLUWO', 'OSUN', '384726'),
(4727, '384727', 'úÏ…W§', '384727@oyoedu.ng', '8051155117', 'LIKE-END MODEL SCH. ', 'OSUN', '384727'),
(4728, '384728', 'úÏ…W§', '384728@oyoedu.ng', '7058475204', '', 'OYO', '384728'),
(4729, '384729', 'úÏ…W§', '384729@oyoedu.ng', '8038268315', 'COMM. HIGH SCH. MELE', 'OYO', '384729'),
(4730, '384730', 'úÏ…W§', '384730@oyoedu.ng', '8140890004', 'MOTHERS JOY COL. BODIJA', 'OYO', '384730'),
(4731, '384731', 'úÏ…W§', '384731@oyoedu.ng', '8140890004', 'DE AYO INT. COLLEGE ', 'OYO', '384731'),
(4732, '384732', 'úÏ…W§', '384732@oyoedu.ng', '8072799424', 'EDUCATINAL LEGACY COLLEGE. ', 'OYO', '384732'),
(4733, '384733', 'úÏ…W§', '384733@oyoedu.ng', '8035794763', 'BE LEADER GROUP OF SCH. ', 'OYO', '384733'),
(4734, '384734', 'úÏ…W§', '384734@oyoedu.ng', '8034473484', 'ACHIEVER SCH. ', 'OYO', '384734'),
(4735, '384735', 'úÏ…W§', '384735@oyoedu.ng', '7030280070', 'UPDHS IWARE ', 'OYO', '384735'),
(4736, '384736', 'úÏ…W§', '384736@oyoedu.ng', '7040942281', 'SAM. ADEGBITE ', 'OYO', '384736'),
(4737, '384737', 'úÏ…W§', '384737@oyoedu.ng', '8060051921', 'MERIT COMP. HIGH SCH. ', 'OYO', '384737'),
(4738, '384738', 'úÏ…W§', '384738@oyoedu.ng', '8028799443', 'REGINA JAMES ACADEMY IB. ', 'OYO', '384738'),
(4739, '384739', 'úÏ…W§', '384739@oyoedu.ng', '8028799443', 'REGINA JAMES ACADEMY IB. ', 'OYO', '384739'),
(4740, '384740', 'úÏ…W§', '384740@oyoedu.ng', '8034204916', 'ST. RAPAACE IKIRE OSUN. ', 'OSUN', '384740'),
(4741, '314741', 'úÏ…W§', '314741@oyoedu.ng', '', 'EPHRAHIM COMPREHENSIVE COLLEGE, LIBERTY ', '', '314741'),
(4742, '374742', 'úÏ…W§', '374742@oyoedu.ng', '', '', '', '374742'),
(4743, '304743', 'úÏ…W§', '304743@oyoedu.ng', '', '', '', '304743'),
(4744, '304744', 'úÏ…W§', '304744@oyoedu.ng', '', '', '', '304744'),
(4745, '304745', 'úÏ…W§', '304745@oyoedu.ng', '', '', '', '304745'),
(4746, '304746', 'úÏ…W§', '304746@oyoedu.ng', '', '', '', '304746'),
(4747, '304747', 'úÏ…W§', '304747@oyoedu.ng', '', '', '', '304747'),
(4748, '304748', 'úÏ…W§', '304748@oyoedu.ng', '', '', '', '304748'),
(4749, '304749', 'úÏ…W§', '304749@oyoedu.ng', '', '', '', '304749'),
(4750, '304750', 'úÏ…W§', '304750@oyoedu.ng', '', '', '', '304750'),
(4751, '304751', 'úÏ…W§', '304751@oyoedu.ng', '', '', '', '304751'),
(4752, '304752', 'úÏ…W§', '304752@oyoedu.ng', '', '', '', '304752'),
(4753, '304753', 'úÏ…W§', '304753@oyoedu.ng', '', '', '', '304753'),
(4754, '304754', 'úÏ…W§', '304754@oyoedu.ng', '', '', '', '304754'),
(4755, '304755', 'úÏ…W§', '304755@oyoedu.ng', '', '', '', '304755'),
(4756, '304756', 'úÏ…W§', '304756@oyoedu.ng', '', '', '', '304756'),
(4757, '304757', 'úÏ…W§', '304757@oyoedu.ng', '', '', '', '304757'),
(4758, '304758', 'úÏ…W§', '304758@oyoedu.ng', '', '', '', '304758'),
(4759, '304759', 'úÏ…W§', '304759@oyoedu.ng', '', '', '', '304759'),
(4760, '304760', 'úÏ…W§', '304760@oyoedu.ng', '', '', '', '304760'),
(4761, '304761', 'úÏ…W§', '304761@oyoedu.ng', '', '', '', '304761'),
(4762, '304762', 'úÏ…W§', '304762@oyoedu.ng', '', '', '', '304762'),
(4763, '304763', 'úÏ…W§', '304763@oyoedu.ng', '', '', '', '304763'),
(4764, '304764', 'úÏ…W§', '304764@oyoedu.ng', '', '', '', '304764'),
(4765, '304765', 'úÏ…W§', '304765@oyoedu.ng', '', '', '', '304765'),
(4766, '304766', 'úÏ…W§', '304766@oyoedu.ng', '', '', '', '304766'),
(4767, '304767', 'úÏ…W§', '304767@oyoedu.ng', '', '', '', '304767'),
(4768, '304768', 'úÏ…W§', '304768@oyoedu.ng', '', '', '', '304768'),
(4769, '304769', 'úÏ…W§', '304769@oyoedu.ng', '', '', '', '304769'),
(4770, '304770', 'úÏ…W§', '304770@oyoedu.ng', '', '', '', '304770'),
(4771, '304771', 'úÏ…W§', '304771@oyoedu.ng', '', '', '', '304771'),
(4772, '304772', 'úÏ…W§', '304772@oyoedu.ng', '', '', '', '304772'),
(4773, '304773', 'úÏ…W§', '304773@oyoedu.ng', '', '', '', '304773'),
(4774, '304774', 'úÏ…W§', '304774@oyoedu.ng', '', '', '', '304774'),
(4775, '304775', 'úÏ…W§', '304775@oyoedu.ng', '', '', '', '304775'),
(4776, '304776', 'úÏ…W§', '304776@oyoedu.ng', '', '', '', '304776'),
(4777, '304777', 'úÏ…W§', '304777@oyoedu.ng', '', '', '', '304777'),
(4778, '304778', 'úÏ…W§', '304778@oyoedu.ng', '', '', '', '304778'),
(4779, '304779', 'úÏ…W§', '304779@oyoedu.ng', '', '', '', '304779'),
(4780, '304780', 'úÏ…W§', '304780@oyoedu.ng', '', '', '', '304780'),
(4781, '304781', 'úÏ…W§', '304781@oyoedu.ng', '', '', '', '304781'),
(4782, '304782', 'úÏ…W§', '304782@oyoedu.ng', '', '', '', '304782'),
(4783, '304783', 'úÏ…W§', '304783@oyoedu.ng', '', '', '', '304783'),
(4784, '304784', 'úÏ…W§', '304784@oyoedu.ng', '', '', '', '304784'),
(4785, '304785', 'úÏ…W§', '304785@oyoedu.ng', '', '', '', '304785'),
(4786, '304786', 'úÏ…W§', '304786@oyoedu.ng', '', '', '', '304786'),
(4787, '304787', 'úÏ…W§', '304787@oyoedu.ng', '', '', '', '304787'),
(4788, '304788', 'úÏ…W§', '304788@oyoedu.ng', '', '', '', '304788'),
(4789, '304789', 'úÏ…W§', '304789@oyoedu.ng', '', '', '', '304789'),
(4790, '304790', 'úÏ…W§', '304790@oyoedu.ng', '', '', '', '304790'),
(4791, '304791', 'úÏ…W§', '304791@oyoedu.ng', '', '', '', '304791'),
(4792, '304792', 'úÏ…W§', '304792@oyoedu.ng', '', '', '', '304792'),
(4793, '304793', 'úÏ…W§', '304793@oyoedu.ng', '', '', '', '304793'),
(4794, '304794', 'úÏ…W§', '304794@oyoedu.ng', '', '', '', '304794'),
(4795, '304795', 'úÏ…W§', '304795@oyoedu.ng', '', '', '', '304795'),
(4796, '304796', 'úÏ…W§', '304796@oyoedu.ng', '', '', '', '304796'),
(4797, '304797', 'úÏ…W§', '304797@oyoedu.ng', '', '', '', '304797'),
(4798, '304798', 'úÏ…W§', '304798@oyoedu.ng', '', '', '', '304798'),
(4799, '304799', 'úÏ…W§', '304799@oyoedu.ng', '', '', '', '304799'),
(4800, '304800', 'úÏ…W§', '304800@oyoedu.ng', '', '', '', '304800'),
(4801, '304801', 'úÏ…W§', '304801@oyoedu.ng', '', '', '', '304801'),
(4802, '304802', 'úÏ…W§', '304802@oyoedu.ng', '', '', '', '304802'),
(4803, '304803', 'úÏ…W§', '304803@oyoedu.ng', '', '', '', '304803'),
(4804, '304804', 'úÏ…W§', '304804@oyoedu.ng', '', '', '', '304804'),
(4805, '304805', 'úÏ…W§', '304805@oyoedu.ng', '', '', '', '304805'),
(4806, '304806', 'úÏ…W§', '304806@oyoedu.ng', '', '', '', '304806'),
(4807, '304807', 'úÏ…W§', '304807@oyoedu.ng', '', '', '', '304807'),
(4808, '304808', 'úÏ…W§', '304808@oyoedu.ng', '', '', '', '304808'),
(4809, '304809', 'úÏ…W§', '304809@oyoedu.ng', '', '', '', '304809'),
(4810, '304810', 'úÏ…W§', '304810@oyoedu.ng', '', '', '', '304810'),
(4811, '304811', 'úÏ…W§', '304811@oyoedu.ng', '', '', '', '304811'),
(4812, '304812', 'úÏ…W§', '304812@oyoedu.ng', '', '', '', '304812'),
(4813, '304813', 'úÏ…W§', '304813@oyoedu.ng', '', '', '', '304813'),
(4814, '304814', 'úÏ…W§', '304814@oyoedu.ng', '', '', '', '304814'),
(4815, '304815', 'úÏ…W§', '304815@oyoedu.ng', '', '', '', '304815'),
(4816, '304816', 'úÏ…W§', '304816@oyoedu.ng', '', '', '', '304816'),
(4817, '304817', 'úÏ…W§', '304817@oyoedu.ng', '', '', '', '304817'),
(4818, '304818', 'úÏ…W§', '304818@oyoedu.ng', '', '', '', '304818'),
(4819, '304819', 'úÏ…W§', '304819@oyoedu.ng', '', '', '', '304819'),
(4820, '304820', 'úÏ…W§', '304820@oyoedu.ng', '', '', '', '304820'),
(4821, '304821', 'úÏ…W§', '304821@oyoedu.ng', '', '', '', '304821'),
(4822, '304822', 'úÏ…W§', '304822@oyoedu.ng', '', '', '', '304822'),
(4823, '304823', 'úÏ…W§', '304823@oyoedu.ng', '', '', '', '304823'),
(4824, '304824', 'úÏ…W§', '304824@oyoedu.ng', '', '', '', '304824'),
(4825, '304825', 'úÏ…W§', '304825@oyoedu.ng', '', '', '', '304825'),
(4826, '304826', 'úÏ…W§', '304826@oyoedu.ng', '', '', '', '304826'),
(4827, '304827', 'úÏ…W§', '304827@oyoedu.ng', '', '', '', '304827'),
(4828, '304828', 'úÏ…W§', '304828@oyoedu.ng', '', '', '', '304828'),
(4829, '304829', 'úÏ…W§', '304829@oyoedu.ng', '', '', '', '304829'),
(4830, '304830', 'úÏ…W§', '304830@oyoedu.ng', '', '', '', '304830'),
(4831, '304831', 'úÏ…W§', '304831@oyoedu.ng', '', '', '', '304831'),
(4832, '304832', 'úÏ…W§', '304832@oyoedu.ng', '', '', '', '304832'),
(4833, '304833', 'úÏ…W§', '304833@oyoedu.ng', '', '', '', '304833'),
(4834, '304834', 'úÏ…W§', '304834@oyoedu.ng', '', '', '', '304834'),
(4835, '304835', 'úÏ…W§', '304835@oyoedu.ng', '', '', '', '304835'),
(4836, '304836', 'úÏ…W§', '304836@oyoedu.ng', '', '', '', '304836'),
(4837, '304837', 'úÏ…W§', '304837@oyoedu.ng', '', '', '', '304837'),
(4838, '304838', 'úÏ…W§', '304838@oyoedu.ng', '', '', '', '304838'),
(4839, '304839', 'úÏ…W§', '304839@oyoedu.ng', '', '', '', '304839'),
(4840, '304840', 'úÏ…W§', '304840@oyoedu.ng', '', '', '', '304840'),
(4841, '304841', 'úÏ…W§', '304841@oyoedu.ng', '', '', '', '304841'),
(4842, '304842', 'úÏ…W§', '304842@oyoedu.ng', '', '', '', '304842'),
(4843, '274843', 'úÏ…W§', '274843@oyoedu.ng', '80', 'OYO', 'OYO', '274843'),
(4844, '214844', 'úÏ…W§', '214844@oyoedu.ng', '80', 'OYO', 'OYO', '214844'),
(4845, '314845', 'úÏ…W§', '314845@oyoedu.ng', '8079038089', 'OYO', 'OYO', '314845'),
(4846, '314846', 'úÏ…W§', '314846@oyoedu.ng', '8033564701', 'OYO', 'OYO', '314846'),
(4847, '644847', 'úÏ…W§', '644847@oyoedu.ng', '8027818680', 'OYO', 'OYO', '644847'),
(4848, '644848', 'úÏ…W§', '644848@oyoedu.ng', '8103797188', 'OYO', 'OYO', '644848'),
(4849, '644849', 'úÏ…W§', '644849@oyoedu.ng', '7061157836', 'OYO', 'OYO', '644849'),
(4850, '644850', 'úÏ…W§', '644850@oyoedu.ng', '9024249247', 'OYO', 'OYO', '644850'),
(4851, '644851', 'úÏ…W§', '644851@oyoedu.ng', '8165553020', 'OYO', 'OYO', '644851'),
(4852, '644852', 'úÏ…W§', '644852@oyoedu.ng', '8148483584', 'OYO', 'OYO', '644852'),
(4853, '644853', 'úÏ…W§', '644853@oyoedu.ng', '8022312944', 'OYO', 'OYO', '644853'),
(4854, '644854', 'úÏ…W§', '644854@oyoedu.ng', '8025783526', 'OYO', 'OYO', '644854'),
(4855, '644855', 'úÏ…W§', '644855@oyoedu.ng', '8113076679', 'OYO', 'OYO', '644855'),
(4856, '644856', 'úÏ…W§', '644856@oyoedu.ng', '8027885202', 'OYO', 'OYO', '644856'),
(4857, '644857', 'úÏ…W§', '644857@oyoedu.ng', '8086702722', 'OYO', 'OYO', '644857'),
(4858, '644858', 'úÏ…W§', '644858@oyoedu.ng', '7051856585', 'OYO', 'OYO', '644858'),
(4859, '644859', 'úÏ…W§', '644859@oyoedu.ng', '9011630146', 'OYO', 'OYO', '644859'),
(4860, '644860', 'úÏ…W§', '644860@oyoedu.ng', '7047251130', 'OYO', 'OYO', '644860'),
(4861, '644861', 'úÏ…W§', '644861@oyoedu.ng', '80', 'OYO', 'OYO', '644861'),
(4862, '644862', 'úÏ…W§', '644862@oyoedu.ng', '8134683607', 'OYO', 'OYO', '644862'),
(4863, '644863', 'úÏ…W§', '644863@oyoedu.ng', '9030138051', 'OYO', 'OYO', '644863'),
(4864, '644864', 'úÏ…W§', '644864@oyoedu.ng', '8062491836', 'OYO', 'OYO', '644864'),
(4865, '644865', 'úÏ…W§', '644865@oyoedu.ng', '8074425992', 'OYO', 'OYO', '644865'),
(4866, '644866', 'úÏ…W§', '644866@oyoedu.ng', '7030491222', 'OYO', 'OYO', '644866'),
(9999, 'femie15', 'úÏ…W§', 'student@student.com', '08043542212', '12, Afe st', 'Jos', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stdid`),
  ADD UNIQUE KEY `stdname` (`stdname`),
  ADD UNIQUE KEY `emailid` (`emailid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
